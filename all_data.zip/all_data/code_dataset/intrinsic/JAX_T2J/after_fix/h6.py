## -----------------
Example_id = h6
## -----------------

## h6 - Set D Fixed Code
import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from jax import random


# Define the Language Model in JAX
class LanguageModel(nn.Module):
    vocab_size: int
    embed_size: int
    hidden_size: int
    num_layers: int

    def setup(self):
        # Use embedding layer, LSTM cell, and dense layer
        self.embedding = nn.Embed(self.vocab_size, self.embed_size)
        # Fixed: Added features parameter to LSTMCell, set to hidden_size
        self.lstm = nn.LSTMCell(features=self.hidden_size)
        self.fc = nn.Dense(self.vocab_size)

    def __call__(self, x):
        # Initialize LSTM hidden and cell states
        embedded = self.embedding(x)
        batch_size = x.shape[0]
        hidden = jnp.zeros((batch_size, self.hidden_size))
        cell = jnp.zeros((batch_size, self.hidden_size))

        def lstm_step(carry, x_t):
            hidden, cell = carry
            (hidden, cell), _ = self.lstm((hidden, cell), x_t)
            return (hidden, cell), hidden

        # Process sequence with scan
        _, hidden_states = jax.lax.scan(lstm_step, (hidden, cell),
                                        embedded.transpose(1, 0, 2))  # (seq_length, batch_size, hidden_size)
        hidden_states = hidden_states.transpose(1, 0, 2)  # (batch_size, seq_length, hidden_size)

        # Use final hidden state for output
        output = self.fc(hidden_states[:, -1, :])  # (batch_size, vocab_size)
        return output


# Example for initializing parameters
key = random.PRNGKey(0)
vocab_size = 50
embed_size = 64
hidden_size = 128
num_layers = 2
seq_length = 10
batch_size = 32
model = LanguageModel(vocab_size=vocab_size, embed_size=embed_size, hidden_size=hidden_size, num_layers=num_layers)
params = model.init(key,
                    jnp.ones((batch_size, seq_length), dtype=jnp.int32))  # Random input shape (batch_size, seq_length)

# Create synthetic data
X_train = jnp.array(random.randint(key, (batch_size, seq_length), 0, vocab_size))
y_train = jnp.array(random.randint(key, (batch_size,), 0, vocab_size))


# Loss function
def loss_fn(params, model, inputs, targets):
    logits = model.apply({'params': params}, inputs)
    # Fixed: Convert integer targets to one-hot for cross-entropy loss
    targets_one_hot = jax.nn.one_hot(targets, vocab_size)
    return optax.softmax_cross_entropy(logits, targets_one_hot).mean()


# Optimizer setup (Adam)
optimizer = optax.adam(learning_rate=0.001)


# Update function
@jax.jit(static_argnums=(1, 4))
def update(params, model, inputs, targets, optimizer, optimizer_state):
    loss, grads = jax.value_and_grad(loss_fn)(params, model, inputs, targets)
    updates, optimizer_state = optimizer.update(grads, optimizer_state)
    new_params = optax.apply_updates(params, updates)
    return new_params, loss, optimizer_state


# Training loop
def train(model, params, X_train, y_train, optimizer, num_epochs=5):
    optimizer_state = optimizer.init(params)
    for epoch in range(num_epochs):
        params, loss, optimizer_state = update(params, model, X_train, y_train, optimizer, optimizer_state)
        print(f"Epoch {epoch + 1}/{num_epochs}: Loss: {loss}")
    return params


# Train the model
params = train(model, params, X_train, y_train, optimizer, num_epochs=5)

# Testing on new data
# Fixed: Ensure X_test matches training input shape (batch_size, seq_length)
X_test = jnp.array(random.randint(key, (2, seq_length), 0, vocab_size))  # Shape: (2, 10)
predictions = model.apply({'params': params}, X_test)
print(f"Predictions for {X_test.tolist()}: {predictions.tolist()}")
