## -----------------
Example_id = m1
## -----------------

import jax
import jax.numpy as jnp
from jax import random
import optax
import matplotlib.pyplot as plt


# Generate synthetic data
def create_in_out_sequences(data, seq_length):
    in_seq = []
    out_seq = []
    for i in range(len(data) - seq_length):
        in_seq.append(data[i:i + seq_length])
        out_seq.append(data[i + seq_length])
    return jnp.stack(in_seq), jnp.stack(out_seq)


def generate_data(num_samples=100):
    key = random.PRNGKey(0)
    X = jnp.linspace(0, 4 * 3.14159, num_samples).reshape(-1, 1)
    y = jnp.sin(X)
    return X, y


X_seq, y_seq = create_in_out_sequences(generate_data()[1], 10)


# Define a simple model using JAX
class LSTMModel:
    def __init__(self, input_dim, hidden_units):
        self.hidden_units = hidden_units
        self.Wxi = jax.random.normal(random.PRNGKey(0), (input_dim, hidden_units))
        self.Whi = jax.random.normal(random.PRNGKey(1), (hidden_units, hidden_units))
        self.bi = jnp.zeros(hidden_units)
        self.input_dim = input_dim
        self.hidden_units = hidden_units

        # Initialize other weights similarly

    def init_params(self):
        key = random.PRNGKey(0)
        keys = random.split(key, 8)  # For all weights and biases
        return {
            'Wxi': random.normal(keys[0], (self.input_dim, self.hidden_units)),
            'Whi': random.normal(keys[1], (self.hidden_units, self.hidden_units)),
            'bi': jnp.zeros(self.hidden_units),
            'Wxf': random.normal(keys[2], (self.input_dim, self.hidden_units)),
            'Whf': random.normal(keys[3], (self.hidden_units, self.hidden_units)),
            'bf': jnp.zeros(self.hidden_units),
            'Wxo': random.normal(keys[4], (self.input_dim, self.hidden_units)),
            'Who': random.normal(keys[5], (self.hidden_units, self.hidden_units)),
            'bo': jnp.zeros(self.hidden_units),
            'Wxc': random.normal(keys[6], (self.input_dim, self.hidden_units)),
            'Whc': random.normal(keys[7], (self.hidden_units, self.hidden_units)),
            'bc': jnp.zeros(self.hidden_units),
        }

    def forward(self, inputs):
        batch_size, seq_len, _ = inputs.shape
        H = jnp.zeros((batch_size, self.hidden_units))
        C = jnp.zeros((batch_size, self.hidden_units))

        all_hidden_states = []
        for t in range(seq_len):
            X_t = inputs[:, t, :]
            I_t = jax.nn.sigmoid(jnp.dot(X_t, self.Wxi) + jnp.dot(H, self.Whi) + self.bi)
            # Add other gate computations (F_t, O_t, C_tilde)
            F_t = jax.nn.sigmoid(jnp.dot(X_t, params['Wxf']) + jnp.dot(H, params['Whf']) + params['bf'])
            # Output gate
            O_t = jax.nn.sigmoid(jnp.dot(X_t, params['Wxo']) + jnp.dot(H, params['Who']) + params['bo'])
            # Cell candidate
            C_tilde = jnp.tanh(jnp.dot(X_t, params['Wxc']) + jnp.dot(H, params['Whc']) + params['bc'])
            C = F_t * C + I_t * C_tilde
            H = O_t * jnp.tanh(C)
            all_hidden_states.append(H)

        return jnp.stack(all_hidden_states, axis=1)


# Define the LSTM model and other components in JAX
def loss_fn(params, inputs, targets):
    predictions = model.forward(inputs)
    return jnp.mean((predictions - targets) ** 2)


def train_step(params, X, y):
    grads = jax.grad(loss_fn)(params, X, y)
    new_params = {k: params[k] - 0.01 * grads[k] for k in params}
    return new_params

    # Training loop with output printing


def train_model(params, X, y, num_epochs=100):
    for epoch in range(num_epochs):
        params = train_step(params, X, y)
        loss = loss_fn(params, X, y)
        if epoch % 10 == 0:  # Print every 10 epochs
            print(f"Epoch {epoch}, Loss: {loss:.4f}")
    return params


# Initialize and train model
model = LSTMModel(1, 50)
params = model.init_params()

# Reshape input for LSTM (batch_size, seq_len, input_dim)
X_seq = X_seq.reshape(X_seq.shape[0], X_seq.shape[1], 1)
y_seq = y_seq.reshape(y_seq.shape[0], 1, 1)

# Train and print outputs
params = train_model(params, X_seq, y_seq)
