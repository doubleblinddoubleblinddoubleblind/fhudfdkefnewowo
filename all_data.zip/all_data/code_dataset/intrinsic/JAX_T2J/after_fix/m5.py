## -----------------
Example_id = m5
## -----------------
import jax
import jax.numpy as jnp
from jax import grad, jit, random
import optax


# Generate synthetic sequential data
def generate_data(num_samples=100):
    X = jnp.linspace(0, 4 * 3.14159, num_samples).reshape(-1, 1)
    y = jnp.sin(X)
    return X, y


# Prepare data for RNN
def create_in_out_sequences(data, seq_length):
    in_seq = []
    out_seq = []
    for i in range(len(data) - seq_length):
        in_seq.append(data[i:i + seq_length])
        out_seq.append(data[i + seq_length])
    return jnp.stack(in_seq), jnp.stack(out_seq)


X, y = generate_data()
sequence_length = 10
X_seq, y_seq = create_in_out_sequences(y, sequence_length)


# Fixed: Update rnn_model to accept params as a tuple
def rnn_model(params, x, hidden_state):
    """
    Process input sequence step-by-step, updating hidden state.
    params: tuple of (rnn_xh, rnn_hh, rnn_hy, rnn_bias)
    x: shape (batch_size, seq_length, input_dim)
    hidden_state: shape (hidden_dim,)
    """

    def step(carry, x_t):
        h = carry
        # Fixed: Access params as tuple indices instead of dictionary keys
        h = jnp.tanh(
            jnp.dot(h, params[1]) +  # Hidden-to-hidden (rnn_hh)
            jnp.dot(x_t, params[0]) +  # Input-to-hidden (rnn_xh)
            params[3]  # Bias (rnn_bias)
        )
        # Output: y_t = W_hy * h_t
        y = jnp.dot(h, params[2])  # Hidden-to-output (rnn_hy)
        return h, y

    # Correctly add batch dimension to hidden_state
    batch_size = x.shape[0]
    hidden_state = jnp.repeat(jnp.expand_dims(hidden_state, 0), batch_size,
                              axis=0)  # Shape (1, hidden_dim) -> (batch_size, hidden_dim)

    # Process sequence
    _, outputs = jax.lax.scan(step, hidden_state, x.transpose(1, 0, 2))  # (seq_length, batch_size, input_dim)
    return outputs.transpose(1, 0, 2)  # (batch_size, seq_length, output_dim)


# Fixed: Update loss_fn to pass params as tuple
def loss_fn(params, X, y, hidden_state):
    preds = rnn_model(params, X, hidden_state)
    return jnp.mean((preds - y) ** 2)


# Fixed: Update compute_gradient to pass params as tuple
@jit
def compute_gradient(params, X, y, hidden_state):
    return grad(loss_fn)(params, X, y, hidden_state)


# Fixed: Update train_step to handle params and grads as tuples
@jit
def train_step(params, X, y, hidden_state, learning_rate=0.001):
    grads = compute_gradient(params, X, y, hidden_state)
    # Fixed: Update params tuple with corresponding gradient tuple
    new_params = tuple(
        p - learning_rate * g for p, g in zip(params, grads)
    )
    return new_params


# Model initialization
def init_model(key, input_dim=1, hidden_dim=50, output_dim=1):
    keys = random.split(key, 4)
    # Fixed: Return params as a tuple to match rnn_model expectation
    params = (
        random.normal(keys[0], (input_dim, hidden_dim)),  # rnn_xh: Input to hidden
        random.normal(keys[1], (hidden_dim, hidden_dim)),  # rnn_hh: Hidden to hidden
        random.normal(keys[2], (hidden_dim, output_dim)),  # rnn_hy: Hidden to output
        random.normal(keys[3], (hidden_dim,))  # rnn_bias: Bias for hidden state
    )
    hidden_state = jnp.zeros((hidden_dim,))
    return params, hidden_state


# Training loop
def train_model(X, y, epochs=500, learning_rate=0.001):
    key = random.PRNGKey(42)
    params, hidden_state = init_model(key)

    for epoch in range(epochs):
        for sequences, labels in zip(X_seq, y_seq):
            sequences = sequences.reshape(1, sequence_length, 1)
            labels = labels.reshape(1, 1, 1)
            params = train_step(params, sequences, labels, hidden_state, learning_rate)

        loss = loss_fn(params, sequences, labels, hidden_state)
        print(f"Epoch [{epoch + 1}/{epochs}], Loss: {loss}")

    return params, hidden_state


# Testing on new data
X_test = jnp.linspace(4 * 3.14159, 5 * 3.14159, sequence_length).reshape(1, sequence_length, 1)

params, hidden_state = train_model(X, y)

# Predictions
predictions = rnn_model(params, X_test, hidden_state)
print(f"Predictions for new sequence: {predictions.tolist()}")
