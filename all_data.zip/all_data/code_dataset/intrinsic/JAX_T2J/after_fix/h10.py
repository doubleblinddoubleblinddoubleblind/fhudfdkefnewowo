## -----------------
Example_id = h10
## -----------------
import jax
import jax.numpy as jnp
import flax.linen as nn
from jax import grad, jit, random
import matplotlib.pyplot as plt
from PIL import Image
import numpy as np

# Define the CNN Model in Flax (Simplified version)
class CNNModel(nn.Module):
    @nn.compact
    def __call__(self, x, return_conv=False):
      # FIX: Ensure conv output is correctly captured and returned
        conv_out = nn.Conv(64, (3, 3), padding="SAME", name="Conv_0")(x)  # Shape: (1, 224, 224, 64)
        conv_out = nn.relu(conv_out)  # Apply ReLU to conv output
        if return_conv:
            return conv_out  # Return conv output for Grad-CAM
        x = nn.Dense(10)(conv_out)  # Shape: (1, 10)
        # END FIX
        return x
def loss_fn(params, model, X, y):
    # FIX: Use params["params"] instead of params
    preds = model.apply({'params': params["params"]}, X)  # Get predictions
    # END FIX
    return jnp.mean((preds - y) ** 2)  # Mean Squared Error Loss

# Grad-CAM implementation in JAX
def grad_cam(model, params, X, target_class):
    # Get the output of the model and the gradients w.r.t the last convolution layer
    def compute_loss(params, X, y):
        # FIX: Use params["params"] instead of params
        preds = model.apply({'params': params["params"]}, X)
        # END FIX
        return jnp.mean((preds - y) ** 2)

    # FIX: Compute gradients and extract Conv_0/kernel gradient
    grads = grad(compute_loss)(params, X, target_class)
    # Extract the gradient for the convolutional layer's kernel
    conv_grad = grads["params"]["Conv_0"]["kernel"]  # Shape: (3, 3, 3, 64)
    # Average over input channels and kernel size to get feature map importance
    feature_weights = jnp.mean(conv_grad, axis=(0, 1, 2))  # Shape: (64,)
    # FIX: Get the Conv_0 layer output explicitly
    # FIX: Ensure conv_output is the Conv_0 output and verify shapes
    conv_output = model.apply({'params': params["params"]}, X, return_conv=True)  # Shape: (1, 224, 224, 64)
    # Debug: Print shapes to verify
    print(f"conv_output shape: {conv_output.shape}, feature_weights shape: {feature_weights.shape}")
    # Compute weighted sum of feature maps
    cam = jnp.einsum('...ijk,k->...ij', conv_output, feature_weights)  # Shape: (1, 224, 224)
    # END FIX
# Generate synthetic data (for testing)
key = random.PRNGKey(0)
X = random.uniform(key, shape=(1, 224, 224, 3))  # Example input data (224x224 RGB image)
y = jnp.array([[1]])  # Example target (class label)

# Initialize the model and parameters
model = CNNModel()
params = model.init(key, X)

# FIX: Use params["params"] instead of params
output = model.apply({'params': params["params"]}, X)
# END FIX
predicted_class = output.argmax()

# Compute Grad-CAM for the predicted class
grads = grad_cam(model, params, X, y)

# Visualize the Grad-CAM output (simplified)
# FIX: Update heatmap computation for the CAM output
heatmap = jnp.mean(grads, axis=-1)  # Average over any remaining dimensions if needed
heatmap = jnp.maximum(heatmap, 0)  # ReLU to keep positive values
heatmap = heatmap / jnp.max(heatmap)  # Normalize the heatmap
# END FIX

# Overlay heatmap on the image
plt.imshow(X[0, :, :, :], alpha=0.7)  # Original image
# Fixed: Resize heatmap to match image dimensions
heatmap_resized = jnp.array(Image.fromarray(np.array(heatmap[0])).resize((224, 224)))
plt.imshow(heatmap, alpha=0.5, cmap='jet')  # Grad-CAM heatmap
plt.title(f"Predicted Class: {predicted_class}")
plt.axis('off')
plt.show()