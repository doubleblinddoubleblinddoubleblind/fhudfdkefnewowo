# -------------------------------
# Example ID = "h9"
# -------------------------------

# Mixed‑precision training in JAX
import jax
import jax.numpy as jnp
from jax import random, value_and_grad, jit
import optax
import numpy as np

# Model definition (single fully‑connected layer, like nn.Linear)

def init_params(key, in_dim=10, out_dim=1, dtype=jnp.float16):
    """Return a pytree with weights and bias in fp16."""
    k1, k2 = random.split(key)
    w = random.normal(k1, (in_dim, out_dim), dtype=dtype)
    b = jnp.zeros((out_dim,), dtype=dtype)
    return {"w": w, "b": b}

def forward(params, x):
    """fp16 matmul, result promoted to fp16, stays fp16."""
    x = x.astype(jnp.float16)
    y_hat = x @ params["w"] + params["b"]
    return y_hat

# Synthetic data and DataLoader helper

def make_dataset(n_samples=1000, in_dim=10, out_dim=1, batch_size=32, key=0):
    key = random.PRNGKey(key)
    X = random.normal(key, (n_samples, in_dim), dtype=jnp.float32)
    y = random.normal(key, (n_samples, out_dim), dtype=jnp.float32)

    # Convert to numpy for simple slicing in a Python loop
    X, y = np.array(X), np.array(y)

    def loader():
        idxs = np.random.permutation(len(X))
        for i in range(0, len(X), batch_size):
            batch_idx = idxs[i : i + batch_size]
            yield X[batch_idx], y[batch_idx]

    return loader

dataloader = make_dataset()


# Loss, mixed‑precision helpers, and GradScaler analogue
def mse(preds, targets):
    return jnp.mean((preds - targets) ** 2)

class GradScaler:
    """
    A minimal dynamic‑loss‑scaling utility akin to torch.cuda.amp.GradScaler.
    Keeps everything in float32 outside the forward pass.
    """
    def __init__(self,
                 init_scale=2.**15,
                 growth_factor=2.,
                 backoff_factor=0.5,
                 growth_interval=2000):
        self.scale = init_scale
        self.growth_factor = growth_factor
        self.backoff_factor = backoff_factor
        self.growth_interval = growth_interval
        self._skip = 0  # counts consecutive non‑overflow steps

    def unscale_and_check(self, grads):
        """Divide grads by scale and test for NaN/Inf overflow."""
        inv_scale = 1. / self.scale
        grads = jax.tree_map(lambda g: g * inv_scale, grads)

        def _has_inf_or_nan(x):
            return jnp.any(~jnp.isfinite(x))

        overflow = jax.tree_util.tree_reduce(
            lambda a, b: jnp.logical_or(a, _has_inf_or_nan(b)), grads, False
        )
        return grads, overflow

    def update(self, overflow):
        """Update scale according to overflow detection."""
        if overflow:
            self.scale = max(self.scale * self.backoff_factor, 1.)
            self._skip = 0
        else:
            self._skip += 1
            if self._skip % self.growth_interval == 0:
                self.scale *= self.growth_factor

# Optimizer (Adam) and training step

lr = 1e-3
optimizer = optax.adam(lr)
key = random.PRNGKey(42)
params = init_params(key)
opt_state = optimizer.init(params)
scaler = GradScaler()

@jit
def train_step(params, opt_state, x, y, scale):
    """
    A single mixed‑precision update step:
    - forward pass in fp16
    - loss scaled to fp32 * scale
    - gradients unscaled before the Adam update
    """
    def loss_fn(p, bx, by):
        preds = forward(p, bx)
        return mse(preds.astype(jnp.float32), by.astype(jnp.float32))

    scaled_loss_fn = lambda p: loss_fn(p, x, y) * scale
    loss_val, grads = value_and_grad(scaled_loss_fn)(params)
    return loss_val, grads

# Training loop
epochs = 5
for epoch in range(epochs):
    for xb, yb in dataloader():
        # Convert NumPy batches to jax arrays on device
        xb = jnp.asarray(xb)
        yb = jnp.asarray(yb)

        # Forward / backward with scaling
        loss_val, grads = train_step(params, opt_state, xb, yb, scaler.scale)

        # Unscale & check overflow
        grads, found_inf = scaler.unscale_and_check(grads)

        # If no overflow, update params
        if not found_inf:
            updates, opt_state = optimizer.update(grads, opt_state, params)
            params = optax.apply_updates(params, updates)

        # Adjust dynamic scale
        scaler.update(found_inf)

    print(f"Epoch {epoch+1}/{epochs}, Loss: {(loss_val / scaler.scale):.4f}")


# Inference (autocast fp16 forward, no grad)

key_pred = random.PRNGKey(2025)
X_test = random.normal(key_pred, (5, 10), dtype=jnp.float32)
predictions = forward(params, X_test).astype(jnp.float32)   # cast back for readability
print("Predictions:", np.array(predictions))
