# -------------------------------
# Example ID = "h6"
# -------------------------------

import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.core import freeze, unfreeze
from flax.training import train_state
import optax
import numpy as np
import os  # THIS IS WHERE THE FIX IS: Added import for os to handle absolute paths

def one_hot(labels, num_classes):
    return jnp.eye(num_classes, dtype=jnp.float32)[labels]

def cross_entropy_with_integer_labels(logits, labels):
    """Equivalent to nn.CrossEntropyLoss in PyTorch (averaged over batch)."""
    return optax.softmax_cross_entropy_with_integer_labels(logits, labels).mean()

class LanguageModel(nn.Module):
    vocab_size:  int          # ← dataclass fields
    embed_size:  int
    hidden_size: int
    num_layers:  int = 1
    @nn.compact
    def __call__(self, x, *, train: bool = True):
        emb = nn.Embed(self.vocab_size, self.embed_size)(x)        # (B,T,E)

        batch_size = x.shape[0] ## THIS IS FIX 1
        rng = jax.random.PRNGKey(0)
        key1, key2 = jax.random.split(rng)
        carry = (
            jax.random.normal(key1, (batch_size, self.hidden_size)),  # Hidden state
            jax.random.normal(key2, (batch_size, self.hidden_size))   # Cell state
        )
        # carry = nn.LSTMCell.initialize_carry(##END OF FIX 1
        #     jax.random.PRNGKey(0),
        #     (batch_size,), self.hidden_size
        # )
        lstm_cell = nn.scan(
            nn.LSTMCell,## THIS IS WHERE THE FIX IS
            variable_broadcast='params',
            split_rngs={'params': False},
            in_axes=1, out_axes=1, length=x.shape[1])(features=self.hidden_size, name='lstm') ## THIS IS WHERE THE FIX IS
        carry, lstm_out = lstm_cell(carry, emb)
        last_h = lstm_out[:, -1, :]
        logits = nn.Dense(self.vocab_size)(last_h)
        probs  = nn.softmax(logits)
        return logits, probs
# tiny weight quantiser
def quantize_params(params):
    """Post‑training symmetric int8 weight quantisation (per‑tensor)."""
    qparams = {}
    for k, v in params.items():
        if isinstance(v, dict):          # recurse into sub‑dicts
            qparams[k] = quantize_params(v)
        else:
            scale = jnp.max(jnp.abs(v)) / 127.  # symmetric int8
            qparams[k] = {
                'int8': jnp.round(v / scale).astype(jnp.int8),
                'scale': scale.astype(jnp.float32)
            }
    return qparams

def dequantize_params(qparams):
    params = {}
    for k, v in qparams.items():
        if isinstance(v, dict) and 'int8' not in v:
            params[k] = dequantize_params(v)
        else:
            params[k] = v['int8'].astype(jnp.float32) * v['scale']
    return params

seed = 42
rng = jax.random.PRNGKey(seed)

vocab_size  = 50
seq_length  = 10
batch_size  = 32
embed_size  = 64
hidden_size = 128
num_layers  = 2
epochs      = 5
lr          = 1e-3

# Synthetic data (match PyTorch’s manual_seed(42) outcome for repeatability)
np.random.seed(seed)
X_train = np.random.randint(0, vocab_size, (batch_size, seq_length))
y_train = np.random.randint(0, vocab_size, (batch_size,))

## THIS IS FIX 2
model = LanguageModel(
    vocab_size=vocab_size,
    embed_size=embed_size,
    hidden_size=hidden_size,
    num_layers=num_layers,
)

def create_train_state(rng):
    params = model.init(rng, jnp.ones((1, seq_length), dtype=jnp.int32))[ 'params']
    optimiser = optax.adam(lr)
    return train_state.TrainState.create(apply_fn=model.apply,
                                         params=params,
                                         tx=optimiser)

state = create_train_state(rng)

@jax.jit
def train_step(state, batch_x, batch_y):
    def loss_fn(params):
        logits, _ = state.apply_fn({'params': params},
                                   batch_x, train=True)
        loss = cross_entropy_with_integer_labels(logits, batch_y)
        return loss
    grad_fn = jax.value_and_grad(loss_fn)
    loss, grads = grad_fn(state.params)
    new_state  = state.apply_gradients(grads=grads)
    return new_state, loss

training loop --
for epoch in range(epochs):
    state, loss = train_step(state,
                             jnp.array(X_train, dtype=jnp.int32),
                             jnp.array(y_train, dtype=jnp.int32))
    print(f"Epoch [{epoch+1}/{epochs}] - Loss: {loss.item():.4f}")
“dynamic” quantisation --
quantised_params = quantize_params(state.params)
flax.serialization:
import orbax.checkpoint as ocp         # optional, but very handy

checkpointer = ocp.PyTreeCheckpointer() ## THIS IS WHERE THE FIX IS
save_path = os.path.abspath("quantised_language_model")
# save_path = "quantised_language_model"
# To reload later:
restored_qparams = checkpointer.restore(save_path)      # dict with int8 + scale
restored_params  = freeze(dequantize_params(restored_qparams))
inference / test ----
model_apply = jax.jit(model.apply)

test_input = np.random.randint(0, vocab_size, (1, seq_length))
_, probs = model_apply({'params': restored_params},
                       jnp.array(test_input, dtype=jnp.int32),
                       train=False)

prediction = int(jnp.argmax(probs, axis=1)[0])
print(f"Prediction for input {test_input.tolist()}: {prediction}")
