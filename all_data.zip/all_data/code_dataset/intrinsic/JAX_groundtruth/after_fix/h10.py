# -------------------------------
# Example ID = "h10"
# -------------------------------
import jax
import jax.numpy as jnp
import flax.linen as nn
import numpy as np
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from PIL import Image
import matplotlib.pyplot as plt
from jax import random


# Define a simplified ResNet-like model in Flax
class ResNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(64, (7, 7), strides=(2, 2), padding='SAME')(x)
        x = nn.relu(x)
        # x = nn.avg_pool(x, (3, 3), strides=(2, 2))
        x = nn.avg_pool(x, (3, 3), strides=(2, 2), padding='SAME')
        x = nn.Conv(512, (3, 3), padding='SAME', name='layer4_conv2')(x)  # Target layer
        self.sow('intermediates', 'activations', x)  # Capture activations
        x = nn.relu(x)
        # x = nn.avg_pool(x, (7, 7))
        x = nn.avg_pool(x, (7, 7), padding='SAME')
        x = x.reshape((x.shape[0], -1))
        # x = nn.Dense(1000, kernel_init=nn.initializers.he_normal())(x)
        x = nn.Dense(1000, kernel_init=nn.initializers.normal(stddev=0.01))(x)
        return x


# Function to compute gradients
def compute_gradients(params, inputs, target_class):
    def forward_fn(inputs):
        model = ResNet()
        logits, state = model.apply({'params': params}, inputs, mutable=['intermediates'])
        return logits[0, target_class], state['intermediates']['activations']

    grad_fn = jax.grad(forward_fn, has_aux=True)
    (grads, activations) = grad_fn(inputs)
    return grads, activations


def main():
    # Initialize random key
    key = random.PRNGKey(0)

    # Load and preprocess image
    dataset = datasets.FakeData(transform=transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ]))
    image, _ = dataset[0]
    image_pil = transforms.ToPILImage()(image)

    preprocess = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    input_tensor = preprocess(image_pil).unsqueeze(0)
    input_tensor = jnp.array(input_tensor)

    # Initialize model
    model = ResNet()
    params = model.init(key, input_tensor)['params']

    # Forward pass
    logits, state = model.apply({'params': params}, input_tensor, mutable=['intermediates'])
    predicted_class = jnp.argmax(logits, axis=1).item()
    activations = state['intermediates']['activations']

    # Backward pass for Grad-CAM
    gradients, _ = compute_gradients(params, input_tensor, predicted_class)

    # Generate Grad-CAM heatmap
    weights = jnp.mean(gradients, axis=(2, 3), keepdims=True)
    heatmap = jnp.sum(weights * activations[0], axis=1).squeeze()
    heatmap = jax.nn.relu(heatmap)

    # Normalize and convert heatmap
    heatmap = heatmap / jnp.max(heatmap + 1e-8)
    heatmap_np = np.array(heatmap)
    heatmap_pil = Image.fromarray((heatmap_np * 255).astype(np.uint8)).resize(image_pil.size, resample=Image.BILINEAR)

    # Display image with heatmap
    plt.imshow(image_pil)
    plt.imshow(heatmap_pil, alpha=0.5, cmap='jet')
    plt.title(f"Predicted Class: {predicted_class}")
    plt.axis('off')
    plt.savefig('gradcam_output.png')


if __name__ == "__main__":
    main()
