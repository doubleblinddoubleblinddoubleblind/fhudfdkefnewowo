import unittest

from transformers import FlaxCTRLConfig, is_flax_available
from transformers.testing_utils import require_flax, slow, jax_prng_key
from ..generation.test_generation_utils import GenerationTesterMixin
from ..test_configuration_common import ConfigTester
from ..test_modeling_common import ModelTesterMixin, ids_tensor, random_attention_mask

if is_flax_available():
    import jax
    import jax.numpy as jnp
    from transformers import (
        FLAX_CTRL_PRETRAINED_MODEL_ARCHIVE_LIST,
        FlaxCTRLForSequenceClassification,
        FlaxCTRLLMHeadModel,
        FlaxCTRLModel,
    )


class FlaxCTRLModelTester:
    def __init__(self, parent):
        self.parent = parent
        self.batch_size = 14
        self.seq_length = 7
        self.is_training = True
        self.use_token_type_ids = True
        self.use_input_mask = True
        self.use_labels = True
        self.use_mc_token_ids = True
        self.vocab_size = 99
        self.hidden_size = 32
        self.num_hidden_layers = 5
        self.num_attention_heads = 4
        self.intermediate_size = 37
        self.hidden_act = "gelu"
        self.hidden_dropout_prob = 0.1
        self.attention_probs_dropout_prob = 0.1
        self.max_position_embeddings = 512
        self.type_vocab_size = 16
        self.type_sequence_label_size = 2
        self.initializer_range = 0.02
        self.num_labels = 3
        self.num_choices = 4
        self.pad_token_id = self.vocab_size - 1

    def prepare_config_and_inputs(self):
        input_ids = ids_tensor([self.batch_size, self.seq_length], self.vocab_size)
        input_mask = random_attention_mask([self.batch_size, self.seq_length]) if self.use_input_mask else None
        token_type_ids = ids_tensor([self.batch_size, self.seq_length], self.type_vocab_size) if self.use_token_type_ids else None
        mc_token_ids = ids_tensor([self.batch_size, self.num_choices], self.seq_length) if self.use_mc_token_ids else None

        sequence_labels = ids_tensor([self.batch_size], self.type_sequence_label_size) if self.use_labels else None
        token_labels = ids_tensor([self.batch_size, self.seq_length], self.num_labels) if self.use_labels else None
        choice_labels = ids_tensor([self.batch_size], self.num_choices) if self.use_labels else None

        config = self.get_config()
        rng = jax_prng_key(0)
        return (
            config,
            rng,
            input_ids,
            input_mask,
            token_type_ids,
            mc_token_ids,
            sequence_labels,
            token_labels,
            choice_labels,
        )

    def get_config(self):
        return FlaxCTRLConfig(
            vocab_size=self.vocab_size,
            n_embd=self.hidden_size,
            n_layer=self.num_hidden_layers,
            n_head=self.num_attention_heads,
            n_positions=self.max_position_embeddings,
            pad_token_id=self.pad_token_id,
        )

    def create_and_check_ctrl_model(self, config, rng, input_ids, input_mask, token_type_ids, *args):
        model = FlaxCTRLModel(config)
        params = model.init(rng, input_ids, token_type_ids=token_type_ids)
        outputs = model.apply(params, input_ids, token_type_ids=token_type_ids)
        last_hidden = outputs.last_hidden_state
        self.parent.assertEqual(last_hidden.shape, (self.batch_size, self.seq_length, self.hidden_size))
        self.parent.assertEqual(len(outputs.past_key_values), config.n_layer)

    def create_and_check_lm_head_model(self, config, rng, input_ids, input_mask, token_type_ids, *args):
        model = FlaxCTRLLMHeadModel(config)
        params = model.init(rng, input_ids, token_type_ids=token_type_ids, labels=input_ids)
        outputs = model.apply(params, input_ids, token_type_ids=token_type_ids, labels=input_ids)
        self.parent.assertIsInstance(outputs.loss, jnp.ndarray)
        self.parent.assertEqual(outputs.logits.shape, (self.batch_size, self.seq_length, self.vocab_size))

    def prepare_config_and_inputs_for_common(self):
        config_and_inputs = self.prepare_config_and_inputs()
        config, rng, input_ids, input_mask, token_type_ids, *_ = config_and_inputs
        inputs_dict = {"input_ids": input_ids, "token_type_ids": token_type_ids}
        return config, rng, inputs_dict

    def create_and_check_ctrl_for_sequence_classification(self, config, rng, input_ids, token_type_ids, *args):
        config.num_labels = self.num_labels
        model = FlaxCTRLForSequenceClassification(config)
        params = model.init(rng, input_ids, token_type_ids=token_type_ids, labels=ids_tensor([self.batch_size], self.type_sequence_label_size))
        outputs = model.apply(params, input_ids, token_type_ids=token_type_ids, labels=ids_tensor([self.batch_size], self.type_sequence_label_size))
        self.parent.assertEqual(outputs.logits.shape, (self.batch_size, self.num_labels))


@require_flax
class FlaxCTRLModelTest(ModelTesterMixin, GenerationTesterMixin, unittest.TestCase):
    all_model_classes = (FlaxCTRLModel, FlaxCTRLLMHeadModel, FlaxCTRLForSequenceClassification) if is_flax_available() else ()
    all_generative_model_classes = (FlaxCTRLLMHeadModel,) if is_flax_available() else ()
    test_pruning = True
    test_resize_embeddings = False
    test_head_masking = False

    def setUp(self):
        self.model_tester = FlaxCTRLModelTester(self)
        self.config_tester = ConfigTester(self, config_class=FlaxCTRLConfig, n_embd=37)

    def test_config(self):
        self.config_tester.run_common_tests()

    def test_ctrl_model(self):
        config_and_inputs = self.model_tester.prepare_config_and_inputs()
        self.model_tester.create_and_check_ctrl_model(*config_and_inputs)

    def test_ctrl_lm_head_model(self):
        config_and_inputs = self.model_tester.prepare_config_and_inputs()
        self.model_tester.create_and_check_lm_head_model(*config_and_inputs)

    @slow
    def test_model_from_pretrained(self):
        for model_name in FLAX_CTRL_PRETRAINED_MODEL_ARCHIVE_LIST[:1]:
            model = FlaxCTRLModel.from_pretrained(model_name)
            self.assertIsNotNone(model)


@require_flax
class FlaxCTRLModelLanguageGenerationTest(unittest.TestCase):
    @slow
    def test_lm_generate_ctrl(self):
        model = FlaxCTRLLMHeadModel.from_pretrained("ctrl")
        input_ids = jnp.array([[11859, 0, 1611, 8]], dtype=jnp.int32)
        expected_output_ids = [11859, 0, 1611, 8, 5, 150, 26449, 2, 19, 348, 469, 3, 2595, 48, 20740, 246533, 246533, 19, 30, 5]
        output_ids = model.generate(input_ids, do_sample=False)
        self.assertListEqual(list(output_ids[0]), expected_output_ids)
