import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Tuple, Any


class EncoderRNN(nn.Module):
    vocab_size: int
    hidden_size: int
    n_layers: int
    dropout: float

    @nn.compact
    def __call__(self, input_token: jnp.ndarray, hidden: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        """ 
        input_token: [batch]    (integer token IDs)
        hidden:      [batch, hidden_size]
        returns:
          output: [batch, hidden_size]
          hidden: [batch, hidden_size]
        """
        # Embedding
        x = nn.Embed(self.vocab_size, self.hidden_size,
                     embedding_init=nn.initializers.uniform(0.1))(
                         input_token)  # [batch, hidden_size]

        # GRU layers
        new_hidden = hidden
        for i in range(self.n_layers):
            # GRUCell returns (next_hidden, new_carry)
            new_hidden, _ = nn.GRUCell(name=f"gru_{i}")(
                new_hidden, x)
            x = nn.Dropout(self.dropout)(new_hidden, deterministic=True)
        return x, new_hidden

    def init_hidden(self, batch_size: int) -> jnp.ndarray:
        return jnp.zeros((batch_size, self.hidden_size))


class ContextRNN(nn.Module):
    encoder_hidden_size: int
    hidden_size: int
    n_layers: int
    dropout: float

    @nn.compact
    def __call__(self, context_vector: jnp.ndarray, hidden: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        """
        context_vector: [batch, encoder_hidden_size]
        hidden:         [batch, hidden_size]
        """
        x = context_vector
        new_hidden = hidden
        for i in range(self.n_layers):
            new_hidden, _ = nn.GRUCell(name=f"context_gru_{i}")(
                new_hidden, x)
            x = nn.Dropout(self.dropout)(new_hidden, deterministic=True)
        return x, new_hidden

    def init_hidden(self, batch_size: int) -> jnp.ndarray:
        return jnp.zeros((batch_size, self.hidden_size))


class DecoderRNN(nn.Module):
    context_output_size: int
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float

    @nn.compact
    def __call__(self,
                 context_output: jnp.ndarray,
                 input_token: jnp.ndarray,
                 hidden: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
        """
        context_output: [batch, context_output_size]
        input_token:    [batch]           (integer token IDs)
        hidden:         [batch, hidden_size]
        returns:
          logits: [batch, output_size]
          hidden: [batch, hidden_size]
        """
        # Embedding
        emb = nn.Embed(self.output_size, self.hidden_size,
                       embedding_init=nn.initializers.uniform(0.1))(
                           input_token)  # [batch, hidden_size]

        # Concatenate context + embed
        x = jnp.concatenate([context_output, emb], axis=-1)

        # GRU layers
        new_hidden = hidden
        for i in range(self.n_layers):
            new_hidden, _ = nn.GRUCell(name=f"dec_gru_{i}")(
                new_hidden, x)
            x = nn.Dropout(self.dropout)(new_hidden, deterministic=True)

        # Output layer
        logits = nn.Dense(self.output_size,
                          kernel_init=nn.initializers.uniform(0.1))(x)
        log_probs = jax.nn.log_softmax(logits)
        return log_probs, new_hidden

    def init_hidden(self, batch_size: int) -> jnp.ndarray:
        return jnp.zeros((batch_size, self.hidden_size))


class DecoderRNNSeq(nn.Module):
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float
    max_length: int

    @nn.compact
    def __call__(self,
                 encoder_outputs: jnp.ndarray,
                 input_token: jnp.ndarray,
                 hidden: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        """
        encoder_outputs: [batch, max_length, hidden_size]
        input_token:     [batch]
        hidden:          [batch, hidden_size]
        returns:
          log_probs:     [batch, output_size]
          hidden:        [batch, hidden_size]
          attn_weights:  [batch, max_length]
        """
        # Embedding
        emb = nn.Embed(self.output_size, self.hidden_size,
                       embedding_init=nn.initializers.uniform(0.1))(
                           input_token)  # [batch, hidden_size]

        # Attention scores
        # Concatenate emb and hidden to compute attention
        concat = jnp.concatenate([emb, hidden], axis=-1)  # [batch, hidden*2]
        attn_logits = nn.Dense(self.max_length)(concat)  # [batch, max_length]
        attn_weights = nn.softmax(attn_logits, axis=-1)  # [batch, max_length]

        # Compute context vector
        # (batch, max_length) @ (batch, max_length, hidden) -> (batch, hidden)
        context = jnp.einsum("bm,bmh->bh", attn_weights, encoder_outputs)

        # Combine and pass through GRU
        x = jnp.concatenate([emb, context], axis=-1)
        new_hidden = hidden
        for i in range(self.n_layers):
            new_hidden, _ = nn.GRUCell(name=f"attn_gru_{i}")(
                new_hidden, x)
            x = nn.Dropout(self.dropout)(new_hidden, deterministic=True)

        # Output layer
        logits = nn.Dense(self.output_size,
                          kernel_init=nn.initializers.uniform(0.1))(x)
        log_probs = jax.nn.log_softmax(logits)
        return log_probs, new_hidden, attn_weights

    def init_hidden(self, batch_size: int) -> jnp.ndarray:
        return jnp.zeros((batch_size, self.hidden_size))
