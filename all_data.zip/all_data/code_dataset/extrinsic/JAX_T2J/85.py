import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any

# --- Model definition -------------------------------------------------------

class HumanPoseNet(nn.Module):
    out_c: int
    pretrained: bool = True  # flag for loading pretrained weights if available

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        # ensure input spatial size
        assert x.shape[-2:] == (224, 224), "Input must be 224×224"

        # instantiate a VGG16‐BN feature extractor
        # (you'll need a Flax‐compatible VGG implementation or load via flaxmodels/timm)
        # Here we assume a helper `FlaxVGG16_BN` exists.
        vgg = FlaxVGG16_BN(pretrained=self.pretrained)

        # replace classifier layers:
        # in PyTorch: features → 25088 → 4096 → 4096 → out_c
        # in Flax, re‐define the Dense heads:
        x = vgg.features(x)
        x = x.reshape((x.shape[0], -1))           # flatten
        x = nn.Dense(4096, name="fc1")(x)         # replaces classifier[0]
        x = nn.relu(x)
        x = nn.Dense(4096, name="fc2")(x)         # replaces classifier[3]
        x = nn.relu(x)
        x = nn.Dense(self.out_c, name="fc3")(x)   # replaces classifier[6]
        return x

# --- Loss function ---------------------------------------------------------

def mse_loss(
    pred: jnp.ndarray,
    target: jnp.ndarray,
    weight: jnp.ndarray,
    weighted_loss: bool = False,
    size_average: bool = True
) -> jnp.ndarray:
    # create mask of where weight ≠ 0
    mask = (weight != 0).astype(jnp.float32)

    if weighted_loss:
        # sum over weighted squared errors
        loss = jnp.sum(weight * (pred - target) ** 2)
    else:
        # apply mask to ignore zero‐weight entries
        loss = jnp.sum(mask * (pred - target) ** 2)

    if size_average:
        # normalize by the total nonzero weight count
        denom = jnp.sum(mask)
        # avoid division by zero
        loss = jnp.where(denom > 0, loss / denom, loss)
    return loss
