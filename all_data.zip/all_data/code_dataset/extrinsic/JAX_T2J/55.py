import argparse
import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import tensorflow_datasets as tfds
from flax import linen as nn
from flax.training import train_state

# -------------------------------------------------
#  Model definition: ResNet18 encoder + head
# -------------------------------------------------
class ResidualBlock(nn.Module):
    filters: int
    strides: tuple = (1,1)

    @nn.compact
    def __call__(self, x):
        residual = x
        x = nn.Conv(self.filters, (3,3), self.strides, padding='SAME')(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.Conv(self.filters, (3,3), padding='SAME')(x)
        x = nn.BatchNorm(use_running_average=False)(x)

        if residual.shape != x.shape:
            residual = nn.Conv(self.filters, (1,1), self.strides, padding='SAME')(residual)
            residual = nn.BatchNorm(use_running_average=False)(residual)

        return nn.relu(x + residual)

class ResNet18(nn.Module):
    @nn.compact
    def __call__(self, x, train: bool = True):
        x = nn.Conv(64, (7,7), (2,2), padding='SAME')(x)
        x = nn.BatchNorm(use_running_average=not train)(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (3,3), (2,2), padding='SAME')

        for filters, blocks, stride in [(64,2,1), (128,2,2), (256,2,2), (512,2,2)]:
            for i in range(blocks):
                x = ResidualBlock(filters, strides=(stride,stride) if i==0 else (1,1))(x)
        x = jnp.mean(x, axis=(1,2))  # global pool
        return x

class EndModel(nn.Module):
    num_classes: int

    @nn.compact
    def __call__(self, x, train: bool = True):
        # x is encode_dim-dimensional
        x = nn.Dense(self.num_classes)(x)
        return x

# -------------------------------------------------
#  Training state and loss
# -------------------------------------------------
class TrainState(train_state.TrainState):
    batch_stats: dict

def create_train_state(rng, learning_rate, momentum, num_classes):
    # initialize encoder and head
    encoder = ResNet18()
    head = EndModel(num_classes)
    params_enc = encoder.init({'params': rng}, jnp.ones([1,32,32,3]), train=True)
    params_head = head.init({'params': rng}, jnp.ones([1,512]), train=True)
    tx = optax.sgd(learning_rate, momentum)
    state = TrainState.create(
        apply_fn={'encode': encoder.apply, 'head': head.apply},
        params={**params_enc['params'], **params_head['params']},
        tx=tx,
        batch_stats={**params_enc['batch_stats'], **params_head.get('batch_stats',{})}
    )
    return state

@jit
def train_step(state, batch, rng):
    imgs, labels = batch

    def loss_fn(params):
        # apply encoder
        variables_enc = {'params': params, 'batch_stats': state.batch_stats}
        feats, new_bs = state.apply_fn['encode'](
            variables_enc, imgs, train=True, mutable=['batch_stats']
        )
        logits, _ = state.apply_fn['head'](
            {'params': params, 'batch_stats': new_bs}, feats, train=True, mutable=['batch_stats']
        )
        onehot = jax.nn.one_hot(labels, logits.shape[-1])
        loss = jnp.mean(optax.softmax_cross_entropy(logits, onehot))
        return loss, new_bs

    (loss, new_bs), grads = value_and_grad(loss_fn, has_aux=True)(state.params)
    state = state.apply_gradients(grads=grads, batch_stats=new_bs['batch_stats'])
    return state, loss

@jit
def eval_step(state, batch):
    imgs, labels = batch
    variables = {'params': state.params, 'batch_stats': state.batch_stats}
    feats = state.apply_fn['encode'](variables, imgs, train=False, mutable=False)
    logits = state.apply_fn['head'](variables, feats, train=False, mutable=False)
    preds = jnp.argmax(logits, axis=-1)
    return jnp.mean(preds == labels)

# -------------------------------------------------
#  Data loading & augmentation
# -------------------------------------------------
def preprocess(example, train):
    img = example['image']
    img = tfds.as_numpy(img) / 255.0
    if train:
        # random crop + flip
        key = random.PRNGKey(example['index'])
        img = jax.image.resize(img, [40,40,3], method='bilinear')
        img = img[4:36,4:36,:]
        if random.uniform(key) > 0.5:
            img = img[:,::-1,:]
    mean = jnp.array([0.4914,0.4822,0.4465])
    std  = jnp.array([0.2023,0.1994,0.2010])
    return (img - mean)/std, example['label']

def make_dataloader(split, batch_size, train):
    ds = tfds.load('cifar10', split=split, as_supervised=False)
    ds = ds.shuffle(10_000) if train else ds
    ds = ds.enumerate().map(lambda idx, ex: {'index':idx, **ex})
    ds = ds.map(lambda ex: preprocess(ex, train), num_parallel_calls=4)
    ds = ds.batch(batch_size).prefetch(1)
    return tfds.as_numpy(ds)

# -------------------------------------------------
#  Main
# -------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('-b','--batch-size', type=int, default=128)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--momentum', type=float, default=0.9)
    args = parser.parse_args()

    rng = random.PRNGKey(0)
    state = create_train_state(rng, args.lr, args.momentum, num_classes=10)

    train_ds = make_dataloader('train', args.batch_size, train=True)
    test_ds  = make_dataloader('test',  args.batch_size, train=False)

    for epoch in range(1, args.epochs + 1):
        # Training
        for batch in train_ds:
            rng, subkey = random.split(rng)
            state, loss = train_step(state, batch, subkey)
        print(f'Epoch {epoch}, Train Loss: {loss:.4f}')

        # Evaluation
        accs = [eval_step(state, batch) for batch in test_ds]
        print(f'Epoch {epoch}, Test Accuracy: {jnp.mean(jnp.stack(accs))*100:.2f}%')

if __name__ == '__main__':
    main()
