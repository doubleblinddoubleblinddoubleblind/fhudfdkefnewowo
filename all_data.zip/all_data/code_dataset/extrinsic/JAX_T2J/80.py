import os
import gzip
import json
import random
import itertools

import jax.numpy as jnp
from jax import random as jrandom

from .rfill_parser import RobustFillParser
from aloe.common.pytorch_util import pad_sequence as torch_pad_sequence  # for reference
from aloe.rfill.utils.rfill_grammar import STATE_TRANS, trans_map, STATE_MAP, RFILL_VOCAB


def pad_sequence(sequences, batch_first=True, padding_value=0):
    # sequences: list of jnp.ndarray with shape (L_i, ...)
    max_len = max(seq.shape[0] for seq in sequences)
    padded = []
    for seq in sequences:
        pad_width = [(0, max_len - seq.shape[0])] + [(0, 0) for _ in range(seq.ndim - 1)]
        padded_seq = jnp.pad(seq, pad_width, constant_values=padding_value)
        padded.append(padded_seq)
    stacked = jnp.stack(padded)
    if not batch_first:
        # move sequence dim first
        axes = list(range(stacked.ndim))
        axes = [1, 0] + axes[2:]
        stacked = jnp.transpose(stacked, axes)
    return stacked


class RFillSample:
    def __init__(self, prog_idx, tree_root, ios, db):
        self.prog_idx = prog_idx
        self.db = db
        self.tree_root = tree_root
        self.raw_ios = ios


class CookedData:
    def __init__(self, padded_i, padded_o, scatter_idx, padded_states):
        self.padded_i = padded_i
        self.padded_o = padded_o
        self.scatter_idx = scatter_idx
        self.padded_states = padded_states

    def get_ios(self):
        return self.padded_i, self.padded_o, self.scatter_idx


def cooked_collade_fn(cls, list_samples):
    list_i, list_o, list_p = [], [], []
    seq_input_ints, seq_outputs_ints, scatter_idx, list_states = [], [], [], []

    # sort by length of program tokens descending
    list_samples.sort(key=lambda x: -len(x[2]))
    for idx, (i, o, p, int_i, int_o, states) in enumerate(list_samples):
        list_i.append(i)
        list_o.append(o)
        list_p.append(p)
        seq_input_ints.extend(int_i)
        seq_outputs_ints.extend(int_o)
        scatter_idx.extend([idx] * len(int_i))
        if cls.need_mask:
            list_states.append(jnp.array(states, dtype=jnp.int32))

    if cls.need_mask:
        padding_val = STATE_MAP['halt']
        padded_states = pad_sequence(list_states, batch_first=True, padding_value=padding_val)
    else:
        padded_states = None

    padded_i = cls.fn_pad_in(seq_input_ints)
    padded_o = cls.fn_pad_out(seq_outputs_ints)
    scatter_idx = jnp.array(scatter_idx, dtype=jnp.int32)

    return list_i, list_o, list_p, CookedData(padded_i, padded_o, scatter_idx, padded_states)


def raw_txt2int(cls, inputs, outputs, prog_tokens):
    seq_input_ints, seq_outputs_ints = [], []
    for x, y in zip(inputs[:cls.numPublicIO], outputs[:cls.numPublicIO]):
        seq_input_ints.append(cls.io2idx_func(x))
        seq_outputs_ints.append(cls.io2idx_func(y))

    if cls.need_mask:
        cur_state = 'start'
        states = []
        for t in prog_tokens:
            cur_state = trans_map[(cur_state, t)]
            states.append(STATE_MAP[cur_state])
    else:
        states = None

    return inputs, outputs, prog_tokens, seq_input_ints, seq_outputs_ints, states


class CookedInfRfill:
    def __init__(self, args, io2idx_func, fn_pad_in, fn_pad_out, need_mask=False):
        self.args = args
        self.iter_per_epoch = args.iter_per_epoch
        self.data_dir = args.data_dir
        self.numPublicIO = args.numPublicIO
        self.io2idx_func = io2idx_func
        self.fn_pad_in = fn_pad_in
        self.fn_pad_out = fn_pad_out
        self.need_mask = need_mask

    def __iter__(self):
        files = [f for f in os.listdir(self.data_dir) if f.startswith('train')]
        random.shuffle(files)
        for fname in files:
            path = os.path.join(self.data_dir, fname)
            with gzip.open(path, 'rb') as f:
                lines = f.readlines()
            random.shuffle(lines)
            for row in lines:
                data_dict = json.loads(row)
                inputs = data_dict['inputs']
                outputs = data_dict['outputs']
                prog_tokens = data_dict['exprs']
                yield raw_txt2int(self, inputs, outputs, prog_tokens)

    def collate_fn(self, list_samples):
        return cooked_collade_fn(self, list_samples)


class RawStaticRfill:
    def __init__(self, args, json_path):
        self.iter_per_epoch = args.iter_per_epoch
        with open(json_path, 'r') as f:
            self.raw_json_strings = f.readlines()
        self.num_programs = len(self.raw_json_strings)
        self.samples = [None] * self.num_programs

    def __len__(self):
        return self.num_programs

    def __getitem__(self, idx):
        if self.samples[idx] is None:
            row = self.raw_json_strings[idx]
            data_dict = json.loads(row)
            self.samples[idx] = (data_dict['inputs'], data_dict['outputs'], data_dict['exprs'])
        return self.samples[idx]

    def collate_fn(self, list_samples):
        list_i, list_o, list_p = [], [], []
        list_samples.sort(key=lambda x: -len(x[2]))
        for i, o, p in list_samples:
            list_i.append(i)
            list_o.append(o)
            list_p.append(p)
        return list_i, list_o, list_p, None
