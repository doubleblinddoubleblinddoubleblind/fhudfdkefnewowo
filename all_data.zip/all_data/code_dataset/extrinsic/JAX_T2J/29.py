import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence


class Bottleneck(nn.Module):
    last_planes: int
    in_planes: int
    out_planes: int
    dense_depth: int
    stride: int
    first_layer: bool

    @nn.compact
    def __call__(self, x):
        # 1×1 conv
        y = nn.Conv(self.in_planes, kernel_size=(1,1), strides=(1,1), use_bias=False)(x)
        y = nn.BatchNorm(use_running_average=False)(y)
        y = nn.relu(y)

        # 3×3 grouped conv
        y = nn.Conv(self.in_planes, kernel_size=(3,3),
                    strides=(self.stride,self.stride),
                    padding='SAME', feature_group_count=32, use_bias=False)(y)
        y = nn.BatchNorm(use_running_average=False)(y)
        y = nn.relu(y)

        # 1×1 conv to out_planes + dense_depth
        y = nn.Conv(self.out_planes + self.dense_depth, kernel_size=(1,1), use_bias=False)(y)
        y = nn.BatchNorm(use_running_average=False)(y)

        # Shortcut
        if self.first_layer:
            sc = nn.Conv(self.out_planes + self.dense_depth, kernel_size=(1,1),
                         strides=(self.stride,self.stride), use_bias=False)(x)
            sc = nn.BatchNorm(use_running_average=False)(sc)
        else:
            sc = x

        # Dual-path concat:
        d = self.out_planes
        # split along channel axis
        sc1, sc2 = sc[:, :d, :, :], sc[:, d:, :, :]
        y1, y2 = y[:, :d, :, :], y[:, d:, :, :]
        out = jnp.concatenate([sc1 + y1, sc2, y2], axis=1)
        return nn.relu(out)


class DPN(nn.Module):
    cfg: dict

    @nn.compact
    def __call__(self, x):
        in_planes = self.cfg['in_planes']
        out_planes = self.cfg['out_planes']
        num_blocks = self.cfg['num_blocks']
        dense_depth = self.cfg['dense_depth']

        # Initial conv
        x = nn.Conv(64, kernel_size=(3,3), strides=(1,1), padding='SAME', use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)

        last_planes = 64
        # build layers
        for i, (inp, outp, nblk, dd, st) in enumerate(zip(in_planes, out_planes, num_blocks, dense_depth, [1,2,2,2])):
            strides = [st] + [1] * (nblk - 1)
            for j, s in enumerate(strides):
                x = Bottleneck(last_planes, inp, outp, dd, s, first_layer=(j==0))(x)
                last_planes = outp + (j+2)*dd

        # global avg pool
        x = jnp.mean(x, axis=(2,3))  # shape (batch, channels)
        # final linear
        x = nn.Dense(10)(x)
        return x


def DPN26():
    cfg = {
        'in_planes': (96,192,384,768),
        'out_planes': (256,512,1024,2048),
        'num_blocks': (2,2,2,2),
        'dense_depth': (16,32,24,128)
    }
    return DPN(cfg)

def DPN92():
    cfg = {
        'in_planes': (96,192,384,768),
        'out_planes': (256,512,1024,2048),
        'num_blocks': (3,4,20,3),
        'dense_depth': (16,32,24,128)
    }
    return DPN(cfg)


# Test function
if __name__ == "__main__":
    import numpy as onp

    key = jax.random.PRNGKey(0)
    model = DPN92()
    # initialize parameters for a dummy input
    variables = model.init(key, jnp.ones((1,3,32,32)))
    logits = model.apply(variables, jnp.ones((1,3,32,32)))
    print("Output shape:", logits.shape)  # should be (1, 10)
