import jax
import jax.numpy as jnp
import optax
from typing import NamedTuple
from jax.tree_util import tree_map, tree_leaves, tree_unflatten, tree_structure

class RM3State(NamedTuple):
    gradients_buffer: any  # pytree matching params, each leaf is an array of shape (3, *grad_shape)
    count: jnp.ndarray     # scalar int32

def rm3(learning_rate: float, weight_decay: float = 0.0) -> optax.GradientTransformation:
    """Returns an Optax GradientTransformation implementing RM3 (median of 3).
    
    Args:
      learning_rate: float, step size.
      weight_decay: float, L2 penalty on parameters.
    """
    def init_fn(params):
        # Build a buffer of shape (3, *param_shape) for each leaf
        def _init_buf(p):
            return jnp.stack([jnp.zeros_like(p) for _ in range(3)], axis=0)
        buf = tree_map(_init_buf, params)
        return RM3State(gradients_buffer=buf,
                        count=jnp.zeros([], jnp.int32))
    
    def update_fn(grads, state: RM3State, params=None):
        # Optionally add weight decay
        if weight_decay != 0.0 and params is not None:
            grads = tree_map(lambda g, p: g + weight_decay * p, grads, params)
        
        # Increment counter and compute buffer index
        count = state.count + 1
        idx = count % 3
        
        # Rotate in the new gradient into the ring buffer
        def _update_buf(buf, g):
            return buf.at[idx].set(g)
        new_buf = tree_map(_update_buf, state.gradients_buffer, grads)
        
        # Compute the median along the first axis of each buffer
        def _median(buf):
            # buf has shape (3, *shape); sort along axis=0 and take middle slice
            sorted_buf = jnp.sort(buf, axis=0)
            return sorted_buf[1]
        med = tree_map(_median, new_buf)
        
        # Scale by learning rate
        updates = tree_map(lambda m: -learning_rate * m, med)
        
        return updates, RM3State(gradients_buffer=new_buf, count=count)
    
    return optax.GradientTransformation(init_fn, update_fn)
