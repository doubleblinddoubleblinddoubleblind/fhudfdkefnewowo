import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import flax.linen as nn
import optax
import numpy as np
import tensorflow_datasets as tfds
from functools import partial
import matplotlib.pyplot as plt

# ----------------------------------------
# Utilities
# ----------------------------------------
def to_onehot(labels, num_classes=10):
    """Convert integer labels to one-hot vectors."""
    return jax.nn.one_hot(labels, num_classes)

def bce_loss(logits, labels):
    """Binary cross-entropy loss."""
    bce = - (labels * jnp.log(logits + 1e-8) +
             (1 - labels) * jnp.log(1 - logits + 1e-8))
    return jnp.mean(bce)  # :contentReference[oaicite:0]{index=0}:contentReference[oaicite:1]{index=1}

# ----------------------------------------
# Data pipeline: MNIST from TFDS
# ----------------------------------------
def load_mnist(batch_size, seed=0):
    ds = tfds.load('mnist', split='train', as_supervised=True)
    ds = ds.shuffle(10_000, seed=seed)
    ds = ds.map(lambda img, lbl: ((jnp.reshape(img, (-1,)) / 255.0) * 2 - 1,
                                  lbl))
    ds = ds.batch(batch_size).prefetch(1)
    return tfds.as_numpy(ds)

# ----------------------------------------
# Model definitions using Flax
# ----------------------------------------
class Discriminator(nn.Module):
    @nn.compact
    def __call__(self, x, c):
        # x: [B, 784], c: [B, 10]
        v = jnp.concatenate([x, c], axis=-1)
        v = nn.Dense(512)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(256)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(1)(v)
        return nn.sigmoid(v)

class Generator(nn.Module):
    latent_dim: int = 100
    @nn.compact
    def __call__(self, z, c):
        # z: [B, latent_dim], c: [B, 10]
        v = jnp.concatenate([z, c], axis=-1)
        v = nn.Dense(128)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(256)(v)
        v = nn.BatchNorm(use_running_average=False)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(512)(v)
        v = nn.BatchNorm(use_running_average=False)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(1024)(v)
        v = nn.BatchNorm(use_running_average=False)(v)
        v = nn.leaky_relu(v, 0.2)
        v = nn.Dense(784)(v)
        v = nn.tanh(v)
        return v  # reshape later to [B,1,28,28]

# ----------------------------------------
# Initialization and optimizers
# ----------------------------------------
batch_size   = 64
latent_dim   = 100
lr           = 2e-4
beta1, beta2 = 0.5, 0.999

key = random.PRNGKey(42)
key, subkey1, subkey2 = random.split(key, 3)

# Initialize models
G = Generator(latent_dim)
D = Discriminator()

z_dummy = random.normal(subkey1, (1, latent_dim))
c_dummy = to_onehot(jnp.array([0]), 10)

G_params = G.init(subkey1, z_dummy, c_dummy)['params']
D_params = D.init(subkey2, jnp.ones((1,784)), c_dummy)['params']

# Create optimizers
G_tx = optax.adam(lr, b1=beta1, b2=beta2)
D_tx = optax.adam(lr, b1=beta1, b2=beta2)

G_opt_state = G_tx.init(G_params)
D_opt_state = D_tx.init(D_params)

# ----------------------------------------
# Training step (JIT-compiled)
# ----------------------------------------
@partial(jit, static_argnums=(6,))
def train_step(G_params, D_params, G_opt_state, D_opt_state,
               real_x, real_lbl, key):
    """Performs one step of CGAN training."""
    B = real_x.shape[0]
    real_c = to_onehot(real_lbl, 10)

    # Discriminator update
    def d_loss_fn(D_pars):
        # Real
        real_logits = D.apply({'params': D_pars}, real_x, real_c)
        real_loss   = bce_loss(real_logits, jnp.ones_like(real_logits))
        # Fake
        nonlocal key
        key, sub = random.split(key)
        z = random.normal(sub, (B, latent_dim))
        fake_x = G.apply({'params': G_params}, z, real_c)
        fake_logits = D.apply({'params': D_pars}, fake_x, real_c)
        fake_loss   = bce_loss(fake_logits, jnp.zeros_like(fake_logits))
        return real_loss + fake_loss

    d_loss, d_grads = value_and_grad(d_loss_fn)(D_params)
    D_updates, D_opt_state = D_tx.update(d_grads, D_opt_state, D_params)
    D_params = optax.apply_updates(D_params, D_updates)

    # Generator update
    def g_loss_fn(G_pars):
        nonlocal key
        key, sub = random.split(key)
        z = random.normal(sub, (B, latent_dim))
        fake_x = G.apply({'params': G_pars}, z, real_c)
        logits = D.apply({'params': D_params}, fake_x, real_c)
        return bce_loss(logits, jnp.ones_like(logits))

    g_loss, g_grads = value_and_grad(g_loss_fn)(G_params)
    G_updates, G_opt_state = G_tx.update(g_grads, G_opt_state, G_params)
    G_params = optax.apply_updates(G_params, G_updates)

    return G_params, D_params, G_opt_state, D_opt_state, d_loss, g_loss, key

# ----------------------------------------
# Training loop
# ----------------------------------------
epochs = 30
ds = load_mnist(batch_size, seed=0)

for epoch in range(epochs):
    for real_x, real_lbl in ds:
        # move data to float32 and flatten
        x = jnp.array(real_x, dtype=jnp.float32).reshape(-1, 784)
        G_params, D_params, G_opt_state, D_opt_state, d_loss, g_loss, key = \
            train_step(G_params, D_params, G_opt_state, D_opt_state, x, real_lbl, key)
    print(f"Epoch {epoch+1}/{epochs} — D_loss: {d_loss:.4f}, G_loss: {g_loss:.4f}")

# ----------------------------------------
# Sample generation and visualization
# ----------------------------------------
def sample_and_plot(G_params, key, num_per_class=10):
    """Generate a grid of images (10 classes × num_per_class each)."""
    fig, axes = plt.subplots(10, num_per_class, figsize=(num_per_class,10))
    c_all = jnp.repeat(jnp.eye(10), num_per_class, axis=0)
    key, sub = random.split(key)
    z = random.normal(sub, (10 * num_per_class, latent_dim))
    imgs = G.apply({'params': G_params}, z, c_all)
    imgs = (imgs + 1) / 2  # to [0,1]
    for i in range(10 * num_per_class):
        ax = axes[i//num_per_class, i%num_per_class]
        ax.imshow(imgs[i].reshape(28,28), cmap='gray')
        ax.axis('off')
    plt.show()

sample_and_plot(G_params, key)
