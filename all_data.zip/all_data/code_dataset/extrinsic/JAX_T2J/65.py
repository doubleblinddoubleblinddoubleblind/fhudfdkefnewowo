import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Any, Dict, Tuple
import numpy as np

class CategoricalMLPPolicy(nn.Module):
    """Flax implementation of a categorical MLP policy."""
    hidden_sizes: Sequence[int]
    num_actions: int

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        # Build hidden layers
        for h in self.hidden_sizes:
            x = nn.Dense(features=h)(x)
            x = nn.tanh(x)
        # Output logits
        logits = nn.Dense(features=self.num_actions)(x)
        # Convert to probabilities
        return nn.softmax(logits)

def get_action(
    params: Dict[str, Any],
    policy_apply: Any,
    observation: np.ndarray,
    key: jax.random.PRNGKey,
    deterministic: bool = False
) -> Tuple[int, Dict[str, np.ndarray]]:
    """
    Sample or select the action given a single observation.

    Args:
      params: Parameter dict returned by `policy.init`.
      policy_apply: The `model.apply` function.
      observation: single observation array, shape (obs_dim,).
      key: PRNGKey for sampling.
      deterministic: if True, pick argmax instead of sampling.

    Returns:
      action (int), info dict with 'prob' array.
    """
    # Convert and add batch dim
    x = jnp.expand_dims(observation.astype(jnp.float32), 0)
    # Compute probabilities
    probs = policy_apply({'params': params}, x)[0]  # shape: (num_actions,)
    if deterministic:
        action = jnp.argmax(probs)
    else:
        action = jax.random.categorical(key, jnp.log(probs))
    return int(action), {'prob': np.array(probs)}

# Example of initializing and using the policy:
def main():
    import numpy as np

    obs_dim = 4
    num_actions = 3
    hidden_sizes = (32, 32)

    # Create PRNG keys
    key_init, key_sample = jax.random.split(jax.random.PRNGKey(0))

    # Dummy observation for init
    dummy_obs = jnp.zeros((1, obs_dim), jnp.float32)

    # Initialize model
    model = CategoricalMLPPolicy(hidden_sizes=hidden_sizes, num_actions=num_actions)
    params = model.init(key_init, dummy_obs)['params']

    # Sample an action
    observation = np.random.rand(obs_dim).astype(np.float32)
    action, info = get_action(params, model.apply, observation, key_sample, deterministic=False)

    print(f"Sampled action: {action}, probabilities: {info['prob']}")

if __name__ == "__main__":
    main()
