import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Union, Literal

# VGG configurations
_cfg = {
    'A': [64, 'M', 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'B': [64, 64, 'M', 128, 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'D': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M'],
    'E': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M']
}

class VGG(nn.Module):
    cfg_name: Literal['A','B','D','E']
    batch_norm: bool = False
    num_classes: int = 1000
    dropout_rate: float = 0.5

    @nn.compact
    def __call__(self, x, train: bool = False):
        # Feature extractor
        in_channels = x.shape[-1]
        for v in _cfg[self.cfg_name]:
            if v == 'M':
                x = nn.max_pool(x, (2,2), (2,2))
            else:
                x = nn.Conv(
                    features=v,
                    kernel_size=(3,3),
                    padding='SAME',
                    use_bias=not self.batch_norm,
                    kernel_init=nn.initializers.kaiming_normal(),
                )(x)
                if self.batch_norm:
                    x = nn.BatchNorm(use_running_average=not train,
                                     momentum=0.9,
                                     epsilon=1e-5,
                                     scale_init=nn.initializers.ones,
                                     bias_init=nn.initializers.zeros)(x)
                x = nn.relu(x)

        # Classifier
        x = x.reshape((x.shape[0], -1))                 # flatten
        x = nn.Dense(4096,
                     kernel_init=nn.initializers.normal(0.01),
                     bias_init=nn.initializers.zeros)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=self.dropout_rate)(x, deterministic=not train)

        x = nn.Dense(4096,
                     kernel_init=nn.initializers.normal(0.01),
                     bias_init=nn.initializers.zeros)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=self.dropout_rate)(x, deterministic=not train)

        x = nn.Dense(self.num_classes,
                     kernel_init=nn.initializers.normal(0.01),
                     bias_init=nn.initializers.zeros)(x)
        return x

# Factory functions for each variant
def vgg11(num_classes=1000, pretrained=False):
    return VGG('A', batch_norm=False, num_classes=num_classes)

def vgg11_bn(num_classes=1000, pretrained=False):
    return VGG('A', batch_norm=True,  num_classes=num_classes)

def vgg13(num_classes=1000, pretrained=False):
    return VGG('B', batch_norm=False, num_classes=num_classes)

def vgg13_bn(num_classes=1000, pretrained=False):
    return VGG('B', batch_norm=True,  num_classes=num_classes)

def vgg16(num_classes=1000, pretrained=False):
    return VGG('D', batch_norm=False, num_classes=num_classes)

def vgg16_bn(num_classes=1000, pretrained=False):
    return VGG('D', batch_norm=True,  num_classes=num_classes)

def vgg19(num_classes=1000, pretrained=False):
    return VGG('E', batch_norm=False, num_classes=num_classes)

def vgg19_bn(num_classes=1000, pretrained=False):
    return VGG('E', batch_norm=True,  num_classes=num_classes)
