import os, glob
from pathlib import Path
from PIL import Image
import cv2

import jax
import jax.numpy as jnp
from jax import random, jit
import flax.linen as nn
from flax.training import checkpoints

# -----------------------------
# Utilities
# -----------------------------
def load_image(path: str) -> jnp.ndarray:
    """Load image with PIL, convert to [0,1] float32, and crop to (416,1024)."""
    img = Image.open(path).convert('RGB')
    arr = jnp.array(img, dtype=jnp.float32) / 255.0
    # ensure shape (H,W,3) ≥ (416,1024,3)
    crop = arr[:416, :1024, :]
    # reshape to (1,3,416,1024)
    return crop.transpose(2,0,1)[None, ...]

# -----------------------------
# Model Definition (stub)
# -----------------------------
class GradientNetFlax(nn.Module):
    """Stub: mirror your PyTorch GradientNet in Flax."""
    # add any config fields here, e.g. growth_rate: int, transition_scale: int, etc.

    @nn.compact
    def __call__(self, x, go_through_merge: bool = False):
        # TODO: re-implement your network architecture in Flax
        # For example:
        # x = nn.Conv(features=32, kernel_size=(3,3))(x)
        # ...
        # if go_through_merge:
        #     return None, merge_list
        raise NotImplementedError("Implement GradientNet architecture in Flax")

# -----------------------------
# Main Loop
# -----------------------------
def main():
    # PRNG key (if your model uses randomness)
    rng = random.PRNGKey(0)

    # where you saved your Flax checkpoint
    ckpt_dir = "./flax_ckpts/"
    params = checkpoints.restore_checkpoint(ckpt_dir, target=None)
    # if you saved under a key, e.g. target={"params": ...}, adjust accordingly

    scenes = sorted(Path("/home/lwp/workspace/sintel2/clean").glob("*"))
    res_root = Path("./results/images/")

    for scene_path in scenes:
        scene = scene_path.name
        out_dir = res_root / scene
        out_dir.mkdir(parents=True, exist_ok=True)

        for type_ in ("albedo", "shading"):
            # directory where PyTorch snapshots lived
            snap_dir = Path(f"/media/lwp/xavier/graduation_results/showcase_model/{scene}/{type_}/{'rgb' if not False else 'gd'}")
            snap_file = snap_dir / "snapshot-239.pth.tar"
            if not snap_file.exists():
                continue

            # --- YOU MUST convert the loaded PyTorch state_dict to Flax params ---
            # e.g. params = convert_torch_to_flax(torch.load(snap_file)["state_dict"], params)

            # instantiate model once
            model = GradientNetFlax()
            # jit the apply for speed
            apply_fn = jit(model.apply, static_argnames=("go_through_merge",))

            num_frames = 40 if scene == "market_6" else 50
            for ind in range(1, num_frames + 1):
                frame_name = f"frame_{ind:04d}.png"
                img_path = scene_path / frame_name
                if not img_path.exists():
                    continue

                x = load_image(str(img_path))  # shape (1,3,416,1024)
                # Flax expects NHWC by default; if you kept NCHW, adjust in model
                # here we assume model accepts (1,3,416,1024)
                _, merge_list = apply_fn({"params": params}, x, go_through_merge=True)
                merged = merge_list[5]           # pick the right merge
                merged = jnp.squeeze(merged, axis=0)  # (3,416,1024)
                # move to HWC and to numpy for OpenCV
                merged_np = jnp.transpose(merged, (1,2,0))
                # take channels 0:3
                dx = jnp.clip(merged_np[..., :3], 0.0, 1.0)
                out_name = f"{type_}_{ind:04d}.png"
                # convert to uint8 BGR
                cv2.imwrite(str(out_dir / out_name),
                            (jnp.array(dx[..., ::-1]) * 255).astype(jnp.uint8))

if __name__ == "__main__":
    main()
