import jax
import jax.numpy as jnp
import jax.nn as jnn
from functools import partial
import time

# -----------------------------------------------------------------------------
# Utility: sample sparse indices & values
# -----------------------------------------------------------------------------
def sample(key, nindices=2*256+2*8, size=(256, 256), var=1.0):
    assert len(size) == 2
    key, subkey1 = jax.random.split(key)
    # Random float coords in [0, size) then floor to long
    coords = jax.random.uniform(subkey1, (nindices, 2), minval=0.0, maxval=1.0)
    indices = jnp.floor(coords * jnp.array(size)).astype(jnp.int32)
    key, subkey2 = jax.random.split(key)
    values = jax.random.normal(subkey2, (nindices,)) * var
    return key, indices, values

# -----------------------------------------------------------------------------
# Sparse sum and logsoftmax (naive & iterative)
# -----------------------------------------------------------------------------
def sparse_to_dense(indices, values, size):
    # indices: (batch, nindices, 2), values: (batch, nindices)
    batch = indices.shape[0]
    out = jnp.zeros((batch, size[0], size[1]), dtype=values.dtype)
    # advanced indexing with .at[].add
    idx0 = jnp.arange(batch)[:, None]
    out = out.at[idx0, indices[..., 0], indices[..., 1]].add(values)
    return out

def sum_sparse(indices, values, size):
    return sparse_to_dense(indices, values, size)

def logsoftmax_sparse(indices, values, size, method='naive'):
    dense = sparse_to_dense(indices, values, size)
    if method == 'naive':
        ls = jnn.log_softmax(dense)
    elif method == 'iteration':
        # iterative over rows
        def row_ls(row):
            return jnn.log_softmax(row)
        ls = jax.vmap(jax.vmap(row_ls, in_axes=1, out_axes=1), in_axes=0)(dense)
    else:
        raise ValueError(f"Unknown method {method}")
    return ls

# -----------------------------------------------------------------------------
# Tests
# -----------------------------------------------------------------------------
def main():
    key = jax.random.PRNGKey(0)

    # test_sum
    size = (5, 5)
    key, *samples = jax.tree_util.tree_unflatten(
        jax.tree_util.tree_structure(((),)),  # dummy structure
        [sample(key, nindices=3, size=size, var=1.0) for _ in range(3)]
    )
    # samples is list of triples (key, idx, val); extract last three keys
    _, idx1, v1 = samples[0]
    _, idx2, v2 = samples[1]
    _, idx3, v3 = samples[2]
    indices = jnp.stack([idx1, idx2, idx3], axis=0)
    values = jnp.stack([v1, v2, v3], axis=0)

    print("indices:", indices)
    print("values:", values)
    res_sum = sum_sparse(indices, values, size)
    print("res", res_sum)

    # test_log_softmax
    print("res naive:", jnp.exp(logsoftmax_sparse(indices, values, size, method='naive')))
    print("res iteration:", jnp.exp(logsoftmax_sparse(indices, values, size, method='iteration')))

    # test gradient + sleep
    key, subkey = jax.random.split(key)
    a = jax.random.normal(subkey, ())  # scalar random
    key, subkey = jax.random.split(key)
    x = jax.random.normal(subkey, (15000, 15000))
    x = x * a
    x = x / 2.0

    # define loss and compute gradient w.r.t. a
    loss_fn = lambda a: jnp.sum((x * a) / 2.0)
    grad_a = jax.grad(loss_fn)(a)
    print("grad wrt a:", grad_a)

    # mimic original sleep
    time.sleep(600)

if __name__ == "__main__":
    main()
