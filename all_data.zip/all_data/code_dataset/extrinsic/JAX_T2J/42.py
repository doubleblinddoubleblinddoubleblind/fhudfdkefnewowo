import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import ray

from bigdl.chronos.model.tcmf.local_model import TemporalConvNet  # assume JAX‐compatible version exists

# ---------------------------
# Data loader conversion
# ---------------------------
def get_tcmf_data_loader(config):
    from bigdl.chronos.model.tcmf.data_loader import TCMFDataLoader
    return TCMFDataLoader(
        Ymat=ray.get(config["Ymat_id"]),
        vbsize=config["vbsize"],
        hbsize=config["hbsize"],
        end_index=config["end_index"],
        val_len=config["val_len"],
        covariates=ray.get(config["covariates_id"]),
        Ycov=ray.get(config["Ycov_id"]),
    )

class TcmfTrainDatasetDist:
    def __init__(self, config):
        self.loader = get_tcmf_data_loader(config)
        self.epoch = 0

    def __iter__(self):
        while self.loader.epoch == self.epoch:
            inp, out, _, _ = self.loader.next_batch()
            # simulate torch.distributed splitting
            nproc = jax.process_count()
            idx = jax.process_index()
            per = inp.shape[0] // nproc
            inp = jnp.split(inp, nproc)[idx]
            out = jnp.split(out, nproc)[idx]
            yield inp, out
        self.epoch += 1

class TcmfTrainDatasetHorovod:
    def __init__(self, config):
        self.loader = get_tcmf_data_loader(config)
        self.epoch = 0

    def __iter__(self):
        while self.loader.epoch == self.epoch:
            inp, out, _, _ = self.loader.next_batch()
            # Horovod-style splitting via process_count/process_index
            nproc = jax.process_count()
            idx = jax.process_index()
            per = inp.shape[0] // nproc
            inp = jnp.split(inp, nproc)[idx]
            out = jnp.split(out, nproc)[idx]
            yield inp, out
        self.epoch += 1

class TcmfValDataset:
    def __init__(self, config):
        self.loader = get_tcmf_data_loader(config)

    def __iter__(self):
        inp, out, _, _ = self.loader.supply_test()
        yield inp, out

# ---------------------------
# Model, Loss & Optimizer
# ---------------------------
def model_creator(config):
    # wrap TemporalConvNet (must be JAX/Flax‐compatible)
    return TemporalConvNet(
        num_inputs=config["num_inputs"],
        num_channels=config["num_channels"],
        kernel_size=config["kernel_size"],
        dropout=config["dropout"],
        init=True,
    )

def loss_fn(params, batch):
    out = model.apply({"params": params}, batch["inp"])
    tgt = batch["out"]
    # L1Loss(normalized)
    return jnp.mean(jnp.abs(out - tgt)) / jnp.mean(jnp.abs(tgt))

def create_train_state(rng, config):
    model = model_creator(config)
    params = model.init(rng, jnp.ones((1, config["num_inputs"], )))["params"]
    tx = optax.adam(config["lr"])
    return model, params, tx.init(params)

# ---------------------------
# Training & Eval loops
# ---------------------------
@jit
def train_step(params, opt_state, batch, model, tx):
    (loss, grads) = value_and_grad(loss_fn)(params, batch)
    updates, opt_state = tx.update(grads, opt_state, params)
    params = optax.apply_updates(params, updates)
    return params, opt_state, loss

@jit
def eval_step(params, batch, model):
    return loss_fn(params, batch)

def train_and_evaluate(config, epochs, workers_per_node):
    # Setup
    key = random.PRNGKey(0)
    model, params, opt_state = create_train_state(key, config)

    # Data loaders
    train_ds = TcmfTrainDatasetDist(config)
    val_ds   = TcmfValDataset(config)

    for epoch in range(epochs):
        # TRAIN
        for inp, out in train_ds:
            batch = {"inp": inp, "out": out}
            params, opt_state, train_loss = train_step(params, opt_state, batch, model, optax.adam(config["lr"]))
        if (epoch + 1) % 10 == 0:
            print(f"[Epoch {epoch+1}] train loss: {train_loss:.4f}")

    # EVAL
    for inp, out in val_ds:
        batch = {"inp": inp, "out": out}
        val_loss = eval_step(params, batch, model)
    print(f"Validation loss: {val_loss:.4f}")

    return params, val_loss

# ---------------------------
# Entry point for Horovod‐style MPI
# ---------------------------
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--workers_per_node", type=int, default=1)
    # other BigDL Chronos config args...
    args, extras = parser.parse_known_args()
    config = {k: v for k, v in zip(extras[::2], extras[1::2])}
    # e.g. config["lr"]=0.001, config["num_inputs"]=..., etc.
    params, loss = train_and_evaluate(config, args.epochs, args.workers_per_node)
