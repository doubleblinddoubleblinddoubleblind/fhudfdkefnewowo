import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Any

ModuleDef = Any

class BasicBlock(nn.Module):
    in_planes: int
    planes: int
    stride: int = 1
    expansion: int = 1

    @nn.compact
    def __call__(self, x, train: bool = True):
        residual = x

        x = nn.Conv(features=self.planes,
                    kernel_size=(3,3),
                    strides=(self.stride, self.stride),
                    padding='SAME',
                    use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)
        x = nn.relu(x)

        x = nn.Conv(features=self.planes,
                    kernel_size=(3,3),
                    strides=(1,1),
                    padding='SAME',
                    use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)

        if self.stride != 1 or self.in_planes != self.expansion * self.planes:
            residual = nn.Conv(features=self.expansion * self.planes,
                               kernel_size=(1,1),
                               strides=(self.stride, self.stride),
                               use_bias=False)(residual)
            residual = nn.BatchNorm(use_running_average=not train)(residual)

        x = x + residual
        return nn.relu(x)


class Bottleneck(nn.Module):
    in_planes: int
    planes: int
    stride: int = 1
    expansion: int = 4

    @nn.compact
    def __call__(self, x, train: bool = True):
        residual = x

        x = nn.Conv(features=self.planes,
                    kernel_size=(1,1),
                    use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)
        x = nn.relu(x)

        x = nn.Conv(features=self.planes,
                    kernel_size=(3,3),
                    strides=(self.stride, self.stride),
                    padding='SAME',
                    use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)
        x = nn.relu(x)

        x = nn.Conv(features=self.expansion * self.planes,
                    kernel_size=(1,1),
                    use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)

        if self.stride != 1 or self.in_planes != self.expansion * self.planes:
            residual = nn.Conv(features=self.expansion * self.planes,
                               kernel_size=(1,1),
                               strides=(self.stride, self.stride),
                               use_bias=False)(residual)
            residual = nn.BatchNorm(use_running_average=not train)(residual)

        x = x + residual
        return nn.relu(x)


class ResNet(nn.Module):
    block: ModuleDef
    num_blocks: Sequence[int]
    num_classes: int = 10

    @nn.compact
    def __call__(self, x, train: bool = True):
        in_planes = 64

        x = nn.Conv(features=64, kernel_size=(3,3), strides=(1,1),
                    padding='SAME', use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=not train)(x)
        x = nn.relu(x)

        # build each layer
        for i, num_block in enumerate(self.num_blocks):
            stride = 1 if i == 0 else 2
            for j in range(num_block):
                s = stride if j == 0 else 1
                x = self.block(in_planes=in_planes,
                               planes=64 * (2**i),
                               stride=s)(x, train=train)
                in_planes = (64 * (2**i)) * self.block.expansion

        # global average pooling
        x = jnp.mean(x, axis=(1,2))
        x = nn.Dense(features=self.num_classes)(x)
        return x


def ResNet18(num_classes: int = 10):
    return ResNet(block=BasicBlock, num_blocks=[2,2,2,2], num_classes=num_classes)

def ResNet34(num_classes: int = 10):
    return ResNet(block=BasicBlock, num_blocks=[3,4,6,3], num_classes=num_classes)

def ResNet50(num_classes: int = 10):
    return ResNet(block=Bottleneck, num_blocks=[3,4,6,3], num_classes=num_classes)

def ResNet101(num_classes: int = 10):
    return ResNet(block=Bottleneck, num_blocks=[3,4,23,3], num_classes=num_classes)

def ResNet152(num_classes: int = 10):
    return ResNet(block=Bottleneck, num_blocks=[3,8,36,3], num_classes=num_classes)


# Example of initializing and applying
if __name__ == "__main__":
    import numpy as onp

    # create dummy input (batch_size=1, height=32, width=32, channels=3)
    x = onp.random.randn(1, 32, 32, 3).astype(onp.float32)

    rng = jax.random.PRNGKey(0)
    model = ResNet18(num_classes=10)
    variables = model.init(rng, x, train=True)
    logits = model.apply(variables, x, train=False)
    print("Logits shape:", logits.shape)  # (1, 10)
