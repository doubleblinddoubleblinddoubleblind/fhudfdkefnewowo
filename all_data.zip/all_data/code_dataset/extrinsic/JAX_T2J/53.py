import gym
import jax
import jax.numpy as jnp
from jax import random

# Create and unwrap the environment
env = gym.make("LunarLander-v2").unwrapped

# Initialize a JAX PRNG key
key = random.PRNGKey(0)

# Reset env to get initial state
state = env.reset()

# Run 1,000 random actions
for _ in range(1000):
    env.render()

    # Split key and sample a random discrete action in [0, n)
    key, subkey = random.split(key)
    action = int(random.randint(subkey, (), 0, env.action_space.n))

    # Step the environment
    next_state, reward, done, info = env.step(action)

    # If episode ends, reset; otherwise continue
    if done:
        state = env.reset()
    else:
        state = next_state
