import jax
import jax.numpy as jnp
from numpy.testing import assert_allclose

def time_distributed(module, *inputs):
    """
    Apply `module` to each time step of inputs.
    Inputs: one or more arrays of shape (batch, time, ...).
    Module should accept inputs flattened over batch*time.
    """
    # Assume at least one input; all share batch and time dims
    batch_size, time_steps = inputs[0].shape[:2]
    # Flatten each input to (batch*time, ...)
    flat_inputs = [x.reshape((batch_size * time_steps,) + x.shape[2:]) for x in inputs]
    # Apply module
    flat_output = module(*flat_inputs)
    # Reshape output back to (batch, time, ...)
    out_shape_rest = flat_output.shape[1:]
    return flat_output.reshape((batch_size, time_steps) + out_shape_rest)

def test_time_distributed_reshapes_correctly():
    # Define embedding weight explicitly
    weight = jnp.array([[.4, .4],
                        [.5, .5]])
    def embedding(x):
        # x: (batch*time, seq_len)
        return weight[x]   # takes indices into weight

    # Single-input test
    char_input = jnp.array([[[1, 0],
                              [1, 1]]])  # shape (1, 2, 2)
    output = time_distributed(embedding, char_input)
    expected = jnp.array([[[[.5, .5], [.4, .4]],
                            [[.5, .5], [.5, .5]]]])
    assert_allclose(output, expected, rtol=1e-6)
    print("test_time_distributed_reshapes_correctly passed.")

def test_time_distributed_works_with_multiple_inputs():
    # Module that adds two inputs elementwise
    def add(x, y):
        return x + y

    x_input = jnp.array([[[1, 2],
                           [3, 4]]])  # (1,2,2)
    y_input = jnp.array([[[4, 2],
                           [9, 1]]])  # (1,2,2)
    output = time_distributed(add, x_input, y_input)
    expected = jnp.array([[[5, 4],
                           [12, 5]]])
    assert_allclose(output, expected, rtol=1e-6)
    print("test_time_distributed_works_with_multiple_inputs passed.")

if __name__ == "__main__":
    test_time_distributed_reshapes_correctly()
    test_time_distributed_works_with_multiple_inputs()
