import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Optional, Tuple, List

from src.monitors import Histogram, BatchMatrixMonitor  # if you have JAX versions
from .matrix_activation import MATRIX_ACTIVATIONS
from allennlp.nn import util  # assuming util has JAX-compatible implementations

class EndpointSpanExtractor(nn.Module):
    input_dim: int
    combination: str = "x,y"
    num_width_embeddings: Optional[int] = None
    span_width_embedding_dim: Optional[int] = None
    bucket_widths: bool = False
    use_exclusive_start_indices: bool = False

    def setup(self):
        # Initialize parent SpanWidth embedding if used
        if self.num_width_embeddings is not None:
            self.span_width_embedding = nn.Embed(
                num_embeddings=self.num_width_embeddings,
                features=self.span_width_embedding_dim or 0
            )
        else:
            self.span_width_embedding = None

        # Sentinel parameter for exclusive start
        if self.use_exclusive_start_indices:
            self.start_sentinel = self.param(
                "start_sentinel",
                nn.initializers.normal(stddev=1.0),
                (1, 1, self.input_dim),
            )

    def get_output_dim(self) -> int:
        combined_dim = util.get_combined_dim(
            self.combination, [self.input_dim, self.input_dim]
        )
        if self.span_width_embedding is not None:
            combined_dim += self.span_width_embedding.embedding.shape[-1]
        return combined_dim

    def __call__(
        self,
        sequence_tensor: jnp.ndarray,       # shape (batch, seq_len, input_dim)
        span_indices: jnp.ndarray,          # shape (batch, num_spans, 2, 1)
        sequence_mask: Optional[jnp.ndarray] = None,
        span_indices_mask: Optional[jnp.ndarray] = None,
    ) -> jnp.ndarray:
        # split into starts/ends
        span_starts, span_ends = jnp.split(span_indices, 2, axis=-2)
        span_starts = span_starts.squeeze(-2).squeeze(-1)  # (batch, num_spans)
        span_ends   = span_ends.squeeze(-2).squeeze(-1)

        if span_indices_mask is not None:
            mask = span_indices_mask
            span_starts = span_starts * mask
            span_ends   = span_ends   * mask

        # select embeddings
        if not self.use_exclusive_start_indices:
            if sequence_tensor.shape[-1] != self.input_dim:
                raise ValueError(
                    f"Dimension mismatch expected ({sequence_tensor.shape[-1]}) "
                    f"received ({self.input_dim})."
                )
            start_embeddings = util.batched_index_select(sequence_tensor, span_starts)
            end_embeddings   = util.batched_index_select(sequence_tensor, span_ends)

        else:
            # convert to exclusive indices
            exclusive_starts = span_starts - 1
            sentinel_mask    = (exclusive_starts == -1)[..., None]
            exclusive_starts = jnp.where(exclusive_starts < 0, 0, exclusive_starts)

            # check at runtime
            if jnp.any(exclusive_starts < 0):
                raise ValueError(
                    f"Adjusted span indices must lie inside the sequence tensor, "
                    f"but found: {exclusive_starts}."
                )

            start_embeddings = util.batched_index_select(sequence_tensor, exclusive_starts)
            end_embeddings   = util.batched_index_select(sequence_tensor, span_ends)

            # replace out-of-bounds with sentinel
            start_embeddings = (
                start_embeddings * (1 - sentinel_mask)
                + sentinel_mask * self.start_sentinel
            )

        # combine endpoint embeddings
        combined = util.combine_tensors(
            self.combination, [start_embeddings, end_embeddings]
        )

        # optionally concatenate width embedding
        if self.span_width_embedding is not None:
            # compute widths
            widths = span_ends - span_starts
            width_emb = self.span_width_embedding(widths)
            combined = jnp.concatenate([combined, width_emb], axis=-1)

        return combined
