import os
import argparse

import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import checkpoints
import optax
import numpy as np

# --- stub replacements for reid libraries ---
# You must implement JAX equivalents of:
#  - datasets.create(...)  → returns an object with `.trainval` and `.images_dir`
#  - mu.predict_prob(model, data, images_dir, cfg)  → returns numpy array of shape (N, num_classes)
#  - mu.evaluate(model, data, cfg)  → prints or logs metrics
#  - Config  → a simple dataclass holding hyperparameters
#  - models.create(name, ...) → returns a Flax Module
from myjaxreid import datasets_jax as datasets
from myjaxreid import model_utils_jax as mu
from myjaxreid.config_jax import Config
from myjaxreid.models_jax import create_model  # factory of Flax Modules


def parse_args():
    parser = argparse.ArgumentParser(description='Model Test (JAX version)')
    parser.add_argument('-d', '--dataset', type=str, default='market1501std',
                        choices=datasets.names())
    parser.add_argument('-a', '--arch', type=str, default='resnet50',
                        choices=models.names())
    parser.add_argument('-m', '--model', type=str, default='spaco')
    parser.add_argument('-b', '--batch-size', type=int, default=256)
    parser.add_argument('--height', type=int, default=256)
    parser.add_argument('--width', type=int, default=128)
    return parser.parse_args()


def main():
    args = parse_args()

    # Prepare data
    data = datasets.create(args.dataset)
    train_data = data.trainval  # e.g. list of (image_path, label)

    # Build config
    cfg = Config()
    cfg.num_features = 512
    cfg.width = args.width
    cfg.height = args.height
    cfg.set_training(False)
    cfg.model_name = args.arch
    cfg.batch_size = args.batch_size
    cfg.logs_dir = os.path.join(os.getcwd(), 'logs')

    # Instantiate model (Flax Module) and optimizer state
    model_def = create_model(cfg.model_name,
                             num_features=cfg.num_features,
                             dropout=cfg.dropout,
                             num_classes=cfg.num_classes)
    rng = jax.random.PRNGKey(0)
    dummy_input = jnp.zeros((1, cfg.height, cfg.width, 3), jnp.float32)
    params = model_def.init({'params': rng}, dummy_input)['params']

    # We're just doing inference, no training here
    for epoch in range(5):
        ckpt_path = os.path.join(cfg.logs_dir,
                                 cfg.model_name,
                                 f'{args.model}.epoch{epoch}')
        if not os.path.exists(ckpt_path):
            continue

        # load_checkpoint should restore a dict matching `params`
        params = checkpoints.restore_checkpoint(ckpt_path, target=params)

        # Predict probabilities on training set
        # mu.predict_prob must internally batch, load images, normalize, apply model_def.apply
        pred_prob = mu.predict_prob(model_def, params, train_data, data.images_dir, cfg)
        pred_y = np.argmax(pred_prob, axis=1)
        true_y = np.array([cls for (_, cls, _, _) in train_data])

        accuracy = np.mean(pred_y == true_y)
        print(f'Epoch {epoch:>2d}: Accuracy on trainval = {accuracy:.4f}')

        # Evaluate with any additional metrics
        mu.evaluate(model_def, params, data, cfg)


if __name__ == '__main__':
    main()
