import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import tensorflow_datasets as tfds
from flax import linen as nn
from flax.training import train_state
import functools

# ---------------------------
# 1) Define the LeNet Model
# ---------------------------
class LeNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        # conv1: (1,28,28) -> (6,28,28)
        x = nn.Conv(features=6, kernel_size=(5,5), strides=(1,1), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        # conv2: (6,14,14) -> (16,10,10) -> (16,5,5)
        x = nn.Conv(features=16, kernel_size=(5,5), strides=(1,1))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        # flatten
        x = x.reshape((x.shape[0], -1))          # (batch, 16*5*5)
        x = nn.Dense(features=120)(x)
        x = nn.relu(x)
        x = nn.Dense(features=84)(x)
        x = nn.relu(x)
        x = nn.Dense(features=10)(x)
        return x

# ---------------------------
# 2) Create Train State
# ---------------------------
def create_train_state(rng, learning_rate):
    """Creates initial `TrainState` with model parameters and optimizer."""
    model = LeNet()
    params = model.init({'params': rng}, jnp.ones([1,28,28,1]))['params']
    tx = optax.sgd(learning_rate=learning_rate, momentum=0.9)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

# ---------------------------
# 3) Loss and Accuracy
# ---------------------------
@functools.partial(jit, static_argnums=0)
def compute_metrics(params, batch):
    logits = LeNet().apply({'params': params}, batch['image'])
    loss = optax.softmax_cross_entropy_with_integer_labels(logits, batch['label']).mean()
    accuracy = jnp.mean(jnp.argmax(logits, -1) == batch['label'])
    return loss, accuracy

@jit
def train_step(state, batch):
    """Single optimization step."""
    (loss, _), grads = value_and_grad(compute_metrics, has_aux=True)(state.params, batch)
    state = state.apply_gradients(grads=grads)
    return state, loss

# ---------------------------
# 4) Data Pipeline
# ---------------------------
def prepare_mnist(batch_size, rng):
    ds_builder = tfds.builder('mnist')
    ds_builder.download_and_prepare()
    def _normalize(sample):
        # To float32 [0,1], add channel dim
        img = jnp.float32(sample['image']) / 255.0
        img = img[..., None]
        return {'image': img, 'label': sample['label']}
    train_ds = ds_builder.as_dataset(split='train', shuffle_files=True)
    train_ds = train_ds.shuffle(10_000, seed=int(rng[0])).batch(batch_size).map(_normalize).prefetch(1)
    test_ds = ds_builder.as_dataset(split='test').batch(batch_size).map(_normalize).prefetch(1)
    return train_ds, test_ds

# ---------------------------
# 5) Training Loop
# ---------------------------
def train_and_evaluate(num_epochs=8, batch_size=64, lr=1e-3):
    rng = random.PRNGKey(0)
    rng, init_rng = random.split(rng)
    state = create_train_state(init_rng, lr)

    train_ds, test_ds = prepare_mnist(batch_size, rng)

    for epoch in range(1, num_epochs+1):
        # Training
        epoch_loss = 0.0
        steps = 0
        for batch in train_ds:
            state, loss = train_step(state, batch)
            epoch_loss += loss
            steps += 1
            if steps % 100 == 0:
                print(f"[Epoch {epoch}] Step {steps}, Avg Loss: {epoch_loss/steps:.3f}")
        # Evaluation
        correct, total = 0, 0
        for batch in test_ds:
            _, acc = compute_metrics(state.params, batch)
            batch_size = batch['image'].shape[0]
            correct += acc * batch_size
            total += batch_size
        print(f"Epoch {epoch} — Test Accuracy: {100 * correct / total:.2f}%")

    return state

# ---------------------------
# 6) Entry Point
# ---------------------------
if __name__ == "__main__":
    final_state = train_and_evaluate()
    # To save parameters:
    import pickle
    with open('lenet_flax_params.pkl', 'wb') as f:
        pickle.dump(final_state.params, f)
