import os
import random
import h5py
import pandas as pd
import numpy as np
import jax.numpy as jnp

def default_loader(path: str):
    """Load a single HDF5 file and normalize to [0,1]."""
    with h5py.File(path, 'r') as f:
        imgA = f['input'][:]    # NumPy array
        imgB = f['output'][:]
    # convert to floats in [0,1] and then to jnp arrays
    return jnp.array(imgA / 255.0), jnp.array(imgB / 255.0)

class RadarsDataset:
    """
    JAX-friendly dataset for radar HDF5 files.
    Reads file paths from a CSV (column 'filename') or directory listing.
    """
    def __init__(
        self,
        csv_file: str = '3_data.csv',
        data_path: str = '/ldata/radar_20d_2000/',
        length: int = -1,
        shuffle: bool = False,
        seed: int = None,
    ):
        # 1) load file list from CSV
        df = pd.read_csv(csv_file)
        all_files = df['filename'].tolist()

        # 2) optionally truncate
        if length > 0:
            all_files = all_files[:length]

        # 3) optionally shuffle
        if shuffle:
            rng = random.Random(seed)
            rng.shuffle(all_files)

        self.image_list = all_files
        self.data_path = data_path

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, idx: int):
        # build full path and load
        fname = self.image_list[idx]
        path = os.path.join(self.data_path, fname)
        imgA, imgB = default_loader(path)
        return imgA, imgB

    def as_numpy_iterator(self):
        """Returns a simple Python iterator yielding NumPy arrays."""
        for idx in range(len(self)):
            a, b = self[idx]
            yield np.array(a), np.array(b)
