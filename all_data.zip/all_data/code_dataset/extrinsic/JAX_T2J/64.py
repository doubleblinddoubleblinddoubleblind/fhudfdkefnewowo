# jax_translation.py

import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Optional


################################################################################
# Modules #
################################################################################

class StackedBRNN(nn.Module):
    input_size: int
    hidden_size: int
    num_layers: int
    dropout_rate: float = 0.0
    dropout_output: bool = False
    variational_dropout: bool = False
    rnn_type: nn.Module = nn.LSTMCell
    concat_layers: bool = False
    padding: bool = False
    bidirectional: bool = True
    return_single_timestep: bool = False

    @nn.compact
    def __call__(self, x, x_mask, train: bool = False):
        # decide padded vs. unpadded path
        if self.padding or self.return_single_timestep or not train:
            return self._forward_padded(x, x_mask, train)
        else:
            return self._forward_unpadded(x, x_mask, train)

    def _apply_dropout(self, y, train: bool):
        if self.dropout_rate == 0 or not train:
            return y
        dropout_layer = nn.Dropout(rate=self.dropout_rate, broadcast_dims=(1,) if self.variational_dropout else ())
        return dropout_layer(y, deterministic=not train)

    def _forward_unpadded(self, x, x_mask, train: bool):
        outputs = [x]
        for i in range(self.num_layers):
            y = outputs[-1]
            y = self._apply_dropout(y, train)
            # single-layer RNN cell wrapped in scan
            cell_fw = self.rnn_type(name=f"rnn_fw_{i}")
            if self.bidirectional:
                cell_bw = self.rnn_type(name=f"rnn_bw_{i}")
                # forward scan
                carry_fw = cell_fw.initialize_carry(jax.random.PRNGKey(0), x.shape[0], self.hidden_size)
                out_fw, _ = nn.scan(cell_fw, variable_broadcast="params", split_rngs={"params": False},
                                    length=y.shape[1], reverse=False)(carry_fw, y)
                # backward scan
                carry_bw = cell_bw.initialize_carry(jax.random.PRNGKey(1), x.shape[0], self.hidden_size)
                out_bw, _ = nn.scan(cell_bw, variable_broadcast="params", split_rngs={"params": False},
                                    length=y.shape[1], reverse=True)(carry_bw, y)
                rnn_output = jnp.concatenate([out_fw, out_bw], axis=-1)
            else:
                carry = cell_fw.initialize_carry(jax.random.PRNGKey(i), x.shape[0], self.hidden_size)
                rnn_output, _ = nn.scan(cell_fw, variable_broadcast="params", split_rngs={"params": False},
                                        length=y.shape[1])(carry, y)
            outputs.append(rnn_output)

        if self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=-1)
        else:
            output = outputs[-1]

        if self.dropout_output:
            output = self._apply_dropout(output, train)
        return output

    def _forward_padded(self, x, x_mask, train: bool):
        # x_mask == 0 for real tokens
        lengths = jnp.sum((x_mask == 0), axis=1)
        # sort batch descending
        idx_sort = jnp.argsort(lengths)[::-1]
        idx_unsort = jnp.argsort(idx_sort)
        x_sorted = x[idx_sort]

        outputs = [x_sorted]
        single_outputs = []
        for i in range(self.num_layers):
            y = outputs[-1]
            y = self._apply_dropout(y, train)
            # pack/unpack manually via mask
            # (for simplicity, here we just apply the same scan but could skip masked timesteps)
            cell_fw = self.rnn_type(name=f"rnn_fw_{i}")
            carry = cell_fw.initialize_carry(jax.random.PRNGKey(i), x.shape[0], self.hidden_size)
            rnn_output, final_state = nn.scan(cell_fw, variable_broadcast="params", split_rngs={"params": False},
                                              length=y.shape[1])(carry, y)
            single_outputs.append(final_state[0])  # take hidden
            outputs.append(rnn_output)

        if self.return_single_timestep:
            output = single_outputs[-1]
        elif self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=-1)
        else:
            output = outputs[-1]

        output = output[idx_unsort]
        if self.dropout_output:
            output = self._apply_dropout(output, train)
        return output


class SeqAttnMatch(nn.Module):
    input_size: int
    identity: bool = False

    def setup(self):
        if not self.identity:
            self.linear = nn.Dense(self.input_size)
        else:
            self.linear = None

    def __call__(self, x, y, y_mask):
        # project
        def proj(z):
            if self.linear:
                z = self.linear(z)
                z = nn.relu(z)
            return z

        x_proj = proj(x)
        y_proj = proj(y)

        # scores: [B, L1, L2]
        scores = jnp.einsum('bih,bjh->bij', x_proj, y_proj)

        # mask invalid positions
        mask = y_mask[:, None, :]
        scores = jnp.where(mask, -1e9, scores)

        alpha = nn.softmax(scores, axis=-1)
        matched = jnp.einsum('bij,bjh->bih', alpha, y)
        return matched


class BilinearSeqAttn(nn.Module):
    x_size: int
    y_size: int
    identity: bool = False

    def setup(self):
        if not self.identity:
            self.linear = nn.Dense(self.x_size)
        else:
            self.linear = None

    def __call__(self, x, y, x_mask):
        Wy = self.linear(y) if self.linear else y
        # [B, L]
        scores = jnp.einsum('bih,bh->bi', x, Wy)
        scores = jnp.where(x_mask, -1e9, scores)
        log_alpha = nn.log_softmax(scores, axis=-1)
        return log_alpha


class LinearSeqAttn(nn.Module):
    input_size: int

    def setup(self):
        self.linear = nn.Dense(1)

    def __call__(self, x, x_mask):
        # [B, L, 1] -> [B, L]
        scores = self.linear(x).squeeze(-1)
        scores = jnp.where(x_mask, -1e9, scores)
        alpha = nn.softmax(scores, axis=-1)
        return alpha


################################################################################
# Functional #
################################################################################

def dropout_fn(x: jnp.ndarray, drop_prob: float, shared_axes: Sequence[int] = (), train: bool = False):
    if drop_prob == 0 or not train:
        return x
    # Flax Dropout wants RNG; here assume called within module
    mask_shape = list(x.shape)
    for ax in shared_axes:
        mask_shape[ax] = 1
    keep = jax.random.bernoulli(jax.random.PRNGKey(0), 1.0 - drop_prob, mask_shape)
    keep = keep.astype(x.dtype) / (1.0 - drop_prob)
    keep = jnp.broadcast_to(keep, x.shape)
    return x * keep

def multi_nll_loss(scores: jnp.ndarray, target_mask: jnp.ndarray) -> jnp.ndarray:
    probs = jnp.exp(scores)
    def single_loss(p, m):
        sel = p[m == 1]
        return -jnp.log(jnp.sum(sel) / jnp.sum(p))
    losses = jax.vmap(single_loss)(probs, target_mask)
    return jnp.sum(losses)

def uniform_weights(x: jnp.ndarray, x_mask: jnp.ndarray) -> jnp.ndarray:
    # returns mask-normalized uniform weights
    valid = 1 - x_mask  # assume mask is 1 for padding
    lengths = jnp.sum(valid, axis=1, keepdims=True)
    return valid / lengths

def weighted_avg(x: jnp.ndarray, weights: jnp.ndarray) -> jnp.ndarray:
    # [B, L, D], [B, L] -> [B, D]
    return jnp.einsum('bld,bl->bd', x, weights)
