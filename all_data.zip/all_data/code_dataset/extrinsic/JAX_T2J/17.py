import os
import sys
import logging
from functools import partial

import jax
import jax.numpy as jnp
from jax import jit
import numpy as np

from transformers import (
    FlaxBertForSequenceClassification,
    BertTokenizer,
)
from datasets import load_dataset, load_metric

# --------------------------------------------------
# Configuration (from command-line args / defaults)
# --------------------------------------------------
TASK_NAME = sys.argv[1]
MODE = sys.argv[2]  # 'reg' or 'cla'

OUTPUT_MODE = 'regression' if MODE == 'reg' else 'classification'
OUTPUT_DIR = f'outputs/{TASK_NAME}{"_reg" if MODE=="reg" else ""}/'
REPORTS_DIR = f'reports/{TASK_NAME}{"_reg" if MODE=="reg" else ""}/'
CACHE_DIR = 'cache/'
MAX_SEQ_LENGTH = 512
EVAL_BATCH_SIZE = 8

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --------------------------------------------------
# Initialize tokenizer & model
# --------------------------------------------------
tokenizer = BertTokenizer.from_pretrained(os.path.join(OUTPUT_DIR, 'vocab.txt'),
                                          do_lower_case=True)
model = FlaxBertForSequenceClassification.from_pretrained(
    OUTPUT_DIR,
    cache_dir=CACHE_DIR,
    num_labels=1 if OUTPUT_MODE=='regression' else None,
)

# --------------------------------------------------
# Load evaluation data via 🤗 datasets
# --------------------------------------------------
dataset = load_dataset('csv', data_files={ 'eval': f'data/{TASK_NAME}/eval.tsv' }, delimiter='\t')
# Assume eval.tsv has columns: sentence, label
def preprocess(batch):
    enc = tokenizer(batch['sentence'], truncation=True, padding='max_length',
                    max_length=MAX_SEQ_LENGTH)
    batch['input_ids'] = enc['input_ids']
    batch['attention_mask'] = enc['attention_mask']
    return batch

eval_ds = dataset['eval'].map(preprocess, batched=True)
eval_ds = eval_ds.remove_columns(['sentence']).with_format('numpy')

# --------------------------------------------------
# Evaluation step
# --------------------------------------------------
@partial(jit, static_argnums=0)
def eval_step(model, params, batch):
    outputs = model.apply({'params': params},
                          input_ids=batch['input_ids'],
                          attention_mask=batch['attention_mask'],
                          train=False)
    logits = outputs.logits
    return logits

# --------------------------------------------------
# Run evaluation
# --------------------------------------------------
params = model.params
all_logits = []
all_labels = []

for start in range(0, len(eval_ds['input_ids']), EVAL_BATCH_SIZE):
    batch = {
        'input_ids': jnp.array(eval_ds['input_ids'][start:start+EVAL_BATCH_SIZE]),
        'attention_mask': jnp.array(eval_ds['attention_mask'][start:start+EVAL_BATCH_SIZE]),
    }
    labels = eval_ds['label'][start:start+EVAL_BATCH_SIZE]
    logits = np.array(eval_step(model, params, batch))
    all_logits.append(logits)
    all_labels.append(labels)

all_logits = np.concatenate(all_logits, axis=0)
all_labels = np.concatenate(all_labels, axis=0)

# --------------------------------------------------
# Post-process predictions
# --------------------------------------------------
if OUTPUT_MODE == 'classification':
    # assume binary classification: take argmax
    preds = np.argmax(all_logits, axis=-1)
    metric = load_metric('accuracy')
    accuracy = metric.compute(predictions=preds, references=all_labels)['accuracy']
    report = {
        'task': TASK_NAME,
        'accuracy': accuracy,
    }
else:
    # regression: logits are shape (N,1)
    preds = all_logits.squeeze(-1)
    from sklearn.metrics import mean_squared_error
    mse = mean_squared_error(all_labels, preds)
    report = {
        'task': TASK_NAME,
        'mse': mse,
    }

# --------------------------------------------------
# Save outputs
# --------------------------------------------------
os.makedirs(REPORTS_DIR, exist_ok=True)
preds_path = os.path.join(REPORTS_DIR, 'predictions.tsv')
with open(preds_path, 'w') as f:
    for label, pred in zip(all_labels, preds):
        f.write(f"{label}\t{pred}\n")

# Save report
import json
with open(os.path.join(REPORTS_DIR, 'eval_results.json'), 'w') as f:
    json.dump(report, f, indent=2)

logger.info("***** Eval results *****")
for k, v in report.items():
    logger.info("  %s = %s", k, v)
