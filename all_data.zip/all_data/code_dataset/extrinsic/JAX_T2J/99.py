import os
from copy import deepcopy
from itertools import chain
import warnings

import jax
import jax.numpy as jnp
import tensorflow_datasets as tfds

from utils.regime import Regime
from utils.dataset import IndexedFileDataset
from preprocess import get_transform

warnings.filterwarnings("ignore", "(Possibly )?corrupt EXIF data", UserWarning)


_DATA_ARGS = {'name', 'split', 'transform', 'target_transform', 'download', 'datasets_path'}
_DATALOADER_ARGS = {'batch_size', 'shuffle', 'num_parallel_calls'}
_TRANSFORM_ARGS = {'transform_name', 'input_size', 'scale_size', 'normalize', 'augment',
                   'cutout', 'duplicates', 'num_crops', 'autoaugment'}
_OTHER_ARGS = {'distributed'}


def get_dataset(name,
                split='train',
                transform=None,
                target_transform=None,
                download=True,
                datasets_path='~/Datasets'):
    """
    Load a standard vision dataset via TensorFlow Datasets.
    """
    ds_name = {
        'cifar10': 'cifar10',
        'cifar100': 'cifar100',
        'mnist': 'mnist',
        'stl10': 'stl10',
        'imagenet': 'imagenet2012',
    }[name]
    tf_split = split if name != 'imagenet' else ('train' if split=='train' else 'validation')
    ds = tfds.load(ds_name,
                   split=tf_split,
                   data_dir=os.path.expanduser(datasets_path),
                   download=download)
    # map to (image, label) and apply transforms
    def _prep(example):
        img = example['image']
        lbl = example.get('label', example.get('fine_label'))
        img = transform(img) if transform else img
        lbl = target_transform(lbl) if target_transform else lbl
        return img, lbl

    return ds.map(_prep, num_parallel_calls=tf.data.AUTOTUNE)


class DataRegime:
    def __init__(self, regime_cfg, defaults=None):
        self.regime = Regime(regime_cfg, deepcopy(defaults or {}))
        self.epoch = 0
        self.steps = None
        self._build_loader(force_update=True)

    def _get_setting(self):
        s = self.regime.setting
        data_kw = {k: s[k] for k in s if k in _DATA_ARGS}
        loader_kw = {k: s[k] for k in s if k in _DATALOADER_ARGS}
        transform_kw = {k: s[k] for k in s if k in _TRANSFORM_ARGS}
        other_kw = {k: s[k] for k in s if k in _OTHER_ARGS}
        transform_kw.setdefault('transform_name', data_kw['name'])
        return data_kw, loader_kw, transform_kw, other_kw

    def get(self, key, default=None):
        return self.regime.setting.get(key, default)

    def _build_loader(self, force_update=False, override=None, subset_indices=None):
        if force_update or self.regime.update(self.epoch, self.steps):
            data_kw, loader_kw, transform_kw, other_kw = self._get_setting()
            if override:
                data_kw.update(override.get('data', {}))
                loader_kw.update(override.get('loader', {}))
            # build transforms
            transform_fn = get_transform(**transform_kw)
            data_kw.setdefault('transform', transform_fn)
            ds = get_dataset(**data_kw)

            if subset_indices is not None:
                ds = ds.enumerate().filter(lambda i, x: i in subset_indices).map(lambda i, x: x)

            if other_kw.get('distributed', False):
                # for multi-device training you might shard here
                pass

            # shuffle, batch, prefetch
            if loader_kw.get('shuffle', True):
                ds = ds.shuffle(10_000, seed=self.epoch)
            ds = ds.batch(loader_kw.get('batch_size', 32))
            ds = ds.prefetch(tf.data.AUTOTUNE)

            # keep for epoch length
            self._steps = None  # let tfds handle
            self._loader = tfds.as_numpy(ds)

        return self._loader

    def get_loader(self, *args, **kw):
        return self._build_loader(*args, **kw)

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __len__(self):
        # length unknown without iterating; placeholder
        return 0

    def __repr__(self):
        return str(self.regime)


class SampledDataLoader:
    def __init__(self, loaders, seed=0):
        self.loaders = loaders
        self.epoch = 0
        self.seed = seed

    def __iter__(self):
        # generate a global ordering
        sizes = [sum(1 for _ in loader) for loader in self.loaders]
        total = sum(sizes)
        key = jax.random.PRNGKey(self.epoch + self.seed)
        perm = jax.random.permutation(key, total).tolist()

        iterators = [iter(loader) for loader in self.loaders]
        idx_offsets = list(jax.numpy.cumsum(jnp.array([0] + sizes)))
        for p in perm:
            # find which loader p falls in
            i = next(i for i, o in enumerate(idx_offsets[:-1]) if idx_offsets[i] <= p < idx_offsets[i+1])
            yield next(iterators[i])

    def __len__(self):
        return sum(sum(1 for _ in loader) for loader in self.loaders)


class SampledDataRegime:
    def __init__(self, regime_list, probs, split_data=True):
        self.regime_list = regime_list
        self.probs = probs
        self.split_data = split_data
        self.epoch = 0

    def get_setting(self):
        return [r._get_setting() for r in self.regime_list]

    def get(self, key, default=None):
        return [r.get(key, default) for r in self.regime_list]

    def get_loader(self, force_update=False):
        if self.split_data:
            # assume equal-sized datasets
            dsizes = [sum(1 for _ in get_dataset(**s[0])) for s in self.get_setting()]
            N = dsizes[0]
            lengths = [int(p * N) for p in self.probs]
            lengths[-1] = N - sum(lengths[:-1])
            key = jax.random.PRNGKey(self.epoch)
            perm = jax.random.permutation(key, N).tolist()
            splits = []
            offset = 0
            for L in lengths:
                splits.append(perm[offset:offset+L])
                offset += L
            loaders = [
                r._build_loader(force_update=True, subset_indices=splits[i])
                for i, r in enumerate(self.regime_list)
            ]
        else:
            loaders = [r.get_loader(force_update) for r in self.regime_list]

        sd = SampledDataLoader(loaders, seed=self.epoch)
        sd.epoch = self.epoch
        return sd

    def set_epoch(self, epoch):
        self.epoch = epoch
        for r in self.regime_list:
            r.set_epoch(epoch)

    def __repr__(self):
        return f"SampledDataRegime(probs={self.probs}, regimes={self.regime_list})"


if __name__ == '__main__':
    # example
    reg1 = DataRegime({'name': 'imagenet', 'batch_size': 16})
    reg2 = DataRegime({'name': 'imagenet', 'batch_size': 32})
    reg1.set_epoch(0)
    reg2.set_epoch(0)
    mreg = SampledDataRegime([reg1, reg2], probs=[0.5, 0.5])
    for batch in mreg.get_loader():
        images, labels = batch
        print(images.shape, labels.shape)
