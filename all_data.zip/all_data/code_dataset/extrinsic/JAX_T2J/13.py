import jax
import jax.numpy as jnp

def dot(a: jnp.ndarray, b: jnp.ndarray) -> jnp.ndarray:
    """
    Compute the batch‐wise dot product between two tensors of shape
    (B, M, D) and (B, N, D), returning (B, M, N).
    """
    # Equivalent to PyTorch's a.bmm(b.transpose(1,2))
    return jnp.einsum('bmd,bnd->bmn', a, b)

class Attention:
    """
    Simple attention mechanism in JAX, mirroring the PyTorch version.
    """

    def __init__(self):
        pass

    def __call__(
        self,
        query: jnp.ndarray,    # (B, M, D)
        key:   jnp.ndarray,    # (B, N, D)
        value: jnp.ndarray     # (B, N, D)
    ) -> tuple[jnp.ndarray, jnp.ndarray]:
        # sanity checks (you can remove in JIT’d code)
        assert query.shape[0] == key.shape[0] == value.shape[0], "Batch sizes must match"
        assert query.shape[2] == key.shape[2] == value.shape[2], "Feature dims must match"

        B, M, D = query.shape
        _, N, _ = key.shape

        # compute raw scores: (B, M, N)
        scores = dot(query, key)

        # scaling: sqrt(1/D)
        scaling = jnp.sqrt(1.0 / D)

        # attention weights: softmax over the key dimension
        alpha = jax.nn.softmax(scores * scaling, axis=-1)

        # weighted sum of values: (B, M, N) @ (B, N, D) → (B, M, D)
        out = jnp.einsum('bmn,bnd->bmd', alpha, value)

        return out, alpha
