import jax
import jax.numpy as jnp
from flax import linen as nn
import dgl
from dgl.nn.jax import PAIRConv  # DGL’s JAX-compatible pairwise conv
from dgl.nn.jax import GATConv   # if you also need GATConv elsewhere

class PAIRGAT(nn.Module):
    num_layers: int
    in_dim: int
    num_hidden: int
    num_classes: int
    num_heads: int
    num_out_heads: int
    feat_drop: float
    attn_drop: float
    negative_slope: float = 0.2
    residual: bool = False
    allow_zero_in_degree: bool = True
    return_attention: bool = False

    @nn.compact
    def __call__(self, g: dgl.DGLGraph, inputs: jnp.ndarray):
        """
        g: DGLGraph
        inputs: [N, in_dim] node features
        returns: [N, num_classes]
        """
        h = inputs
        # input layer
        h = PAIRConv(
            in_feats=self.in_dim,
            out_feats=self.num_hidden,
            num_heads=self.num_heads,
            feat_drop=self.feat_drop,
            attn_drop=self.attn_drop,
            negative_slope=self.negative_slope,
            activation=lambda x: x,            # apply activation after flatten
            allow_zero_in_degree=self.allow_zero_in_degree,
            return_attention=self.return_attention,
            name="pairconv_0"
        )(g, h)
        # flatten head dimension
        h = h.reshape(h.shape[0], -1)

        # hidden layers
        for l in range(1, self.num_layers):
            h = PAIRConv(
                in_feats=(self.num_hidden + 1) * self.num_heads,
                out_feats=self.num_hidden,
                num_heads=self.num_heads,
                feat_drop=self.feat_drop,
                attn_drop=self.attn_drop,
                negative_slope=self.negative_slope,
                activation=lambda x: x,
                allow_zero_in_degree=self.allow_zero_in_degree,
                return_attention=self.return_attention,
                name=f"pairconv_{l}"
            )(g, h)
            h = h.reshape(h.shape[0], -1)

        # output projection
        logits = nn.Dense(
            features=self.num_classes,
            use_bias=True,
            name="output_dense"
        )(h)
        return logits

# Example of initialization and forward pass:
def main():
    import numpy as np

    # Create a random DGL graph and features
    g = dgl.rand_graph(100, 300)  # 100 nodes, 300 edges
    X = jnp.array(np.random.randn(100, 16), dtype=jnp.float32)

    # Instantiate the model
    model = PAIRGAT(
        num_layers=3,
        in_dim=16,
        num_hidden=32,
        num_classes=5,
        num_heads=4,
        num_out_heads=1,
        feat_drop=0.2,
        attn_drop=0.2
    )

    # Initialize parameters
    rng = jax.random.PRNGKey(0)
    params = model.init(rng, g, X)

    # Forward
    logits = model.apply(params, g, X)
    print("Logits shape:", logits.shape)  # should be (100, 5)

if __name__ == "__main__":
    main()
