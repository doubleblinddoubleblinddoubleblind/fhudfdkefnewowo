import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Any

def LayerNorm(normalized_shape: Sequence[int],
              eps: float = 1e-5,
              elementwise_affine: bool = True,
              export: bool = False) -> nn.Module:
    """
    Factory matching PyTorch LayerNorm/export logic.
    In JAX we always trace, so export flag is ignored.
    """
    return nn.LayerNorm(
        axis=tuple(range(-len(normalized_shape), 0)),
        epsilon=eps,
        use_scale=elementwise_affine,
        use_bias=elementwise_affine,
    )

class Fp32LayerNorm(nn.Module):
    """
    Always cast to float32 for normalization, then cast back to input dtype.
    Mirrors your PyTorch Fp32LayerNorm logic.
    """
    normalized_shape: Sequence[int]
    eps: float = 1e-5
    elementwise_affine: bool = True

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        orig_dtype = x.dtype
        x32 = x.astype(jnp.float32)
        ln = nn.LayerNorm(
            axis=tuple(range(-len(self.normalized_shape), 0)),
            epsilon=self.eps,
            use_scale=self.elementwise_affine,
            use_bias=self.elementwise_affine,
        )
        y32 = ln(x32)
        return y32.astype(orig_dtype)
