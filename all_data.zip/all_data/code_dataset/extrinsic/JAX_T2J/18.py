import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.core import freeze, unfreeze
import optax
from typing import Any, Sequence, Tuple
from functools import partial

# --------------------------------------------------
# Vision module
# --------------------------------------------------
class VisionM(nn.Module):
    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        # x: [batch, 3, 84,84]
        x = nn.Conv(32, (8, 8), strides=(4, 4), name="conv1")(x)
        x = nn.Conv(64, (4, 4), strides=(2, 2), name="conv2")(x)
        x = nn.Conv(64, (3, 3), strides=(1, 1), name="conv3")(x)
        return x  # [batch, 64,7,7]

# --------------------------------------------------
# Language module
# --------------------------------------------------
class LanguageM(nn.Module):
    vocab_size: int = 10
    embed_dim:  int = 128
    hidden_size:int = 128

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        # x: [batch, seq_len]
        emb = nn.Embed(self.vocab_size, self.embed_dim, name="embed")(x)
        # run one-layer LSTM
        lstm = nn.LSTMCell(name="lstm")
        h = jnp.zeros((x.shape[0], self.hidden_size))
        c = jnp.zeros_like(h)
        for t in range(emb.shape[1]):
            h, c = lstm(h, c, emb[:, t, :])
        return h  # return final hidden

    def LP(self, emb_input: jnp.ndarray, params: Any) -> jnp.ndarray:
        # linear projection using embedding weights
        w = params["params"]["embed"]["embedding"]  # [vocab, emb]
        return emb_input @ w.T

# --------------------------------------------------
# Mixing module
# --------------------------------------------------
class MixingM(nn.Module):
    @nn.compact
    def __call__(self, visual: jnp.ndarray, instr: jnp.ndarray) -> jnp.ndarray:
        # visual: [batch,64,7,7] → flatten
        v = visual.reshape((visual.shape[0], -1))
        # instr: [batch, hidden] → already flat
        return jnp.concatenate([v, instr], axis=-1)

# --------------------------------------------------
# Action module (two LSTMCells)
# --------------------------------------------------
class ActionM(nn.Module):
    hidden_size: int = 256

    def setup(self):
        self.lstm1 = nn.LSTMCell(name="lstm1")
        self.lstm2 = nn.LSTMCell(name="lstm2")
        # carry states stored external to module

    def __call__(
        self,
        x: jnp.ndarray,
        carry1: Tuple[jnp.ndarray,jnp.ndarray],
        carry2: Tuple[jnp.ndarray,jnp.ndarray]
    ) -> Tuple[jnp.ndarray, Tuple, Tuple]:
        # x: [batch, input=3264]
        h1, c1 = self.lstm1(carry1[0], carry1[1], x)
        h2, c2 = self.lstm2(carry2[0], carry2[1], h1)
        return h2, (h1, c1), (h2, c2)

# --------------------------------------------------
# Policy network
# --------------------------------------------------
class PolicyNet(nn.Module):
    action_space: int

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> Tuple[jnp.ndarray,jnp.ndarray]:
        # x: [batch, 256]
        x = nn.relu(nn.Dense(128, name="affine1")(x))
        logits = nn.Dense(self.action_space, name="action_head")(x)
        value  = nn.Dense(1,              name="value_head")(x)
        return logits, value

    def tAE(self, logits: jnp.ndarray, params: Any) -> jnp.ndarray:
        # temporal autoencoder head: invert the action_head linear
        w = params["params"]["action_head"]["kernel"]  # [128,action_space]
        b = params["params"]["action_head"]["bias"]    # [action_space]
        # subtract bias and multiply by wᵀ
        out = (logits - b) @ w.T
        return out  # [batch,128]

# --------------------------------------------------
# Temporal AutoEncoder
# --------------------------------------------------
class TemporalAutoEncoder(nn.Module):
    policy: PolicyNet
    vision: VisionM

    @nn.compact
    def __call__(self, visual: jnp.ndarray, action_logits: jnp.ndarray, params: Any) -> jnp.ndarray:
        # visual: [batch,3,84,84]
        v_enc = self.vision(visual)
        # tAE projection
        a_proj = self.policy.tAE(action_logits, params)
        # expand & reshape
        x = nn.Dense(64*7*7, name="linear1")(a_proj)
        x = x.reshape((x.shape[0],64,7,7))
        mix = x * v_enc
        # deconv
        x = nn.ConvTranspose(64,(3,3), strides=(1,1), name="deconv1")(mix)
        x = nn.ConvTranspose(32,(4,4), strides=(2,2), name="deconv2")(x)
        x = nn.ConvTranspose(3, (8,8), strides=(4,4), name="deconv3")(x)
        return x

# --------------------------------------------------
# Language Prediction
# --------------------------------------------------
class LanguagePrediction(nn.Module):
    lang_module: LanguageM

    @nn.compact
    def __call__(self, v_enc: jnp.ndarray, params: Any) -> jnp.ndarray:
        v_flat = v_enc.reshape((v_enc.shape[0], -1))
        x = nn.relu(nn.Dense(128,name="vision_transform")(v_flat))
        return self.lang_module.LP(x, params)

# --------------------------------------------------
# Reward predictor
# --------------------------------------------------
class RewardPredictor(nn.Module):
    vision: VisionM
    language: LanguageM
    mixing: MixingM

    def setup(self):
        self.linear = nn.Dense(1, name="reward_linear")

    def __call__(self, batches: Sequence[Any], params: Any) -> jnp.ndarray:
        # batches: list of length T, each is batch of transitions with .visual and .instruction
        visuals = jnp.concatenate([jnp.stack([b.visual for b in batch],axis=0)
                                   for batch in batches], axis=0)
        instrs  = jnp.concatenate([jnp.stack([b.instruction for b in batch],axis=0)
                                   for batch in batches], axis=0)
        v_enc = self.vision(visuals)
        i_enc = self.language(instrs)
        mix   = self.mixing(v_enc, i_enc)
        # reshape to [T, batch_mixed]
        mix = mix.reshape((len(batches), -1))
        return self.linear(mix)

# --------------------------------------------------
# Example of initializing & running
# --------------------------------------------------
def initialize_all(rng: jax.random.PRNGKey) -> Tuple:
    rng, vkey, lkey = jax.random.split(rng, 3)
    dummy_img = jnp.zeros((1,3,84,84))
    dummy_txt = jnp.zeros((1,10), dtype=jnp.int32)

    vision = VisionM()
    v_params = vision.init(vkey, dummy_img)

    language = LanguageM()
    l_params = language.init(lkey, dummy_txt)

    policy = PolicyNet(action_space=4)  # e.g. 4 actions
    p_params = policy.init(rng, jnp.zeros((1,256)))

    mixing = MixingM()
    m_params = mixing.init(rng, jnp.zeros((1,64,7,7)), jnp.zeros((1,128)))

    tae = TemporalAutoEncoder(policy=policy, vision=vision)
    tae_params = tae.init(rng, dummy_img, jnp.zeros((1,4)), 
                          {"params":{**p_params["params"], **v_params["params"]}})

    langpred = LanguagePrediction(lang_module=language)
    lp_params = langpred.init(rng, jnp.zeros((1,64,7,7)),
                              {"params":l_params["params"]})

    reward = RewardPredictor(vision=vision, language=language, mixing=mixing)
    # dummy batch struct: replace with actual dataclass with .visual/.instruction
    RewardParams = reward.init(rng, [[type("B",(object,),{"visual":dummy_img, "instruction":dummy_txt})]*3])

    return (v_params, l_params, p_params, m_params, tae_params, lp_params, RewardParams)

# --------------------------------------------------
# You’d then set up optimizers via Optax, write training loops, etc.
# --------------------------------------------------
