import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Optional, Callable

# Base encoder module
class CNNEncoderBase(nn.Module):
    model: nn.Module
    context_size: int
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None
    spatial_context: bool = True

    @nn.compact
    def __call__(self, x):
        # Extract features from pretrained backbone
        x = self.model(x)
        # If not using spatial context, global average pool
        if not self.spatial_context:
            x = jnp.mean(x, axis=(1, 2))  # shape: (batch, features)
        # Apply optional context transform (Conv or Dense)
        if self.context_transform is not None:
            x = self.context_transform(x)
        # Apply optional nonlinearity
        if self.context_nonlinearity is not None:
            x = self.context_nonlinearity(x)
        return x

# Specific encoders using Flax pretrained models
# Note: assumes availability of flaxmodels or similar library providing these models without classifier heads
from flaxmodels import ResNet50, DenseNet121, VGG16, AlexNet, SqueezeNet1_1

class ResNetEncoder(nn.Module):
    pretrained: bool = True
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None
    spatial_context: bool = True

    def setup(self):
        # Load backbone without top classification head
        self.backbone = ResNet50(pretrained=self.pretrained, num_classes=None)
        self.context_size = self.backbone.num_features
        if self.context_transform is not None and not self.spatial_context:
            # use Dense layer for non-spatial
            self.context_dense = nn.Dense(self.context_transform)
        elif self.context_transform is not None:
            # use 1x1 Conv for spatial context
            self.context_conv = nn.Conv(self.context_transform, kernel_size=(1,1))

    def __call__(self, x):
        # Forward through ResNet backbone
        x = self.backbone(x)
        if not self.spatial_context:
            x = jnp.mean(x, axis=(1,2))
        if hasattr(self, 'context_conv'):
            # Conv2D expects NHWC by default; ensure x is (N,H,W,C) or adjust
            x = self.context_conv(x)
        if hasattr(self, 'context_dense'):
            x = self.context_dense(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x

# Similarly define other encoders
class DenseNetEncoder(nn.Module):
    pretrained: bool = True
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None
    spatial_context: bool = True

    def setup(self):
        self.backbone = DenseNet121(pretrained=self.pretrained, num_classes=None)
        self.context_size = self.backbone.num_features
        if self.context_transform is not None and not self.spatial_context:
            self.context_dense = nn.Dense(self.context_transform)
        elif self.context_transform is not None:
            self.context_conv = nn.Conv(self.context_transform, kernel_size=(1,1))

    def __call__(self, x):
        # Flax DenseNet feature extractor
        x = self.backbone.features(x)
        x = nn.relu(x)
        if not self.spatial_context:
            x = jnp.mean(x, axis=(1,2))
        if hasattr(self, 'context_conv'):
            x = self.context_conv(x)
        if hasattr(self, 'context_dense'):
            x = self.context_dense(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x

class VGGEncoder(nn.Module):
    pretrained: bool = True
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None

    def setup(self):
        self.backbone = VGG16(pretrained=self.pretrained, num_classes=None)
        self.context_size = self.backbone.num_features
        if self.context_transform is not None:
            self.context_dense = nn.Dense(self.context_transform)

    def __call__(self, x):
        x = self.backbone.features(x)
        if self.context_transform is not None:
            x = self.context_dense(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x

class AlexNetEncoder(nn.Module):
    pretrained: bool = True
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None

    def setup(self):
        self.backbone = AlexNet(pretrained=self.pretrained, num_classes=None)
        self.context_size = self.backbone.num_features
        if self.context_transform is not None:
            self.context_dense = nn.Dense(self.context_transform)

    def __call__(self, x):
        x = self.backbone.features(x)
        if self.context_transform is not None:
            x = self.context_dense(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x

class SqueezeNetEncoder(nn.Module):
    pretrained: bool = True
    context_transform: Optional[nn.Module] = None
    context_nonlinearity: Optional[Callable] = None

    def setup(self):
        self.backbone = SqueezeNet1_1(pretrained=self.pretrained, num_classes=None)
        self.context_size = self.backbone.num_features
        if self.context_transform is not None:
            self.context_dense = nn.Dense(self.context_transform)

    def __call__(self, x):
        x = self.backbone.features(x)
        if self.context_transform is not None:
            x = self.context_dense(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x
