import numpy as np
import jax
import jax.numpy as jnp
from jax import vmap
from typing import Tuple

# 1) Prepare the raw input lists
inputs = [
    [[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]],
    [[13, 14, 15, 16]]
]
batch_size = len(inputs)
seq_lengths = jnp.array([len(seq) for seq in inputs])   # [3, 1]
max_len = int(seq_lengths.max())
feature_dim = len(inputs[0][0])

# 2) Build padded tensor of shape (batch, max_len, feature_dim)
def pad_sequence(seq: np.ndarray, max_len: int) -> jnp.ndarray:
    # seq: (L, D) → padded to (max_len, D)
    L, D = seq.shape
    pad = jnp.zeros((max_len - L, D), dtype=seq.dtype)
    return jnp.concatenate([jnp.array(seq), pad], axis=0)

padded_batch = jnp.stack([
    pad_sequence(np.asarray(seq), max_len)
    for seq in inputs
])   # shape (batch, max_len, feature_dim)

# 3) Transpose to (time, batch, feature), matching PyTorch default for RNNs
seq_tensor = jnp.transpose(padded_batch, (1, 0, 2))   # (T, B, D)

# 4) "Pack": flatten out only the valid timesteps in order
#    Create a boolean mask of shape (T, B)
mask = (jnp.arange(max_len)[:, None] < seq_lengths[None, :])  # True where t < length[b]

#    Use the mask to gather all valid timesteps into one 2D array
packed = seq_tensor[mask]   # shape (sum(seq_lengths), D)

# 5) ... here you would feed `packed` into your RNN cell as a single long sequence ...

# 6) "Unpack": to reconstruct a padded sequence after RNN processing:
#    suppose `packed_out` is the RNN’s output of shape (sum(lengths), D_out)
#    we want back a tensor of shape (T, B, D_out), padding where mask is False.

def unpack_sequence(packed_out: jnp.ndarray,
                    mask: jnp.ndarray,
                    D_out: int) -> jnp.ndarray:
    """
    Rebuilds a (T, B, D_out) array from the 1D-packed `packed_out` and boolean mask.
    """
    # Flatten mask to 1D, then scatter back
    flat_indices = jnp.nonzero(mask.reshape(-1), size=mask.sum())[0]
    T, B = mask.shape
    # Initialize output with zeros
    out = jnp.zeros((T * B, D_out), packed_out.dtype)
    out = out.at[flat_indices].set(packed_out)
    return out.reshape((T, B, D_out))

# Example of unpacking:
# Let's pretend our RNN just returned the packed inputs unchanged:
packed_out = packed
D_out = packed.shape[-1]
unpadded = unpack_sequence(packed_out, mask, D_out)
# `unpadded` now has shape (T, B, D_out)

# 7) If you need the final return to be (B, T, D_out), transpose back:
unpadded_batch = jnp.transpose(unpadded, (1, 0, 2))  # (B, T, D_out)

# 8) Shapes for verification
print("Original seq_tensor shape:", seq_tensor.shape)             # (T, B, D)
print("Packed shape:", packed.shape)                             # (sum(lengths), D)
print("Unpacked shape:", unpadded.shape)                         # (T, B, D)
print("Unpacked batch shape:", unpadded_batch.shape)             # (B, T, D)
