#!/usr/bin/env python3
import argparse
import gym
import numpy as np

import jax
import jax.numpy as jnp
from jax import random, lax, value_and_grad
import flax.linen as nn
import optax

# ------------------------------
# Hyperparameters
# ------------------------------
GAMMA = 0.99
LR = 3e-2
HIDDEN_SIZE = 128

# ------------------------------
# Policy-Value Network
# ------------------------------
class ActorCritic(nn.Module):
    action_dim: int

    @nn.compact
    def __call__(self, x):
        x = nn.Dense(HIDDEN_SIZE)(x)
        x = nn.relu(x)
        logits = nn.Dense(self.action_dim)(x)
        value  = nn.Dense(1)(x)
        return logits, jnp.squeeze(value, -1)

# ------------------------------
# Utilities
# ------------------------------
def discount_rewards(rewards, gamma):
    def scan_fn(carry, r):
        cumul = r + gamma * carry
        return cumul, cumul
    # reverse‐scan, then flip back
    _, out = lax.scan(scan_fn, 0.0, rewards[::-1])
    return out[::-1]

@jax.jit
def select_action(params, obs, key):
    logits, value = ActorCritic(action_dim)(obs)
    key, subkey = random.split(key)
    action = random.categorical(subkey, logits)
    logp   = jax.nn.log_softmax(logits)[action]
    return int(action), float(logp), float(value), key

# ------------------------------
# Loss & Update
# ------------------------------
def loss_fn(params, obs_buf, act_buf, ret_buf, adv_buf, key):
    def single_loss(obs, act, ret, adv, rng):
        logits, val = ActorCritic(action_dim).apply({'params': params}, obs, rngs={'params': rng})
        logp = jax.nn.log_softmax(logits)[act]
        # policy loss (actor)
        p_loss = -logp * adv
        # value loss (critic)
        v_loss = (ret - val)**2
        return p_loss + 0.5 * v_loss

    keys = random.split(key, obs_buf.shape[0])
    # vectorize over trajectory
    losses = jax.vmap(single_loss)(obs_buf, act_buf, ret_buf, adv_buf, keys)
    return jnp.sum(losses)

@jax.jit
def update(params, opt_state, obs_buf, act_buf, ret_buf, adv_buf, key):
    (loss, grads) = value_and_grad(loss_fn)(params, obs_buf, act_buf, ret_buf, adv_buf, key)
    updates, opt_state = optimizer.update(grads, opt_state)
    new_params = optax.apply_updates(params, updates)
    return new_params, opt_state, loss

# ------------------------------
# Main Training Loop
# ------------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--gamma',       type=float, default=GAMMA)
    parser.add_argument('--seed',        type=int,   default=543)
    parser.add_argument('--render',      action='store_true')
    parser.add_argument('--log-interval',type=int,   default=10)
    args = parser.parse_args()

    # env and RNG
    env = gym.make('CartPole-v0')
    env.seed(args.seed)
    key = random.PRNGKey(args.seed)

    obs_dim    = env.observation_space.shape[0]
    action_dim = env.action_space.n

    # init network & optimizer
    dummy_obs = jnp.zeros((obs_dim,))
    model = ActorCritic(action_dim=action_dim)
    params = model.init(key, dummy_obs)['params']
    optimizer = optax.adam(LR)
    opt_state = optimizer.init(params)

    running_reward = 10.0
    episode = 0

    while True:
        obs_buf, act_buf, rew_buf, val_buf, logp_buf = [], [], [], [], []
        state = env.reset()
        ep_reward = 0.0
        done = False

        # collect one episode
        while not done:
            if args.render:
                env.render()
            key, subkey = random.split(key)
            action, logp, value, key = select_action(params, jnp.array(state), subkey)
            next_state, reward, done, _ = env.step(action)

            obs_buf.append(state)
            act_buf.append(action)
            rew_buf.append(reward)
            val_buf.append(value)
            logp_buf.append(logp)

            state = next_state
            ep_reward += reward

        # compute returns and advantages
        returns    = discount_rewards(np.array(rew_buf), args.gamma)
        values     = np.array(val_buf + [0.0])  # bootstrap zero for terminal
        advantages = returns - values[:-1]

        # batch arrays
        obs_arr = jnp.array(obs_buf)
        act_arr = jnp.array(act_buf)
        ret_arr = jnp.array(returns)
        adv_arr = jnp.array(advantages)

        # update network
        params, opt_state, loss = update(params, opt_state, obs_arr, act_arr, ret_arr, adv_arr, key)

        episode += 1
        running_reward = 0.99 * running_reward + 0.01 * ep_reward

        if episode % args.log_interval == 0:
            print(f"Episode {episode}\tLast length: {len(rew_buf)}\tAverage length: {running_reward:.2f}")

        if running_reward > env.spec.reward_threshold:
            print(f"Solved! Running reward is now {running_reward:.2f} and the last episode length was {len(rew_buf)}")
            break
