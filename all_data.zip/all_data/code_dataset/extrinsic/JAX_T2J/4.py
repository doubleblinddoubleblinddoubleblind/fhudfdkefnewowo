import os
import time
import datetime

import jax
import jax.numpy as jnp
from jax import random, lax, value_and_grad, pmap
import optax
import tensorflow as tf
import tensorflow_datasets as tfds
from flax import linen as nn
from flax.training import train_state, checkpoints

# -----------------------------------------------------------------------------
# 1) Dataset and Transforms
# -----------------------------------------------------------------------------

def get_dataset(split: str,
                dataset_name: str,
                batch_size: int,
                shuffle: bool,
                train: bool,
                seed: int):
    """Load VOC or COCO segmentation from TFDS and apply transforms."""
    ds = tfds.load(f"{dataset_name}/segmentation", split=split, data_dir="~/tfds")
    def _preprocess(example):
        image = example["image"]
        mask  = example["segmentation_mask"]
        # Resize/RandomResize
        h = tf.cast(tf.shape(image)[0], tf.float32)
        scale = tf.random.uniform([], 
                  0.5 if train else 1.0,
                  2.0 if train else 1.0)
        new_h = tf.cast(h * scale, tf.int32)
        image = tf.image.resize(image, (new_h, new_h), method="bilinear")
        mask  = tf.image.resize(mask[...,None], (new_h, new_h), method="nearest")[...,0]
        if train:
            image = tf.image.random_flip_left_right(image)
            image = tf.image.random_crop(image, [480,480,3])
            mask  = tf.image.random_crop(mask[...,None], [480,480,1])[...,0]
        else:
            image = tf.image.resize_with_crop_or_pad(image,480,480)
            mask  = tf.image.resize_with_crop_or_pad(mask[...,None],480,480)[...,0]
        image = tf.cast(image, tf.float32) / 255.0
        mean = tf.constant([0.485,0.456,0.406])
        std  = tf.constant([0.229,0.224,0.225])
        image = (image - mean) / std
        return {"image": image, "mask": tf.cast(mask, tf.int32)}
    ds = ds.map(_preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    if shuffle:
        ds = ds.shuffle(1024, seed=seed)
    ds = ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    return ds

# -----------------------------------------------------------------------------
# 2) Model Definition (FCN/DeepLab-like)
# -----------------------------------------------------------------------------

class SegmentationModel(nn.Module):
    num_classes: int
    backbone: str = "ResNet101"  # or "ResNet50", etc.

    @nn.compact
    def __call__(self, x, train: bool):
        # Example: use a simple conv net; in practice plug in a Flax pretrained backbone
        x = nn.Conv(64, (7,7), strides=(2,2), padding="SAME")(x)
        x = nn.relu(x)
        # ... add more layers or import a pretrained encoder ...
        x = nn.Conv(self.num_classes, (1,1))(x)
        # Upsample to input size
        H, W = x.shape[1], x.shape[2]
        x = jax.image.resize(x, (x.shape[0], 480, 480, self.num_classes), method="bilinear")
        return x  # logits of shape [B, H, W, C]

# -----------------------------------------------------------------------------
# 3) Loss and Metrics
# -----------------------------------------------------------------------------

def cross_entropy_loss(logits, labels):
    one_hot = jax.nn.one_hot(labels, logits.shape[-1])
    loss = optax.softmax_cross_entropy(logits, one_hot)
    return jnp.mean(loss)

def compute_confusion_matrix(preds, labels, num_classes):
    preds = preds.argmax(-1).flatten()
    labels = labels.flatten()
    cm = jnp.zeros((num_classes, num_classes), dtype=jnp.int32)
    cm = cm.at[labels, preds].add(1)
    return cm

# -----------------------------------------------------------------------------
# 4) TrainState and update step
# -----------------------------------------------------------------------------

class TrainState(train_state.TrainState):
    batch_stats: Any = None  # if using BatchNorm

def create_train_state(rng, model, learning_rate, num_classes):
    params = model.init(rng, jnp.zeros([1,480,480,3]), train=True)
    tx = optax.sgd(learning_rate, momentum=0.9, weight_decay=1e-4)
    return TrainState.create(apply_fn=model.apply, params=params, tx=tx)

@jax.jit
def train_step(state, batch, num_classes):
    def loss_fn(params):
        logits = state.apply_fn({"params": params}, batch["image"], train=True)
        return cross_entropy_loss(logits, batch["mask"])
    grad_fn = value_and_grad(loss_fn)
    loss, grads = grad_fn(state.params)
    state = state.apply_gradients(grads=grads)
    return state, loss

@jax.jit
def eval_step(state, batch, num_classes):
    logits = state.apply_fn({"params": state.params}, batch["image"], train=False)
    loss = cross_entropy_loss(logits, batch["mask"])
    cm   = compute_confusion_matrix(logits, batch["mask"], num_classes)
    return loss, cm

# -----------------------------------------------------------------------------
# 5) Multi-device (pmapped) Trainer
# -----------------------------------------------------------------------------

def replicate(state):
    return jax.device_put_replicated(state, jax.local_devices())

def sync_metrics(metrics):
    return jax.tree_map(lambda x: jax.lax.psum(x, 'batch'), metrics)

def train_and_evaluate(args):
    # Prepare RNG
    rng = random.PRNGKey(0)
    rng, init_rng = random.split(rng)

    # Build model and state
    model = SegmentationModel(num_classes=args.num_classes)
    state = create_train_state(init_rng, model, args.lr, args.num_classes)
    state = replicate(state)

    # Datasets
    train_ds = get_dataset("train", args.dataset, args.batch_size, True, True, seed=0)
    val_ds   = get_dataset("validation", args.dataset, args.batch_size, False, False, seed=1)

    for epoch in range(args.epochs):
        # Training loop
        for batch in train_ds:
            images = jnp.array(batch["image"])
            masks  = jnp.array(batch["mask"])
            # shard across devices
            shard = lambda x: x.reshape((jax.local_device_count(), -1) + x.shape[1:])
            b = {"image": shard(images), "mask": shard(masks)}
            state, loss = pmap(lambda st, b: train_step(st, b, args.num_classes), axis_name='batch')(state, b)

        # Validation loop
        total_cm = jnp.zeros((args.num_classes,args.num_classes), jnp.int32)
        total_loss = 0.0
        n = 0
        for batch in val_ds:
            images = shard(jnp.array(batch["image"]))
            masks  = shard(jnp.array(batch["mask"]))
            loss, cm = pmap(lambda st, b: eval_step(st, b, args.num_classes), axis_name='batch')(state, {"image":images, "mask":masks})
            # aggregate
            total_loss += loss.sum()
            total_cm   += cm.sum(axis=0)
            n += 1

        miou = jnp.diag(total_cm) / (total_cm.sum(1) + total_cm.sum(0) - jnp.diag(total_cm))
        print(f"Epoch {epoch+1}, Val Loss: {total_loss/n:.4f}, mIoU: {jnp.mean(miou):.4f}")

        # Checkpoint
        if jax.process_index() == 0:
            ckpt_dir = os.path.join(args.output_dir, "checkpoints")
            checkpoints.save_checkpoint(ckpt_dir, jax.device_get(jax.tree_map(lambda x: x[0], state.params)),
                                        epoch, keep=3)

# -----------------------------------------------------------------------------
# 6) Argument parsing and main
# -----------------------------------------------------------------------------

def parse_args():
    import argparse
    p = argparse.ArgumentParser("JAX Segmentation Training")
    p.add_argument("--dataset",     default="voc",        help="voc or coco")
    p.add_argument("--batch-size",  default=8,    type=int)
    p.add_argument("--epochs",      default=30,   type=int)
    p.add_argument("--lr",          default=0.01, type=float)
    p.add_argument("--output-dir",  default=".",   help="checkpoint path")
    p.add_argument("--num-classes", default=21,   type=int)
    return p.parse_args()

if __name__ == "__main__":
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    start = time.time()
    train_and_evaluate(args)
    total_time = datetime.timedelta(seconds=int(time.time()-start))
    print(f"Training finished in {total_time}")
