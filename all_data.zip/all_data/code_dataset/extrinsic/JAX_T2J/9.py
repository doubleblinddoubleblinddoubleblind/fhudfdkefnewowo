import jax.numpy as jnp
from src.monitors import Histogram, BatchMatrixMonitor
from .matrix_activation import MATRIX_ACTIVATIONS

class Adjacency:
    def __init__(
        self,
        name: str = None,
        symmetric: bool = False,
        act: str = None,
        logger=None,
        logging_frequency: int = None,
    ):
        # Initialization
        self.name = name
        self.symmetric = symmetric
        self.activation = MATRIX_ACTIVATIONS[act]
        self.monitoring = logger is not None

        if self.monitoring:
            # Set up monitors exactly once
            self.dij_histogram = Histogram('dij', n_bins=10, rootname=self.name, append=True)
            self.dij_matrix_monitor = BatchMatrixMonitor('dij')
            self.monitors = [self.dij_matrix_monitor, self.dij_histogram]
            for m in self.monitors:
                m.initialize(None, logger.plotsdir)
            self.logging_frequency = logging_frequency

    def raw_matrix(self, h):
        """
        Override this method in subclasses to compute the adjacency matrix from h.
        """
        raise NotImplementedError

    def forward(self, h, mask=None, epoch=None, iters=None, **kwargs):
        # Compute adjacency
        M = self.raw_matrix(h)

        # Symmetrize if requested
        if self.symmetric:
            M = 0.5 * (M + jnp.swapaxes(M, 1, 2))

        # Apply activation if provided
        if self.activation is not None:
            M = self.activation(M, mask)

        # Logging hooks
        if self.monitoring:
            self._logging(dij=M, mask=mask, epoch=epoch, iters=iters, **kwargs)

        return M

    def _logging(self, dij=None, mask=None, epoch=None, iters=None, **kwargs):
        # Only log at specified epochs
        if epoch is not None and epoch % self.logging_frequency == 0:
            # Build histogram values
            if mask is not None:
                # Count unmasked lengths per example
                nonmask_ends = [int(jnp.sum(m, axis=0)[0]) for m in mask]
                dij_hist = [
                    d[:n, :n].reshape(-1) for d, n in zip(dij, nonmask_ends)
                ]
                dij_hist = jnp.concatenate(dij_hist, axis=0)
            else:
                dij_hist = dij.reshape(-1)

            # Update histogram
            self.dij_histogram(values=dij_hist)

            # On the first iteration, also visualize matrices
            if iters == 0:
                self.dij_histogram.visualize(f'epoch-{epoch}/{self.name}')
                self.dij_matrix_monitor(dij=dij)
                self.dij_matrix_monitor.visualize(f'epoch-{epoch}/{self.name}', n=10)
