import jax
import jax.numpy as jnp
import tensorflow_datasets as tfds
from flax import linen as nn
from flax.training import train_state
import optax
from typing import Any, Tuple

# ---------------------------
# Model Definition
# ---------------------------
class CNN(nn.Module):
    dropout_rate: float = 0.25

    @nn.compact
    def __call__(self, x, train: bool):
        # input x: [batch, 28,28,1], dtype=float32
        x = nn.Conv(features=32, kernel_size=(3,3))(x)
        x = nn.relu(x)
        x = nn.Conv(features=64, kernel_size=(3,3))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        x = nn.Dropout(self.dropout_rate)(x, deterministic=not train)
        x = x.reshape((x.shape[0], -1))              # Flatten
        x = nn.Dense(features=128)(x)
        x = nn.relu(x)
        x = nn.Dropout(0.5)(x, deterministic=not train)
        x = nn.Dense(features=10)(x)
        return nn.log_softmax(x)                     # [batch,10]

# ---------------------------
# Utility: create TrainState
# ---------------------------
def create_train_state(rng: jax.random.PRNGKey, learning_rate: float) -> train_state.TrainState:
    """Initialize model parameters and optimizer state."""
    model = CNN()
    params = model.init(rng, jnp.ones([1,28,28,1], jnp.float32), train=True)['params']
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

# ---------------------------
# Loss & Step Functions
# ---------------------------
def compute_metrics(logits: jnp.ndarray, labels: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
    loss = -jnp.mean(jnp.sum(nn.one_hot(labels, 10) * logits, axis=-1))
    accuracy = jnp.mean(jnp.argmax(logits, -1) == labels)
    return loss, accuracy

@jax.jit
def train_step(state: train_state.TrainState, batch: Any, rng: jax.random.PRNGKey) -> Tuple[train_state.TrainState, dict]:
    """Single SGD step over one batch."""
    images, labels = batch['image'], batch['label']
    def loss_fn(params):
        logits = state.apply_fn({'params': params}, images, train=True, rngs={'dropout': rng})
        loss, _ = compute_metrics(logits, labels)
        return loss
    grads = jax.grad(loss_fn)(state.params)
    state = state.apply_gradients(grads=grads)
    logits = state.apply_fn({'params': state.params}, images, train=False)
    loss, acc = compute_metrics(logits, labels)
    metrics = {'loss': loss, 'accuracy': acc}
    return state, metrics

@jax.jit
def eval_step(state: train_state.TrainState, batch: Any) -> dict:
    images, labels = batch['image'], batch['label']
    logits = state.apply_fn({'params': state.params}, images, train=False)
    loss, acc = compute_metrics(logits, labels)
    return {'loss': loss, 'accuracy': acc}

# ---------------------------
# Data Loading & Preprocessing
# ---------------------------
def prepare_datasets(batch_size: int):
    """Load MNIST via TFDS, normalize, batch, and prefetch."""
    ds_builder = tfds.builder("mnist")
    ds_builder.download_and_prepare()
    def _preprocess(sample):
        img = sample['image'] / 255.0
        return {'image': jnp.reshape(img, [-1,28,28,1]), 'label': sample['label']}
    train_ds = ds_builder.as_dataset(split='train', as_supervised=False)
    train_ds = train_ds.map(_preprocess).shuffle(10_000).batch(batch_size).prefetch(1)
    test_ds = ds_builder.as_dataset(split='test', as_supervised=False)
    test_ds = test_ds.map(_preprocess).batch(batch_size).prefetch(1)
    return train_ds, test_ds

# ---------------------------
# Training Loop
# ---------------------------
def train_and_evaluate(epochs: int = 1, batch_size: int = 256, lr: float = 1e-2):
    rng = jax.random.PRNGKey(0)
    rng, init_rng = jax.random.split(rng)
    state = create_train_state(init_rng, lr)

    train_ds, test_ds = prepare_datasets(batch_size)

    for epoch in range(1, epochs + 1):
        # Training
        batch_metrics = []
        for batch in train_ds:
            rng, step_rng = jax.random.split(rng)
            state, metrics = train_step(state, batch, step_rng)
            batch_metrics.append(metrics)
        train_loss = jnp.mean(jnp.array([m['loss'] for m in batch_metrics]))
        train_acc  = jnp.mean(jnp.array([m['accuracy'] for m in batch_metrics]))

        # Evaluation
        eval_metrics = [eval_step(state, batch) for batch in test_ds]
        test_loss = jnp.mean(jnp.array([m['loss'] for m in eval_metrics]))
        test_acc  = jnp.mean(jnp.array([m['accuracy'] for m in eval_metrics]))

        print(f"Epoch {epoch}: "
              f"Train Loss: {train_loss:.4f}, Train Acc: {100.*train_acc:.2f}%; "
              f"Test Loss: {test_loss:.4f}, Test Acc: {100.*test_acc:.2f}%")

if __name__ == "__main__":
    train_and_evaluate(epochs=1, batch_size=256, lr=1e-2)
