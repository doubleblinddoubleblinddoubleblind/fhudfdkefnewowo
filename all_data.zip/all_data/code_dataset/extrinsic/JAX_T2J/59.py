import os
from typing import Any, Callable, Dict, List, Tuple

import jax
import jax.numpy as jnp
from jax import random, lax
from flax import linen as nn
from flax.serialization import to_bytes, from_bytes
from flax.training import checkpoints

# Utility to pad variable‐length sequences
def pad_and_mask(seqs: List[jnp.ndarray], pad_value: int = 0) -> Tuple[jnp.ndarray, jnp.ndarray]:
    # seqs: list of [L_i, D] arrays
    lengths = jnp.array([s.shape[0] for s in seqs])
    maxlen = lengths.max()
    batch = []
    mask = []
    for s in seqs:
        pad_len = maxlen - s.shape[0]
        batch.append(jnp.pad(s, ((0, pad_len), (0, 0)), constant_values=pad_value))
        mask.append(jnp.concatenate([jnp.ones(s.shape[0]), jnp.zeros(pad_len)]))
    return jnp.stack(batch), jnp.stack(mask)

# ----------------------------------------
# 1) RNNLanguageModel → Flax
# ----------------------------------------
class RNNLanguageModel(nn.Module):
    n_tokens: int
    hidden_size: int
    embedding_size: int
    bidirectional: bool = False

    @nn.compact
    def __call__(self, ids: jnp.ndarray, lengths: jnp.ndarray):
        # ids: [batch, time]   lengths: [batch]
        embed = nn.Embed(self.n_tokens, self.embedding_size)(ids)  # [B, T, E]

        # LSTM parameters
        lstm = nn.scan(nn.LSTMCell,
                       variable_broadcast="params",
                       split_rngs={"params": False},
                       length=ids.shape[1])
        # initialize carry
        batch_size = ids.shape[0]
        init_carry = lstm.initialize_carry(
            jax.random.PRNGKey(0),  # for initialization only; not used in inference
            (batch_size,),
            self.hidden_size,
        )  # (c, h) each [B, H]

        # scan over time
        (c_final, h_final), hiddens = lstm(init_carry, embed)  
        # hiddens: [time, batch, H]
        hiddens = jnp.transpose(hiddens, (1, 0, 2))  # → [batch, time, H]

        # mask out padding positions
        # here we simply zero–out positions ≥ length
        mask = (jnp.arange(hiddens.shape[1])[None, :] < lengths[:, None])
        return hiddens * mask[:, :, None]  # [batch, time, H]

    @classmethod
    def load(cls, model_dir: str) -> "RNNLanguageModel":
        ckpt = checkpoints.restore_checkpoint(model_dir, target=None)
        config = ckpt["config"]
        module = cls(**config)
        return module.bind(ckpt["params"])

    def save(self, params: Dict, model_dir: str):
        ckpt = {"params": params,
                "config": {
                  "n_tokens": self.n_tokens,
                  "hidden_size": self.hidden_size,
                  "embedding_size": self.embedding_size,
                  "bidirectional": self.bidirectional
                }}
        checkpoints.save_checkpoint(model_dir, ckpt, step=0, overwrite=True)

# ----------------------------------------
# 2) ContextualStringEmbeddingModule → Flax
# ----------------------------------------
class ContextualStringEmbeddingModule(nn.Module):
    """Runs two RNNLanguageModels (forward/backward) and selects token‐level outputs."""
    vocab_size: int
    embedding_size: int
    hidden_size: int
    forward_ckpt: str
    backward_ckpt: str

    def setup(self):
        # load two pretrained models
        self.f_lm = RNNLanguageModel(
            n_tokens=self.vocab_size,
            embedding_size=self.embedding_size,
            hidden_size=self.hidden_size,
        )
        self.b_lm = RNNLanguageModel(
            n_tokens=self.vocab_size,
            embedding_size=self.embedding_size,
            hidden_size=self.hidden_size,
        )
        # parameters will be bound at apply time

    def run_lm(self, lm: RNNLanguageModel, params: Dict,
               ids: jnp.ndarray, offsets: jnp.ndarray) -> jnp.ndarray:
        # ids: [batch, total_chars]; offsets: [batch, num_tokens]
        # We reconstruct per‐token hidden states via indexing.
        # First, pack sequences by lengths
        char_lens = (ids != 0).sum(axis=1)
        hiddens = lm.apply({"params": params}, ids, char_lens)  # [B, C, H]
        # offsets: position of each token char in C‐axis, so gather
        batch_idx = jnp.arange(ids.shape[0])[:, None]
        return hiddens[batch_idx, offsets]  # [B, T, H]

    @nn.compact
    def __call__(self,
                 f_ids: jnp.ndarray,
                 f_offsets: jnp.ndarray,
                 b_ids: jnp.ndarray,
                 b_offsets: jnp.ndarray,
                 *,
                 f_params: Dict,
                 b_params: Dict) -> jnp.ndarray:
        # run both directions
        f_out = self.run_lm(self.f_lm, f_params, f_ids, f_offsets)
        b_out = self.run_lm(self.b_lm, b_params, b_ids, b_offsets)
        # concatenate along feature axis
        return jnp.concatenate([f_out, b_out], axis=-1)  # [B, T, 2H]

# ----------------------------------------
# Example of wiring it all together
# ----------------------------------------
def main():
    # Example usage: assume you have token→char‐ids and offsets prepared
    batch_f_ids = jnp.array([[1, 2, 3, 0], [4, 5, 0, 0]])       # [B=2, C=4]
    batch_f_offsets = jnp.array([[0, 2], [1, 1]])               # [B=2, T=2]
    batch_b_ids = jnp.array([[3, 2, 1, 0], [5, 4, 0, 0]])
    batch_b_offsets = jnp.array([[3, 1], [2, 0]])

    # Load pretrained checkpoints
    f_ckpt = checkpoints.restore_checkpoint("forward_lm_dir", target=None)
    b_ckpt = checkpoints.restore_checkpoint("backward_lm_dir", target=None)

    emb_module = ContextualStringEmbeddingModule(
        vocab_size=f_ckpt["config"]["n_tokens"],
        embedding_size=f_ckpt["config"]["embedding_size"],
        hidden_size=f_ckpt["config"]["hidden_size"],
        forward_ckpt="forward_lm_dir",
        backward_ckpt="backward_lm_dir"
    )

    # bind parameters
    variables = {
        "params": {
           **{"f_lm": f_ckpt["params"]},
           **{"b_lm": b_ckpt["params"]}
        }
    }

    # call and get embeddings
    out = emb_module.apply(
        variables,
        batch_f_ids, batch_f_offsets,
        batch_b_ids, batch_b_offsets,
        f_params=f_ckpt["params"],
        b_params=b_ckpt["params"]
    )  # [2, 2, 2H]

    print("Output shape:", out.shape)

if __name__ == "__main__":
    main()
