import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Callable, Optional

class Linear(nn.Module):
    features: int                                    # output dimension
    use_bias: bool = True                            # whether to include bias
    dtype: Any = jnp.float32                         # module’s default dtype
    kernel_init: Callable[[Any, tuple], jnp.ndarray] = nn.initializers.lecun_normal()
    bias_init: Callable[[Any, tuple], jnp.ndarray] = nn.initializers.zeros

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        """
        Applies a linear transformation y = x @ W + b, but first casts
        W and b to the dtype of x (e.g. for AMP compatibility).
        """
        in_features = x.shape[-1]
        # Initialize weight matrix of shape (in_features, features)
        kernel = self.param('kernel',
                            self.kernel_init,
                            (in_features, self.features))
        # Optionally initialize bias of shape (features,)
        bias = (self.param('bias',
                           self.bias_init,
                           (self.features,))
                if self.use_bias else None)

        # Cast to the input’s dtype to mirror the PyTorch workaround
        kernel = kernel.astype(x.dtype)
        if bias is not None:
            bias = bias.astype(x.dtype)

        y = jnp.dot(x, kernel)
        if bias is not None:
            y = y + bias
        return y
