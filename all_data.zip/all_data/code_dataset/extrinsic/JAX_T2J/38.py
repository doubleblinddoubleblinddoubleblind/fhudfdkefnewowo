import cv2
import numpy as np
import jax
import jax.numpy as jnp
from flax import linen as nn
from tvm import relay
from tvm.runtime.vm import VirtualMachine
import tvm
import tvm.testing
from tvm.relay.frontend.pytorch_utils import (
    rewrite_nms_to_batched_nms,
    rewrite_scatter_to_gather,
)
from tvm.contrib.download import download

# --- constants ---
in_size = 300

# --- image preprocessing in JAX style ---
def process_image_jax(img_path: str) -> jnp.ndarray:
    # OpenCV → NumPy → JAX
    img = cv2.imread(img_path).astype("float32")
    img = cv2.resize(img, (in_size, in_size))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img / 255.0
    # NHWC → NCHW
    img = np.transpose(img, (2, 0, 1))[None, ...]
    return jnp.array(img)

# --- placeholder Flax “wrapper” ---
# You’ll need to supply your own Flax module after exporting the detection backbone.
class FlaxDetectionWrapper(nn.Module):
    # In practice you would load parameters from an ONNX/Relay conversion
    @nn.compact
    def __call__(self, x):
        # stub: replace with your real detection forward
        # e.g. call into a Relay‐compiled VM via TVM’s Python API
        raise NotImplementedError

# --- VM execution helper (identical to PyTorch version) ---
def compile_and_run_vm(mod, params, data_np, target="llvm"):
    with tvm.transform.PassContext(opt_level=3):
        vm_exec = relay.vm.compile(mod, target=target, params=params)
    dev = tvm.device(target, 0)
    vm = VirtualMachine(vm_exec, dev)
    vm.set_input("main", input0=data_np)
    return vm.run()

# --- end‐to‐end test harness in JAX style ---
def test_detection_models_jax(onnx_path: str, img_url: str = None):
    # 1) download image
    img = "test_street_small.jpg"
    if img_url:
        download(img_url, img)

    # 2) preprocess
    data = process_image_jax(img)
    data_np = np.array(data)

    # 3) load ONNX (or Relay) model
    #    Here we assume you've converted your PyTorch script to ONNX and then to Relay:
    from tvm.contrib import graph_executor
    #    -- load onnx → relay IRModule + params
    import onnx
    onnx_model = onnx.load(onnx_path)
    shape_dict = {"input0": data_np.shape}
    mod, params = relay.frontend.from_onnx(onnx_model, shape_dict)

    # 4) run baseline
    #    If you have reference outputs (e.g. from ONNX Runtime), compare here.
    #    For demonstration, we skip direct reference and just run TVM VM once:
    tvm_res = compile_and_run_vm(mod, params, data_np)

    # 5) apply Relay rewrites
    mod_batched = rewrite_nms_to_batched_nms(mod)
    mod_scatter = rewrite_scatter_to_gather(mod_batched, 4)

    # 6) run after rewrite
    tvm_res_rewrite = compile_and_run_vm(mod_scatter, params, data_np)

    # 7) validate
    for a, b in zip(tvm_res, tvm_res_rewrite):
        tvm.testing.assert_allclose(a.numpy(), b.numpy(), rtol=1e-5, atol=1e-5)

    print("JAX-based detection test passed.")

if __name__ == "__main__":
    # Example usage:
    # - Export your TorchScript model to ONNX (e.g. via torch.onnx.export).
    # - Call this harness with that ONNX path.
    onnx_model_path = "maskrcnn_resnet50_fpn.onnx"
    img_url = (
        "https://raw.githubusercontent.com/dmlc/web-data/"
        "master/gluoncv/detection/street_small.jpg"
    )
    test_detection_models_jax(onnx_model_path, img_url)
