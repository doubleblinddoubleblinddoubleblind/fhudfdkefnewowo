import pytest
import numpy as np
import math

import jax
import jax.numpy as jnp
import optax

import pyjet
from pyjet.metrics import Accuracy
from pyjet.losses import categorical_crossentropy
from pyjet.test_utils import (
    ReluNet,
    binary_loss,
    multi_binary_loss,
    one_loss,
    InferNet1D,
    InferNet2D,
    InferNet3D,
)
import pyjet.backend as J

# -- Fixtures --------------------------------------------------------------

@pytest.fixture
def relu_net():
    return ReluNet()

@pytest.fixture
def test_infer_net1d():
    return InferNet1D()

@pytest.fixture
def test_infer_net2d():
    return InferNet2D()

@pytest.fixture
def test_infer_net3d():
    return InferNet3D()

@pytest.fixture
def binary_loss_fn():
    return binary_loss

@pytest.fixture
def multi_binary_loss_fn():
    return multi_binary_loss


# -- Inference shape tests ------------------------------------------------

def test_infer_net(test_infer_net1d, test_infer_net2d, test_infer_net3d):
    # JAX arrays instead of torch tensors
    test_infer_net1d(jnp.zeros((1, 10, 3)))
    test_infer_net2d(jnp.zeros((1, 10, 10, 3)))
    test_infer_net3d(jnp.zeros((1, 10, 10, 10, 3)))


# -- ReluNet predict / validate -------------------------------------------

def test_predict_batch(relu_net):
    x = np.array([[-1., 1., 2., -2.]])
    expected = np.array([[0., 1., 2., 0.]])
    out = relu_net.predict_on_batch(x)
    assert np.all(out == expected)

def test_validate_batch(relu_net):
    x = np.array([[.2, .3, .5, -1], [-1, .6, .4, -1]])
    y = np.array([2, 2])
    (loss, accuracy_score), preds = relu_net.validate_on_batch(
        x, y, metrics=[categorical_crossentropy, Accuracy()]
    )
    # Categorical crossentropy over numpy inputs
    expected_loss = -(math.log(x[0, y[0]]) + math.log(x[1, y[1]])) / 2
    assert math.isclose(loss, expected_loss, rel_tol=1e-7)
    assert accuracy_score == 50.


# -- Optimizer manager ----------------------------------------------------

def test_optimizer(relu_net):
    # Replace torch.optim.SGD with optax.sgd
    optimizer = optax.sgd(0.01)  # SGD at lr=0.01 :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}

    # unnamed
    relu_net.add_optimizer(optimizer)
    assert len(relu_net.optimizer_manager.optimizers) == \
           len(relu_net.optimizer_manager.names) == 1
    assert optimizer in relu_net.optimizer_manager.optimizers
    assert "optimizer_0" in relu_net.optimizer_manager.names

    # named
    relu_net.clear_optimizers()
    name = "sgd_optim"
    relu_net.add_optimizer(optimizer, name=name)
    assert optimizer in relu_net.optimizer_manager.optimizers
    assert name in relu_net.optimizer_manager.names

    # multiple
    optimizer2 = optax.sgd(0.02)
    relu_net.clear_optimizers()
    relu_net.add_optimizer(optimizer, name=name)
    relu_net.add_optimizer(optimizer2)
    assert optimizer2 in relu_net.optimizer_manager.optimizers
    assert "optimizer_1" in relu_net.optimizer_manager.names

    # remove last
    optim_info = relu_net.remove_optimizer()
    assert optim_info["name"] == "optimizer_1"
    assert optim_info["optimizer"] is optimizer2
    assert len(relu_net.optimizer_manager.optimizers) == 1

    # remove by name (out of order)
    relu_net.add_optimizer(optimizer)
    optim_info = relu_net.remove_optimizer(name=name)
    assert optim_info["name"] == name
    assert optim_info["optimizer"] is optimizer
    assert len(relu_net.optimizer_manager.optimizers) == 1

    relu_net.clear_optimizers()


# -- Loss manager ---------------------------------------------------------

def test_loss(relu_net, binary_loss_fn, multi_binary_loss_fn):
    x = np.array([[-1., 1., 0., 1.],
                  [-2., 0., 1., 1.]])
    y = np.array([[1., 1., 0., 1.],
                  [1., 0., 1., 1.]])
    # Cast helpers still produce torch for now
    x_torch = relu_net.cast_input_to_torch(x)
    y_torch = relu_net.cast_target_to_torch(y)

    # no losses initially
    assert len(relu_net.loss_manager) == 0

    # add single loss
    relu_net.add_loss(binary_loss_fn)
    _ = relu_net(x_torch)
    assert relu_net.loss(y_torch) == 4.

    # loss_in override
    relu_net.clear_losses()
    relu_net.add_loss(binary_loss_fn, inputs='loss_in')
    _ = relu_net(x_torch)
    assert relu_net.loss(y_torch) == 4.

    # multi loss input with named loss
    relu_net.add_loss(one_loss, inputs=['loss_in2'], name="new_loss")
    pred = relu_net(x_torch)
    relu_net.loss_in2 = pred
    assert relu_net.loss(y_torch) == 5.
    assert relu_net.loss_manager.get_loss_score('loss_0') == 4.
    assert relu_net.loss_manager.get_loss_score('new_loss') == 1.

    # remove losses
    loss_info = relu_net.remove_loss(name="new_loss")
    assert loss_info["name"] == "new_loss"
    loss_info = relu_net.remove_loss()
    assert loss_info["name"] == "loss_0"

    # multi-input multi-binary loss
    relu_net.add_loss(multi_binary_loss_fn, inputs=['loss_in', 'loss_in2'])
    pred = relu_net(x_torch)
    relu_net.loss_in2 = pred
    assert relu_net.loss(y_torch) == 8.

    relu_net.clear_losses()
