import os
import random
import shutil
import tempfile

import numpy as np
import tensorflow as tf
import tensorflow_datasets as tfds

import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax

# ----------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------
BATCH_SIZE = 64
EPOCHS = 5
SEED = 42
N_HIDDEN = 100
LEARNING_RATE = 0.02

# Make TensorFlow deterministic (for dataset shuffling, etc.)
tf.random.set_seed(SEED)
np.random.seed(SEED)
random.seed(SEED)

# ----------------------------------------------------------------------
# Model Definition
# ----------------------------------------------------------------------
class FlaxMNIST(nn.Module):
    hidden: int

    @nn.compact
    def __call__(self, x):
        x = nn.Dense(self.hidden)(x)
        x = nn.relu(x)
        x = nn.Dense(10)(x)
        # Flax’s numerically-stable log_softmax
        return x - jax.scipy.special.logsumexp(x, axis=-1, keepdims=True)


# ----------------------------------------------------------------------
# Data pipeline using TFDS
# ----------------------------------------------------------------------
def prepare_mnist(split, batch_size, shuffle=False, seed=0):
    ds = tfds.load("mnist", split=split, as_supervised=True)
    if shuffle:
        ds = ds.shuffle(10_000, seed=seed)
    ds = ds.map(lambda img, lbl: (
        # Normalize to match torchvision: (x/255 - 0.1307)/0.3081
        (tf.cast(img, tf.float32) / 255.0 - 0.1307) / 0.3081,
        lbl
    ))
    ds = ds.map(lambda img, lbl: (jnp.reshape(img, (-1,)), lbl))
    ds = ds.batch(batch_size).prefetch(1)
    return ds


# ----------------------------------------------------------------------
# Create training state
# ----------------------------------------------------------------------
def create_train_state(rng, hidden, learning_rate):
    model = FlaxMNIST(hidden)
    params = model.init(rng, jnp.ones((1, 28 * 28)))["params"]
    tx = optax.sgd(learning_rate, momentum=0.25)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)


# ----------------------------------------------------------------------
# Loss and metric functions
# ----------------------------------------------------------------------
def compute_metrics(logits, labels):
    loss = -jnp.sum(logits * jax.nn.one_hot(labels, 10)) / labels.shape[0]
    accuracy = jnp.mean(jnp.argmax(logits, -1) == labels)
    return loss, accuracy


@jax.jit
def train_step(state, batch):
    imgs, lbls = batch

    def loss_fn(params):
        logits = state.apply_fn({"params": params}, imgs)
        return -jnp.sum(logits * jax.nn.one_hot(lbls, 10)) / lbls.shape[0]

    grads = jax.grad(loss_fn)(state.params)
    new_state = state.apply_gradients(grads=grads)
    logits = new_state.apply_fn({"params": new_state.params}, imgs)
    loss, acc = compute_metrics(logits, lbls)
    return new_state, loss, acc


@jax.jit
def eval_step(state, batch):
    imgs, lbls = batch
    logits = state.apply_fn({"params": state.params}, imgs)
    loss, acc = compute_metrics(logits, lbls)
    return loss, acc


# ----------------------------------------------------------------------
# Main training/testing loop
# ----------------------------------------------------------------------
def main():
    # Temporary directory (analogous to your TF TestCase setup)
    tmpdir = tempfile.mkdtemp()
    try:
        rng = jax.random.PRNGKey(SEED)
        rng, init_rng = jax.random.split(rng)
        state = create_train_state(init_rng, N_HIDDEN, LEARNING_RATE)

        # Prepare datasets
        train_ds = prepare_mnist("train", BATCH_SIZE, shuffle=True, seed=SEED)
        test_ds = prepare_mnist("test", BATCH_SIZE, shuffle=False)

        # Training
        for epoch in range(1, EPOCHS + 1):
            batch_losses = []
            batch_accs = []
            for batch in train_ds:
                state, loss, acc = train_step(state, batch)
                batch_losses.append(loss)
                batch_accs.append(acc)
            train_loss = jnp.mean(jnp.array(batch_losses))
            train_acc = jnp.mean(jnp.array(batch_accs))
            print(f"Epoch {epoch}/{EPOCHS} — Train loss: {train_loss:.4f}, acc: {train_acc:.4f}")

        # Evaluation
        test_losses = []
        test_accs = []
        for batch in test_ds:
            loss, acc = eval_step(state, batch)
            test_losses.append(loss)
            test_accs.append(acc)
        test_loss = jnp.mean(jnp.array(test_losses))
        test_acc = jnp.mean(jnp.array(test_accs))
        print(f"Test loss: {test_loss:.4f}, acc: {test_acc:.4f}")

    finally:
        shutil.rmtree(tmpdir)


if __name__ == "__main__":
    main()
