import argparse
import os
import sys
import time
import numpy as np

import jax
import jax.numpy as jnp
from jax import random, jit, grad, pmap, value_and_grad
import flax.linen as nn
from flax.training import train_state, checkpoints
import optax

from importlib import import_module
from data import DefenseDataset

# Logger: simple file logger
class Logger:
    def __init__(self, path):
        self.log_file = open(path, 'w')
    def write(self, s):
        self.log_file.write(s + '\n')
        self.log_file.flush()
        print(s)
    def flush(self):
        pass

parser = argparse.ArgumentParser(description='JAX/Flax defense model')
parser.add_argument('--exp', '-e', default='sample', help='model')
parser.add_argument('-j', '--workers', default=32, type=int, help='workers (unused)')
parser.add_argument('--epochs', default=100, type=int, help='total epochs')
parser.add_argument('--start-epoch', default=0, type=int, help='start epoch')
parser.add_argument('-b', '--batch-size', default=32, type=int, help='batch size')
parser.add_argument('--lr', default=0.01, type=float, help='learning rate')
parser.add_argument('--momentum', default=0.9, type=float, help='momentum')
parser.add_argument('--weight-decay', default=0.0, type=float, help='weight decay')
parser.add_argument('--save-freq', default=1, type=int, help='save freq')
parser.add_argument('--print-iter', default=0, type=int, help='print every iter')
parser.add_argument('--resume', default='', help='resume checkpoint')
parser.add_argument('--save-dir', default='', help='save dir')
parser.add_argument('--debug', action='store_true', help='debug')
parser.add_argument('--test', default=0, type=int, help='test mode')
parser.add_argument('--defense', default=1, type=int, help='defense flag')
parser.add_argument('--optimizer', default='adam', help='optimizer')

def create_train_state(rng, model_def, learning_rate, weight_decay):
    params = model_def.init(rng, jnp.ones([1, *model_def.input_shape]))['params']
    if optimizer == 'sgd':
        tx = optax.sgd(learning_rate, momentum)
    else:
        tx = optax.adamw(learning_rate, weight_decay)
    return train_state.TrainState.create(apply_fn=model_def.apply, params=params, tx=tx)


def get_lr(epoch, base_lr, epochs):
    if epoch <= epochs * 0.6:
        return base_lr
    elif epoch <= epochs * 0.9:
        return base_lr * 0.1
    else:
        return base_lr * 0.01


def main():
    args = parser.parse_args()
    modelpath = os.path.join(os.path.abspath('../pixel_Exps'), args.exp)
    train_data = np.load(os.path.join(modelpath, 'train_split.npy'))
    val_data = np.load(os.path.join(modelpath, 'val_split.npy'))
    with open(os.path.join(modelpath, 'train_attack.txt')) as f:
        train_attack = [line.split()[0] for line in f]
    sys.path.append(modelpath)
    model_mod = import_module('model')
    config, net_def = model_mod.get_model()  # net_def: Flax Module

    start_epoch = args.start_epoch or 1
    save_dir = args.save_dir or time.strftime('%Y%m%d-%H%M%S', time.localtime())
    save_dir = os.path.join(modelpath, 'results', save_dir)

    if args.resume:
        state = checkpoints.restore_checkpoint(args.resume, None)
        start_epoch = state['epoch'] + 1
    else:
        rng = random.PRNGKey(0)
        state = create_train_state(rng, net_def, args.lr, args.weight_decay)

    if args.test == 1:
        # Testing pipeline
        test_data = np.load(os.path.join(modelpath, 'test_split.npy'))
        with open(os.path.join(modelpath, 'test_attack.txt')) as f:
            test_attack = [line.split()[0] for line in f]
        dataset = DefenseDataset(config, 'test', test_data, test_attack)
        # implement single-device eval
        net = state.apply_fn
        name = f"result_{args.exp}_{os.path.basename(args.resume)}"
        model_mod.test(net, dataset, name, bool(args.defense))
        return

    # Training and validation pipelines
    train_dataset = DefenseDataset(config, 'train', train_data, train_attack)
    val_dataset = DefenseDataset(config, 'val', val_data, train_attack)

    os.makedirs(save_dir, exist_ok=True)
    sys.stdout = Logger(os.path.join(save_dir, 'log'))

    for epoch in range(start_epoch, args.epochs + 1):
        lr = get_lr(epoch, args.lr, args.epochs)
        state = state.replace(opt_state=state.tx.update(hyperparams={'learning_rate': lr}, params=state.params))

        # train step
        model_mod.train_epoch(state, train_dataset, args.batch_size)
        # val step
        model_mod.val_epoch(state, val_dataset, args.batch_size)

        if epoch % args.save_freq == 0:
            ckpt = {'epoch': epoch, 'state_dict': state.params}
            checkpoints.save_checkpoint(save_dir, ckpt, epoch)

if __name__ == '__main__':
    main()
