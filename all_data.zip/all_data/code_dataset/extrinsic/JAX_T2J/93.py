import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from typing import Any, Callable, Dict, Optional, Tuple


# --------------------------------------------------
# Discriminator
# --------------------------------------------------
class Discriminator(nn.Module):
    feature_maps: int
    image_channels: int

    @nn.compact
    def __call__(self, x: jnp.ndarray, train: bool = True) -> jnp.ndarray:
        def block(in_c, out_c, *, kernel=4, stride=2, pad=1, bn=True):
            layers = []
            layers.append(nn.Conv(out_c, (kernel, kernel), (stride, stride), padding=pad,
                                  kernel_init=nn.initializers.kaiming_normal()))
            if bn:
                layers.append(nn.BatchNorm(use_running_average=not train))
            layers.append(nn.leaky_relu)
            return layers

        # four down‐sampling blocks
        x = x.astype(jnp.float32)
        for i, (in_c, out_c) in enumerate([
            (self.image_channels, self.feature_maps),
            (self.feature_maps, self.feature_maps * 2),
            (self.feature_maps * 2, self.feature_maps * 4),
            (self.feature_maps * 4, self.feature_maps * 8),
        ]):
            for layer in block(in_c, out_c, bn=(i != 0)):
                x = layer(x)

        # final block → 1×1 patch
        x = nn.Conv(1, (4, 4), (1, 1), padding=0,
                    kernel_init=nn.initializers.kaiming_normal())(x)
        x = nn.sigmoid(x)
        # flatten to shape (batch,)
        return jnp.squeeze(x.reshape((x.shape[0], -1)), axis=-1)


# --------------------------------------------------
# Generator
# --------------------------------------------------
class Generator(nn.Module):
    latent_dim: int
    feature_maps: int
    image_channels: int

    @nn.compact
    def __call__(self, z: jnp.ndarray, train: bool = True) -> jnp.ndarray:
        def block(in_c, out_c, *, kernel=4, stride=2, pad=1, bn=True):
            layers = []
            layers.append(nn.ConvTranspose(out_c, (kernel, kernel), (stride, stride),
                                           padding=pad, kernel_init=nn.initializers.kaiming_normal()))
            if bn:
                layers.append(nn.BatchNorm(use_running_average=not train))
            layers.append(nn.relu)
            return layers

        x = z.reshape((z.shape[0], self.latent_dim, 1, 1))
        for in_c, out_c in [
            (self.latent_dim, self.feature_maps * 8),
            (self.feature_maps * 8, self.feature_maps * 4),
            (self.feature_maps * 4, self.feature_maps * 2),
            (self.feature_maps * 2, self.feature_maps),
        ]:
            for layer in block(in_c, out_c):
                x = layer(x)

        # final to image_channels
        x = nn.ConvTranspose(self.image_channels, (4, 4), (2, 2), padding=1,
                             kernel_init=nn.initializers.xavier_uniform())(x)
        return nn.sigmoid(x)


# --------------------------------------------------
# Utilities
# --------------------------------------------------
def get_noise(key: jax.random.KeyArray, batch_size: int, latent_dim: int) -> jnp.ndarray:
    z = jax.random.normal(key, (batch_size, latent_dim))
    return z


def instance_noise(key: jax.random.KeyArray,
                   x: jnp.ndarray,
                   noise_level: float,
                   gamma: Optional[float],
                   epoch: int) -> jnp.ndarray:
    lvl = (gamma ** epoch * noise_level) if gamma is not None else noise_level
    noise = lvl * jax.random.normal(key, x.shape)
    return x + noise


def top_k_preds(preds: jnp.ndarray, k: int, gamma: Optional[float], epoch: int) -> jnp.ndarray:
    kk = int((gamma ** epoch * k) if gamma is not None else k)
    vals, _ = jax.lax.top_k(preds, kk)
    return vals


# --------------------------------------------------
# Loss functions
# --------------------------------------------------
def disc_loss(params_d: Dict, params_g: Dict,
              batch_real: jnp.ndarray,
              key: jax.random.KeyArray,
              discriminator: Callable[..., Any],
              generator: Callable[..., Any],
              configs: Dict,
              epoch: int) -> Tuple[jnp.ndarray, Dict]:
    """Compute D loss + updated params for D and G if using optax updates elsewhere."""
    # real
    key, subkey = jax.random.split(key)
    real_in = instance_noise(subkey, batch_real,
                              configs["instance_noise_params"]["noise_level"],
                              configs["instance_noise_params"]["gamma"],
                              epoch)
    real_logits = discriminator.apply({"params": params_d}, real_in, train=True)
    real_loss = optax.sigmoid_binary_cross_entropy(real_logits, jnp.ones_like(real_logits)).mean()

    # fake
    key, subkey = jax.random.split(key)
    z = get_noise(subkey, batch_real.shape[0], configs["latent_dim"])
    fake = generator.apply({"params": params_g}, z, train=True)
    key, subkey = jax.random.split(key)
    fake = instance_noise(subkey, fake,
                          configs["instance_noise_params"]["noise_level"],
                          configs["instance_noise_params"]["gamma"], epoch)
    fake_logits = discriminator.apply({"params": params_d}, fake, train=True)
    fake_logits = top_k_preds(fake_logits,
                              configs["top_k_params"]["k"],
                              configs["top_k_params"]["gamma"],
                              epoch)
    fake_loss = optax.sigmoid_binary_cross_entropy(fake_logits, jnp.zeros_like(fake_logits)).mean()

    return real_loss + fake_loss, {"key": key}


def gen_loss(params_g: Dict, params_d: Dict,
             batch_real: jnp.ndarray,
             key: jax.random.KeyArray,
             discriminator: Callable[..., Any],
             generator: Callable[..., Any],
             configs: Dict,
             epoch: int) -> Tuple[jnp.ndarray, Dict]:
    """Compute G loss."""
    # fake only
    key, subkey = jax.random.split(key)
    z = get_noise(subkey, batch_real.shape[0], configs["latent_dim"])
    fake = generator.apply({"params": params_g}, z, train=True)
    key, subkey = jax.random.split(key)
    fake = instance_noise(subkey, fake,
                          configs["instance_noise_params"]["noise_level"],
                          configs["instance_noise_params"]["gamma"], epoch)
    fake_logits = discriminator.apply({"params": params_d}, fake, train=True)
    fake_logits = top_k_preds(fake_logits,
                              configs["top_k_params"]["k"],
                              configs["top_k_params"]["gamma"],
                              epoch)
    loss = optax.sigmoid_binary_cross_entropy(fake_logits, jnp.ones_like(fake_logits)).mean()
    return loss, {"key": key}
