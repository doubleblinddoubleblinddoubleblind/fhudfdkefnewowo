import os
import json
import random
import math

import numpy as np
import jax
import jax.numpy as jnp

from pose.utils.osutils import isfile
from pose.utils.imutils import load_image, fliplr
from pose.utils.transforms import crop, color_normalize, transform, draw_labelmap, shufflelr

class MscocoJax:
    def __init__(self, is_train=True, **kwargs):
        self.is_train      = is_train
        self.inp_res       = kwargs['inp_res']
        self.out_res       = kwargs['out_res']
        self.sigma         = kwargs['sigma']
        self.scale_factor  = kwargs['scale_factor']
        self.rot_factor    = kwargs['rot_factor']
        self.label_type    = kwargs['label_type']
        self.year          = kwargs['year']
        self.jsonfile      = kwargs['anno_path']
        img_folder         = kwargs['image_path']

        # choose train/val folders
        suffix = 'train' if is_train else 'val'
        self.img_folder = f"{img_folder}/{suffix}{self.year}"

        # load annotations
        with open(self.jsonfile, 'r') as f:
            self.anno = json.load(f)

        self.train = [i for i,v in enumerate(self.anno) if not v['isValidation']]
        self.valid = [i for i,v in enumerate(self.anno) if v['isValidation']]

        self.mean, self.std = self._compute_mean()

    def _compute_mean(self):
        meanstd_file = './data/coco/mean.npz'
        if os.path.isfile(meanstd_file):
            data = np.load(meanstd_file)
            mean, std = data['mean'], data['std']
        else:
            print("==> Computing mean/std over training set")
            mean = np.zeros(3)
            std  = np.zeros(3)
            for idx in self.train:
                ann = self.anno[idx]
                img = load_image(os.path.join(self.img_folder, ann['img_paths']))  # CxHxW numpy
                # compute per-channel mean & std
                ch, h, w = img.shape
                flat = img.reshape(ch, -1)
                mean += flat.mean(axis=1)
                std  += flat.std(axis=1)
            mean /= len(self.train)
            std  /= len(self.train)
            np.savez(meanstd_file, mean=mean, std=std)

        if self.is_train:
            print(f"   Mean: {mean[0]:.4f}, {mean[1]:.4f}, {mean[2]:.4f}")
            print(f"   Std:  {std[0]:.4f}, {std[1]:.4f}, {std[2]:.4f}")

        return mean, std

    def __len__(self):
        return len(self.train) if self.is_train else len(self.valid)

    def __getitem__(self, index, rng=None):
        """Return one example: (inp, target, meta)."""
        # choose annotation
        idx = self.train[index] if self.is_train else self.valid[index]
        ann = self.anno[idx]

        # load image and keypoints
        img = load_image(os.path.join(self.img_folder, ann['img_paths']))  # numpy CxHxW
        pts = np.array(ann['joint_self'], dtype=np.float32)   # (nparts,3)
        c   = np.array(ann['objpos'], dtype=np.float32)      # center
        s   = float(ann['scale_provided'])

        # adjust center & scale
        if c[0] != -1:
            c[1] += 15 * s
            s   *= 1.25

        # data augmentation
        if self.is_train:
            if rng is None:
                rng = jax.random.PRNGKey(random.randint(0, 1<<31))
            # scale & rotation
            key, sub = jax.random.split(rng)
            scale = float(jax.random.normal(key, ()) * self.scale_factor + 1.0)
            key, sub = jax.random.split(sub)
            rot   = float(jax.random.normal(key, ()) * self.rot_factor) if random.random() <= 0.6 else 0.0

            # horizontal flip
            if random.random() < 0.5:
                img = fliplr(img)
                pts = shufflelr(pts, width=img.shape[2], dataset='mpii')
                c[0] = img.shape[2] - c[0]

            # color jitter (per-channel)
            for ch in range(3):
                factor = random.uniform(0.8, 1.2)
                img[ch] = np.clip(img[ch] * factor, 0.0, 1.0)
        else:
            scale, rot = 1.0, 0.0

        # prepare input
        inp = crop(img, c, s*scale, [self.inp_res]*2, rot=rot)
        inp = color_normalize(inp, self.mean, self.std)

        # generate ground truth heatmaps
        tpts          = pts.copy()
        nparts        = tpts.shape[0]
        target        = np.zeros((nparts, self.out_res, self.out_res), dtype=np.float32)
        target_weight = tpts[:, 2].reshape(nparts,1).copy()

        for i in range(nparts):
            if tpts[i,2] > 0:
                # transform joint center
                xy = transform(tpts[i,:2]+1, c, s*scale, [self.out_res]*2, rot=rot)
                tpts[i,:2] = xy
                target[i], vis = draw_labelmap(target[i], xy-1, self.sigma, type=self.label_type)
                target_weight[i,0] = vis

        meta = {
            'index': index,
            'center': c,
            'scale': s*scale,
            'pts': pts,
            'tpts': tpts,
            'img_path': ann['img_paths'],
            'target_weight': target_weight
        }

        # convert to JAX arrays
        return jnp.array(inp), jnp.array(target), meta

    def batch_generator(self, batch_size, shuffle=True):
        """Yields batches of (inp, target, meta)."""
        idxs = list(range(len(self)))
        if shuffle:
            random.shuffle(idxs)
        for start in range(0, len(idxs), batch_size):
            batch_idxs = idxs[start:start+batch_size]
            inps, tars, metas = [], [], []
            for i in batch_idxs:
                inp, tar, meta = self.__getitem__(i)
                inps.append(inp)
                tars.append(tar)
                metas.append(meta)
            # stack numpy->JAX
            yield jnp.stack(inps), jnp.stack(tars), metas

def coco_jax(**kwargs):
    return MscocoJax(**kwargs)
