import jax
import jax.numpy as jnp
from flax import linen as nn
from ogb.utils.features import get_atom_feature_dims, get_bond_feature_dims

# Retrieve the feature‐dim lists (same as in PyTorch)
full_atom_feature_dims = get_atom_feature_dims()
full_bond_feature_dims = get_bond_feature_dims()

class AtomEncoder(nn.Module):
    emb_dim: int
    atom_feature_dims: list[int]

    @nn.compact
    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        """
        x: int array of shape [batch, num_atom_features]
        returns: float array [batch, emb_dim]
        """
        # Sum embeddings over each feature channel
        out = 0.0
        for i, dim in enumerate(self.atom_feature_dims):
            emb = nn.Embed(
                num_embeddings=dim,
                features=self.emb_dim,
                embedding_init=nn.initializers.xavier_uniform(),
                name=f"atom_embed_{i}"
            )
            # x[:, i] has ints in [0, dim)
            out = out + emb(x[:, i])
        return out

class BondEncoder(nn.Module):
    emb_dim: int
    bond_feature_dims: list[int]

    @nn.compact
    def __call__(self, edge_attr: jnp.ndarray) -> jnp.ndarray:
        """
        edge_attr: int array of shape [batch, num_bond_features]
        returns: float array [batch, emb_dim]
        """
        out = 0.0
        for i, dim in enumerate(self.bond_feature_dims):
            emb = nn.Embed(
                num_embeddings=dim,
                features=self.emb_dim,
                embedding_init=nn.initializers.xavier_uniform(),
                name=f"bond_embed_{i}"
            )
            out = out + emb(edge_attr[:, i])
        return out

def main():
    # Example of instantiation + forward pass
    # In practice, encoder parameters are included in a Flax train-state.
    from loader import GraphClassificationPygDataset  # your dataset loader

    # Prepare data
    dataset = GraphClassificationPygDataset(name='tox21')
    x = jnp.array(dataset[0].x, dtype=jnp.int32)           # [num_nodes, num_atom_features]
    edge_attr = jnp.array(dataset[0].edge_attr, dtype=jnp.int32)  # [num_edges, num_bond_features]

    # Initialize PRNG keys
    rng = jax.random.PRNGKey(0)
    rng, atom_key, bond_key = jax.random.split(rng, 3)

    # Initialize modules
    atom_enc = AtomEncoder(emb_dim=100, atom_feature_dims=full_atom_feature_dims)
    bond_enc = BondEncoder(emb_dim=100, bond_feature_dims=full_bond_feature_dims)

    # Initialize parameters with dummy inputs
    atom_params = atom_enc.init({'params': atom_key}, x)['params']
    bond_params = bond_enc.init({'params': bond_key}, edge_attr)['params']

    # Apply encoders
    atom_embeddings = atom_enc.apply({'params': atom_params}, x)
    bond_embeddings = bond_enc.apply({'params': bond_params}, edge_attr)

    print("Atom embeddings shape:", atom_embeddings.shape)
    print("Bond embeddings shape:", bond_embeddings.shape)

if __name__ == "__main__":
    main()
