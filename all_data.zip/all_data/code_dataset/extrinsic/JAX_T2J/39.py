import json
import jax
import jax.numpy as jnp
from secret_sauce.action_models_jax import action_train, action_predict

# --- load and prepare your training data (unchanged JSON structure) ---
with open("app/datasets/action_dataset.json", "r") as f:
    training_data = json.load(f)

# If your action_train expects arrays rather than Python lists,
# you can convert fields inside training_data to jnp.arrays here.
# For example, if each example is a dict with a feature vector "x":
# for ex in training_data:
#     ex["x"] = jnp.array(ex["x"], dtype=jnp.float32)

# --- train the JAX model ---
# we pass the same arguments: number of steps and our parsed data
action_train(num_steps=20_000, data=training_data)

# --- predict on a new input ---
intent = action_predict("hello")
print(f"intent: {intent}")
