import collections
import random as pyrandom

import jax
import jax.numpy as jnp
import numpy as np

from serpent.machine_learning.reinforcement_learning.rainbow_dqn.segment_tree import SegmentTree

Transition = collections.namedtuple(
    "Transition",
    ("timestep", "state", "action", "reward", "nonterminal")
)
_blank_state = jnp.zeros((100, 100), dtype=jnp.uint8)

blank_transition = Transition(
    timestep=0,
    state=_blank_state,
    action=None,
    reward=0.0,
    nonterminal=False
)

class ReplayMemory:
    def __init__(
        self,
        capacity: int,
        history: int = 4,
        discount: float = 0.99,
        multi_step: int = 3,
        priority_weight: float = 0.4,
        priority_exponent: float = 0.5
    ):
        self.capacity = capacity
        self.history = history
        self.discount = discount
        self.multi_step = multi_step
        self.priority_weight = priority_weight
        self.priority_exponent = priority_exponent

        self.timestep = 0
        # Underlying circular buffer with a SegmentTree
        self.transitions = SegmentTree(capacity)
        self.full = False
        self.next_idx = 0

    def __len__(self):
        return self.capacity if self.full else self.next_idx

    def append(self, state: jnp.ndarray, action: int, reward: float, terminal: bool):
        # quantize state to uint8 on host
        cpu_state = (state[-1] * 255).astype(jnp.uint8)
        trans = Transition(
            timestep=self.timestep,
            state=cpu_state,
            action=action,
            reward=reward,
            nonterminal=not terminal
        )
        # insert with max priority
        self.transitions.append(trans, self.transitions.max())
        # advance
        self.timestep = 0 if terminal else self.timestep + 1
        if not self.full:
            self.next_idx += 1
            if self.next_idx == self.capacity:
                self.full = True

    def sample(self, batch_size: int, key: jax.random.KeyArray):
        total_p = self.transitions.total()
        seg = total_p / batch_size

        # draw one index per segment
        idxs = []
        ks = jax.random.split(key, batch_size)
        for i, k in enumerate(ks):
            s = jax.random.uniform(k, minval=i*seg, maxval=(i+1)*seg)
            p, idx, tree_idx = self.transitions.find(float(s))
            # ensure valid multi-step/history window
            # fallback to resample if invalid
            while ((self.next_idx - idx) % self.capacity <= self.multi_step
                   or (idx - self.next_idx) % self.capacity < self.history
                   or p == 0):
                s = pyrandom.uniform(i*seg, (i+1)*seg)  # small use of Python RNG
                p, idx, tree_idx = self.transitions.find(s)
            idxs.append((p, idx, tree_idx))

        # gather transitions
        batch = [self._get_transition(idx) for (_, idx, tree_idx) in idxs]
        probs, indices, tree_idxs, states, actions, returns, next_states, nonterms = zip(*batch)

        probs = jnp.array(probs, dtype=jnp.float32) / total_p
        weights = (len(self) * probs) ** -self.priority_weight
        weights = weights / jnp.max(weights)

        return (
            tree_idxs,
            jnp.stack(states),                # [B, history, H, W] float32
            jnp.array(actions, dtype=jnp.int32),
            jnp.stack(returns),               # [B, 1] float32
            jnp.stack(next_states),           # [B, history, H, W] float32
            jnp.stack(nonterms),              # [B, 1] float32
            weights
        )

    def update_priorities(self, indices, new_priorities):
        # exponentiate and update tree
        ps = (jnp.array(new_priorities) ** self.priority_exponent).tolist()
        for idx, p in zip(indices, ps):
            self.transitions.update(idx, float(p))

    def _get_transition(self, idx: int):
        buf = [None] * (self.history + self.multi_step)
        # center
        buf[self.history - 1] = self.transitions.get(idx)
        # build history
        prev_t = buf[self.history - 1].timestep
        for t in range(self.history - 2, -1, -1):
            if prev_t == 0:
                buf[t] = blank_transition
            else:
                buf[t] = self.transitions.get((idx + t - self.history + 1) % self.capacity)
                prev_t -= 1
        # build multi-step
        for t in range(self.history, self.history + self.multi_step):
            if buf[t-1].nonterminal:
                buf[t] = self.transitions.get((idx - self.history + 1 + t) % self.capacity)
            else:
                buf[t] = blank_transition
        return buf

    def _get_sample_from_segment(self, *args, **kwargs):
        raise NotImplementedError(
            "_get_sample_from_segment is handled inside sample()"
        )
