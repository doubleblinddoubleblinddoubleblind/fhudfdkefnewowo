from __future__ import absolute_import, division, print_function

import functools
import inspect
import os
from collections.abc import Mapping
from contextlib import contextmanager

from odin.backend import (interpolation, keras_callbacks, keras_helpers, losses,
                          metrics)
from odin.backend.alias import *
from odin.backend.maths import *
from odin.backend.tensor import *
from odin.backend.types_helpers import *
from odin.utils import as_tuple, is_path, is_string
from six import add_metaclass
from six.moves import builtins, cPickle

import jax
import jax.numpy as jnp
import flax.linen as nn
from odin import networks_jax  # your JAX-specific custom layers/helpers


# ===========================================================================
# Make the layers accessible through backend
# ===========================================================================
class _nn_meta(type):

    def __getattr__(cls, key):
        fw = get_framework()
        all_objects = {}

        # PyTorch path (unchanged)
        if fw.__name__ == "torch":
            import torch
            from odin import networks_torch
            all_objects.update(torch.nn.__dict__)
            all_objects.update(networks_torch.__dict__)

        # TensorFlow path (unchanged)
        elif fw.__name__ in ("tensorflow", "tensorflow.python.framework.ops"):
            import tensorflow as tf
            from odin import networks
            from tensorflow.python.keras.engine import sequential, training
            all_objects.update(tf.keras.layers.__dict__)
            all_objects.update(networks.__dict__)
            all_objects.update(sequential.__dict__)
            all_objects.update(training.__dict__)

        # JAX path (new)
        elif fw.__name__ in ("jax", "jax.numpy"):
            # Core Flax layers
            all_objects.update(nn.__dict__)
            # Any custom JAX layers/helpers
            all_objects.update(networks_jax.__dict__)

        else:
            raise NotImplementedError(f"No neural networks support for framework: {fw}")

        try:
            return all_objects[key]
        except KeyError:
            raise AttributeError(f"Layer '{key}' not found in framework {fw}")

@add_metaclass(_nn_meta)
class nn:
    """Proxy for backend neural‐network layers/functions.

    Usage:
        from odin.backend.nn import Dense, Conv2D, etc.

    Dynamically routes to:
      - torch.nn when get_framework() is torch  
      - tf.keras.layers when TensorFlow  
      - flax.linen when JAX  
    """
    pass
