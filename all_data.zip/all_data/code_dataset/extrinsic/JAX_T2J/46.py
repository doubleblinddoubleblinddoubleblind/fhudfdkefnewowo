import jax
import jax.numpy as jnp
from flax import linen as nn

# -------------------------------------------------------------------
# Base module
# -------------------------------------------------------------------
class ResNetWSL(nn.Module):
    """Flax version of ResNetWSL with Wildcat pooling."""
    base: nn.Module            # e.g. ResNet50(..., include_top=False)
    num_classes: int           # number of output channels for classifier
    pooling: nn.Module         # e.g. a Flax WildcatPool2d equivalent
    dense: bool = False        # whether to apply pooling

    @nn.compact
    def __call__(self, x):
        # Image normalization (N, H, W, C) assumed
        mean = jnp.array([0.485, 0.456, 0.406]).reshape((1,1,1,3))
        std  = jnp.array([0.229, 0.224, 0.225]).reshape((1,1,1,3))
        x = (x - mean) / std

        # Extract features
        # Assumes `self.base` returns the feature map up to layer4
        x = self.base(x)

        # 1×1 classifier conv
        x = nn.Conv(
            features=self.num_classes,
            kernel_size=(1,1),
            strides=(1,1),
            padding='SAME',
            use_bias=True,
            name='classifier_conv'
        )(x)

        if not self.dense:
            x = self.pooling(x)

        return x

# -------------------------------------------------------------------
# Factory functions
# -------------------------------------------------------------------
def resnet50_wildcat(num_classes,
                     pretrained=True,
                     kmax=1, kmin=None, alpha=1,
                     num_maps=1):
    """
    Instantiate a ResNet50-based WSL model.
    """
    # Import your Flax ResNet-50 here; adjust as needed
    from flaxmodels import ResNet50

    # Load backbone without the final Dense head
    backbone = ResNet50(
        pretrained=pretrained,
        include_top=False,   # drop final classification head
        name='resnet50_backbone'
    )

    # Build pooling: class-wise then spatial
    # You’ll need Flax/JAX equivalents of ClassWisePool & WildcatPool2d
    pooling = nn.Sequential([
        ClassWisePool(num_maps=name='class_wise_pool'),   # implement in JAX
        WildcatPool2d(kmax=kmax, kmin=kmin, alpha=alpha, name='wildcat_pool')
    ], name='wildcat_pooling')

    return ResNetWSL(
        base=backbone,
        num_classes=num_classes * num_maps,
        pooling=pooling,
        dense=False
    )

def resnet101_wildcat(num_classes,
                      pretrained=True,
                      kmax=1, kmin=None, alpha=1,
                      num_maps=1):
    """
    Instantiate a ResNet101-based WSL model.
    """
    from flaxmodels import ResNet101

    backbone = ResNet101(
        pretrained=pretrained,
        include_top=False,
        name='resnet101_backbone'
    )

    pooling = nn.Sequential([
        ClassWisePool(num_maps, name='class_wise_pool'),
        WildcatPool2d(kmax=kmax, kmin=kmin, alpha=alpha, name='wildcat_pool')
    ], name='wildcat_pooling')

    return ResNetWSL(
        base=backbone,
        num_classes=num_classes * num_maps,
        pooling=pooling,
        dense=False
    )
