import jax
import jax.numpy as jnp
from flax import linen as nn
from ray.rllib.models.model import restore_original_dimensions

class JAXModel(nn.Module):
    """Abstract base for a JAX/Flax version of RLlib’s TorchModel."""
    obs_space: object
    num_outputs: int
    options: dict

    def setup(self):
        # No submodules by default; override in concrete subclasses
        pass

    def __call__(self, input_dict, hidden_state):
        # Cast to float32 and restore original observation dims
        obs = input_dict["obs"].astype(jnp.float32)
        obs = restore_original_dimensions(
            obs, self.obs_space, tensorlib=jax)
        # Rebuild input_dict with restored obs
        input_dict = {**input_dict, "obs": obs}

        # Delegate to user‐implemented _forward
        outputs, features, value_fn, new_state = self._forward(
            input_dict, hidden_state)
        return outputs, features, value_fn, new_state

    def state_init(self):
        """Returns initial hidden state(s)."""
        return []

    def _forward(self, input_dict, hidden_state):
        """Override this in subclasses to implement your network.

        Should return a 4‐tuple:
            (outputs, feature_layer, value_fn, new_hidden_state)
        """
        raise NotImplementedError("Must implement `_forward` in subclasses")
