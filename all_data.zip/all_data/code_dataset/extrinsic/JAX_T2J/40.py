import jax
import jax.numpy as jnp
import numpy as np
import heapq
import random

# select_random: same behavior, but could be JIT-disabled host code
def select_random(r, train_size, key, batch0=1280, batch1=128):
    """r: int; train_size: int; key: jax.random.PRNGKey; returns Python list of indices."""
    if r == 0:
        return random.sample(range(train_size), batch0)
    else:
        return random.sample(range(train_size), batch1)


def select_margin(r, model_apply, params, emb_dataset, primary="image", key=None, batch_size=128):
    """
    emb_dataset: dict with 'image' and 'caption' keys mapping to numpy arrays or lists.
    model_apply, params: for model.val_start() equivalent (ignored if embeddings precomputed).
    Returns list of best_n_indices.
    """
    if r == 0:
        return random.sample(range(len(emb_dataset[primary])), batch_size * 10)
    # assume embeddings already extracted; skip model_apply
    primary_embs = jnp.array(emb_dataset[primary])
    secondary_embs = jnp.array(emb_dataset["caption" if primary=="image" else "image"])

    scores = []
    Np, Ns = primary_embs.shape[0], secondary_embs.shape[0]
    for i in range(0, Np, batch_size):
        p_batch = primary_embs[i : i + batch_size]
        # compute cosine distances via matrix‐mul
        # (we use dot; for true cosine, embeddings should be normalized beforehand)
        dists = jnp.abs(jnp.dot(p_batch, secondary_embs.T))
        # for each row, find two smallest distances
        top2 = jnp.sort(dists, axis=1)[:, :2]
        margins = jnp.abs(top2[:, 0] - top2[:, 1])
        scores.extend(np.array(margins))
    # pick 128 smallest margins
    best = heapq.nsmallest(batch_size, enumerate(scores), key=lambda x: x[1])
    return [idx for idx, _ in best]


def select_caption_similarity(r, emb_dataset, batch_size=5):
    if r == 0:
        return random.sample(range(len(emb_dataset["caption"])), batch_size * 256)
    cap_embs = jnp.array(emb_dataset["caption"])
    scores = []
    for i in range(0, cap_embs.shape[0], batch_size):
        batch = cap_embs[i : i + batch_size]
        # average pairwise dot distance
        avg = jnp.mean(jnp.dot(batch, batch.T))
        scores.append(float(avg))
    best = heapq.nsmallest(128, enumerate(scores), key=lambda x: x[1])
    return [idx for idx, _ in best]


def select_uncertainty(r, emb_dataset, batch_size=128):
    if r == 0:
        return random.sample(range(len(emb_dataset["image"])), batch_size * 10)
    primary_embs = jnp.array(emb_dataset["image"])
    secondary_embs = jnp.array(emb_dataset["caption"])

    scores = []
    for i in range(0, primary_embs.shape[0], batch_size):
        p_batch = primary_embs[i : i + batch_size]
        dists = jnp.dot(p_batch, secondary_embs.T)
        # indices of 10 smallest distances
        idx10 = jnp.argsort(dists, axis=1)[:, :10]
        for row in np.array(idx10):
            # gather corresponding secondary_embs and compute std
            vecs = secondary_embs[row]
            scores.append(float(jnp.std(vecs)))
    best = heapq.nlargest(128, enumerate(scores), key=lambda x: x[1])
    return [idx for idx, _ in best]


def select_hybrid(r, train_size, key, **kwargs):
    if r == 0:
        return random.sample(range(train_size), 1280)
    elif r % 2 == 0:
        return select_uncertainty(r, **kwargs)
    else:
        return select_margin(r, **kwargs)


def select_all(r, train_size, feature_dim):
    if r == 0:
        return list(range(train_size * feature_dim - feature_dim))
    else:
        raise SystemExit("Done!")
