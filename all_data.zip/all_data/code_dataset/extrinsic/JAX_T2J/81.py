import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Callable, Optional


class ResNeXtBottleneck(nn.Module):
    inplanes: int
    planes: int
    cardinality: int
    base_width: int
    stride: int = 1
    downsample: Optional[Callable] = None

    expansion: int = 4

    def setup(self):
        D = int(self.planes * (self.base_width / 64.0))
        C = self.cardinality

        # 1×1 reduce
        self.conv_reduce = nn.Conv(
            features=D * C, kernel_size=(1,1), strides=(1,1), use_bias=False
        )
        self.bn_reduce = nn.BatchNorm(use_running_average=True)

        # 3×3 grouped conv
        self.conv_conv = nn.Conv(
            features=D * C,
            kernel_size=(3,3),
            strides=(self.stride, self.stride),
            padding='SAME',
            feature_group_count=C,
            use_bias=False,
        )
        self.bn = nn.BatchNorm(use_running_average=True)

        # 1×1 expand
        self.conv_expand = nn.Conv(
            features=self.planes * self.expansion,
            kernel_size=(1,1),
            strides=(1,1),
            use_bias=False,
        )
        self.bn_expand = nn.BatchNorm(use_running_average=True)

        if self.downsample is not None:
            # downsample is expected to be a Flax Module or function returning x → conv+bn
            self.down = self.downsample

    def __call__(self, x, *, train: bool):
        residual = x

        # reduce
        y = self.conv_reduce(x)
        y = self.bn_reduce(y, use_running_average=not train)
        y = nn.relu(y)

        # conv
        y = self.conv_conv(y)
        y = self.bn(y, use_running_average=not train)
        y = nn.relu(y)

        # expand
        y = self.conv_expand(y)
        y = self.bn_expand(y, use_running_average=not train)

        if self.downsample is not None:
            residual = self.down(residual, train=train)

        return nn.relu(residual + y)


class CifarResNeXt(nn.Module):
    block: Callable  # e.g. ResNeXtBottleneck
    depth: int
    cardinality: int
    base_width: int
    num_classes: int

    def setup(self):
        assert (self.depth - 2) % 9 == 0, "depth should be one of 29, 38, 47, 56, 101"
        self.layer_blocks = (self.depth - 2) // 9

        # initial conv + bn
        self.conv1 = nn.Conv(features=64, kernel_size=(3,3), strides=(1,1), padding='SAME', use_bias=False)
        self.bn1 = nn.BatchNorm(use_running_average=True)

        # keep track of current inplanes
        self.inplanes = 64

        # build stages
        self.stage1 = self._make_layer(planes=64, stride=1)
        self.stage2 = self._make_layer(planes=128, stride=2)
        self.stage3 = self._make_layer(planes=256, stride=2)

        # global pool and classifier
        self.avgpool = nn.avg_pool
        self.fc = nn.Dense(features=self.num_classes)

    def _make_layer(self, *, planes: int, stride: int):
        layers = []

        exp_planes = planes * self.block.expansion
        downsample = None
        if stride != 1 or self.inplanes != exp_planes:
            # create a conv+bn downsample
            downsample = lambda x, train: nn.BatchNorm(use_running_average=not train)(
                nn.Conv(
                    features=exp_planes,
                    kernel_size=(1,1),
                    strides=(stride, stride),
                    use_bias=False
                )(x),
                use_running_average=not train
            )

        # first block with possible downsample
        layers.append(
            self.block(
                inplanes=self.inplanes,
                planes=planes,
                cardinality=self.cardinality,
                base_width=self.base_width,
                stride=stride,
                downsample=downsample
            )
        )
        self.inplanes = exp_planes

        # remaining blocks
        for _ in range(1, self.layer_blocks):
            layers.append(
                self.block(
                    inplanes=self.inplanes,
                    planes=planes,
                    cardinality=self.cardinality,
                    base_width=self.base_width,
                    stride=1,
                    downsample=None
                )
            )

        return layers

    def __call__(self, x, *, train: bool):
        # initial
        x = nn.relu(self.bn1(self.conv1(x), use_running_average=not train))

        # stages
        for blk in self.stage1:
            x = blk(x, train=train)
        for blk in self.stage2:
            x = blk(x, train=train)
        for blk in self.stage3:
            x = blk(x, train=train)

        # global average pool over H×W
        x = self.avgpool(x, window_shape=(x.shape[1], x.shape[2]), strides=(1,1), padding='VALID')
        x = x.reshape((x.shape[0], -1))

        # classifier and log‐softmax
        logits = self.fc(x)
        return nn.log_softmax(logits)
  

def resnext29_16_64(num_classes: int = 10):
    return CifarResNeXt(
        block=ResNeXtBottleneck,
        depth=29,
        cardinality=16,
        base_width=64,
        num_classes=num_classes
    )


def resnext29_8_64(num_classes: int = 10):
    return CifarResNeXt(
        block=ResNeXtBottleneck,
        depth=29,
        cardinality=8,
        base_width=64,
        num_classes=num_classes
    )
