import argparse
import time

import numpy as np
import jax
import jax.numpy as jnp
from jax import grad, jit, random, vmap, value_and_grad
import optax
import tensorflow_datasets as tfds
import tensorflow as tf
from flax import linen as nn
from flax.training import train_state

# Precomputed characteristics of the MNIST dataset
MNIST_MEAN = 0.1307
MNIST_STD = 0.3081

class SampleConvNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        # x: [B, 1, 28, 28]
        x = nn.Conv(features=16, kernel_size=(8,8), strides=(2,2), padding=((3,3),(3,3)))(x)
        x = nn.relu(x)                               # [B,16,14,14]
        x = nn.max_pool(x, window_shape=(2,2), strides=(1,1))  # [B,16,13,13]
        x = nn.Conv(features=32, kernel_size=(4,4), strides=(2,2))(x)
        x = nn.relu(x)                               # [B,32,5,5]
        x = nn.max_pool(x, window_shape=(2,2), strides=(1,1))  # [B,32,4,4]
        x = x.reshape((x.shape[0], -1))              # [B,512]
        x = nn.Dense(features=32)(x)
        x = nn.relu(x)                               # [B,32]
        x = nn.Dense(features=10)(x)                 # [B,10]
        return x

def create_train_state(rng, learning_rate):
    """Initialize model and optimizer state."""
    model = SampleConvNet()
    params = model.init(rng, jnp.ones([1,1,28,28]))['params']
    tx = optax.sgd(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

@jit
def train_step(state, batch):
    """Single training step."""
    imgs, labels = batch
    def loss_fn(params):
        logits = state.apply_fn({'params': params}, imgs)
        onehot = jax.nn.one_hot(labels, 10)
        loss = jnp.mean(optax.softmax_cross_entropy(logits=logits, labels=onehot))
        return loss
    loss, grads = value_and_grad(loss_fn)(state.params)
    state = state.apply_gradients(grads=grads)
    return state, loss

@jit
def eval_step(params, batch):
    imgs, labels = batch
    logits = SampleConvNet().apply({'params': params}, imgs)
    pred = jnp.argmax(logits, axis=-1)
    return jnp.mean(pred == labels)

def main():
    tf.config.experimental.set_visible_devices([], "GPU")  # avoid TF GPU
    parser = argparse.ArgumentParser(description="JAX MNIST Example")
    parser.add_argument("-b", "--batch-size", type=int, default=250, help="batch size")
    parser.add_argument("-n", "--epochs",     type=int, default=15,  help="number of epochs")
    parser.add_argument("--lr",               type=float, default=0.25, help="learning rate")
    parser.add_argument("--disable-dp",       action="store_true", help="disable DP (not implemented)")
    parser.add_argument("--data-root",        type=str, default=".", help="TFDS data dir")
    args = parser.parse_args()

    # Load and preprocess entire dataset in memory
    ds = tfds.as_numpy(tfds.load("mnist", batch_size=-1, data_dir=args.data_root))
    train_images = ds['train']['image'].astype(np.float32)
    train_labels = ds['train']['label'].astype(np.int32)
    test_images  = ds['test']['image'].astype(np.float32)
    test_labels  = ds['test']['label'].astype(np.int32)

    # normalize and reshape: [N,28,28,1] → [N,1,28,28]
    def norm(img):
        img = img / 255.0
        return (img - MNIST_MEAN) / MNIST_STD
    train_images = norm(train_images).transpose(0,3,1,2)
    test_images  = norm(test_images).transpose(0,3,1,2)

    ntrain = train_images.shape[0]
    num_batches = ntrain // args.batch_size

    # Python generator for shuffled batches
    def data_stream():
        key = np.random.RandomState(0)
        while True:
            perm = key.permutation(ntrain)
            for i in range(num_batches):
                idx = perm[i*args.batch_size:(i+1)*args.batch_size]
                yield train_images[idx], train_labels[idx]
    train_ds = data_stream()

    def test_batch():
        yield test_images, test_labels
    test_ds = test_batch()

    # Initialize model & optimizer
    rng = random.PRNGKey(0)
    state = create_train_state(rng, args.lr)

    # Training loop
    epoch_times = []
    for epoch in range(args.epochs):
        start = time.time()
        for _ in range(num_batches):
            batch = next(train_ds)
            state, loss = train_step(state, batch)
        t = time.time() - start
        epoch_times.append(t)
        print(f"Train Epoch: {epoch}  Loss: {loss:.4f}  Time: {t:.2f}s")

    print("Avg epoch time: %.2f Median: %.2f (except first avg: %.2f)" %
          (np.mean(epoch_times), np.median(epoch_times), np.mean(epoch_times[1:])))

    # Evaluation
    test_images, test_labels = next(test_ds)
    acc = eval_step(state.params, (test_images, test_labels))
    print(f"Test Accuracy: {acc*100:.2f}%")

if __name__ == "__main__":
    main()
