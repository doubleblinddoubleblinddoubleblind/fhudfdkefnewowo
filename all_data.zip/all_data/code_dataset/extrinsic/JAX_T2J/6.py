import argparse
import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import flax.linen as nn
import tensorflow_datasets as tfds

# ----------------------------
# Model Definition (Flax)
# ----------------------------
class Net(nn.Module):
    @nn.compact
    def __call__(self, x, train: bool):
        x = x[..., None]                             # add channel dim
        x = nn.Conv(features=10, kernel_size=(5,5))(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        x = nn.relu(x)
        x = nn.Conv(features=20, kernel_size=(5,5))(x)
        x = nn.Dropout(0.5, deterministic=not train)(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        x = nn.relu(x)
        x = x.reshape((x.shape[0], -1))              # flatten
        x = nn.Dense(features=50)(x)
        x = nn.relu(x)
        x = nn.Dropout(0.5, deterministic=not train)(x)
        x = nn.Dense(features=10)(x)
        return nn.log_softmax(x)

# ----------------------------
# Data Loading
# ----------------------------
def load_datasets(batch_size, seed):
    ds_builder = tfds.builder('mnist')
    ds_builder.download_and_prepare()
    def _prep(example):
        img = example['image'] / 255.0
        lbl = example['label']
        return jnp.array(img, dtype=jnp.float32), jnp.array(lbl, jnp.int32)
    train = ds_builder.as_dataset(split='train', shuffle_files=True)
    train = train.shuffle(10_000, seed=seed).map(_prep).batch(batch_size)
    test  = ds_builder.as_dataset(split='test',  shuffle_files=False)
    test  = test.map(_prep).batch(batch_size)
    return train, test

# ----------------------------
# Train / Eval Steps
# ----------------------------
@jit
def train_step(params, state, batch, rng):
    imgs, labels = batch
    def loss_fn(p):
        logits = Net().apply({'params': p}, imgs, True, rngs={'dropout': rng})
        onehot = jax.nn.one_hot(labels, 10)
        return -jnp.mean(jnp.sum(logits * onehot, axis=-1))
    (loss, grads) = value_and_grad(loss_fn)(params)
    updates, new_opt_state = state.optimizer.update(grads, state.opt_state)
    new_params = optax.apply_updates(params, updates)
    return new_params, state.replace(opt_state=new_opt_state), loss

@jit
def eval_step(params, batch):
    imgs, labels = batch
    logits = Net().apply({'params': params}, imgs, False)
    pred = jnp.argmax(logits, axis=-1)
    acc = jnp.mean(pred == labels)
    return acc

# ----------------------------
# Main
# ----------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch-size', type=int, default=64)
    parser.add_argument('--epochs',     type=int, default=10)
    parser.add_argument('--lr',         type=float, default=0.01)
    parser.add_argument('--seed',       type=int, default=1)
    args = parser.parse_args()

    rng = random.PRNGKey(args.seed)
    rng, init_rng = random.split(rng)

    train_ds, test_ds = load_datasets(args.batch_size, args.seed)

    # Initialize parameters and optimizer
    dummy_x = jnp.zeros((1,28,28), jnp.float32)
    params = Net().init(init_rng, dummy_x, False)['params']
    optimizer = optax.sgd(args.lr, momentum=0.5)
    opt_state = optimizer.init(params)

    from flax.struct import dataclass
    @dataclass
    class TrainState:
        optimizer: optax.GradientTransformation
        opt_state: optax.OptState

    state = TrainState(optimizer, opt_state)

    for epoch in range(1, args.epochs + 1):
        # Training
        for batch in train_ds:
            rng, step_rng = random.split(rng)
            params, state, loss = train_step(params, state, batch, step_rng)

        # Evaluation
        accs = [eval_step(params, batch) for batch in test_ds]
        test_acc = jnp.mean(jnp.stack(accs))
        print(f"Epoch {epoch}: Test Accuracy: {test_acc * 100:.2f}%")

if __name__ == '__main__':
    main()
