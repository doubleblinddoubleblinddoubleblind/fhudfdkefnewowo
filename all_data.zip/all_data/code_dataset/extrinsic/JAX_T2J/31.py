import time
import pickle
import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Callable, List, Optional, Tuple, Union


PyTree = Any


class Lightnet(nn.Module):
    """
    Base Lightnet framework module in Flax.

    Attributes:
      layers:     Either an nn.Sequential or a Python list of nn.Module
      loss_fns:   A list of callables loss_fn(output, target) when training
      post_fns:   A list of callables postprocess_fn(output) when evaluating
    """
    layers: Optional[Union[nn.Sequential, List[nn.Module]]] = None
    loss_fns: Optional[List[Callable[[jnp.ndarray, jnp.ndarray], jnp.ndarray]]] = None
    post_fns: Optional[List[Callable[[jnp.ndarray], Any]]] = None

    @nn.compact
    def __call__(self,
                 x: jnp.ndarray,
                 target: Optional[jnp.ndarray] = None,
                 train: bool = True
                 ) -> Union[jnp.ndarray, Tuple[Any, float]]:
        # We keep `seen` in the mutable collection "batch_stats" so it updates each step.
        seen = self.variable("batch_stats", "seen", lambda: jnp.array(0, dtype=jnp.int32))

        def _forward(inputs):
            if isinstance(self.layers, nn.Sequential):
                return self.layers(inputs)
            elif isinstance(self.layers, list):
                out = inputs
                for layer in self.layers:
                    out = layer(out)
                return out
            else:
                raise NotImplementedError(f"No default _forward for layers type {type(self.layers)}")

        outputs = _forward(x)

        if train:
            # increment seen
            seen.value += x.shape[0]

            # ensure lengths match
            assert isinstance(outputs, (list, tuple)) and len(outputs) == len(self.loss_fns)

            total_loss = 0.0
            for out, loss_fn in zip(outputs, self.loss_fns):
                total_loss += loss_fn(out, target)
            return total_loss

        else:
            # evaluation / inference
            assert isinstance(outputs, (list, tuple)) and len(outputs) == len(self.post_fns)
            # apply postprocess to each output
            tdets = [fn(o) for fn, o in zip(self.post_fns, outputs)]
            # collate per-batch
            batch_size = tdets[0].shape[0]
            dets = []
            for i in range(batch_size):
                single = []
                for t in tdets:
                    single.extend(t[i])
                dets.append(single)
            return dets, 0.0


def init_weights(params: PyTree, rng: jax.random.PRNGKey) -> PyTree:
    """
    Example weight initializer (Kaiming for Conv2D, zero for biases, normal for Dense).
    Call this once after model.init().
    """
    # You would traverse `params` pytree here and apply initializers.
    # This is left as a stub, since the details depend on your exact layer types.
    return params


def save_weights(params: PyTree, seen: int, path: str) -> None:
    """
    Save model parameters plus seen count.
    """
    payload = {"seen": int(seen), "params": params}
    with open(path, "wb") as f:
        pickle.dump(payload, f)


def load_weights(path: str) -> Tuple[int, PyTree]:
    """
    Load model parameters plus seen count.
    """
    with open(path, "rb") as f:
        payload = pickle.load(f)
    return payload["seen"], payload["params"]
