#!/usr/bin/env python3
# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# …

import os
import sys
import argparse
import logging

import jax
import jax.numpy as jnp
from transformers import FlaxEncoderDecoderModel, PreTrainedTokenizerFast
import pandas as pd

from new_semantic_parsing import cli_utils
from new_semantic_parsing import EncoderDecoderWPointerModel, TopSchemaTokenizer
from new_semantic_parsing.data import (
    make_dataset,
    make_test_dataset,
    Seq2SeqDataCollator,
    PointerDataset,
)

os.environ["TOKENIZERS_PARALLELISM"] = "false"

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger(os.path.basename(__file__))


def parse_args(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--data",        required=True, help="path to data file")
    parser.add_argument("--model",       required=True, help="path to a Flax model checkpoint")
    parser.add_argument("--output-file", required=True, help="file to save predictions")
    parser.add_argument("--schema-tokenizer", default=None,
                        help="path to saved schema tokenizer; defaults to --model")
    parser.add_argument("--batch-size",  default=32, type=int)
    parser.add_argument("--num-beams",   default=4,  type=int)
    parser.add_argument("--src-max-len", default=63, type=int)
    parser.add_argument("--tgt-max-len", default=98, type=int)
    parser.add_argument("--seed",        default=34, type=int)
    args = parser.parse_args(args)
    args.schema_tokenizer = args.schema_tokenizer or args.model
    if os.path.exists(args.output_file):
        raise ValueError(f"output file {args.output_file} already exists")
    return args


def main():
    args = parse_args()
    # reproducibility
    jax_key = jax.random.PRNGKey(args.seed)

    logger.info("Loading tokenizers")
    schema_tokenizer = TopSchemaTokenizer.load(args.schema_tokenizer)
    text_tokenizer: PreTrainedTokenizerFast = schema_tokenizer.src_tokenizer

    logger.info("Loading data")
    dataset: PointerDataset = make_test_dataset(
        args.data, schema_tokenizer, max_len=args.src_max_len
    )
    collator = Seq2SeqDataCollator(pad_id=text_tokenizer.pad_token_id).collate_batch

    # We can reuse PyTorch DataLoader here for simplicity, since it only batches Python lists
    from torch.utils.data import DataLoader
    dataloader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        collate_fn=collator,
        num_workers=8,
    )

    logger.info(f"Maximum source text length {dataset.get_max_len()[0]}")

    logger.info("Loading Flax model")
    # Load the same checkpoint but as a Flax model
    flax_model: FlaxEncoderDecoderModel = EncoderDecoderWPointerModel.from_pretrained(
        args.model, from_pt=True, dtype=jnp.float32
    )
    params = flax_model.params  # FrozenDict of parameters

    # Inference loop
    all_ids: list = []
    all_str: list = []
    for batch in dataloader:
        # batch is a dict of numpy arrays
        input_ids = jnp.array(batch["input_ids"])
        attention_mask = jnp.array(batch["attention_mask"])

        # generate (Flax supports generate in transformers>=4.27)
        outputs = flax_model.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            num_beams=args.num_beams,
            max_length=args.tgt_max_len,
            params=params,
            prng_key=jax_key,
        )
        # outputs.sequences is a numpy array of shape (batch, seq_len)
        seqs = jnp.array(outputs.sequences)
        texts = text_tokenizer.batch_decode(seqs, skip_special_tokens=True)

        all_ids.extend(seqs.tolist())
        all_str.extend(texts)

    # write predictions
    with open(args.output_file, "w") as f:
        for pred in all_str:
            f.write(pred + "\n")
    with open(args.output_file + ".ids", "w") as f:
        for pred in all_ids:
            f.write(str(pred) + "\n")

    logger.info(f"Prediction finished, results saved to {args.output_file}")
    logger.info(f"Ids saved to {args.output_file}.ids")

    # compute metrics if labeled data available
    try:
        data_df = pd.read_table(args.data, names=["text", "tokens", "schema"])
        dataset_with_labels = make_dataset(args.data, schema_tokenizer)
        targets_str = list(data_df.schema)

        exact_match_str = sum(p == t for p, t in zip(all_str, targets_str)) / len(targets_str)
        logger.info(f"Exact match (strings): {exact_match_str:.4f}")

        targets_ids = [list(ex.labels.numpy()[:-1]) for ex in dataset_with_labels]
        exact_match_ids = sum(str(p) == str(l) for p, l in zip(all_ids, targets_ids)) / len(targets_ids)
        logger.info(f"Exact match (ids): {exact_match_ids:.4f}")

    except FileNotFoundError as e:
        logger.warning(f"No labels available: {e}")


if __name__ == "__main__":
    main()
