import jax
import jax.numpy as jnp
from functools import partial

@partial(jax.jit, static_argnums=())
def nndistance(points1: jnp.ndarray, points2: jnp.ndarray):
    """
    points1: (B, N, D)
    points2: (B, M, D)
    returns:
      dist1: (B, N)  — for each of N points in points1, the distance to its nearest neighbor in points2
      dist2: (B, M)  — for each of M points in points2, the distance to its nearest neighbor in points1
    """
    # Expand dims for pairwise differences
    diff = points1[:, :, None, :] - points2[:, None, :, :]  # (B, N, M, D)
    dists = jnp.linalg.norm(diff, axis=-1)                  # (B, N, M)

    dist1 = jnp.min(dists, axis=-1)  # (B, N)
    dist2 = jnp.min(dists, axis=1)   # (B, M)
    return dist1, dist2

def main():
    # Initialize random data
    key = jax.random.PRNGKey(0)
    key, k1, k2 = jax.random.split(key, 3)
    p1 = jax.random.uniform(k1, shape=(10, 1000, 3))
    p2 = jax.random.uniform(k2, shape=(10, 1500, 3))

    # Make points1 differentiable
    points1 = p1
    points2 = p2

    # Forward pass
    dist1, dist2 = nndistance(points1, points2)
    print("dist1:", dist1)
    print("dist2:", dist2)

    # Compute loss and gradients
    loss = jnp.sum(dist1)
    print("loss:", loss)

    grads_fn = jax.grad(lambda a, b: jnp.sum(nndistance(a, b)[0]))
    grad_p1, grad_p2 = grads_fn(points1, points2)

    print("grad points1 shape:", grad_p1.shape)
    print("grad points2 shape:", grad_p2.shape)

    # (In JAX, arrays go to GPU/TPU automatically if available—no explicit `.cuda()` needed.)
    # You can block until ready before printing if you like:
    # print(grad_p1.block_until_ready(), grad_p2.block_until_ready())

if __name__ == "__main__":
    main()
