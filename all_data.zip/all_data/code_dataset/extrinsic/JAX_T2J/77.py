import jax.numpy as jnp
from dataclasses import dataclass
from typing import Sequence, Optional, Union


@dataclass
class MaskedTensor:
    tensor: jnp.ndarray
    mask: jnp.ndarray

    def __eq__(self, other: "MaskedTensor") -> jnp.ndarray:
        return (self.tensor == other.tensor) & (self.mask == other.mask)


class MaskedTorch:
    @staticmethod
    def cat(tensors: Sequence[MaskedTensor], dim: int = 0) -> MaskedTensor:
        ts = [t.tensor for t in tensors]
        ms = [t.mask   for t in tensors]
        return MaskedTensor(
            tensor=jnp.concatenate(ts, axis=dim),
            mask  =jnp.concatenate(ms, axis=dim),
        )

    @staticmethod
    def stack(tensors: Sequence[MaskedTensor], dim: int = 0) -> MaskedTensor:
        ts = [t.tensor for t in tensors]
        ms = [t.mask   for t in tensors]
        return MaskedTensor(
            tensor=jnp.stack(ts, axis=dim),
            mask  =jnp.stack(ms, axis=dim),
        )

    @staticmethod
    def zeros(*shape: int, dtype: Optional[Union[jnp.dtype, str]] = None) -> MaskedTensor:
        tensor = jnp.zeros(shape, dtype=dtype)
        mask   = jnp.zeros(shape, dtype=jnp.bool_)
        return MaskedTensor(tensor=tensor, mask=mask)

    @staticmethod
    def sum(x: MaskedTensor, *args, **kwargs) -> jnp.ndarray:
        # Fallback: just sum the underlying values
        return jnp.sum(x.tensor, *args, **kwargs)
