import jax
import jax.numpy as jnp
from flax import linen as nn
from hypergan.gan_component import GANComponent

class BaseLoss(GANComponent):
    def __init__(self, gan, config):
        super().__init__(gan, config)
        # use jax.nn.relu as the activation
        self.relu = jax.nn.relu

    def create(self, *args):
        pass

    def required(self):
        # no required extra inputs
        return []

    def __call__(self, d_real, d_fake):
        # assume self._forward returns (d_loss_tensor, g_loss_tensor)
        d_loss_t, g_loss_t = self._forward(d_real, d_fake)
        # take means just like in PyTorch
        d_loss = jnp.mean(d_loss_t)
        g_loss = jnp.mean(g_loss_t)
        return d_loss, g_loss
