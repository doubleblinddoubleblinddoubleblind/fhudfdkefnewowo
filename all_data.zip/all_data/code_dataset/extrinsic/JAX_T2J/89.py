import numpy as np
import jax.numpy as jnp

from fairseq.data import FairseqDataset, plasma_utils
from fairseq.data.token_block_utils_fast import (
    _get_slice_indices_fast,
    _get_block_to_dataset_index_fast,
)

class TokenBlockDataset(FairseqDataset):
    """Break a Dataset of tokens into blocks, JAX-compatible version."""

    def __init__(
        self,
        dataset,
        sizes,
        block_size,
        pad,
        eos,
        break_mode=None,
        include_targets=False,
        document_sep_len=1,
    ):
        super().__init__()
        self.dataset = dataset
        self.pad = pad
        self.eos = eos
        self.include_targets = include_targets

        # Ensure sizes is a 1D NumPy array of int64
        if isinstance(sizes, list):
            sizes_arr = np.array(sizes, dtype=np.int64)
        else:
            sizes_arr = np.array(sizes, dtype=np.int64)

        break_mode = break_mode or "none"
        if break_mode == "eos" and block_size is None:
            block_size = 0

        # compute slice indices: shape (num_blocks, 2)
        slice_indices = _get_slice_indices_fast(
            sizes_arr, break_mode, block_size, document_sep_len
        )
        # block lengths
        block_lengths = slice_indices[:, 1] - slice_indices[:, 0]

        # build mapping from block index to (start_ds_idx, start_offset, end_ds_idx)
        if break_mode == "eos":
            # simpler for EOS mode
            n = len(sizes_arr)
            b2d = np.stack([
                np.arange(n),
                np.zeros(n, dtype=np.int64),
                np.arange(n),
            ], axis=1)
        else:
            b2d = _get_block_to_dataset_index_fast(sizes_arr, slice_indices)

        # wrap in PlasmaArray for shared memory / zero copy
        self._slice_indices = plasma_utils.PlasmaArray(slice_indices)
        self._sizes = plasma_utils.PlasmaArray(block_lengths)
        self._block_to_dataset_index = plasma_utils.PlasmaArray(b2d)

    @property
    def slice_indices(self):
        # returns a NumPy array of shape (num_blocks, 2)
        return self._slice_indices.array

    @property
    def sizes(self):
        return self._sizes.array

    @property
    def block_to_dataset_index(self):
        return self._block_to_dataset_index.array

    def attr(self, attr: str, index: int):
        start_ds_idx, _, _ = self.block_to_dataset_index[index]
        return getattr(self.dataset, attr)(start_ds_idx)

    def __getitem__(self, index):
        start_ds_idx, start_offset, end_ds_idx = self.block_to_dataset_index[index]

        # gather all tokens between start_ds_idx and end_ds_idx
        # assume each self.dataset[i] returns a 1D array of tokens (NumPy or JAX)
        pieces = [self.dataset[i] for i in range(start_ds_idx, end_ds_idx + 1)]
        # convert to JAX array
        buffer = jnp.concatenate([jnp.asarray(p) for p in pieces], axis=0)

        slice_s, slice_e = self.slice_indices[index]
        length = slice_e - slice_s
        s, e = start_offset, start_offset + length
        item = buffer[s:e]

        if self.include_targets:
            # construct source, target, past_target
            # item has dtype int (token IDs)
            pad_arr = jnp.array([self.pad], dtype=item.dtype)
            eos_arr = jnp.array([self.eos], dtype=item.dtype)

            if s == 0:
                # left-pad with eos
                source = jnp.concatenate([eos_arr, buffer[0 : e - 1]], axis=0)
                past_target = jnp.concatenate(
                    [pad_arr, eos_arr, buffer[0 : e - 2]], axis=0
                )
            else:
                source = buffer[s - 1 : e - 1]
                if s == 1:
                    past_target = jnp.concatenate([eos_arr, buffer[0 : e - 2]], axis=0)
                else:
                    past_target = buffer[s - 2 : e - 2]

            return source, item, past_target

        return item

    def __len__(self):
        return len(self.slice_indices)

    @property
    def supports_prefetch(self):
        return getattr(self.dataset, "supports_prefetch", False)

    def prefetch(self, indices):
        # turn block indices into dataset indices and prefetch
        ds_idxs = {
            ds_idx
            for idx in indices
            for start_ds, _, end_ds in [self.block_to_dataset_index[idx]]
            for ds_idx in range(start_ds, end_ds + 1)
        }
        self.dataset.prefetch(ds_idxs)
