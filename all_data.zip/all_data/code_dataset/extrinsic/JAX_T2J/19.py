import jax
import jax.numpy as jnp
import tensorflow as tf
import tensorflow_datasets as tfds
from functools import partial

# Defaults from timm
IMAGENET_MEAN = jnp.array([0.485, 0.456, 0.406])
IMAGENET_STD  = jnp.array([0.229, 0.224, 0.225])

def _pil_interp_tf(method: str):
    # Map PIL modes to TF resize methods
    if method == 'bicubic':
        return tf.image.ResizeMethod.BICUBIC
    elif method == 'lanczos':
        return tf.image.ResizeMethod.LANCZOS3
    elif method == 'hamming':
        return tf.image.ResizeMethod.LANCZOS5
    else:
        return tf.image.ResizeMethod.BILINEAR

def build_transform(is_train: bool, config):
    """Returns a tf.data-compatible preprocessing fn."""
    interp = _pil_interp_tf(config.DATA.INTERPOLATION)
    size = config.DATA.IMG_SIZE
    mean = IMAGENET_MEAN
    std  = IMAGENET_STD

    def _train_preprocess(example):
        img = example['image']
        # RandomResizedCrop equivalent
        img = tf.image.random_crop(img, size=[size, size, 3])
        img = tf.image.random_flip_left_right(img)
        # (Optional) auto augment, color_jitter, etc. could be plugged here.
        img = tf.cast(img, tf.float32) / 255.0
        img = (img - mean) / std
        label = example['label']
        return img, label

    def _val_preprocess(example):
        img = example['image']
        # Resize + center crop
        scaled = tf.image.resize(img, [int((256/224)*size), int((256/224)*size)], method=interp)
        img = tf.image.central_crop(scaled, size/ (int((256/224)*size)))
        img = tf.image.resize(img, [size, size], method=interp)
        img = tf.cast(img, tf.float32) / 255.0
        img = (img - mean) / std
        label = example['label']
        return img, label

    return _train_preprocess if is_train else _val_preprocess

def build_dataset(is_train: bool, config):
    split = 'train' if is_train else 'validation'
    ds = tfds.load('imagenet2012',
                   split=split,
                   data_dir=config.DATA.DATA_PATH if not config.DATA.ZIP_MODE else None,
                   download=not config.DATA.ZIP_MODE)
    preprocess_fn = build_transform(is_train, config)
    ds = ds.map(preprocess_fn, num_parallel_calls=tf.data.AUTOTUNE)

    if is_train:
        if config.DATA.ZIP_MODE and config.DATA.CACHE_MODE == 'part':
            # Emulate partial cache by sharding indices
            ds = ds.shard(num_shards=jax.process_count(), index=jax.process_index())
        else:
            ds = ds.shuffle(buffer_size=10_000)
    ds = ds.cache() if config.DATA.CACHE_MODE != 'none' else ds
    return ds

def build_loader(config, rng_key: jax.random.PRNGKey):
    """Returns train & val tf.data.Datasets and an optional mixup function."""
    # immutable config assumed
    train_ds = build_dataset(True,  config)
    val_ds   = build_dataset(False, config)

    train_ds = train_ds.batch(config.DATA.BATCH_SIZE).prefetch(tf.data.AUTOTUNE)
    val_ds   = val_ds.batch(config.DATA.BATCH_SIZE).prefetch(tf.data.AUTOTUNE)

    # Mixup setup
    mixup_fn = None
    if config.AUG.MIXUP > 0 or config.AUG.CUTMIX > 0 or config.AUG.CUTMIX_MINMAX is not None:
        def mixup(batch, rng):
            imgs, labels = batch
            rng, key1, key2 = jax.random.split(rng, 3)
            lam = jax.random.beta(key1, config.AUG.MIXUP, config.AUG.CUTMIX)
            idx = jax.random.permutation(key2, imgs.shape[0])
            mixed_imgs   = lam * imgs + (1 - lam) * imgs[idx]
            mixed_labels = lam * labels + (1 - lam) * labels[idx]
            return (mixed_imgs, mixed_labels), rng
        mixup_fn = mixup

    return train_ds, val_ds, mixup_fn
