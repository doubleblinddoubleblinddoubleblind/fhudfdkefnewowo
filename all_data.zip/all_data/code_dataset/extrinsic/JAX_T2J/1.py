import jax
import jax.numpy as jnp
from jax import random
import flax.linen as nn
import optax
from typing import Sequence


class ConvRec(nn.Module):
    n_classes: int
    vocab: int
    emb_dim: int = 100
    out_channels: int = 128
    kernel_sizes: Sequence[int] = (5, 3)
    pool_size: int = 2
    act: str = 'relu'
    conv_type: str = 'wide'
    rnn_layers: int = 1
    hid_dim: int = 128
    bidi: bool = True
    dropout: float = 0.0

    @nn.compact
    def __call__(self, inp, *, train: bool):
        # Embedding
        x = nn.Embed(num_embeddings=self.vocab,
                     features=self.emb_dim,
                     embedding_init=nn.initializers.normal())(inp)
        # x: (batch, seq_len, emb_dim)
        x = jnp.transpose(x, (0, 2, 1))           # (batch, emb_dim, seq_len)
        x = x[:, None, :, :]                     # (batch, 1, emb_dim, seq_len)

        # Convolutional stack
        for i, W in enumerate(self.kernel_sizes):
            H = self.emb_dim if i == 0 else 1
            padding = (0, (W // 2) * 2) if self.conv_type == 'wide' else (0, 0)
            x = nn.Conv(features=self.out_channels,
                        kernel_size=(H, W),
                        padding=padding,
                        kernel_init=nn.initializers.kaiming_normal())(x)
            x = nn.max_pool(x,
                            window_shape=(1, self.pool_size),
                            strides=(1, self.pool_size),
                            padding='VALID')
            act_fn = getattr(nn, self.act) if hasattr(nn, self.act) else nn.relu
            x = act_fn(x)
            x = nn.Dropout(rate=self.dropout)(x, deterministic=not train)

        # Prepare for RNN: (batch, out_channels, 1, seq_len') → (seq_len', batch, out_channels)
        seq_len = x.shape[-1]
        x = jnp.squeeze(x, axis=2)               # (batch, out_channels, seq_len)
        x = jnp.transpose(x, (2, 0, 1))         # (seq_len, batch, out_channels)

        # Bidirectional LSTM
        lstm_hidden = self.hid_dim // 2 if self.bidi else self.hid_dim
        lstm_cells = []
        for _ in range(self.rnn_layers):
            lstm_cells.append(nn.LSTMCell(name=f'lstm_fwd'))
            if self.bidi:
                lstm_cells.append(nn.LSTMCell(name=f'lstm_bwd'))

        def apply_lstm(carry, x_t):
            new_carry = []
            outputs = []
            for (cell, (h, c)) in zip(lstm_cells, carry):
                (h_new, c_new), y = cell((h, c), x_t)
                new_carry.append((h_new, c_new))
                outputs.append(y)
            # concat forward and backward if bidi
            y_cat = jnp.concatenate(outputs, axis=-1)
            return new_carry, y_cat

        # initialize carry
        carry0 = []
        key = self.make_rng('params')
        for cell in lstm_cells:
            batch = x.shape[1]
            h0 = jnp.zeros((batch, lstm_hidden))
            c0 = jnp.zeros((batch, lstm_hidden))
            carry0.append((h0, c0))

        _, y_seq = nn.scan(apply_lstm,
                           in_axes=0,
                           out_axes=0,
                           length=seq_len,
                           variable_broadcast='params',
                           split_rngs={'params': False})(carry0, x)
        # y_seq: (seq_len, batch, hid_dim * (1+int(bidi)))

        # take all but last for sum, last separately
        avg = jnp.sum(y_seq[:-1], axis=0)       # (batch, hid_dim*2)
        last = y_seq[-1]                        # (batch, hid_dim*2)
        rnn_out = jnp.concatenate([avg, last], axis=-1)

        # Projection
        logits = nn.Dense(features=self.n_classes,
                          kernel_init=nn.initializers.xavier_uniform())(rnn_out)
        logp = nn.log_softmax(logits)
        return logp


# Example of training step
@jax.jit
def train_step(state, batch):
    def loss_fn(params):
        logits = ConvRec(**state.model_kwargs).apply(
            {'params': params},
            batch['inputs'],
            train=True,
            rngs={'dropout': batch['dropout_key']})
        loss = -jnp.mean(jnp.sum(batch['targets'] * logits, axis=-1))
        return loss

    grads = jax.grad(loss_fn)(state.params)
    new_state = state.apply_gradients(grads=grads)
    return new_state
