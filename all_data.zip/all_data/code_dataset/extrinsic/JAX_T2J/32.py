import numpy as np
import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
from flax import linen as nn
from mushroom_rl.algorithms.actor_critic import DDPG, TD3
from mushroom_rl.core import Core, Logger
from mushroom_rl.environments.gym_env import Gym
from mushroom_rl.policy import OrnsteinUhlenbeckPolicy
from mushroom_rl.utils.dataset import compute_J
from tqdm import trange


class CriticNetwork(nn.Module):
    n_features: int
    @nn.compact
    def __call__(self, state: jnp.ndarray, action: jnp.ndarray) -> jnp.ndarray:
        x = jnp.concatenate([state, action], axis=-1)
        x = nn.Dense(self.n_features,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(x)
        x = nn.relu(x)
        x = nn.Dense(self.n_features,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(x)
        x = nn.relu(x)
        q = nn.Dense(1,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(x)
        return jnp.squeeze(q, -1)


class ActorNetwork(nn.Module):
    n_features: int
    action_dim: int
    @nn.compact
    def __call__(self, state: jnp.ndarray) -> jnp.ndarray:
        # remove singleton time axis if present
        s = jnp.squeeze(state, axis=1) if state.ndim == 3 else state
        x = nn.Dense(self.n_features,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(s)
        x = nn.relu(x)
        x = nn.Dense(self.n_features,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(x)
        x = nn.relu(x)
        a = nn.Dense(self.action_dim,
                     kernel_init=nn.initializers.xavier_uniform(),
                     bias_init=nn.initializers.zeros)(x)
        return a


def experiment_jax(alg, n_epochs, n_steps, n_steps_test, seed=0):
    key = random.PRNGKey(seed)
    np.random.seed(seed)
    logger = Logger(alg.__name__, results_dir=None)
    logger.strong_line()
    logger.info(f'Experiment Algorithm: {alg.__name__}')

    # MDP
    horizon = 200
    gamma = 0.99
    mdp = Gym('Pendulum-v0', horizon, gamma)

    # Policy
    policy_class = OrnsteinUhlenbeckPolicy
    policy_params = dict(sigma=np.ones(1) * .2, theta=.15, dt=1e-2)

    # Hyperparameters
    initial_replay_size = 500
    max_replay_size = 5000
    batch_size = 200
    n_features = 80
    tau = .001
    lr_actor = 1e-3
    lr_critic = 1e-3

    # Build actor and critic with their optax states
    actor_input_shape = mdp.info.observation_space.shape
    action_dim = mdp.info.action_space.shape[0]
    critic_input_shape = (actor_input_shape[-1] + action_dim,)

    # Initialize network params
    key, subkey1, subkey2 = random.split(key, 3)
    actor_def = ActorNetwork(n_features=n_features, action_dim=action_dim)
    actor_params = actor_def.init({'params': subkey1}, jnp.zeros((1, *actor_input_shape)))
    actor_tx = optax.adam(lr_actor)
    actor_state = optax.MultiSteps(actor_tx).init(actor_params['params'])

    critic_def = CriticNetwork(n_features=n_features)
    dummy_state = jnp.zeros((1, critic_input_shape[0]))
    dummy_action = jnp.zeros((1, action_dim))
    critic_params = critic_def.init({'params': subkey2}, dummy_state, dummy_action)
    critic_tx = optax.adam(lr_critic)
    critic_state = optax.MultiSteps(critic_tx).init(critic_params['params'])

    # Agent (mimic PyTorch API)
    agent = alg(
        mdp.info, policy_class, policy_params,
        dict(network=ActorNetwork, init_params=actor_params, tx=actor_tx),
        dict(class_=optax.adam, params={'learning_rate': lr_actor}),
        dict(network=CriticNetwork, init_params=critic_params, tx=critic_tx),
        batch_size, initial_replay_size, max_replay_size, tau
    )

    core = Core(agent, mdp)
    # prefill replay
    core.learn(n_steps=initial_replay_size, n_steps_per_fit=initial_replay_size)
    # evaluation
    dataset = core.evaluate(n_steps=n_steps_test, render=False)
    J = np.mean(compute_J(dataset, gamma))
    R = np.mean(compute_J(dataset))
    logger.epoch_info(0, J=J, R=R)

    for epoch in trange(n_epochs, leave=False):
        core.learn(n_steps=n_steps, n_steps_per_fit=1)
        dataset = core.evaluate(n_steps=n_steps_test, render=False)
        J = np.mean(compute_J(dataset, gamma))
        R = np.mean(compute_J(dataset))
        logger.epoch_info(epoch + 1, J=J, R=R)

    logger.info('Press a button to visualize pendulum')
    input()
    core.evaluate(n_episodes=5, render=True)


if __name__ == '__main__':
    for alg in [DDPG, TD3]:
        experiment_jax(alg, n_epochs=40, n_steps=1000, n_steps_test=2000)
