import jax
import jax.numpy as jnp
from jax import grad, jit, vmap, random
import numpyro
import numpyro.distributions as dist
from numpyro.handlers import seed, trace, replay
from numpyro.infer.reparam import LocScaleReparam
from numpy.testing import assert_allclose


# Test helper to extract central moments
def get_moments(x):
    m1 = x.mean(0)
    x0 = x - m1
    xx = x0 * x0
    m2 = xx.mean(0)
    m3 = (x0 * xx).mean(0) / m2 ** 1.5
    m4 = (xx * xx).mean(0) / m2 ** 2
    return jnp.stack([m1, m2, m3, m4])


def test_moments(dist_type, centered, shape, rng_key):
    # sample shape plate and particle plate
    @jit
    def model_particle(key):
        key, sub = random.split(key)
        if dist_type == "Normal":
            rv = dist.Normal(loc, scale)
        elif dist_type == "StudentT":
            rv = dist.StudentT(df=10.0, loc=loc, scale=scale)
        else:
            rv = dist.AsymmetricLaplace(loc, scale, 1.5)
        return rv.sample(sub, sample_shape=(200000,))

    # generate inputs
    loc = random.uniform(rng_key, shape, minval=-1.0, maxval=1.0)
    scale = random.uniform(rng_key, shape, minval=0.5, maxval=1.5)
    if isinstance(centered, float):
        centered = jnp.full(shape, centered)
    elif centered is None:
        centered = None
    elif isinstance(centered, jnp.ndarray):
        centered = jnp.broadcast_to(centered, shape)

    # obtain moments without reparam
    values = model_particle(rng_key)
    expected = get_moments(values)

    # apply LocScaleReparam
    reparam = LocScaleReparam(centered)
    reparam_model = numpyro.handlers.reparam(model_particle, {"x": reparam})
    values_r = trace(seed(reparam_model, rng_key)).get_trace()["x"]["value"]
    actual = get_moments(values_r)

    # shape_params assertions
    if centered is not None:
        if dist_type == "Normal":
            assert reparam.shape_params == ()
        elif dist_type == "StudentT":
            assert reparam.shape_params == ("df",)
        else:
            assert reparam.shape_params == ("asymmetry",)

    # compare probes
    assert_allclose(actual, expected, atol=0.1, rtol=0.05)

    # compare gradients
    def probe_fn(x):
        return get_moments(x).sum(1)  # sum over stats to get scalar per param

    exp_grads = grad(lambda l, s: probe_fn(model_particle(rng_key)).sum(), argnums=(0,1))(loc, scale)
    act_grads = grad(lambda l, s: probe_fn(values_r).sum(), argnums=(0,1))(loc, scale)
    assert_allclose(act_grads[0], exp_grads[0], atol=0.1, rtol=0.05)
    assert_allclose(act_grads[1], exp_grads[1], atol=0.1, rtol=0.05)


def test_init(dist_type, centered, shape, rng_key):
    loc = random.uniform(rng_key, shape, minval=-1.0, maxval=1.0)
    scale = random.uniform(rng_key, shape, minval=0.5, maxval=1.5)

    def model():
        if dist_type == "Normal":
            return dist.Normal(loc, scale)
        elif dist_type == "StudentT":
            return dist.StudentT(10.0, loc, scale)
        else:
            return dist.AsymmetricLaplace(loc, scale, 1.5)

    # this utility should mirror your check_init_reparam
    def check_init(reparam):
        # build a replayed model trace with the reparam
        traced = trace(seed(numpyro.handlers.reparam(model, {"x": reparam}), rng_key)).get_trace()
        # ensure the sampled site 'x' exists & reparam.shape_params was set
        assert "x" in traced

    reparam = LocScaleReparam(centered)
    check_init(reparam)
