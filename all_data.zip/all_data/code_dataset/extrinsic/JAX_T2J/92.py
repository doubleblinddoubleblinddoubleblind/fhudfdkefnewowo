import os
import functools
import numpy as np
import matplotlib.pyplot as plt

import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad

import flax.linen as nn
from flax.training import train_state
import optax

import tensorflow_datasets as tfds

# Hyperparameters
mb_size = 32
z_dim    = 100
nc       = 1       # channels in image
ngf      = 4       # generator feature map base
ndf      = 4       # discriminator feature map base
lr       = 1e-3
m        = 5.0     # margin for EBGAN
num_iters = 10000

# ----------------------------
#  Generator
# ----------------------------
class Generator(nn.Module):
    @nn.compact
    def __call__(self, z):
        # reshape z: (batch, z_dim) → (batch, z_dim, 1, 1)
        x = z.reshape((z.shape[0], z_dim, 1, 1))
        x = nn.ConvTranspose(features=28*28, kernel_size=(1,1), strides=(1,1), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=14*14, kernel_size=(2,2), strides=(2,2), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=7*7, kernel_size=(2,2), strides=(2,2), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=nc, kernel_size=(7,7), strides=(7,7), use_bias=False)(x)
        return nn.sigmoid(x)  # (batch, 1, 28, 28)

# ----------------------------
#  Discriminator autoencoder
# ----------------------------
class Discriminator(nn.Module):
    @nn.compact
    def __call__(self, x):
        # Encoder
        x = nn.Conv(features=ngf,  kernel_size=(3,3), strides=(1,1))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2,2), (2,2))
        x = nn.Conv(features=ngf*2, kernel_size=(3,3), strides=(1,1))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2,2), (2,2))
        x = nn.Conv(features=ngf*4, kernel_size=(3,3), strides=(1,1))(x)
        x = nn.relu(x)
        x = nn.Conv(features=z_dim,    kernel_size=(3,3), strides=(1,1))(x)
        x = nn.relu(x)
        # Decoder
        x = nn.ConvTranspose(features=ngf*4, kernel_size=(1,1), strides=(1,1), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=ngf*2, kernel_size=(1,1), strides=(1,1), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=ngf,   kernel_size=(4,4), strides=(2,2), padding='SAME', use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=nc,    kernel_size=(4,4), strides=(2,2), padding='SAME', use_bias=False)(x)
        return x  # reconstruction

# ----------------------------
#  Energy function: MSE between input and autoencoded output
# ----------------------------
def energy_fn(params_d, x, model_d):
    recon = model_d.apply({'params': params_d}, x)
    return jnp.mean(jnp.sum((x - recon)**2, axis=(1,2,3)))

# ----------------------------
#  Training state for G and D
# ----------------------------
def create_train_state(rng, model, learning_rate):
    params = model.init(rng, jnp.ones((mb_size, z_dim)))['params'] \
             if isinstance(model, Generator) \
             else model.init(rng, jnp.ones((mb_size, 28,28,1)))['params']
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

# ----------------------------
#  One training step
# ----------------------------
@jit
def train_step(state_g, state_d, real_batch, rng):
    rng, z_rng = random.split(rng)
    # Sample noise
    z = random.normal(z_rng, (mb_size, z_dim))
    # Generator forward
    fake = state_g.apply_fn({'params': state_g.params}, z)
    # Compute energies
    e_real = energy_fn(state_d.params, real_batch, Discriminator())
    e_fake = energy_fn(state_d.params, fake, Discriminator())
    # Discriminator loss: E_real + max(0, m - E_fake)
    loss_d = e_real + jnp.maximum(0.0, m - e_fake)
    # Generator loss: E_fake
    loss_g = e_fake

    # Compute grads
    grads_d = value_and_grad(lambda p: energy_fn(p, real_batch, Discriminator())
                              + jnp.maximum(0.0, m - energy_fn(p, fake, Discriminator())))(state_d.params)[1]
    grads_g = value_and_grad(lambda p: energy_fn(state_d.params,
                              state_g.apply_fn({'params': p}, z), Discriminator()))(state_g.params)[1]

    # Apply updates
    new_state_d = state_d.apply_gradients(grads=grads_d)
    new_state_g = state_g.apply_gradients(grads=grads_g)
    return new_state_g, new_state_d, loss_g, loss_d, rng

# ----------------------------
#  Data loader: MNIST via tfds
# ----------------------------
def prepare_dataset(split, batch_size):
    ds = tfds.load('mnist', split=split, shuffle_files=True)
    ds = ds.map(lambda x: (tf.cast(x['image'], tf.float32)/255.0,))\
           .map(lambda img: jnp.reshape(img, (28,28,1)))\
           .shuffle(10_000).batch(batch_size).prefetch(1)
    return ds

# ----------------------------
#  Main training loop
# ----------------------------
def main():
    # Setup
    rng = random.PRNGKey(0)
    gen = Generator()
    dis = Discriminator()
    rng, g_rng, d_rng = random.split(rng, 3)
    state_g = create_train_state(g_rng, gen, lr)
    state_d = create_train_state(d_rng, dis, lr)

    ds = prepare_dataset('train', mb_size)

    losses_g = []
    losses_d = []
    for it, batch in enumerate(tfds.as_numpy(ds)):
        real = batch.reshape((mb_size,28,28,1))
        state_g, state_d, lg, ld, rng = train_step(state_g, state_d, real, rng)
        if it % 100 == 0:
            print(f"Iter {it}, G_loss={lg:.4f}, D_loss={ld:.4f}")
            losses_g.append(lg)
            losses_d.append(ld)
        if it >= num_iters:
            break

    # Optional: plot loss curves
    plt.plot(losses_g, label='G_loss')
    plt.plot(losses_d, label='D_loss')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()
