import jax
import jax.numpy as jnp
from flax import linen as nn
import numpy as np

# 1) StandardMLP → Flax version
class StandardMLP(nn.Module):
    hidden_sizes: tuple[int, ...]
    num_classes: int

    @nn.compact
    def __call__(self, x):
        # flatten
        x = x.reshape((x.shape[0], -1))
        # hidden layers
        for h in self.hidden_sizes:
            x = nn.Dense(features=h)(x)
            x = nn.relu(x)
        # output layer
        x = nn.Dense(features=self.num_classes)(x)
        return x


# 2) ModifiedInitStandardMLP → same architecture, custom uniform init
class ModifiedInitStandardMLP(nn.Module):
    hidden_sizes: tuple[int, ...]
    num_classes: int

    @nn.compact
    def __call__(self, x):
        x = x.reshape((x.shape[0], -1))
        input_density = 1.0
        weight_density = 1.0

        # build hidden layers with modified uniform initialization
        for fan_in in self.hidden_sizes:
            bound = 1.0 / np.sqrt(input_density * weight_density * fan_in)
            kernel_init = nn.initializers.uniform(scale=bound)
            x = nn.Dense(features=fan_in, kernel_init=kernel_init)(x)
            x = nn.relu(x)
            # after ReLU activations, density halves
            input_density = 0.5

        # final output layer (no ReLU)
        # here we use default init or could similarly customize
        x = nn.Dense(features=self.num_classes)(x)
        return x


# 3) SparseMLP → demonstration using a custom SparseLinear layer
class SparseLinear(nn.Module):
    in_features: int
    out_features: int
    percent_on: float  # fraction of weights to keep

    @nn.compact
    def __call__(self, x):
        # initialize a full dense weight matrix
        w = self.param("kernel",
                       nn.initializers.xavier_uniform(),
                       (self.in_features, self.out_features))
        b = self.param("bias", nn.initializers.zeros, (self.out_features,))

        # create a fixed random mask for sparsity
        mask = self.variable("mask", "mask",
                             lambda rng: jax.random.bernoulli(rng, 
                                       p=self.percent_on,
                                       shape=w.shape))
        w_sparse = w * mask.value
        return jnp.dot(x, w_sparse) + b


class SparseMLP(nn.Module):
    hidden_sizes: tuple[int, ...]
    output_size: int
    kw_percent_on: tuple[float, ...]
    weight_sparsity: tuple[float, ...]
    use_batch_norm: bool = True
    dropout_rate: float = 0.0

    @nn.compact
    def __call__(self, x, *, train: bool):
        x = x.reshape((x.shape[0], -1))

        for i, h in enumerate(self.hidden_sizes):
            x = SparseLinear(
                in_features=x.shape[-1],
                out_features=h,
                percent_on=self.kw_percent_on[i]
            )(x)
            if self.use_batch_norm:
                x = nn.BatchNorm(use_running_average=not train)(x)
            x = nn.relu(x)
            if self.dropout_rate > 0:
                x = nn.Dropout(rate=self.dropout_rate, deterministic=not train)(x)

        x = nn.Dense(features=self.output_size)(x)
        return x
