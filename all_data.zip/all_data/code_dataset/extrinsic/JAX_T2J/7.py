import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.core.frozen_dict import freeze, unfreeze
from typing import Any

# ------------------------------------------------------------
# Utility: wrap a pretrained ResNet18 backbone from flaxmodels
# ------------------------------------------------------------
try:
    from flaxmodels import ResNet18  # pip install flaxmodels
except ImportError:
    raise ImportError("Please install flaxmodels (pip install flaxmodels)")

class QestimatorResNet18(nn.Module):
    """ResNet-18 with a custom final head for num_label outputs."""
    num_label: int

    @nn.compact
    def __call__(self, x):
        # backbone returns a feature vector per image
        features = ResNet18(pretrained=True, dtype=jnp.float32)(x)
        # replace the final classifier head
        logits = nn.Dense(self.num_label)(features)
        return logits

def create_resnet18_state(rng: Any, input_shape: tuple, num_label: int):
    """Initialize parameters for QestimatorResNet18."""
    rng, init_rng = jax.random.split(rng)
    model = QestimatorResNet18(num_label=num_label)
    dummy_input = jnp.zeros((1, *input_shape), jnp.float32)
    params = model.init({'params': init_rng}, dummy_input)['params']
    return rng, freeze(params), model

# ------------------------------------------------------------
# Naïve convolutional Q-estimator
# ------------------------------------------------------------
class QestimatorNaive(nn.Module):
    """A simple 3‐layer conv net followed by a linear head."""
    num_label: int

    @nn.compact
    def __call__(self, x):
        # conv + BN + ReLU stack
        x = nn.Conv(features=16, kernel_size=(5,5), strides=(2,2))(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)

        x = nn.Conv(features=32, kernel_size=(5,5), strides=(2,2))(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)

        x = nn.Conv(features=32, kernel_size=(5,5), strides=(2,2))(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)

        # flatten and head
        batch, h, w, c = x.shape
        x = x.reshape((batch, -1))
        logits = nn.Dense(self.num_label)(x)
        return logits

def create_naive_state(rng: Any, input_shape: tuple, num_label: int):
    """Initialize parameters for QestimatorNaive."""
    rng, init_rng = jax.random.split(rng)
    model = QestimatorNaive(num_label=num_label)
    dummy_input = jnp.zeros((1, *input_shape), jnp.float32)
    params = model.init({'params': init_rng}, dummy_input)['params']
    return rng, freeze(params), model

# ------------------------------------------------------------
# Example of a pure training step for either model
# ------------------------------------------------------------
import optax

def train_step(params, model, x, y, opt_state, optimizer):
    """Compute gradients and update parameters."""
    def loss_fn(p):
        preds = model.apply({'params': p}, x)
        return jnp.mean((preds - y) ** 2)

    loss, grads = jax.value_and_grad(loss_fn)(params)
    updates, opt_state = optimizer.update(grads, opt_state)
    new_params = optax.apply_updates(params, updates)
    return new_params, opt_state, loss

# ------------------------------------------------------------
# Usage sketch
# ------------------------------------------------------------
if __name__ == "__main__":
    # hyperparams
    num_label = 10
    input_shape = (224, 224, 3)       # for ResNet
    naive_input_shape = (64, 64, 3)   # e.g. your `input_h` applied to square images

    # RNG and optimizers
    rng = jax.random.PRNGKey(0)
    rng, res_params, res_model = create_resnet18_state(rng, input_shape, num_label)
    rng, naive_params, naive_model = create_naive_state(rng, naive_input_shape, num_label)

    optimizer = optax.adam(1e-3)
    opt_state_res = optimizer.init(res_params)
    opt_state_naive = optimizer.init(naive_params)

    # dummy batch
    x_res = jnp.zeros((8, *input_shape), jnp.float32)
    y_res = jnp.zeros((8, num_label), jnp.float32)

    # one training step for resnet-based Q-estimator
    res_params, opt_state_res, loss_res = train_step(
        res_params, res_model, x_res, y_res, opt_state_res, optimizer)

    print("ResNet step loss:", loss_res)

    # dummy batch for naive model
    x_naive = jnp.zeros((8, *naive_input_shape), jnp.float32)
    y_naive = jnp.zeros((8, num_label), jnp.float32)

    naive_params, opt_state_naive, loss_naive = train_step(
        naive_params, naive_model, x_naive, y_naive, opt_state_naive, optimizer)

    print("Naive step loss:", loss_naive)
