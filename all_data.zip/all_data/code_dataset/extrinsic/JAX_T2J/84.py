import os
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Union, Dict, Any

import jax.numpy as jnp
from jax import random
from datasets import load_dataset, DatasetDict
from transformers import PreTrainedTokenizerFast
from transformers.data.processors.squad import SquadV1Processor, SquadV2Processor, squad_convert_examples_to_features

# -----------------------------------------------------------------------------
# 1) Arguments dataclass
# -----------------------------------------------------------------------------
@dataclass
class SquadDataTrainingArguments:
    model_type: str = field(
        default=None,
        metadata={"help": "Model type selected (must match one of the supported HF models)"},
    )
    data_dir: str = field(
        default=None,
        metadata={"help": "Local directory containing squad .json files, or 'squad_v1'/'squad_v2' to download"},
    )
    max_seq_length: int = field(default=128, metadata={"help": "Max total input sequence length"})
    doc_stride: int = field(default=128, metadata={"help": "Stride between chunks when splitting long docs"})
    max_query_length: int = field(default=64, metadata={"help": "Max question length"})
    threads: int = field(default=1, metadata={"help": "Threads for feature conversion"})
    version_2_with_negative: bool = field(default=False, metadata={"help": "If true, use SQuAD v2"})
    overwrite_cache: bool = field(default=False, metadata={"help": "Overwrite processed cache"})


# -----------------------------------------------------------------------------
# 2) Split enum to mirror the original
# -----------------------------------------------------------------------------
class Split(Enum):
    train = "train"
    validation = "validation"


# -----------------------------------------------------------------------------
# 3) JAX Dataset class
# -----------------------------------------------------------------------------
class SquadJaxDataset:
    def __init__(
        self,
        args: SquadDataTrainingArguments,
        tokenizer: PreTrainedTokenizerFast,
        split: Union[str, Split] = Split.train,
        cache_dir: Optional[str] = None,
    ):
        self.args = args
        if isinstance(split, str):
            split = Split[split]
        self.split = split

        # decide processor
        processor = SquadV2Processor() if args.version_2_with_negative else SquadV1Processor()

        # prepare cache paths
        version_tag = "v2" if args.version_2_with_negative else "v1"
        cache_name = f"{split.value}_{tokenizer.__class__.__name__}_{args.max_seq_length}_{version_tag}"
        cache_path = os.path.join(cache_dir or args.data_dir, f"cached_{cache_name}.npz")

        if os.path.exists(cache_path) and not args.overwrite_cache:
            # load processed features + arrays
            data = jnp.load(cache_path, allow_pickle=True)
            self.features = data["features"].tolist()
            self.input_ids = data["input_ids"]
            self.attention_mask = data["attention_mask"]
            self.token_type_ids = data["token_type_ids"]
            self.start_positions = data.get("start_positions", None)
            self.end_positions = data.get("end_positions", None)
            print(f"Loaded cached features from {cache_path} (took {(time.time()):.3f}s)")
        else:
            # load raw examples
            raw_split = "train" if split == Split.train else "validation"
            ds = load_dataset(
                "squad_v2" if args.version_2_with_negative else "squad",
                cache_dir=args.data_dir,
                split=raw_split,
            )

            examples = processor.get_train_examples(args.data_dir) if split == Split.train else processor.get_dev_examples(args.data_dir)

            # convert examples to features + numpy arrays
            features, dataset = squad_convert_examples_to_features(
                examples=examples,
                tokenizer=tokenizer,
                max_seq_length=args.max_seq_length,
                doc_stride=args.doc_stride,
                max_query_length=args.max_query_length,
                is_training=(split == Split.train),
                threads=args.threads,
                return_dataset="np",
            )

            self.features = features
            self.input_ids = dataset["input_ids"]
            self.attention_mask = dataset["attention_mask"]
            self.token_type_ids = dataset.get("token_type_ids", None)
            if split == Split.train:
                self.start_positions = dataset["start_positions"]
                self.end_positions = dataset["end_positions"]

            # cache to disk
            jnp.savez(
                cache_path,
                features=features,
                input_ids=self.input_ids,
                attention_mask=self.attention_mask,
                token_type_ids=self.token_type_ids,
                start_positions=getattr(self, "start_positions", None),
                end_positions=getattr(self, "end_positions", None),
            )
            print(f"Saved features to cache at {cache_path} [took {(time.time()):.3f}s]")

    def __len__(self) -> int:
        return self.input_ids.shape[0]

    def __getitem__(self, idx: int) -> Dict[str, jnp.ndarray]:
        batch = {
            "input_ids": jnp.array(self.input_ids[idx], dtype=jnp.int32),
            "attention_mask": jnp.array(self.attention_mask[idx], dtype=jnp.int32),
        }
        if self.token_type_ids is not None:
            batch["token_type_ids"] = jnp.array(self.token_type_ids[idx], dtype=jnp.int32)
        if self.split == Split.train:
            batch["start_positions"] = jnp.array(self.start_positions[idx], dtype=jnp.int32)
            batch["end_positions"] = jnp.array(self.end_positions[idx], dtype=jnp.int32)
        return batch
