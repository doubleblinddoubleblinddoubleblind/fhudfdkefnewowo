import os
import time
from datetime import datetime
import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import pandas as pd
from functools import partial
from dynamicplot import DynamicPlot  # if you have a JAX‐compatible plotting helper

# ---------------------------------------------------------------------------- #
# 1) Config & Device
# ---------------------------------------------------------------------------- #
config = util.get_args()
config.cuda = not config.no_cuda
rng = random.PRNGKey(0)

# ---------------------------------------------------------------------------- #
# 2) Dataset
# ---------------------------------------------------------------------------- #
# Assuming grassdata.GRASSDataset can be reused or replaced by a CSV loader:
def load_data(path: str):
    df = pd.read_csv(path)
    # Convert to jnp arrays or keep as numpy for iteration
    return df

data_df = load_data(config.data_path)

def data_generator(df, batch_size, shuffle=True):
    N = len(df)
    idx = jnp.arange(N)
    if shuffle:
        idx = random.permutation(rng, idx)
    for start in range(0, N, batch_size):
        batch_idx = idx[start:start + batch_size]
        batch = df.iloc[batch_idx]
        # Extract whatever fields you need for encoder/decoder
        yield batch

# ---------------------------------------------------------------------------- #
# 3) Models in Flax
# ---------------------------------------------------------------------------- #
import flax.linen as nn

class GRASSEncoderFlax(nn.Module):
    # define your encoder parameters here
    @nn.compact
    def __call__(self, example):
        # translate grassmodel.encode_structure_fold logic
        # ...
        return encoded

class GRASSDecoderFlax(nn.Module):
    @nn.compact
    def __call__(self, code, example):
        # translate grassmodel.decode_structure_fold logic
        # ...
        return recon, kl_div

# ---------------------------------------------------------------------------- #
# 4) Initialize models & optimizers
# ---------------------------------------------------------------------------- #
# Initialize parameters
rng, enc_key, dec_key = random.split(rng, 3)
dummy_example = jnp.zeros((1,))  # replace with proper shape
enc_params = GRASSEncoderFlax().init({'params': enc_key}, dummy_example)['params']
dec_params = GRASSDecoderFlax().init({'params': dec_key}, dummy_example, dummy_example)['params']

# Optax optimizers
enc_opt = optax.adam(1e-3)
dec_opt = optax.adam(1e-3)
enc_opt_state = enc_opt.init(enc_params)
dec_opt_state = dec_opt.init(dec_params)

# ---------------------------------------------------------------------------- #
# 5) Loss & Train Step
# ---------------------------------------------------------------------------- #
def compute_loss(enc_params, dec_params, batch, rng):
    # 1) Encoding
    encoded = GRASSEncoderFlax().apply({'params': enc_params}, batch, rngs={'dropout': rng})
    # 2) Decoding
    recon, kl_div = GRASSDecoderFlax().apply(
        {'params': dec_params}, encoded, batch, rngs={'dropout': rng}
    )
    recon_loss = jnp.mean(recon)
    kl_loss = -0.05 * jnp.mean(kl_div)
    total_loss = recon_loss + kl_loss
    return total_loss, (recon_loss, kl_loss)

@jit
def train_step(enc_params, dec_params,
               enc_opt_state, dec_opt_state,
               batch, rng):
    (loss, (r_loss, k_loss)), grads = value_and_grad(compute_loss, argnums=(0,1), has_aux=True)(
        enc_params, dec_params, batch, rng
    )
    enc_grads, dec_grads = grads
    enc_updates, enc_opt_state = enc_opt.update(enc_grads, enc_opt_state)
    dec_updates, dec_opt_state = dec_opt.update(dec_grads, dec_opt_state)
    enc_params = optax.apply_updates(enc_params, enc_updates)
    dec_params = optax.apply_updates(dec_params, dec_updates)
    return enc_params, dec_params, enc_opt_state, dec_opt_state, loss, r_loss, k_loss

# ---------------------------------------------------------------------------- #
# 6) Training Loop
# ---------------------------------------------------------------------------- #
total_iter = config.epochs * (len(data_df) // config.batch_size)
if not config.no_plot:
    dp = DynamicPlot(
        title='Training loss over epochs (GRASS)',
        xdata=list(range(total_iter)),
        ydata={'Total_loss':[None]*total_iter,
               'Recon_loss':[None]*total_iter,
               'KL_div_loss':[None]*total_iter}
    )
    iter_id = 0
    max_loss = 0.

start_time = time.time()
if config.save_log:
    with open('training_log.log','a') as f:
        f.write(f"\n\nTraining log at {datetime.now():%Y-%m-%d %H:%M:%S}")
        f.write(f"\n#epoch: {config.epochs}, batch_size: {config.batch_size}, cuda: {config.cuda}\n")

for epoch in range(config.epochs):
    for batch in data_generator(data_df, config.batch_size, shuffle=True):
        rng, step_key = random.split(rng)
        enc_params, dec_params, enc_opt_state, dec_opt_state, \
            loss, r_loss, k_loss = train_step(
                enc_params, dec_params,
                enc_opt_state, dec_opt_state,
                batch, step_key
            )

        # Logging
        if (epoch * (len(data_df)//config.batch_size) + iter_id) % config.show_log_every == 0:
            elapsed = time.time() - start_time
            progress = 100. * iter_id / total_iter
            print(f"[{elapsed:7.1f}s] Epoch {epoch+1}/{config.epochs} "
                  f"Iter {iter_id}/{total_iter} {progress:6.2f}%  "
                  f"Recon={r_loss:.4f}  KL={k_loss:.4f}  Total={loss:.4f}")

        # Dynamic plot update
        if not config.no_plot:
            dp.ydata['Total_loss'][iter_id] = loss
            dp.ydata['Recon_loss'][iter_id] = r_loss
            dp.ydata['KL_div_loss'][iter_id] = k_loss
            max_loss = max(max_loss, loss, r_loss, k_loss)
            dp.setxlim(0, iter_id*1.05)
            dp.setylim(0, max_loss*1.05)
            dp.update_plots()
        iter_id += 1

    # Snapshot
    if config.save_snapshot and (epoch+1) % config.save_snapshot_every == 0:
        os.makedirs(config.save_path, exist_ok=True)
        enc_file = os.path.join(config.save_path,
                                f"encoder_epoch{epoch+1}_loss{loss:.2f}.ckpt")
        dec_file = os.path.join(config.save_path,
                                f"decoder_epoch{epoch+1}_loss{loss:.2f}.ckpt")
        with open(enc_file, 'wb') as f: f.write(flax.serialization.to_bytes(enc_params))
        with open(dec_file, 'wb') as f: f.write(flax.serialization.to_bytes(dec_params))
        print(f"Saved snapshots to {config.save_path}")

    # Log file
    if config.save_log and (epoch+1) % config.save_log_every == 0:
        with open('training_log.log','a') as f:
            f.write(f"Epoch {epoch+1}: recon={r_loss:.4f}, kl={k_loss:.4f}, total={loss:.4f}\n")

# Final save
os.makedirs(config.save_path, exist_ok=True)
with open(os.path.join(config.save_path,'encoder_final.ckpt'),'wb') as f:
    f.write(flax.serialization.to_bytes(enc_params))
with open(os.path.join(config.save_path,'decoder_final.ckpt'),'wb') as f:
    f.write(flax.serialization.to_bytes(dec_params))
print("Training complete – final models saved.")
