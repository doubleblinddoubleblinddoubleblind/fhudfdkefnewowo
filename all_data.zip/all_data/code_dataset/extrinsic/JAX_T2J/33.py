import jax
import jax.numpy as jnp
from flax import linen as nn

class RefineNet(nn.Module):
    """
    RefineNet in Flax: Multi‐Path Refinement Networks for High‐Resolution Semantic Segmentation.
    Ported from PyTorch refinenet(nn.Module).  

    Attributes:
        n_classes: Number of output segmentation classes.
    """
    n_classes: int = 21

    @nn.compact
    def __call__(self, x):
        # TODO: implement the feature‐fusion and upsampling blocks.
        # For example:
        # x = nn.Conv(features=64, kernel_size=(3,3), padding='SAME')(x)
        # x = nn.relu(x)
        # … your multi‐path refinement heads …
        #
        # Finally project to n_classes channels:
        logits = nn.Conv(self.n_classes, kernel_size=(1,1), padding='SAME')(x)
        return logits

# Example of instantiation & a dummy forward pass:
if __name__ == "__main__":
    # Create a PRNGKey and dummy input tensor of shape (batch, H, W, C)
    key = jax.random.PRNGKey(0)
    dummy = jnp.ones((1, 256, 256, 3))  # e.g. a 256×256 RGB image

    # Initialize parameters
    model = RefineNet(n_classes=21)
    params = model.init(key, dummy)

    # Run a forward pass
    out = model.apply(params, dummy)
    print("Output shape:", out.shape)  # → (1, 256, 256, 21)
