import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.struct import dataclass
import optax
from typing import Any, Tuple, Dict

# ----------------------------------------
# Utilities for target network updates
# ----------------------------------------
def soft_update(params, target_params, tau):
    return jax.tree_map(lambda p, tp: tp * (1 - tau) + p * tau, params, target_params)

def hard_update(params, target_params):
    return params

# ----------------------------------------
# Dataclass to hold all training state
# ----------------------------------------
@dataclass
class TrainState:
    policy_params: Any
    qf_params: Any
    target_policy_params: Any
    target_qf_params: Any
    opt_state_policy: optax.OptState
    opt_state_qf: optax.OptState
    step: int
    eval_stats: Dict[str, float]

# ----------------------------------------
# Main Trainer
# ----------------------------------------
class DDPGJaxTrainer:
    def __init__(
        self,
        qf_def: nn.Module,
        policy_def: nn.Module,
        discount: float = 0.99,
        reward_scale: float = 1.0,
        policy_lr: float = 1e-4,
        qf_lr: float = 1e-3,
        qf_weight_decay: float = 0.0,
        target_hard_update_period: int = 1000,
        tau: float = 1e-2,
        use_soft_update: bool = False,
        policy_pre_activation_weight: float = 0.0,
    ):
        # network definitions
        self.qf_def = qf_def
        self.policy_def = policy_def

        # hyperparams
        self.discount = discount
        self.reward_scale = reward_scale
        self.qf_weight_decay = qf_weight_decay
        self.target_hard_update_period = target_hard_update_period
        self.tau = tau
        self.use_soft_update = use_soft_update
        self.preact_wt = policy_pre_activation_weight

        # optimizers
        self.policy_tx = optax.adam(policy_lr)
        self.qf_tx = optax.adam(qf_lr)

        # compile train step
        self._train_step = jax.jit(self._train_step)

    def init(self, rng: jax.random.PRNGKey, example_batch: Dict[str, jnp.ndarray]) -> TrainState:
        """Initialize parameters and optimizer states."""
        rng1, rng2, rng3, rng4 = jax.random.split(rng, 4)
        policy_params = self.policy_def.init(rng1, example_batch['observations'])
        qf_params     = self.qf_def.init(rng2, example_batch['observations'], example_batch['actions'])
        # target nets start identical
        target_policy_params = policy_params
        target_qf_params     = qf_params

        opt_state_policy = self.policy_tx.init(policy_params)
        opt_state_qf     = self.qf_tx.init(qf_params)

        return TrainState(
            policy_params,
            qf_params,
            target_policy_params,
            target_qf_params,
            opt_state_policy,
            opt_state_qf,
            step=0,
            eval_stats={}
        )

    def train(self, state: TrainState, batch: Dict[str, jnp.ndarray]) -> TrainState:
        """Public API: run one training step."""
        return self._train_step(state, batch)

    def _train_step(self, state: TrainState, batch: Dict[str, jnp.ndarray]) -> TrainState:
        obs, actions = batch['observations'], batch['actions']
        rewards, dones = batch['rewards'], batch['terminals']
        next_obs = batch['next_observations']

        def qf_loss_fn(qf_params, policy_params):
            # compute target Q
            next_actions = self.policy_def.apply(state.target_policy_params, next_obs)
            target_q = self.qf_def.apply(state.target_qf_params, next_obs, next_actions)
            y = rewards * self.reward_scale + (1.0 - dones) * self.discount * target_q
            y = jnp.clip(y, a_min=-jnp.inf, a_max=jnp.inf)
            # current Q
            q_pred = self.qf_def.apply(qf_params, obs, actions)
            # MSE + weight decay
            mse = jnp.mean((q_pred - jax.lax.stop_gradient(y))**2)
            wd = 0.0
            if self.qf_weight_decay > 0:
                flat = jax.tree_util.tree_leaves(qf_params)
                wd = self.qf_weight_decay * sum([jnp.sum(p**2) for p in flat])
            return mse + wd, (mse, q_pred, y)

        def policy_loss_fn(policy_params, qf_params):
            # possibly include pre-activation penalty
            if self.preact_wt > 0:
                actions_pi, preact = self.policy_def.apply(policy_params, obs, return_preactivations=True)
                pre_loss = jnp.mean(jnp.sum(preact**2, axis=-1))
            else:
                actions_pi = self.policy_def.apply(policy_params, obs)
                pre_loss = 0.0

            q_val = self.qf_def.apply(qf_params, obs, actions_pi)
            p_loss = - jnp.mean(q_val)
            return p_loss + self.preact_wt * pre_loss, (p_loss, pre_loss, q_val)

        # Critic update
        (qf_loss, (raw_qf_loss, q_pred, q_target)), qf_grads = jax.value_and_grad(qf_loss_fn, has_aux=True)(
            state.qf_params, state.policy_params
        )
        updates_q, new_opt_state_q = self.qf_tx.update(qf_grads, state.opt_state_qf)
        new_qf_params = optax.apply_updates(state.qf_params, updates_q)

        # Policy update
        (policy_loss, (raw_policy_loss, pre_loss, q_pi)), policy_grads = jax.value_and_grad(policy_loss_fn, has_aux=True)(
            state.policy_params, new_qf_params
        )
        updates_p, new_opt_state_p = self.policy_tx.update(policy_grads, state.opt_state_policy)
        new_policy_params = optax.apply_updates(state.policy_params, updates_p)

        # Target network updates
        if self.use_soft_update:
            new_target_policy = soft_update(new_policy_params, state.target_policy_params, self.tau)
            new_target_qf     = soft_update(new_qf_params, state.target_qf_params, self.tau)
        else:
            if (state.step + 1) % self.target_hard_update_period == 0:
                new_target_policy = new_policy_params
                new_target_qf     = new_qf_params
            else:
                new_target_policy = state.target_policy_params
                new_target_qf     = state.target_qf_params

        # Collect eval stats on first pass only
        eval_stats = {
            'Policy Loss': policy_loss,
            'Raw Policy Loss': raw_policy_loss,
            'QF Loss': qf_loss,
            'Raw QF Loss': raw_qf_loss,
        }

        return TrainState(
            policy_params=new_policy_params,
            qf_params=new_qf_params,
            target_policy_params=new_target_policy,
            target_qf_params=new_target_qf,
            opt_state_policy=new_opt_state_p,
            opt_state_qf=new_opt_state_q,
            step=state.step + 1,
            eval_stats=eval_stats
        )
