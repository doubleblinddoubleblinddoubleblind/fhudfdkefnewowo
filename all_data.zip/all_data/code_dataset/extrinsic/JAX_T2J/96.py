#!/usr/bin/env python3

import math
import unittest

import jax.numpy as jnp
from jax import jit, vmap

class PeriodicKernelJAX:
    """Periodic kernel: k(x, x') = exp(-2 * sin^2(pi*(x - x') / period) / lengthscale)"""
    def __init__(self, lengthscale=1.0, period_length=1.0):
        # store as floats or arrays
        self.params = {
            "lengthscale": jnp.array(lengthscale, dtype=jnp.float32),
            "period_length": jnp.array(period_length, dtype=jnp.float32)
        }

    def initialize(self, lengthscale, period_length):
        # accept Python scalars or JAX arrays
        self.params["lengthscale"] = jnp.array(lengthscale, dtype=jnp.float32)
        self.params["period_length"] = jnp.array(period_length, dtype=jnp.float32)
        return self

    def eval(self):
        # no-op for compatibility
        return self

    @jit
    def __call__(self, a, b):
        # a: [..., N, 1], b: [..., M, 1], broadcast batch dims
        ls = self.params["lengthscale"]
        p  = self.params["period_length"]
        # compute pairwise differences
        # shape: [..., N, M]
        def pairwise(x, y):
            diff = x - y
            sin_term = jnp.sin(math.pi * diff / p)
            return jnp.exp(-2.0 * sin_term**2 / ls)
        # vectorize over last two dims
        return vmap(lambda row: vmap(lambda col: pairwise(row, col))(b), in_axes=0)(a)

    def evaluate(self, mat):
        # identity for API parity: mat is the direct __call__ result
        return mat

class TestPeriodicKernelJAX(unittest.TestCase):

    def test_computes_periodic_function(self):
        a = jnp.array([4, 2, 8], dtype=jnp.float32).reshape(3,1)
        b = jnp.array([0, 2], dtype=jnp.float32).reshape(2,1)
        lengthscale = 2.0
        period = 3.0
        kernel = PeriodicKernelJAX().initialize(lengthscale=lengthscale, period_length=period).eval()

        # Reference using pure JAX/numpy-style
        actual = jnp.zeros((3,2), dtype=jnp.float32)
        for i in range(3):
            for j in range(2):
                val = 2 * jnp.sin(math.pi * (a[i,0] - b[j,0]) / period)**2 / lengthscale
                actual = actual.at[i,j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch(self):
        a = jnp.array([[4,2,8],[1,2,3]], dtype=jnp.float32).reshape(2,3,1)
        b = jnp.array([[0,2],[-1,2]], dtype=jnp.float32).reshape(2,2,1)
        period = jnp.array(1.0, dtype=jnp.float32).reshape(1,1,1)
        lengthscale = jnp.array(2.0, dtype=jnp.float32).reshape(1,1,1)
        kernel = PeriodicKernelJAX().initialize(lengthscale=lengthscale, period_length=period).eval()

        actual = jnp.zeros((2,3,2), dtype=jnp.float32)
        for k in range(2):
            for i in range(3):
                for j in range(2):
                    val = 2 * jnp.sin(math.pi * (a[k,i,0] - b[k,j,0]) / period[0,0,0])**2 / lengthscale[0,0,0]
                    actual = actual.at[k,i,j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch_separate(self):
        a = jnp.array([[4,2,8],[1,2,3]], dtype=jnp.float32).reshape(2,3,1)
        b = jnp.array([[0,2],[-1,2]], dtype=jnp.float32).reshape(2,2,1)
        period = jnp.array([1.0,2.0], dtype=jnp.float32).reshape(2,1,1)
        lengthscale = jnp.array([2.0,1.0], dtype=jnp.float32).reshape(2,1,1)
        kernel = PeriodicKernelJAX().initialize(lengthscale=lengthscale, period_length=period).eval()

        actual = jnp.zeros((2,3,2), dtype=jnp.float32)
        for k in range(2):
            for i in range(3):
                for j in range(2):
                    val = 2 * jnp.sin(math.pi * (a[k,i,0] - b[k,j,0]) / period[k,0,0])**2 / lengthscale[k,0,0]
                    actual = actual.at[k,i,j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)


if __name__ == "__main__":
    unittest.main()
