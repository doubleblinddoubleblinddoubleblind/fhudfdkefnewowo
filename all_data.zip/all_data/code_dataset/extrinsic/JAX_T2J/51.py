import os
import argparse
import random as pyrandom

import numpy as np
import pandas as pd

import jax
import jax.numpy as jnp
from jax import random
from flax import linen as nn
from flax.training import train_state
import optax

# ----------------------------------------
# ARGPARSE
# ----------------------------------------
parser = argparse.ArgumentParser(description='Train a network (JAX/Flax version).')
parser.add_argument('--na', type=str, default=None, help='Experiment name')
parser.add_argument('--sr', type=str, default=None, help='Save root')
parser.add_argument('--bs', type=int, default=10, help='Batch size')
parser.add_argument('--sp', type=int, default=50000, help='Number of sample points')
parser.add_argument('--scale_norm', type=int, default=2000, help='Scale factor for normalization')
parser.add_argument('--co', action='store_true', help='Disable GPU')
parser.add_argument('--seed', type=int, default=0, help='Random seed')
parser.add_argument('--ctx', type=int, default=20000, help='Context size in nm')
parser.add_argument('--use_bias', type=bool, default=True, help='Use bias in Convpoint layers')
parser.add_argument('--use_syntype', type=bool, default=True, help='Use synapse type')
parser.add_argument('-j', '--jit', metavar='MODE', choices=['disabled','train','onsave'], default='disabled',
                    help='JIT tracing mode')
parser.add_argument('--cval', type=int, default=None, help='Cross-validation split')
args = parser.parse_args()

# ----------------------------------------
# SEEDS & DEVICES
# ----------------------------------------
seed = args.seed
key = random.PRNGKey(seed)                                    # :contentReference[oaicite:2]{index=2}:contentReference[oaicite:3]{index=3}
pyrandom.seed(seed)
np.random.seed(seed)

use_gpu = not args.co
device = jax.devices('gpu')[0] if use_gpu else jax.devices('cpu')[0]
print(f"Using device: {device}")

# ----------------------------------------
# EXPERIMENT NAME
# ----------------------------------------
name = args.na or f"celltype_pts_scale{args.scale_norm}_nb{args.sp}_ctx{args.ctx}"
if not args.use_syntype: name += "_noSyntype"
if args.use_bias is False: name += "_noBias"
name += f"_CV{args.cval or 0}_seed{seed}"

save_root = os.path.expanduser(args.sr or '~/e3_training_convpoint/')
os.makedirs(save_root, exist_ok=True)

# ----------------------------------------
# MODEL DEFINITION (Flax)
# ----------------------------------------
class FlaxModelNet40(nn.Module):
    input_channels: int
    num_classes: int
    dropout: float
    use_norm: str
    track_running_stats: bool
    act: str
    use_bias: bool

    @nn.compact
    def __call__(self, coords, points):
        # NOTE: You’ll need to port elektronn3.models.convpoint.ModelNet40 internals here.
        # Below is just a placeholder skeleton.
        x = nn.Dense(64, use_bias=self.use_bias)(points)
        if self.use_norm == 'gn':
            x = nn.GroupNorm(num_groups=8)(x)
        x = getattr(nn, self.act.capitalize())()(x)
        x = nn.Dropout(self.dropout)(x, deterministic=False)
        logits = nn.Dense(self.num_classes, use_bias=self.use_bias)(x)
        return logits

# ----------------------------------------
# TRAIN STATE
# ----------------------------------------
def create_train_state(rng, model, learning_rate):
    params = model.init(rng,                     # PRNG split for init
                        jnp.zeros((args.bs, args.sp, args.input_channels)),
                        jnp.zeros((args.bs, args.sp, 3)))['params']
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

# ----------------------------------------
# DATA LOADER STUB
# ----------------------------------------
def data_generator(split='train'):
    """
    Stub: wrap your CellCloudData class to yield batches of
    (coords: [B, N, 3], points: [B, N, C], labels: [B]).
    """
    # Example: load from a CSV if needed (your data.csv)
    # df = pd.read_csv('3_data.csv')
    # … construct arrays …
    while True:
        yield {
          'coords': jnp.zeros((args.bs, args.sp, 3)), 
          'points': jnp.zeros((args.bs, args.sp, input_channels)),
          'labels': jnp.zeros((args.bs,), dtype=jnp.int32)
        }

# ----------------------------------------
# LOSS & METRICS
# ----------------------------------------
def cross_entropy_loss(logits, labels):
    onehot = jax.nn.one_hot(labels, num_classes)
    return jnp.mean(optax.softmax_cross_entropy(logits, onehot))

@jax.jit
def train_step(state, batch, rng):
    def loss_fn(params):
        logits = state.apply_fn({'params': params},
                                 batch['coords'], batch['points'],
                                 rngs={'dropout': rng})
        loss = cross_entropy_loss(logits, batch['labels'])
        return loss, logits
    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    (loss, logits), grads = grad_fn(state.params)
    state = state.apply_gradients(grads=grads)
    return state, loss

# ----------------------------------------
# TRAINING LOOP
# ----------------------------------------
# Instantiate model & state
input_channels = 5 if args.use_syntype else 4
num_classes    = 8
lr             = 5e-4

model = FlaxModelNet40(input_channels=input_channels,
                       num_classes=num_classes,
                       dropout=0.3,
                       use_norm='gn',
                       track_running_stats=False,
                       act='swish',
                       use_bias=args.use_bias)
state = create_train_state(key, model, lr)

# Training
train_gen = data_generator('train')
for step in range(200_000):
    key, subkey = random.split(key)
    batch = next(train_gen)
    state, loss = train_step(state, batch, subkey)
    if step % 1000 == 0:
        print(f"Step {step}, Loss: {loss:.4f}")

# Save final parameters
param_file = os.path.join(save_root, f"{name}_final_params.msgpack")
with open(param_file, "wb") as f:
    f.write(flax.serialization.to_bytes(state.params))
print(f"Saved trained parameters to {param_file}")
