import os
import gzip
import pickle

import numpy as np
import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
from flax import linen as nn
from flax.training import train_state
from tqdm import tqdm

# -------------------------------------------------------------------
# Data utilities (mirror batchify_data, get_MNIST_data)
# -------------------------------------------------------------------
def load_mnist(path="mnist.npz"):
    # expects an npz with arrays 'x_train','y_train','x_test','y_test'
    with np.load(path) as data:
        X_train = data['x_train']
        y_train = data['y_train']
        X_test  = data['x_test']
        y_test  = data['y_test']
    # reshape to (N,28,28,1) and normalize to [0,1]
    X_train = X_train.reshape(-1,28,28,1) / 255.0
    X_test  = X_test.reshape(-1,28,28,1)  / 255.0
    return X_train, y_train, X_test, y_test

def data_loader(X, y, batch_size, shuffle=True, seed=0):
    n = X.shape[0]
    idx = np.arange(n)
    if shuffle:
        rng = np.random.default_rng(seed)
        rng.shuffle(idx)
    for i in range(0, n, batch_size):
        batch_idx = idx[i:i+batch_size]
        yield X[batch_idx], y[batch_idx]

# -------------------------------------------------------------------
# Model definition
# -------------------------------------------------------------------
class DigitCNN(nn.Module):
    @nn.compact
    def __call__(self, x, train: bool):
        # x: (B,28,28,1)
        x = nn.Conv(features=32, kernel_size=(3,3))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        x = nn.Conv(features=64, kernel_size=(3,3))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2,2), strides=(2,2))
        x = x.reshape((x.shape[0], -1))          # flatten
        x = nn.Dense(features=128)(x)
        x = nn.Dropout(rate=0.5)(x, deterministic=not train)
        x = nn.Dense(features=10)(x)
        return x

# -------------------------------------------------------------------
# Training and evaluation step functions
# -------------------------------------------------------------------
@jit
def compute_metrics(logits, labels):
    loss = optax.softmax_cross_entropy_with_integer_labels(logits, labels).mean()
    accuracy = jnp.mean(jnp.argmax(logits, -1) == labels)
    return loss, accuracy

def create_train_state(rng, learning_rate):
    model = DigitCNN()
    params = model.init({'params': rng, 'dropout': rng},
                        jnp.ones([1,28,28,1]), train=True)['params']
    tx = optax.sgd(learning_rate, momentum=0.9, nesterov=True)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

@jit
def train_step(state, batch, rng):
    X, y = batch
    def loss_fn(params):
        logits = state.apply_fn({'params': params},
                                X, train=True, rngs={'dropout': rng})
        loss, _ = compute_metrics(logits, y)
        return loss, logits
    (loss, logits), grads = value_and_grad(loss_fn, has_aux=True)(state.params)
    state = state.apply_gradients(grads=grads)
    _, acc = compute_metrics(logits, y)
    return state, loss, acc

@jit
def eval_step(state, batch):
    X, y = batch
    logits = state.apply_fn({'params': state.params}, X, train=False)
    return compute_metrics(logits, y)

# -------------------------------------------------------------------
# Main — training loop, evaluation, saving
# -------------------------------------------------------------------
def main():
    # seeds
    np.random.seed(12321)
    rng = random.PRNGKey(12321)

    # load or train
    ckpt_path = "digits_flax.pkl"
    if os.path.isfile(ckpt_path):
        with open(ckpt_path, "rb") as f:
            params = pickle.load(f)
        state = train_state.TrainState.create(
            apply_fn=DigitCNN().apply,
            params=params,
            tx=optax.sgd(0.0),  # dummy optimizer for eval
        )
    else:
        # prepare data
        X_train, y_train, X_test, y_test = load_mnist()
        train_batches = data_loader(X_train, y_train, batch_size=32, shuffle=True, seed=12321)
        test_batches  = data_loader(X_test,  y_test,  batch_size=32, shuffle=False)

        # initialize state
        rng, init_rng = random.split(rng)
        state = create_train_state(init_rng, learning_rate=0.01)

        # training loop
        for epoch in range(1, 11):  # 10 epochs
            # train
            batch_metrics = []
            for Xb, yb in tqdm(train_batches, desc=f"Epoch {epoch}", leave=False):
                rng, step_rng = random.split(rng)
                # cast to jnp arrays
                Xb_j = jnp.array(Xb)
                yb_j = jnp.array(yb)
                state, loss, acc = train_step(state, (Xb_j, yb_j), step_rng)
                batch_metrics.append((loss, acc))
            train_loss, train_acc = np.mean([m[0] for m in batch_metrics]), np.mean([m[1] for m in batch_metrics])
            print(f"Epoch {epoch} — train loss: {train_loss:.4f}, train acc: {train_acc:.4f}")

        # save parameters
        with open(ckpt_path, "wb") as f:
            pickle.dump(state.params, f)

    # final evaluation
    X_test, y_test = load_mnist()[2:]
    test_batches = data_loader(X_test, y_test, batch_size=32, shuffle=False)
    metrics = [eval_step(state, (jnp.array(Xb), jnp.array(yb))) for Xb, yb in test_batches]
    losses, accs = zip(*metrics)
    print(f"Test loss: {np.mean(losses):.4f}, test acc: {np.mean(accs):.4f}")

    # print model summary
    print(state.apply_fn)

if __name__ == "__main__":
    main()
