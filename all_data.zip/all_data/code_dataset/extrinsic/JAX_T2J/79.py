import jax
import jax.numpy as jnp
from flax import linen as nn

class ESMap(nn.Module):
    """JAX/Flax version of the PyTorch ESMap module."""
    screen_size: tuple
    frame_num: int
    variable_num: int
    button_num: int

    @nn.compact
    def __call__(self, screen, variables):
        # conv layers
        x = nn.Conv(features=64,
                    kernel_size=(3, 3),
                    strides=(2, 2),
                    name="conv1")(
            screen
        )
        x = jax.nn.relu(x)
        x = nn.Conv(features=128,
                    kernel_size=(3, 3),
                    strides=(2, 2),
                    name="conv2")(x)
        x = jax.nn.relu(x)
        x = nn.Conv(features=256,
                    kernel_size=(3, 3),
                    strides=(2, 2),
                    name="conv3")(x)
        x = jax.nn.relu(x)
        x = nn.Conv(features=256,  # screen_feature_num
                    kernel_size=(1, 3),
                    strides=(1, 1),
                    name="conv4")(x)
        # flatten
        batch, *spatial = x.shape
        x = x.reshape((batch, -1))
        x = jax.nn.relu(x)

        # action pathway
        a = nn.Dense(features=64, name="action1")(x)
        a = jax.nn.relu(a)
        # concatenate with variables
        # variables is assumed shape (batch, variable_num)
        a = jnp.concatenate([a, variables], axis=1)
        a = nn.Dense(features=self.button_num, name="action2")(a)

        # take argmax along button dimension, keep dims
        # PyTorch: _, action = action.max(1, keepdim=True)
        action = jnp.argmax(a, axis=1)
        # bring back the singleton dim for compatibility
        action = action[:, None]

        return action
