import jax
import jax.numpy as jnp
import tensorflow as tf
import tensorflow_datasets as tfds  # For CIFAR-10
import flax.linen as nn
from flax.training import train_state
import matplotlib.pyplot as plt
import numpy as np

def load_cifar10(batch_size=32):
    # Load CIFAR-10 with labels
    ds = tfds.load('cifar10', split='train', as_supervised=True)

    def preprocess(image, label):
        # Random data augmentation
        image = tf.image.random_flip_left_right(image)
        image = tf.pad(image, [[4, 4], [4, 4], [0, 0]], mode='REFLECT')
        image = tf.image.random_crop(image, size=[32, 32, 3])

        # Normalize to [0,1], then to approximately [-1,1]
        image = tf.cast(image, tf.float32) / 255.0
        image = (image - 0.5) / 0.5

        return image, label

    ds = ds.map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
    ds = ds.shuffle(10_000)
    ds = ds.batch(batch_size)
    ds = ds.prefetch(tf.data.AUTOTUNE)

    # Convert to NumPy arrays for JAX
    return tfds.as_numpy(ds)

def imshow_grid(images):
    # Display an 8×8 grid of images
    grid = np.concatenate([
        np.concatenate([img for img in images[i : i + 8]], axis=1)
        for i in range(0, len(images), 8)
    ], axis=0)
    plt.figure(figsize=(6,6))
    plt.imshow(grid)
    plt.axis('off')
    plt.show()

def main():
    batch_size = 32
    cifar10_data = load_cifar10(batch_size)

    # Iterate one batch and display
    for images, labels in cifar10_data:
        print("Batch shapes:", images.shape, labels.shape)
        imshow_grid(images)
        break  # Remove to process all batches

if __name__ == "__main__":
    main()
