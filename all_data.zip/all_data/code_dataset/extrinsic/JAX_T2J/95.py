import os
import errno
import numpy as np
import jax.numpy as jnp
from PIL import Image
import requests
import tarfile
import hashlib

class STL10:
    """Pure-JAX STL10 dataset loader."""
    base_folder = "stl10_binary"
    url = "http://ai.stanford.edu/~acoates/stl10/stl10_binary.tar.gz"
    filename = "stl10_binary.tar.gz"
    tgz_md5 = "91f7769df0f17e558f3565bffb0c7dfb"
    class_names_file = "class_names.txt"

    train_list = [
        ("train_X.bin", "918c2871b30a85fa023e0c44e0bee87f"),
        ("train_y.bin", "5a34089d4802c674881badbb80307741"),
        ("unlabeled_X.bin", "5242ba1fed5e4be9e1e742405eb56ca4"),
    ]
    test_list = [
        ("test_X.bin", "7f263ba9f9e0b06b93213547f721ac82"),
        ("test_y.bin", "36f9794fa4beb8a2c72628de14fa638e"),
    ]
    splits = ("train", "train+unlabeled", "unlabeled", "test")

    def __init__(
        self,
        root: str,
        split: str = "train",
        transform=None,
        target_transform=None,
        download: bool = False,
    ):
        if split not in self.splits:
            raise ValueError(f'Split "{split}" not found; valid splits: {self.splits}')
        self.root = os.path.expanduser(root)
        self.split = split
        self.transform = transform
        self.target_transform = target_transform

        if download:
            self._download_and_extract()

        if not self._check_integrity():
            raise RuntimeError(
                "Dataset not found or corrupted. "
                "Use download=True to fetch it."
            )

        # Load data + labels according to split
        if split == "train":
            self.data, self.labels = self._load_file(*self.train_list[:2])
        elif split == "train+unlabeled":
            X, y = self._load_file(*self.train_list[:2])
            Xu, _ = self._load_file(self.train_list[2][0], None)
            self.data = np.concatenate([X, Xu], axis=0)
            self.labels = np.concatenate(
                [y, np.full((Xu.shape[0],), -1, dtype=np.int32)], axis=0
            )
        elif split == "unlabeled":
            X, _ = self._load_file(self.train_list[2][0], None)
            self.data = X
            self.labels = np.full((X.shape[0],), -1, dtype=np.int32)
        else:  # test
            self.data, self.labels = self._load_file(*self.test_list)

        # Optionally load class names
        cls_file = os.path.join(self.root, self.base_folder, self.class_names_file)
        if os.path.isfile(cls_file):
            with open(cls_file, "r") as f:
                self.classes = [line.strip() for line in f]

    def __getitem__(self, index: int):
        img_np = self.data[index]  # shape (3, H, W)
        target = None if self.labels is None else int(self.labels[index])

        # convert channel-first numpy array to HxWxC for PIL
        img = Image.fromarray(np.transpose(img_np, (1, 2, 0)))
        if self.transform:
            img = self.transform(img)
        x = jnp.array(img)

        if self.target_transform and target is not None:
            target = self.target_transform(target)

        return x, target

    def __len__(self):
        return self.data.shape[0]

    def _check_integrity(self) -> bool:
        folder = os.path.join(self.root, self.base_folder)
        return os.path.isdir(folder)

    def _download_and_extract(self):
        os.makedirs(self.root, exist_ok=True)
        tgz_path = os.path.join(self.root, self.filename)
        if not os.path.isfile(tgz_path) or not self._check_md5(tgz_path, self.tgz_md5):
            # download
            resp = requests.get(self.url, stream=True)
            resp.raise_for_status()
            with open(tgz_path, "wb") as f:
                for chunk in resp.iter_content(1024):
                    f.write(chunk)
        # extract
        with tarfile.open(tgz_path, "r:gz") as tar:
            tar.extractall(path=self.root)

    @staticmethod
    def _check_md5(fpath: str, md5: str) -> bool:
        hash_md5 = hashlib.md5()
        with open(fpath, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest() == md5

    def _load_file(self, data_file: str, labels_file: str = None):
        folder = os.path.join(self.root, self.base_folder)

        labels = None
        if labels_file:
            lbl_path = os.path.join(folder, labels_file)
            labels = np.fromfile(lbl_path, dtype=np.uint8) - 1  # zero-based

        data_path = os.path.join(folder, data_file)
        raw = np.fromfile(data_path, dtype=np.uint8)
        imgs = raw.reshape(-1, 3, 96, 96)
        # transpose to (N, C, H, W) → (N, 3, 96, 96) → works with __getitem__
        return imgs, labels
