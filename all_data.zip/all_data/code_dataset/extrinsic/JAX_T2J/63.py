#!/usr/bin/env python3

import abc
from typing import Any, Callable, Tuple

import jax
import jax.numpy as jnp
from flax import linen as nn
from flax import struct

from .. import settings
from ..distributions import Delta, MultivariateNormal
from ..utils.broadcasting import _mul_broadcast_shape
from ..utils.memoize import cached, clear_cache_hook

@struct.dataclass
class VariationalParamsInitialized:
    done: jnp.ndarray = jnp.array(0)

class VariationalStrategy(nn.Module, abc.ABC):
    """
    JAX/Flax port of gpytorch._VariationalStrategy.
    """
    model: Any
    # We store inducing_points as a Flax param or constant depending on learn_inducing_locations
    inducing_points: jnp.ndarray
    variational_distribution_fn: Callable[[], Any]
    learn_inducing_locations: bool = True

    @nn.compact
    def __call__(
        self,
        x: jnp.ndarray,
        prior: bool = False,
    ) -> MultivariateNormal:
        # If prior mode, delegate to the base model
        if prior:
            return self.model(x)

        # Clear memo if training
        if self.is_mutable_collection("cache"):
            clear_cache_hook(self)

        # Initialize variational distribution once
        vp_init = self.variable("state", "variational_params_initialized", VariationalParamsInitialized)
        if vp_init.value.done == 0:
            prior_dist = self.prior_distribution()
            vd = self.variational_distribution()
            vd.initialize_variational_distribution(prior_dist)
            vp_init.value = VariationalParamsInitialized(done=jnp.array(1))

        # Expand x and inducing_points to match batch dims
        z = self.param(
            "inducing_points",
            lambda rng, shape: self.inducing_points,
            self.inducing_points.shape,
        ) if self.learn_inducing_locations else self.constant("inducing_points", self.inducing_points)
        if z.shape[:-2] != x.shape[:-2]:
            x, z = self._expand_inputs(x, z)

        # Get q(u)
        variational_dist_u = self.variational_distribution()

        # Delegate to parent strategy forward logic
        if isinstance(variational_dist_u, MultivariateNormal):
            return super().__call__(
                x,
                z,
                inducing_values=variational_dist_u.mean,
                variational_inducing_covar=variational_dist_u.lazy_covariance_matrix,
            )
        elif isinstance(variational_dist_u, Delta):
            return super().__call__(
                x,
                z,
                inducing_values=variational_dist_u.mean,
                variational_inducing_covar=None,
            )
        else:
            raise RuntimeError(
                f"Invalid variational distribution ({type(variational_dist_u)}); "
                "expected MultivariateNormal or Delta."
            )

    def _expand_inputs(
        self,
        x: jnp.ndarray,
        inducing_points: jnp.ndarray
    ) -> Tuple[jnp.ndarray, jnp.ndarray]:
        """
        Broadcast x and inducing_points to a common batch shape.
        """
        # Compute broadcasted batch shape
        batch_shape = _mul_broadcast_shape(inducing_points.shape[:-2], x.shape[:-2])
        new_z = jnp.broadcast_to(inducing_points, (*batch_shape, *inducing_points.shape[-2:]))
        new_x = jnp.broadcast_to(x, (*batch_shape, *x.shape[-2:]))
        return new_x, new_z

    @abc.abstractmethod
    @cached(name="prior_distribution_memo")
    def prior_distribution(self) -> MultivariateNormal:
        """
        Must return p(u) as a MultivariateNormal.
        """
        raise NotImplementedError

    @property
    @cached(name="variational_distribution_memo")
    def variational_distribution(self) -> Any:
        return self.variational_distribution_fn()

    def kl_divergence(self) -> jnp.ndarray:
        """
        KL(q(u) || p(u))
        """
        # Temporarily disable preconditioning
        with settings.max_preconditioner_size(0):
            q = self.variational_distribution
            p = self.prior_distribution
            return jax.scipy.stats.kl_divergence(q, p)

    def train(self, mode: bool = True):
        """
        Clear cache when toggling between train/eval.
        """
        if (self.is_mutable_collection("cache") and not mode) or mode:
            clear_cache_hook(self)
        # Flax modules are pure; training/eval handled in apply() collections
        return self

