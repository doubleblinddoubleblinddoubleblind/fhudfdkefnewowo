import argparse
import os
import time
import random as pyrandom

import jax
import jax.numpy as jnp
from jax import grad, jit
import optax
from flax import linen as nn
import numpy as np

# -----------------------------------------------------------------------------
# Utilities (ported from helpers.py in PyTorch version)
# -----------------------------------------------------------------------------
def read_file(path):
    """Read file and return content as a Python string and its length."""
    with open(path, 'r') as f:
        data = f.read()
    return data, len(data)

def char_tensor(string):
    """Map each char to its ord() and return a jnp.int32 array."""
    arr = np.frombuffer(string.encode('utf-8'), dtype=np.uint8)
    return jnp.array(arr, dtype=jnp.int32)

def time_since(start):
    elapsed = time.time() - start
    m = int(elapsed // 60)
    s = int(elapsed % 60)
    return f"{m}m {s}s"

# -----------------------------------------------------------------------------
# Data‐sampling function
# -----------------------------------------------------------------------------
def random_training_set(file_str, file_len, chunk_len, key):
    start = pyrandom.randint(0, file_len - chunk_len - 1)
    chunk = file_str[start : start + chunk_len + 1]
    inp = char_tensor(chunk[:-1])
    target = char_tensor(chunk[1:])
    return inp, target

# -----------------------------------------------------------------------------
# Model definition (a simple character‐level RNN)
# -----------------------------------------------------------------------------
class RNN(nn.Module):
    vocab_size: int
    hidden_size: int
    output_size: int
    n_layers: int

    @nn.compact
    def __call__(self, x, carry):
        # x: [ ], an int32 scalar
        # embed
        embed = nn.Embed(num_embeddings=self.vocab_size, features=self.hidden_size)(x)
        new_carry = carry
        out = embed
        for _ in range(self.n_layers):
            new_carry, out = nn.LSTMCell()(new_carry, out)
        logits = nn.Dense(self.output_size)(out)
        return logits, new_carry

    def init_carry(self, batch_size=1):
        # initialize LSTMCell carry: (c,h)
        return nn.LSTMCell.initialize_carry(jax.random.PRNGKey(0), (batch_size,), self.hidden_size)

# -----------------------------------------------------------------------------
# Training step
# -----------------------------------------------------------------------------
@jit
def train_step(params, carry, inp_seq, target_seq, optimizer_state, model):
    """Perform one chunk‐length training step."""
    def loss_fn(params):
        loss = 0.0
        c = carry
        for t in range(inp_seq.shape[0]):
            logits, c = model.apply({'params': params}, inp_seq[t], c, mutable=False)
            loss += optax.softmax_cross_entropy_with_integer_labels(logits, target_seq[t])
        return loss / inp_seq.shape[0]

    loss, grads = jax.value_and_grad(loss_fn)(params)
    updates, optimizer_state = optimizer.update(grads, optimizer_state)
    params = optax.apply_updates(params, updates)
    return params, optimizer_state, loss, c

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main():
    # parse args
    parser = argparse.ArgumentParser()
    parser.add_argument('filename', type=str)
    parser.add_argument('--n_epochs', type=int, default=2000)
    parser.add_argument('--print_every', type=int, default=100)
    parser.add_argument('--hidden_size', type=int, default=50)
    parser.add_argument('--n_layers', type=int, default=2)
    parser.add_argument('--learning_rate', type=float, default=0.01)
    parser.add_argument('--chunk_len', type=int, default=200)
    args = parser.parse_args()

    # read data
    file_str, file_len = read_file(args.filename)

    # model init
    vocab_size = 256  # assume byte‐level
    model = RNN(vocab_size, args.hidden_size, vocab_size, args.n_layers)
    rng = jax.random.PRNGKey(0)
    dummy_x = jnp.array(0, dtype=jnp.int32)
    dummy_carry = model.init_carry()
    params = model.init(rng, dummy_x, dummy_carry)['params']

    # optimizer
    optimizer = optax.adam(args.learning_rate)
    opt_state = optimizer.init(params)

    # training
    start = time.time()
    carry = model.init_carry()
    for epoch in range(1, args.n_epochs + 1):
        inp, target = random_training_set(file_str, file_len, args.chunk_len, rng)
        params, opt_state, loss, carry = train_step(params, carry, inp, target, opt_state, model)

        if epoch % args.print_every == 0:
            print(f'[{time_since(start)} ({epoch} {epoch/args.n_epochs*100:.2f}%) {loss:.4f}]')
            # example generation (greedy)
            sample_carry = model.init_carry()
            prompt = 'Wh'
            idxs = [ord(c) for c in prompt]
            out_str = prompt
            for _ in range(100):
                x = jnp.array(idxs[-1], dtype=jnp.int32)
                logits, sample_carry = model.apply({'params': params}, x, sample_carry)
                next_idx = int(jnp.argmax(logits))
                out_str += chr(next_idx)
                idxs.append(next_idx)
            print(out_str, '\n')

    # save parameters
    base = os.path.splitext(os.path.basename(args.filename))[0]
    save_path = f'{base}_rnn_params.npy'
    with open(save_path, 'wb') as f:
        np.save(f, params)
    print(f'Saved parameters to {save_path}')

if __name__ == '__main__':
    main()
