import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any


class Inception(nn.Module):
    in_planes: int
    n1x1: int
    n3x3red: int
    n3x3: int
    n5x5red: int
    n5x5: int
    pool_planes: int

    @nn.compact
    def __call__(self, x):
        # 1x1 conv branch
        b1 = nn.Conv(self.n1x1, kernel_size=(1,1))(x)
        b1 = nn.BatchNorm(use_running_average=False)(b1)
        b1 = nn.relu(b1)

        # 1x1 -> 3x3 conv branch
        b2 = nn.Conv(self.n3x3red, kernel_size=(1,1))(x)
        b2 = nn.BatchNorm(use_running_average=False)(b2)
        b2 = nn.relu(b2)
        b2 = nn.Conv(self.n3x3, kernel_size=(3,3), padding=((1,1),(1,1)))(b2)
        b2 = nn.BatchNorm(use_running_average=False)(b2)
        b2 = nn.relu(b2)

        # 1x1 -> two 3x3 conv branch (as 5x5)
        b3 = nn.Conv(self.n5x5red, kernel_size=(1,1))(x)
        b3 = nn.BatchNorm(use_running_average=False)(b3)
        b3 = nn.relu(b3)
        b3 = nn.Conv(self.n5x5, kernel_size=(3,3), padding=((1,1),(1,1)))(b3)
        b3 = nn.BatchNorm(use_running_average=False)(b3)
        b3 = nn.relu(b3)
        b3 = nn.Conv(self.n5x5, kernel_size=(3,3), padding=((1,1),(1,1)))(b3)
        b3 = nn.BatchNorm(use_running_average=False)(b3)
        b3 = nn.relu(b3)

        # 3x3 pool -> 1x1 conv branch
        b4 = nn.max_pool(x, window_shape=(3,3), strides=(1,1), padding='SAME')
        b4 = nn.Conv(self.pool_planes, kernel_size=(1,1))(b4)
        b4 = nn.BatchNorm(use_running_average=False)(b4)
        b4 = nn.relu(b4)

        # Concatenate along channel axis
        return jnp.concatenate([b1, b2, b3, b4], axis=-1)


class GoogLeNet(nn.Module):
    num_classes: int = 10

    @nn.compact
    def __call__(self, x):
        # Pre‐layers
        x = nn.Conv(192, kernel_size=(3,3), padding='SAME')(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)

        # Inception blocks
        x = Inception(192, 64, 96, 128, 16, 32, 32)(x)
        x = Inception(256, 128, 128, 192, 32, 96, 64)(x)
        x = nn.max_pool(x, window_shape=(3,3), strides=(2,2), padding='SAME')

        x = Inception(480, 192, 96, 208, 16, 48, 64)(x)
        x = Inception(512, 160, 112, 224, 24, 64, 64)(x)
        x = Inception(512, 128, 128, 256, 24, 64, 64)(x)
        x = Inception(512, 112, 144, 288, 32, 64, 64)(x)
        x = Inception(528, 256, 160, 320, 32, 128, 128)(x)

        x = nn.max_pool(x, window_shape=(3,3), strides=(2,2), padding='SAME')
        x = Inception(832, 256, 160, 320, 32, 128, 128)(x)
        x = Inception(832, 384, 192, 384, 48, 128, 128)(x)

        # Global average pooling and linear
        x = jnp.mean(x, axis=(1,2))               # shape: (batch, channels)
        x = nn.Dense(self.num_classes)(x)
        return x


def create_model(rng: Any, input_shape=(1, 32, 32, 3), num_classes=10):
    """
    Initializes GoogLeNet model parameters.
    """
    model = GoogLeNet(num_classes=num_classes)
    variables = model.init(rng, jnp.ones(input_shape, jnp.float32))
    return model, variables


# Example usage:
if __name__ == "__main__":
    rng = jax.random.PRNGKey(0)
    model, vars = create_model(rng)
    dummy = jnp.ones((1, 32, 32, 3))
    logits = model.apply(vars, dummy)
    print("Output shape:", logits.shape)   # (1, 10)
