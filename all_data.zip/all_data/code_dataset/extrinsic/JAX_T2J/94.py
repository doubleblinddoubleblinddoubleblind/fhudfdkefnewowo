import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Sequence, Optional

class Encoder(nn.Module):
    input_size: int
    embedding_size: int
    hidden_size: int
    n_layers: int = 1
    bidirec: bool = False

    @nn.compact
    def __call__(self,
                 inputs: jnp.ndarray,            # shape: (batch, seq_len), dtype=int32
                 input_lengths: Sequence[int]    # list/array of sequence lengths
                ) -> tuple[jnp.ndarray, jnp.ndarray]:
        """
        Args:
            inputs: integer token IDs, shape (B, T)
            input_lengths: true lengths for each sequence in the batch
        Returns:
            outputs: hidden states for each time step, shape (B, T, hidden_size * directions)
            final_hidden: concatenated final hidden state, shape (B, 1, hidden_size * directions)
        """
        B, T = inputs.shape
        D = 2 if self.bidirec else 1

        # embedding lookup
        embed = nn.Embed(num_embeddings=self.input_size,
                         features=self.embedding_size,
                         embedding_init=nn.initializers.xavier_uniform())
        x = embed(inputs)                                     # (B, T, E)

        # initialize hidden states
        h = jnp.zeros((self.n_layers * D, B, self.hidden_size))  # (layers*dirs, B, H)

        # define a single-layer GRU cell
        gru_cell = nn.GRUCell()

        def step_fn(carry, xt):
            h_prev = carry                                # (layers*dirs, B, H)
            h_next_layers = []

            # for simplicity, we do single-direction only here;
            # bidirectional could be emulated by running forward/backward scans
            inp = xt                                       # (B, E)
            for layer in range(self.n_layers):
                idx = layer * D                             # start index for this layer
                prev = h_prev[idx]                          # (B, H)
                new_h, _ = gru_cell(prev, inp)              # (B, H), cell_outputs
                inp = new_h                                 # feed into next layer
                h_next_layers.append(new_h)
            h_next = jnp.stack(h_next_layers, axis=0)      # (layers, B, H)
            return h_next, inp                             # carry, output at this step

        # scan over time steps
        h_seq, last = nn.scan(step_fn,
                              in_axes=1,     # split over time dimension
                              length=T,
                              variable_broadcast="params",
                              split_rngs={"params": False}
                             )(h, x)
        # h_seq has shape (layers, B, H) carried through; but scan returns final carry in `h_seq`

        # for outputs, we re-run step_fn but collecting all outputs
        outputs = []
        carry = h
        for t in range(T):
            carry, out_t = step_fn(carry, x[:, t, :])
            outputs.append(out_t)
        outputs = jnp.stack(outputs, axis=1)               # (B, T, H)

        # pick final hidden
        if self.n_layers > 1:
            final_layer = carry[-1]                        # (B, H)
        else:
            final_layer = carry[0]
        final_hidden = final_layer[:, None, :]            # (B, 1, H)

        return outputs, final_hidden
