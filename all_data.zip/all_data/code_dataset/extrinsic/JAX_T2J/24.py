# jax_multi_headed_similarity.py

import jax
import jax.numpy as jnp
from flax import linen as nn
from allennlp.common.checks import ConfigurationError
from allennlp.common import Params


class MultiHeadedSimilarity(nn.Module):
    num_heads: int
    tensor_1_dim: int
    tensor_1_projected_dim: int = None
    tensor_2_dim: int = None
    tensor_2_projected_dim: int = None

    def setup(self):
        # Default projected dims to input dims if not provided
        t1_pd = self.tensor_1_projected_dim or self.tensor_1_dim
        t2_pd = self.tensor_2_projected_dim or self.tensor_2_dim or self.tensor_1_dim

        # Must be divisible by num_heads
        if t1_pd % self.num_heads != 0 or t2_pd % self.num_heads != 0:
            raise ConfigurationError(
                f"Projected dimensions ({t1_pd}, {t2_pd}) must be divisible by num_heads={self.num_heads}"
            )

        # Define weight matrices
        self.tensor_1_projection = self.param(
            "tensor_1_projection",
            nn.initializers.xavier_uniform(),
            (self.tensor_1_dim, t1_pd),
        )
        self.tensor_2_projection = self.param(
            "tensor_2_projection",
            nn.initializers.xavier_uniform(),
            (self.tensor_2_dim, t2_pd),
        )

    @nn.compact
    def __call__(self, x: jnp.ndarray, y: jnp.ndarray) -> jnp.ndarray:
        """
        x: shape (..., seq1, tensor_1_dim)
        y: shape (..., seq2, tensor_2_dim)
        returns: similarity tensor of shape (..., seq1, seq2, num_heads)
        """
        W1 = self.tensor_1_projection
        W2 = self.tensor_2_projection
        # Project
        x_proj = jnp.einsum("...id,dp->...ip", x, W1)
        y_proj = jnp.einsum("...jd,dq->...jq", y, W2)
        # Split into heads
        head_size1 = W1.shape[1] // self.num_heads
        head_size2 = W2.shape[1] // self.num_heads
        x_h = x_proj.reshape(*x_proj.shape[:-1], -1, self.num_heads, head_size1)
        y_h = y_proj.reshape(*y_proj.shape[:-1], -1, self.num_heads, head_size2)
        # Compute dot-product similarity per head
        # result shape: (..., seq1, seq2, num_heads)
        sim = jnp.einsum("...ihd,...jhd->...ijh", x_h, y_h)
        return sim

    @classmethod
    def from_params(cls, params: Params) -> "MultiHeadedSimilarity":
        # Mimic AllenNLP Params.from_params behavior
        kwargs = params.as_dict(quiet=True)
        return cls(**kwargs)


# tests_jax_multi_headed_similarity.py

import pytest
import numpy as np
from flax import linen as nn
from flax.core import freeze, unfreeze
from jax import random

from jax_multi_headed_similarity import MultiHeadedSimilarity
from allennlp.common.checks import ConfigurationError


class TestMultiHeadedSimilarityFunction:
    def test_weights_are_correct_sizes(self):
        # 1) Explicit projection dims
        similarity = MultiHeadedSimilarity(
            num_heads=3,
            tensor_1_dim=9,
            tensor_1_projected_dim=6,
            tensor_2_dim=6,
            tensor_2_projected_dim=12,
        )
        # Initialize parameters
        key = random.PRNGKey(0)
        variables = similarity.init(key,
                                    jnp.zeros((1, 1, 2, 9)),   # dummy x
                                    jnp.zeros((1, 1, 2, 6)),)  # dummy y
        params = variables["params"]
        assert params["tensor_1_projection"].shape == (9, 6)
        assert params["tensor_2_projection"].shape == (6, 12)

        # 2) Missing required tensor_2_projected_dim
        with pytest.raises(ConfigurationError):
            MultiHeadedSimilarity(num_heads=3, tensor_1_dim=10)  # t1_pd=10 not divisible by 3

        # 3) from_params missing required dims
        bad = Params({"num_heads": 3, "tensor_1_dim": 9, "tensor_2_dim": 10})
        with pytest.raises(ConfigurationError):
            MultiHeadedSimilarity.from_params(bad)

    def test_forward(self):
        # No explicit projected dims -> defaults to input dims
        sim = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=6)
        key = random.PRNGKey(1)
        vars = sim.init(key,
                        jnp.zeros((1, 1, 2, 6)),  # x: batch=1,1,2,6
                        jnp.zeros((1, 1, 2, 6)))  # y: same dims
        # Manually override projections to identity
        p = unfreeze(vars["params"])
        p["tensor_1_projection"] = jnp.eye(6)
        p["tensor_2_projection"] = jnp.eye(6)
        vars = freeze({"params": p})

        a = jnp.array([[[[1, 1, -1, -1, 0, 1],
                         [-2, 5,  9, -1, 3, 4]]]], dtype=jnp.float32)
        b = jnp.array([[[[1, 1,  1,  0, 2, 5],
                         [0, 1, -1, -7, 1, 2]]]], dtype=jnp.float32)
        result = sim.apply(vars, a, b)
        # expected shape: (1,1,2,3)
        assert result.shape == (1,1,2,3)
        # head-wise dot products:
        # head0 uses dims [0:2], head1 [2:4], head2 [4:6]
        # For [1,1,-1,-1,0,1] vs [1,1,1,0,2,5]:
        #   head0 dot: [1,1]·[1,1] = 2
        #   head1 dot: [-1,-1]·[1,0] = -1
        #   head2 dot: [0,1]·[2,5] = 5
        # Similarly for the second position:
        #   [-2,5]·[0,1]=5, [9,-1]·[-1,-7]=-2, [3,4]·[1,2]=11
        np.testing.assert_allclose(
            result,
            np.array([[[[ 2, -1,  5],
                        [ 5, -2, 11]]]]),
            atol=1e-5,
        )
