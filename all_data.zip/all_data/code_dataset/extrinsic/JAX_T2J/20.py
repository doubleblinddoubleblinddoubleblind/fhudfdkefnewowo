import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax
from functools import partial

# --------------------------------------------------------
# Model definitions
# --------------------------------------------------------

class Encoder(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Dense(256)(x)
        x = nn.relu(x)
        x = nn.Dense(28)(x)
        x = nn.relu(x)
        return x

class Decoder(nn.Module):
    @nn.compact
    def __call__(self, z):
        z = nn.Dense(256)(z)
        z = nn.relu(z)
        z = nn.Dense(28)(z)
        z = nn.sigmoid(z)
        return z

class Autoencoder(nn.Module):
    """Flax Autoencoder: encoder + decoder"""
    def setup(self):
        self.encoder = Encoder()
        self.decoder = Decoder()

    def __call__(self, x):
        z = self.encoder(x)
        return self.decoder(z)


# --------------------------------------------------------
# Training utilities
# --------------------------------------------------------

def create_train_state(rng, learning_rate):
    """Initialize model + optimizer state."""
    model = Autoencoder()
    params = model.init(rng, jnp.ones([1, 28]))['params']
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(
        apply_fn=model.apply, params=params, tx=tx
    )

@partial(jax.jit, static_argnums=0)
def train_step(state, batch):
    """Single train step: compute loss & update."""
    def loss_fn(params):
        recon = state.apply_fn({'params': params}, batch)
        # mean squared error, summed over features then averaged over batch
        return jnp.mean(jnp.sum((recon - batch) ** 2, axis=-1))
    grads = jax.grad(loss_fn)(state.params)
    state = state.apply_gradients(grads=grads)
    loss = loss_fn(state.params)
    return state, loss

# --------------------------------------------------------
# Example training loop
# --------------------------------------------------------

def main():
    # PRNG setup
    rng = jax.random.PRNGKey(0)
    rng, init_rng = jax.random.split(rng)

    # Create train state
    state = create_train_state(init_rng, learning_rate=1e-4)

    # Dummy data loader (replace with your cortex data pipeline)
    # Here we pretend inputs are 28-dim vectors
    num_batches = 100
    batch_size = 64
    for epoch in range(1, 11):
        epoch_loss = 0.0
        for _ in range(num_batches):
            rng, data_rng = jax.random.split(rng)
            # synthetic batch: uniform [0,1) as placeholder
            batch = jax.random.uniform(data_rng, (batch_size, 28))
            state, loss = train_step(state, batch)
            epoch_loss += loss
        print(f"Epoch {epoch:02d}, Loss: {epoch_loss / num_batches:.4f}")

    # After training, you can reconstruct:
    rng, test_rng = jax.random.split(rng)
    test_x = jax.random.uniform(test_rng, (10, 28))
    recon = state.apply_fn({'params': state.params}, test_x)
    print("Reconstruction shape:", recon.shape)

if __name__ == "__main__":
    main()
