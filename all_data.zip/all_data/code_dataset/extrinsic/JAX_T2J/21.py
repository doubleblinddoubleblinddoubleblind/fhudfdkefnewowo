import jax.numpy as jnp

def pad_ids(input_ids: list[int],
            attention_mask: list[int],
            token_type_ids: list[int],
            max_length: int,
            pad_token: int,
            mask_padding_with_zero: bool,
            pad_token_segment_id: int,
            pad_on_left: bool = False):
    """
    Pads/truncates lists of ids and masks to exactly max_length.
    """
    padding_length = max_length - len(input_ids)
    if padding_length < 0:
        # optionally: truncate instead of error
        input_ids = input_ids[:max_length]
        attention_mask = attention_mask[:max_length]
        token_type_ids = token_type_ids[:max_length]
    else:
        pad_id_list = [pad_token] * padding_length
        pad_mask_list = [0 if mask_padding_with_zero else 1] * padding_length
        pad_type_list = [pad_token_segment_id] * padding_length

        if pad_on_left:
            input_ids      = pad_id_list + input_ids
            attention_mask = pad_mask_list + attention_mask
            token_type_ids = pad_type_list + token_type_ids
        else:
            input_ids      = input_ids + pad_id_list
            attention_mask = attention_mask + pad_mask_list
            token_type_ids = token_type_ids + pad_type_list

    # convert to JAX arrays with appropriate dtypes
    return (
        jnp.array(input_ids,      dtype=jnp.int32),
        jnp.array(attention_mask, dtype=jnp.bool_),
        jnp.array(token_type_ids, dtype=jnp.int32),
    )


def dual_process_fn(line: str, i: int, tokenizer, args):
    """
    For lines with two tab-separated fields: [id, text].
    Returns a single feature list: [input_ids, attention_mask, token_type_ids, qid].
    """
    cells = line.split("\t")
    if len(cells) != 2:
        raise ValueError(f"Line has {len(cells)} cells; expected 2.")

    mask_padding_with_zero = True
    pad_token_segment_id   = 0
    pad_on_left            = False

    qid, text = cells[0], cells[1].strip()
    input_id_a = tokenizer.encode(
        text,
        add_special_tokens=True,
        max_length=args.max_seq_length,
    )
    token_type_ids_a   = [0] * len(input_id_a)
    attention_mask_a   = [1 if mask_padding_with_zero else 0] * len(input_id_a)

    input_ids, attn_mask, token_types = pad_ids(
        input_id_a, attention_mask_a, token_type_ids_a,
        args.max_seq_length,
        tokenizer.pad_token_id,
        mask_padding_with_zero,
        pad_token_segment_id,
        pad_on_left,
    )

    return [[
        input_ids,        # jnp.int32 array, shape (max_seq_length,)
        attn_mask,        # jnp.bool_ array
        token_types,      # jnp.int32 array
        int(qid),         # Python int
    ]]


def triple_process_fn(line: str, i: int, tokenizer, args):
    """
    For lines with three tab-separated texts: [q, pos, neg].
    Returns a single feature list of six JAX arrays:
      [input_ids, attention_mask] × 3
    """
    cells = line.split("\t")
    if len(cells) != 3:
        raise ValueError(f"Line has {len(cells)} cells; expected 3.")

    features = []
    mask_padding_with_zero = True
    pad_token_segment_id   = 0
    pad_on_left            = False

    for text in cells:
        toks = tokenizer.encode(
            text.strip(),
            add_special_tokens=True,
            max_length=args.max_seq_length,
        )
        token_types = [0] * len(toks)
        attn_mask   = [1 if mask_padding_with_zero else 0] * len(toks)

        ids, mask, types = pad_ids(
            toks, attn_mask, token_types,
            args.max_seq_length,
            tokenizer.pad_token_id,
            mask_padding_with_zero,
            pad_token_segment_id,
            pad_on_left,
        )
        features.extend([ids, mask])

    return [features]


def triple2dual_process_fn(line: str, i: int, tokenizer, args):
    """
    For lines with three tab-separated texts: [q, pos, neg].
    Returns two entries: one positive example [q, pos, 1] and one negative [q, neg, 0].
    Each entry is a list of four items: [input_ids, attention_mask, label].
    """
    cells = line.split("\t")
    if len(cells) != 3:
        raise ValueError(f"Line has {len(cells)} cells; expected 3.")

    mask_padding_with_zero = True
    pad_token_segment_id   = 0
    pad_on_left            = False

    pos_feats = []
    neg_feats = []

    for idx, text in enumerate(cells):
        toks = tokenizer.encode(
            text.strip(),
            add_special_tokens=True,
            max_length=args.max_seq_length,
        )
        token_types = [0] * len(toks)
        attn_mask   = [1 if mask_padding_with_zero else 0] * len(toks)

        ids, mask, _ = pad_ids(
            toks, attn_mask, token_types,
            args.max_seq_length,
            tokenizer.pad_token_id,
            mask_padding_with_zero,
            pad_token_segment_id,
            pad_on_left,
        )

        if idx == 0:
            # the query goes into both examples
            pos_feats.extend([ids, mask])
            neg_feats.extend([ids, mask])
        elif idx == 1:
            # positive passage, label=1
            pos_feats.append(jnp.int32(1))
        else:
            # negative passage, label=0
            neg_feats.append(jnp.int32(0))

    return [pos_feats, neg_feats]
