import logging
import os
from typing import Any, Dict, Optional, Union, NamedTuple

import jax
import jax.numpy as jnp
import optax

from allennlp.common import Registrable
from allennlp.common.checks import ConfigurationError, check_for_gpu  # re-use existing checks
from allennlp.common.util import int_to_device

logger = logging.getLogger(__name__)


class TrainerCheckpoint(NamedTuple):
    model_state: Dict[str, Any]
    trainer_state: Dict[str, Any]


class Trainer(Registrable):
    """
    JAX/Flax version of the AllenNLP Trainer.
    Subclasses should implement `train` and likely `from_params`.
    """

    default_implementation = "gradient_descent"

    def __init__(
        self,
        serialization_dir: Union[str, os.PathLike] = None,
        cuda_device: Optional[Union[int, jax.lib.xla_client.Device]] = None,
        distributed: bool = False,
        local_rank: int = 0,
        world_size: int = 1,
    ) -> None:
        # Choose device: map torch.cuda logic to jax.devices()
        devices = jax.devices()
        if cuda_device is None:
            cuda_device = 0 if devices else -1
        check_for_gpu(cuda_device)  # still uses existing check

        # Ensure serialization directory exists.
        if serialization_dir is None:
            import tempfile
            self._serialization_dir = tempfile.mkdtemp()
        else:
            self._serialization_dir = str(serialization_dir)
        os.makedirs(self._serialization_dir, exist_ok=True)

        # Only single‐device per process
        if isinstance(cuda_device, list):
            raise ConfigurationError(
                "In AllenNLP 1.0, the Trainer can only be assigned a single `cuda_device`."
            )
        if distributed and world_size <= 1:
            raise ConfigurationError(
                "Distributed training can be performed only with more than 1 device."
            )

        # Map int -> jax.Device
        if cuda_device >= 0:
            self.device = devices[cuda_device]
        else:
            self.device = None  # CPU

        self._distributed = distributed
        self._rank = local_rank
        self._primary = (self._rank == 0)
        self._world_size = world_size

    def train(self) -> Dict[str, Any]:
        """
        Train a model and return results.
        Must be overridden by subclasses.
        """
        raise NotImplementedError

    def get_checkpoint_state(self) -> Optional[TrainerCheckpoint]:
        """
        Returns a TrainerCheckpoint holding model & trainer state dicts.
        """
        raise NotImplementedError

    def get_best_weights_path(self) -> Optional[str]:
        """
        Returns path to file containing the current best weights (if any).
        """
        return None
