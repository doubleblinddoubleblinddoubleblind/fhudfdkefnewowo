import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Tuple, Any


class ConvolutionalBlock(nn.Module):
    in_channels: int
    n_filters: int = 256

    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=self.n_filters,
                    kernel_size=(3, 3),
                    padding='SAME',
                    use_bias=True)(x)
        x = nn.BatchNorm(use_running_average=False,
                         momentum=0.9,
                         epsilon=1e-5)(x)
        x = nn.relu(x)
        return x


class ResidualBlock(nn.Module):
    n_filters: int

    @nn.compact
    def __call__(self, x):
        residual = x
        # First conv → BN → ReLU
        y = nn.Conv(features=self.n_filters,
                    kernel_size=(3, 3),
                    padding='SAME',
                    use_bias=True)(x)
        y = nn.BatchNorm(use_running_average=False)(y)
        y = nn.relu(y)
        # Second conv → BN
        y = nn.Conv(features=self.n_filters,
                    kernel_size=(3, 3),
                    padding='SAME',
                    use_bias=True)(y)
        y = nn.BatchNorm(use_running_average=False)(y)
        # Add skip connection
        y = y + residual
        y = nn.relu(y)
        return y


class PolicyHead(nn.Module):
    n_filters: int
    board_size: int = 9

    @nn.compact
    def __call__(self, x):
        # 1×1 conv → BN → ReLU
        x = nn.Conv(features=2,
                    kernel_size=(1, 1),
                    padding='VALID',
                    use_bias=True)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        # Flatten and dense
        x = x.reshape((x.shape[0], -1))  # (-1, 2*9*9)
        x = nn.Dense(features=self.board_size * self.board_size + 1)(x)
        return x


class ValueHead(nn.Module):
    n_filters: int
    board_size: int = 9
    hidden_units: int = 256

    @nn.compact
    def __call__(self, x):
        # 1×1 conv → BN → ReLU
        x = nn.Conv(features=1,
                    kernel_size=(1, 1),
                    padding='VALID',
                    use_bias=True)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        # Flatten → dense → ReLU → dense → tanh
        x = x.reshape((x.shape[0], -1))  # (-1, 9*9)
        x = nn.Dense(features=self.hidden_units)(x)
        x = nn.relu(x)
        x = nn.Dense(features=1)(x)
        x = nn.tanh(x)
        return x


class ConvNet(nn.Module):
    in_channels: int
    conv_depth: int = 9
    n_filters: int = 64
    board_size: int = 9

    def setup(self):
        self.conv_block = ConvolutionalBlock(self.in_channels, self.n_filters)
        self.residual_blocks = [ResidualBlock(self.n_filters)
                                for _ in range(self.conv_depth)]
        self.policy_head = PolicyHead(self.n_filters, board_size=self.board_size)
        self.value_head = ValueHead(self.n_filters, board_size=self.board_size)

    def __call__(self, x):
        x = self.conv_block(x)
        for block in self.residual_blocks:
            x = block(x)
        p = self.policy_head(x)
        v = self.value_head(x)
        return p, v


# Example of initializing and running the model:

def main():
    # Create dummy input: batch of size 1, in_channels × 9 × 9
    batch_size = 1
    key = jax.random.PRNGKey(0)
    dummy_input = jax.random.normal(key, (batch_size, 3, 9, 9))

    # Initialize model
    model = ConvNet(in_channels=3, conv_depth=9, n_filters=64, board_size=9)
    variables = model.init(key, dummy_input)

    # Run forward pass
    policy_logits, value = model.apply(variables, dummy_input)
    print("Policy logits shape:", policy_logits.shape)  # (1, 82)
    print("Value shape:", value.shape)                  # (1, 1)


if __name__ == "__main__":
    main()
