import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.linen import initializers
from typing import Any, Optional, Tuple


def orthogonal(scale=1.0):
    """Orthogonal initializer with gain."""
    return initializers.orthogonal(scale)


def constant_zero():
    """Constant zero initializer."""
    return initializers.zeros


class Flatten(nn.Module):
    @nn.compact
    def __call__(self, x):
        return x.reshape((x.shape[0], -1))


class CNNBase(nn.Module):
    num_inputs: int
    use_gru: bool = False

    @nn.compact
    def __call__(
        self,
        inputs: jnp.ndarray,                    # shape (batch, C, H, W)
        states: Optional[jnp.ndarray],
        masks: jnp.ndarray                      # shape (batch,) or (steps, batch)
    ) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
        # normalize inputs
        x = inputs / 255.0

        # convolutional trunk
        x = nn.Conv(
            features=32, kernel_size=(8, 8), strides=(4, 4),
            kernel_init=orthogonal(jnp.sqrt(2)),
            bias_init=constant_zero()
        )(x)
        x = nn.relu(x)

        x = nn.Conv(
            features=64, kernel_size=(4, 4), strides=(2, 2),
            kernel_init=orthogonal(jnp.sqrt(2)),
            bias_init=constant_zero()
        )(x)
        x = nn.relu(x)

        x = nn.Conv(
            features=64, kernel_size=(3, 3), strides=(1, 1),
            kernel_init=orthogonal(jnp.sqrt(2)),
            bias_init=constant_zero()
        )(x)
        x = nn.relu(x)

        x = Flatten()(x)

        x = nn.Dense(
            features=512,
            kernel_init=orthogonal(jnp.sqrt(2)),
            bias_init=constant_zero()
        )(x)
        x = nn.relu(x)

        # recurrent core (optional)
        new_states = states
        if self.use_gru:
            gru = nn.GRUCell()
            if inputs.shape[0] == states.shape[0]:
                # standard batch mode
                new_states, x = gru(new_states * masks[:, None], x)
            else:
                # time-major sequence mode
                seq_len = inputs.shape[0] // states.shape[0]
                x_seq = x.reshape((seq_len, states.shape[0], -1))
                mask_seq = masks.reshape((seq_len, states.shape[0]))
                outputs = []
                h = new_states
                for t in range(seq_len):
                    h, out = gru(h * mask_seq[t][:, None], x_seq[t])
                    outputs.append(out)
                x = jnp.concatenate(outputs, axis=0)
                new_states = h

        # critic head
        v = nn.Dense(
            features=1,
            kernel_init=orthogonal(),
            bias_init=constant_zero()
        )(x)

        return v, x, new_states
