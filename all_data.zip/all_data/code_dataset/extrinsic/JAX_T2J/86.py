import argparse
import numpy as np

import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad

from flax import linen as nn
from flax.training import train_state
import optax

# ---------------------------
# Model Definition (Flax)
# ---------------------------
class Net(nn.Module):
    dropout: float
    fc1_size: int
    fc2_size: int

    @nn.compact
    def __call__(self, x, *, train: bool):
        # fc1 -> ReLU
        x = nn.Dense(self.fc1_size)(x)
        x = nn.relu(x)
        # Dropout
        x = nn.Dropout(rate=self.dropout)(x, deterministic=not train)
        # fc2 -> PReLU
        x = nn.Dense(self.fc2_size)(x)
        # parametrized ReLU
        alpha = self.param('prelu_alpha',
                           nn.initializers.constant(0.25),
                           (self.fc2_size,))
        x = jnp.maximum(0, x) + alpha * jnp.minimum(0, x)
        # output layer + sigmoid
        x = nn.Dense(1)(x)
        return nn.sigmoid(x)

# ---------------------------
# Data Generation
# ---------------------------
def get_data(key, size):
    # Mimic get_x_y in NumPy but with JAX RNG
    key, sub1, sub2 = random.split(key, 3)
    half = size // 2
    X1 = random.normal(sub1, (half, 50))
    X2 = random.normal(sub2, (half, 50)) + 1.5
    X = jnp.concatenate([X1, X2], axis=0)
    y = jnp.concatenate([jnp.zeros((half,1)), jnp.ones((half,1))], axis=0)
    return key, X, y

# ---------------------------
# Loss and Metrics
# ---------------------------
def bce_loss(params, model, X, y, rng):
    preds = model.apply({'params': params}, X, train=False, rngs={'dropout': rng})
    # binary cross-entropy
    eps = 1e-7
    loss = -jnp.mean(y * jnp.log(preds + eps) + (1-y) * jnp.log(1 - preds + eps))
    return loss

@jit
def train_step(state, X, y, rng):
    """Single training step."""
    rng, subkey = random.split(rng)
    (loss, grads) = value_and_grad(bce_loss)(state.params,
                                              state.apply_fn,
                                              X, y, subkey)
    state = state.apply_gradients(grads=grads)
    return state, loss, rng

# ---------------------------
# Training Loop
# ---------------------------
def train_and_evaluate(dropout, fc1_size, fc2_size,
                       lr, batch_size, epochs, rng):
    # Initialize model & optimizer state
    model = Net(dropout=dropout, fc1_size=fc1_size, fc2_size=fc2_size)
    dummy_input = jnp.ones((1, 50))
    params = model.init({'params': rng, 'dropout': rng},
                        dummy_input,
                        train=True)['params']

    tx = optax.sgd(lr)
    state = train_state.TrainState.create(apply_fn=model.apply,
                                          params=params,
                                          tx=tx)

    # Generate train & val data
    rng, sub = random.split(rng)
    rng, X_train, y_train = get_data(rng, 1000)
    rng, X_val,   y_val   = get_data(rng,  400)

    # Batch iterator
    def batches(X, y):
        n = X.shape[0]
        perm = jax.random.permutation(rng, n)
        X, y = X[perm], y[perm]
        for i in range(0, n, batch_size):
            yield X[i:i+batch_size], y[i:i+batch_size]

    # Training
    for epoch in range(1, epochs+1):
        for Xb, yb in batches(X_train, y_train):
            state, loss, rng = train_step(state, Xb, yb, rng)
        if epoch % 1 == 0:
            val_loss = bce_loss(state.params, state.apply_fn,
                                X_val, y_val, rng)
            print(f"Epoch [{epoch}/{epochs}], "
                  f"Train Loss: {loss:.4f}, Val Loss: {val_loss:.4f}")

    return state, X_val, y_val

# ---------------------------
# Main & Arg Parsing
# ---------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dropout',    type=float, default=0.2)
    parser.add_argument('--fc1_size',   type=int,   default=50)
    parser.add_argument('--fc2_size',   type=int,   default=100)
    parser.add_argument('--lr',         type=float, default=0.001)
    parser.add_argument('--batch_size', type=int,   default=32)
    parser.add_argument('--epochs',     type=int,   default=10)
    parser.add_argument('--seed',       type=int,   default=0)
    args = parser.parse_args()

    rng = random.PRNGKey(args.seed)
    state, X_val, y_val = train_and_evaluate(
        args.dropout, args.fc1_size, args.fc2_size,
        args.lr, args.batch_size, args.epochs, rng)

    # Simple accuracy on validation set
    preds = state.apply_fn({'params': state.params},
                            X_val, train=False,
                            rngs={'dropout': rng})
    acc = jnp.mean((preds > 0.5) == (y_val > 0.5))
    print("Validation accuracy:", float(acc))

if __name__ == "__main__":
    main()
