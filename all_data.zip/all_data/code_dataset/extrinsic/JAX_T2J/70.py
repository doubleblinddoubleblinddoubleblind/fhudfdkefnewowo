import jax
import jax.numpy as jnp
from jax import random, jit, value_and_grad
import optax
import matplotlib.pyplot as plt

# ---------------------------
# Data generation
# ---------------------------
key = random.PRNGKey(0)
# generate 100 points in [-1, 1]
X = jnp.linspace(-1.0, 1.0, 100).reshape(-1, 1)
# add noise
key, subkey = random.split(key)
noise = random.normal(subkey, shape=X.shape) * 0.2
Y = X**2 + noise

# ---------------------------
# Model definition
# ---------------------------
def init_params(key):
    """Initialize a 1-hidden-layer MLP with 10 units."""
    keys = random.split(key, 4)
    params = {
        'W1': random.uniform(keys[0], (1, 10), minval=-1.0, maxval=1.0),
        'b1': jnp.zeros((10,)),
        'W2': random.uniform(keys[1], (10, 1), minval=-1.0, maxval=1.0),
        'b2': jnp.zeros((1,))
    }
    return params

def forward(params, x):
    h = jnp.dot(x, params['W1']) + params['b1']
    h = jax.nn.relu(h)
    y = jnp.dot(h, params['W2']) + params['b2']
    return y

# ---------------------------
# Loss and update
# ---------------------------
def loss_fn(params, x, y):
    preds = forward(params, x)
    return jnp.mean((preds - y)**2)

@jit
def update(params, x, y, lr):
    loss, grads = value_and_grad(loss_fn)(params, x, y)
    # simple SGD update
    new_params = {k: params[k] - lr * grads[k] for k in params}
    return new_params, loss

# ---------------------------
# Training loop with plotting
# ---------------------------
params = init_params(key)
learning_rate = 0.5

plt.ion()
fig, ax = plt.subplots()
for t in range(100):
    params, loss = update(params, X, Y, learning_rate)

    if t % 5 == 0:
        ax.cla()
        ax.scatter(jnp.array(X).flatten(), jnp.array(Y).flatten(), label='data')
        preds = forward(params, X)
        ax.plot(jnp.array(X).flatten(), jnp.array(preds).flatten(), 'r-', lw=2, label='pred')
        ax.text(0.5, 0.0, f'Loss={loss:.4f}', fontdict={'size':14,'color':'red'})
        ax.legend()
        plt.pause(0.1)

plt.ioff()
plt.show()
