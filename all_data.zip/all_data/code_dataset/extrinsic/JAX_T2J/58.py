import jax
import jax.numpy as jnp
import optax
from typing import Sequence

def piecewise_linear_schedule(
    milestones: Sequence[int],
    lrs: Sequence[float],
) -> optax.Schedule:
    """
    Build a piecewise-linear schedule that:
      - uses lrs[0] up to step=0,
      - linearly anneals to lrs[1] over [0, milestones[0]),
      - then linearly from lrs[1]→lrs[2] over [milestones[0], milestones[1]), etc.
    """
    assert len(milestones) + 1 == len(lrs), "need #lrs = #milestones + 1"
    # Compute each segment length
    boundaries = list(milestones)
    # Optax wants transition_steps for each segment, so:
    steps = [milestones[0]] + [
        m2 - m1 for m1, m2 in zip(milestones[:-1], milestones[1:])
    ]
    # Build a linear schedule for each segment
    schedules = [
        optax.linear_schedule(init_value=lr_start,
                              end_value=lr_end,
                              transition_steps=step_len)
        for (lr_start, lr_end), step_len in zip(zip(lrs, lrs[1:]), steps)
    ]
    return optax.join_schedules(schedules, boundaries)


def cosine_annealing_schedule(
    base_lr: float,
    T_max: int,
    eta_min: float = 0.0,
) -> optax.Schedule:
    """
    Cosine annealing schedule with no restarts:
      lr(t) = eta_min + 0.5 * (base_lr - eta_min) * (1 + cos(pi * t / T_max))
    """
    # optax.cosine_decay_schedule does exactly this if you set alpha = eta_min/base_lr
    return optax.cosine_decay_schedule(
        init_value=base_lr,
        decay_steps=T_max,
        alpha=eta_min / base_lr,
    )


# Example usage:

# 1) Piecewise: LR = [0.1→0.01 over 5k steps, then 0.01→0.001 over next 5k]
pw_sched = piecewise_linear_schedule(
    milestones=[5000],
    lrs=[0.1, 0.01, 0.001]
)
optimizer = optax.sgd(learning_rate=pw_sched)

# 2) Cosine annealing from 0.1 down to 0.001 over 10k steps:
cos_sched = cosine_annealing_schedule(base_lr=0.1, T_max=10000, eta_min=0.001)
optimizer = optax.sgd(learning_rate=cos_sched)

# 3) If you ever need just a simple linear ramp (start→end):
def linear_schedule(start_lr: float, end_lr: float, length: int) -> optax.Schedule:
    return optax.linear_schedule(
        init_value=start_lr,
        end_value=end_lr,
        transition_steps=length
    )

# Plug into your training loop
# -----------------------------
# Suppose you have `opt_state = optimizer.init(params)`
# At each step `i` you do:
#
#   updates, opt_state = optimizer.update(grads, opt_state, params)
#   params = optax.apply_updates(params, updates)
#
# The `optimizer` will call your schedule with the current step to pick the LR.
