# SPDX-License-Identifier: Apache-2.0

import pytest
import jax
import jax.numpy as jnp
from jax import grad, random

import numpyro
import numpyro.distributions as dist
from numpyro.infer.reparam import GumbelSoftmaxReparam
from numpyro.handlers import trace, seed, reparam


# Test helper to extract a few central moments from samples.
def get_moments(x):
    # x: [num_samples, ..., dim]
    m1 = jnp.mean(x, axis=0)
    x_centered = x - m1
    xx = x_centered[..., None] * x_centered[..., None, :]
    m2 = jnp.mean(xx, axis=0)
    return jnp.concatenate([m1.ravel(), m2.ravel()])


@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_gumbel_softmax(temperature, shape, dim):
    key = random.PRNGKey(0)
    temperature = jnp.array(temperature)
    # random logits, with grad
    key, subkey = random.split(key)
    logits = random.normal(subkey, shape + (dim,))

    def model():
        # draw 10000 samples with RelaxedOneHotCategorical
        with numpyro.plate_stack("plates", shape):
            with numpyro.plate("particles", 10000):
                return numpyro.sample(
                    "x",
                    dist.RelaxedOneHotCategorical(temperature, logits=logits),
                )

    # trace the unconstrained model
    sampled = trace(seed(model, key)).get_trace()["x"]["value"]
    expected_probe = get_moments(sampled)

    # apply GumbelSoftmax reparam
    reparam_model = reparam(model, {"x": GumbelSoftmaxReparam()})
    sampled_reparam = trace(seed(reparam_model, key)).get_trace()["x"]["value"]
    actual_probe = get_moments(sampled_reparam)

    # check that the moments match
    assert jnp.allclose(actual_probe, expected_probe, atol=0.05)

    # gradient check: each moment w.r.t. logits
    for actual_m, expected_m in zip(actual_probe, expected_probe):
        g_expected = grad(lambda l: get_moments(
            trace(seed(model, key)).get_trace()["x"]["value"])[0])(logits)
        g_actual   = grad(lambda l: get_moments(
            trace(seed(reparam_model, key)).get_trace()["x"]["value"])[0])(logits)
        assert jnp.allclose(g_actual, g_expected, atol=0.05)


@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_init(temperature, shape, dim):
    key = random.PRNGKey(1)
    temperature = jnp.array(temperature)
    key, subkey = random.split(key)
    logits = random.normal(subkey, shape + (dim,))

    def model():
        with numpyro.plate_stack("plates", shape):
            return numpyro.sample(
                "x",
                dist.RelaxedOneHotCategorical(temperature, logits=logits),
            )

    # this simply tests that initialization of the reparam doesn't error
    GumbelSoftmaxReparam().init_fn(model, {"x": None})
