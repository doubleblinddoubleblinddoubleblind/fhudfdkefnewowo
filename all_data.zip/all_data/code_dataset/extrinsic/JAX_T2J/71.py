import bisect
import os
from typing import List, Optional, Tuple

import jax
import jax.numpy as jnp
from flax.training import train_state, checkpoints


def calc_dynamic_intervals(
    start_interval: int,
    dynamic_interval_list: List[Tuple[int, int]]
) -> Tuple[List[int], List[int]]:
    """
    Compute dynamic milestones and corresponding evaluation intervals.
    """
    milestones = [0] + [milestone for milestone, _ in dynamic_interval_list]
    intervals = [start_interval] + [interval for _, interval in dynamic_interval_list]
    return milestones, intervals


class EvalHook:
    """
    Periodic evaluation and checkpoint hook for a JAX training loop.
    """
    def __init__(
        self,
        base_interval: int,
        dynamic_intervals: Optional[List[Tuple[int, int]]] = None,
        by_epoch: bool = True,
        save_dir: str = './checkpoints',
        save_best: bool = True,
        metric_name: str = 'accuracy',
    ):
        self.base_interval = base_interval
        self.by_epoch = by_epoch
        self.save_dir = save_dir
        self.save_best = save_best
        self.metric_name = metric_name
        self.best_value = None
        
        self.use_dynamic = dynamic_intervals is not None
        if self.use_dynamic:
            self.milestones, self.intervals = calc_dynamic_intervals(
                base_interval, dynamic_intervals
            )

    def _current_interval(self, progress: int) -> int:
        if not self.use_dynamic:
            return self.base_interval
        idx = bisect.bisect(self.milestones, progress)
        return self.intervals[idx - 1]

    def before_train_epoch(self, epoch: int, state: train_state.TrainState, eval_fn):
        """
        To be called at the start of each epoch.
        """
        interval = self._current_interval(epoch)
        if (epoch + 1) % interval == 0:
            self._evaluate_and_save(epoch, state, eval_fn)

    def before_train_step(self, step: int, state: train_state.TrainState, eval_fn):
        """
        To be called at each training iteration if by_epoch=False.
        """
        if not self.by_epoch:
            interval = self._current_interval(step)
            if (step + 1) % interval == 0:
                self._evaluate_and_save(step, state, eval_fn)

    def _evaluate_and_save(
        self,
        progress: int,
        state: train_state.TrainState,
        eval_fn,
    ):
        """
        Run evaluation function and save checkpoints based on metric.
        eval_fn(state) should return a dict of metrics.
        """
        metrics = eval_fn(state)
        value = metrics.get(self.metric_name)
        if value is None:
            return

        # Save best checkpoint
        if self.save_best and (self.best_value is None or value > self.best_value):
            self.best_value = value
            checkpoints.save_checkpoint(
                ckpt_dir=self.save_dir,
                target=state.params,
                step=state.step,
                prefix='best_'
            )


class DistEvalHook(EvalHook):
    """
    Distributed evaluation hook for multi-device JAX training.
    """
    def __init__(self, *args, sync_bn: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        self.sync_bn = sync_bn

    def _sync_batch_stats(self, state: train_state.TrainState) -> train_state.TrainState:
        """
        All-reduce batch statistics across devices if Flax models use batch_stats collection.
        """
        if not self.sync_bn or 'batch_stats' not in state.params:
            return state
        synced = jax.lax.pmean(state.params['batch_stats'], axis_name='batch')
        new_params = state.params.copy()
        new_params['batch_stats'] = synced
        return state.replace(params=new_params)

    def before_train_epoch(self, epoch: int, state: train_state.TrainState, eval_fn):
        # synchronize BN, then evaluate
        state = self._sync_batch_stats(state)
        super().before_train_epoch(epoch, state, eval_fn)

    def before_train_step(self, step: int, state: train_state.TrainState, eval_fn):
        if not self.by_epoch:
            state = self._sync_batch_stats(state)
            super().before_train_step(step, state, eval_fn)
