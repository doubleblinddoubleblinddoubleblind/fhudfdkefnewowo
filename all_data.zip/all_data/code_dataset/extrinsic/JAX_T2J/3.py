import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Dict, Optional, Tuple


class SeqAttnMatch(nn.Module):
    dim: int

    @nn.compact
    def __call__(self, x: jnp.ndarray, y: jnp.ndarray, y_mask: jnp.ndarray) -> jnp.ndarray:
        # x: [B, Lx, D], y: [B, Ly, D], y_mask: [B, Ly]
        # Compute attention weights of y over each position in x
        scores = jnp.einsum('bld,bmd->blm', x, y)  # [B, Lx, Ly]
        mask = y_mask[:, None, :]  # [B,1,Ly]
        scores = jnp.where(mask, scores, -1e9)
        alpha = nn.softmax(scores, axis=-1)  # [B, Lx, Ly]
        return jnp.einsum('blm,bmd->bld', alpha, y)  # [B, Lx, D]


class BilinearSeqAttn(nn.Module):
    x_dim: int
    y_dim: int

    def setup(self):
        self.U = self.param('U', nn.initializers.xavier_uniform(),
                            (self.x_dim, self.y_dim))

    def __call__(self,
                 x: jnp.ndarray,      # [B, L, Dx]
                 y: jnp.ndarray,      # [B, Dy]
                 x_mask: jnp.ndarray  # [B, L]
                 ) -> jnp.ndarray:
        # Compute x U y^T for each position
        Uy = jnp.dot(y, self.U.T)         # [B, Dx]
        scores = jnp.einsum('bld,bd->bl', x, Uy)  # [B, L]
        scores = jnp.where(x_mask, scores, -1e9)
        return scores


class StackedBRNN(nn.Module):
    hidden_size: int
    num_layers: int
    dropout_rate: float
    bidirectional: bool = True

    @nn.compact
    def __call__(self,
                 inputs: jnp.ndarray,    # [B, L, D]
                 mask: jnp.ndarray       # [B, L]
                 ) -> jnp.ndarray:
        B, L, _ = inputs.shape
        x = inputs
        for _ in range(self.num_layers):
            # Forward LSTM
            f_carry = nn.LSTMCell.initialize_carry(
                jax.random.PRNGKey(0), (B,), self.hidden_size)
            b_carry = nn.LSTMCell.initialize_carry(
                jax.random.PRNGKey(1), (B,), self.hidden_size)
            # scan forward
            def f_step(carry, xt):
                new_carry, yt = nn.LSTMCell()(carry, xt)
                return new_carry, yt
            _, f_seq = nn.scan(f_step,
                               variable_broadcast='params',
                               split_rngs={'params': False},
                               length=L,
                               reverse=False)(f_carry, x)
            # scan backward
            def b_step(carry, xt):
                new_carry, yt = nn.LSTMCell()(carry, xt)
                return new_carry, yt
            _, b_seq = nn.scan(b_step,
                               variable_broadcast='params',
                               split_rngs={'params': False},
                               length=L,
                               reverse=True)(b_carry, x)
            b_seq = jnp.flip(b_seq, axis=1)
            x = jnp.concatenate([f_seq, b_seq], axis=-1)  # [B, L, 2H]
            x = nn.Dropout(self.dropout_rate)(x, deterministic=not self.is_mutable_collection('dropout'))
        return x  # [B, L, 2H]


class RnnDocReader(nn.Module):
    opt: Dict[str, Any]

    def setup(self):
        o = self.opt
        # embedding
        self.embedding = nn.Embed(num_embeddings=o['vocab_size'],
                                  features=o['embedding_dim'])
        # optional question‐aware embedding
        if o['use_qemb']:
            self.qemb_match = SeqAttnMatch(o['embedding_dim'])
        # stacked bidirectional RNNs
        doc_in = o['embedding_dim'] + o['num_features']
        if o['use_qemb']:
            doc_in += o['embedding_dim']
        self.doc_rnn = StackedBRNN(hidden_size=o['hidden_size'],
                                   num_layers=o['doc_layers'],
                                   dropout_rate=o['dropout_rnn'])
        self.question_rnn = StackedBRNN(hidden_size=o['hidden_size'],
                                         num_layers=o['question_layers'],
                                         dropout_rate=o['dropout_rnn'])
        # self‐attn on question
        if o['question_merge'] == 'self_attn':
            self.self_attn = nn.Dense(1)
        # bilinear span scorers
        doc_dim = (2 * o['hidden_size']) * (o['doc_layers'] if o['concat_rnn_layers'] else 1)
        q_dim = (2 * o['hidden_size']) * (o['question_layers'] if o['concat_rnn_layers'] else 1)
        self.start_attn = BilinearSeqAttn(doc_dim, q_dim)
        self.end_attn   = BilinearSeqAttn(doc_dim, q_dim)

    def __call__(self,
                 x1: jnp.ndarray,      # [B, Ld]
                 x1_f: jnp.ndarray,    # [B, Ld, F]
                 x1_mask: jnp.ndarray, # [B, Ld]
                 x2: jnp.ndarray,      # [B, Lq]
                 x2_mask: jnp.ndarray  # [B, Lq]
                 ) -> Tuple[jnp.ndarray, jnp.ndarray]:
        # embed
        x1_emb = self.embedding(x1)  # [B, Ld, D]
        x2_emb = self.embedding(x2)  # [B, Lq, D]
        # dropout
        if self.opt['dropout_emb'] > 0:
            x1_emb = nn.Dropout(self.opt['dropout_emb'])(x1_emb,
                                                        deterministic=not self.is_mutable_collection('dropout'))
            x2_emb = nn.Dropout(self.opt['dropout_emb'])(x2_emb,
                                                        deterministic=not self.is_mutable_collection('dropout'))
        # add question emb
        if self.opt['use_qemb']:
            x2_w = self.qemb_match(x1_emb, x2_emb, x2_mask)  # [B, Ld, D]
            drnn_in = jnp.concatenate([x1_emb, x2_w, x1_f], axis=-1)
        else:
            drnn_in = jnp.concatenate([x1_emb, x1_f], axis=-1)
        # encode doc & question
        doc_h = self.doc_rnn(drnn_in, x1_mask)  # [B, Ld, 2H*layers]
        q_h   = self.question_rnn(x2_emb, x2_mask)  # [B, Lq, 2H*layers]
        # merge question
        if self.opt['question_merge'] == 'avg':
            qh = jnp.sum(q_h * x2_mask[..., None], axis=1) / jnp.sum(x2_mask, axis=1, keepdims=True)
        else:
            # self‐attn: compute scores then weighted avg
            scores = self.self_attn(q_h).squeeze(-1)  # [B, Lq]
            scores = jnp.where(x2_mask, scores, -1e9)
            alpha = nn.softmax(scores, axis=-1)[..., None]  # [B, Lq,1]
            qh = jnp.sum(q_h * alpha, axis=1)  # [B, 2H*layers]
        # span scores
        start_scores = self.start_attn(doc_h, qh, x1_mask)  # [B, Ld]
        end_scores   = self.end_attn(  doc_h, qh, x1_mask)  # [B, Ld]
        return start_scores, end_scores
