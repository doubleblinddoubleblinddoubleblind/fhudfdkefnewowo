import os
import logging
import sys
import datetime
import gc
from functools import reduce
import operator as op
import numpy as np

import jax
import jax.numpy as jnp

# Check GPU availability
GPU_AVAILABLE = any(device.platform == 'gpu' for device in jax.devices())

if GPU_AVAILABLE:
    from jax.lib import xla_bridge


def get_immediate_subdirectories(a_dir):
    return [name for name in os.listdir(a_dir)
            if os.path.isdir(os.path.join(a_dir, name))]


def get_logfile(exp_dir, silent: bool = False, verbose: bool = False):
    logfile = os.path.join(exp_dir, 'log.txt')
    logging.basicConfig(
        level=logging.INFO,
        filename=logfile,
        filemode="a+",
        format="%(message)s"
    )

    debugfile = os.path.join(exp_dir, 'debug.txt')
    ch_debug = logging.StreamHandler(debugfile)
    ch_debug.setLevel(logging.DEBUG)

    if not silent:
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)
        ch = logging.StreamHandler(sys.stdout)
        ch.setLevel(logging.INFO if verbose else logging.WARNING)
        formatter = logging.Formatter('%(message)s')
        ch.setFormatter(formatter)
        root.addHandler(ch)
    return logfile


def timestring():
    dt = datetime.datetime.now()
    return f"{dt.strftime('%b')}-{dt.day} at {dt.hour:02d}:{dt.minute:02d}:{dt.second:02d}"


def log_gpu_usage():
    if GPU_AVAILABLE:
        devices = jax.devices('gpu')
        # JAX does not expose memoryUsed, but we can log device info
        dev = devices[0]
        logging.info(f"GPU device: {dev.topology}" )


def get_tensors_in_memory(ndim=None):
    tensor_list = []
    for obj in gc.get_objects():
        try:
            if isinstance(obj, jax.Array):
                cond = True
                if ndim is not None:
                    cond = cond and (obj.ndim == ndim)
                if cond:
                    tensor_list.append(obj)
        except Exception:
            pass
    return tensor_list


def memory_footprint(x):
    # Number of bytes = count * itemsize
    return x.size * x.dtype.itemsize


def get_bytes(tensor_list):
    return sum(memory_footprint(t) for t in tensor_list)


def format_bytes(n: int) -> str:
    s = str(int(n))
    if len(s) < 4:
        return f"{s} B"
    if len(s) < 7:
        return f"{s[:-3]} kB"
    if len(s) < 10:
        return f"{s[:-6]}.{s[-6:-5]} MB"
    if len(s) < 14:
        return f"{s[:-9]}.{s[-9:-8]} GB"
    return f"{s[:-12]}.{s[-12:-11]} TB"


def see_tensors_in_memory(ndim=None, summary=False, cuda=False):
    tensor_list = get_tensors_in_memory(ndim)
    if cuda:
        tensor_list = [t for t in tensor_list if t.device().platform == 'gpu']
        device_type = 'CUDA'
    else:
        tensor_list = [t for t in tensor_list if t.device().platform != 'gpu']
        device_type = 'CPU'

    total_bytes = get_bytes(tensor_list)
    logging.info(
        f"There are {len(tensor_list)} instantiated {device_type} tensors in memory, consuming {format_bytes(total_bytes)} total."
    )
    if not summary:
        for t in tensor_list:
            logging.info(','.join(map(str, t.shape)))


class memory_snapshot:
    def __init__(self, ndim=None, cuda=False, summary=False):
        self.ndim = ndim
        self.cuda = cuda
        self.summary = summary

    def __enter__(self):
        logging.info("BEFORE")
        see_tensors_in_memory(self.ndim, self.summary, self.cuda)

    def __exit__(self, exc_type, exc_val, exc_tb):
        logging.info("AFTER")
        see_tensors_in_memory(self.ndim, self.summary, self.cuda)
