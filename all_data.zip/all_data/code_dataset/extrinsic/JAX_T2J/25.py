import os
import time
import numpy as np

import jax
import jax.numpy as jnp
from jax import grad, jit, random

import optax
import flax.linen as nn
from flax.training import train_state

import ray
from ray import tune
from ray.tune.integration.horovod import DistributedTrainableCreator
import horovod.torch as hvd


# ----------------------------------------
# Model definition with Flax
# ----------------------------------------
class Net(nn.Module):
    mode: str  # "square" or "cubic"

    @nn.compact
    def __call__(self, x):
        if self.mode == "square":
            # parameters [m1, m0]
            p = self.param("p", nn.initializers.normal(), (2,))
            return x * x + p[0] * x + p[1]
        else:
            # parameters [m2, m1, m0]
            p = self.param("p", nn.initializers.normal(), (3,))
            # m3 * x^3 + m2 * x^2 + m1 * x + m0
            return 10.0 * x**3 + p[0] * x**2 + p[1] * x + p[2]


# ----------------------------------------
# Utility: create TrainState
# ----------------------------------------
def create_train_state(rng, mode, lr):
    """Initialize model + optimizer state."""
    model = Net(mode=mode)
    params = model.init(rng, jnp.ones([1,]))["params"]
    tx = optax.sgd(lr)
    return train_state.TrainState.create(
        apply_fn=model.apply, params=params, tx=tx
    )


# ----------------------------------------
# Loss and update step
# ----------------------------------------
def mse_loss(params, apply_fn, x, y):
    preds = apply_fn({"params": params}, x)
    return jnp.mean((preds - y) ** 2)


@jit
def train_step(state, x, y):
    """Single JIT-compiled update step."""
    loss, grads = jax.value_and_grad(mse_loss)(
        state.params, state.apply_fn, x, y
    )
    state = state.apply_gradients(grads=grads)
    return state, loss


# ----------------------------------------
# Ray Trainable
# ----------------------------------------
def train(config):
    # Horovod: initialize
    hvd.init()
    # Seed numpy & JAX per rank for data shuffling
    np.random.seed(1 + hvd.rank())
    key = random.PRNGKey(1234 + hvd.rank())

    mode = config["mode"]
    lr = config["lr"]
    x_max = config["x_max"]

    # Initialize model state
    state = create_train_state(key, mode, lr)
    # Broadcast initial parameters & optimizer state
    hvd.broadcast_parameters(state.params, root_rank=0)

    num_steps = 5
    start = time.time()

    for step in range(1, num_steps + 1):
        # sample one feature
        feats = (np.random.rand(1) * 2 * x_max - x_max).astype(np.float32)
        x = jnp.array(feats)
        # compute label
        if mode == "square":
            labels = 1.0 * x**2 - 20.0 * x + 50.0
        else:
            labels = 10.0 * x**3 + 5.0 * x**2 - 20.0 * x - 5.0

        # update
        state, loss = train_step(state, x, labels)
        # Horovod: allreduce loss to get average
        loss = hvd.allreduce(loss, op=hvd.Sum) / hvd.size()

        tune.report(loss=float(loss))

        time.sleep(0.1)

    total = time.time() - start
    if hvd.rank() == 0:
        print(f"Took {total:0.3f}s. Avg: {total/num_steps:0.3f}s.")


def tune_horovod(hosts_per_trial,
                 slots_per_host,
                 num_samples,
                 use_gpu,
                 mode="square",
                 x_max=1.0):
    horovod_trainable = DistributedTrainableCreator(
        train,
        use_gpu=use_gpu,
        num_hosts=hosts_per_trial,
        num_slots=slots_per_host,
        replicate_pem=False)
    analysis = tune.run(
        horovod_trainable,
        metric="loss",
        mode="min",
        config={
            "lr": tune.uniform(0.1, 1.0),
            "mode": mode,
            "x_max": x_max
        },
        num_samples=num_samples,
        fail_fast=True)
    print("Best hyperparameters found were:", analysis.best_config)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", type=str, default="square",
                        choices=["square", "cubic"])
    parser.add_argument("--learning_rate", type=float,
                        default=0.1, dest="learning_rate")
    parser.add_argument("--x_max", type=float, default=1.0, dest="x_max")
    parser.add_argument("--gpu", action="store_true")
    parser.add_argument("--smoke-test", action="store_true",
                        help="Finish quickly for testing.")
    parser.add_argument("--hosts-per-trial", type=int, default=1)
    parser.add_argument("--slots-per-host", type=int, default=2)
    parser.add_argument("--server-address", type=str, default=None)
    args, _ = parser.parse_known_args()
