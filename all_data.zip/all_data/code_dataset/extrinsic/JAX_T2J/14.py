import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Tuple
import numpy as np
import pytest

KeyArray = Any

# ------------------------------------------------------------------
# 1) Stacked Bidirectional LSTM Module in Flax
# ------------------------------------------------------------------
class StackedBiLSTM(nn.Module):
    input_size:  int
    hidden_size: int
    num_layers:  int
    layer_dropout:     float = 0.0
    recurrent_dropout: float = 0.0

    @nn.compact
    def __call__(self,
                 x: jnp.ndarray,
                 mask: jnp.ndarray,
                 initial: Tuple[jnp.ndarray, jnp.ndarray] = None
                ) -> Tuple[jnp.ndarray, Tuple[jnp.ndarray, jnp.ndarray]]:
        """
        x:    [batch, time, input_size]
        mask: [batch, time] boolean
        initial:  two tensors each [num_layers*2, batch, hidden_size]
        returns:  output [batch, time, hidden*2], states tuple
        """
        B, T, _ = x.shape
        h_states = []
        c_states = []

        # initialize states to zeros if not provided
        if initial is None:
            init_h = jnp.zeros((self.num_layers * 2, B, self.hidden_size))
            init_c = jnp.zeros((self.num_layers * 2, B, self.hidden_size))
        else:
            init_h, init_c = initial

        carry = (init_h, init_c)

        # sequentially apply each layer
        out = x
        new_h = []
        new_c = []
        for layer in range(self.num_layers):
            # forward cell
            fwd_cell = nn.LSTMCell(name=f"fwd_l{layer}")
            # backward cell
            bwd_cell = nn.LSTMCell(name=f"bwd_l{layer}")

            h_f, c_f = carry[0][2*layer], carry[1][2*layer]
            h_b, c_b = carry[0][2*layer+1], carry[1][2*layer+1]

            # scan forward
            def fwd_step(carry, xi_mask):
                xi, mk = xi_mask
                (hf, cf) = carry
                (hf, cf), y = fwd_cell((hf, cf), xi)
                # apply recurrent dropout on hf if needed
                hf = nn.Dropout(rate=self.recurrent_dropout)(hf, deterministic=False)
                y = mk[:,None] * y
                return (hf, cf), y
            # scan backward
            def bwd_step(carry, xi_mask):
                xi, mk = xi_mask
                (hb, cb) = carry
                (hb, cb), y = bwd_cell((hb, cb), xi)
                hb = nn.Dropout(rate=self.recurrent_dropout)(hb, deterministic=False)
                y = mk[:,None] * y
                return (hb, cb), y

            # prepare sequences with mask
            seq = jnp.swapaxes(out, 0, 1)  # [time, batch, input]
            ms  = jnp.swapaxes(mask, 0, 1) # [time, batch]

            # forward scan
            (hf_final, cf_final), ys_f =  nn.scan(fwd_step,
                                                  variable_broadcast="params",
                                                  length=T,
                                                  split_rngs={"dropout": True}
                                                 )((h_f, c_f), (seq, ms))
            # backward scan
            rev_seq = seq[::-1]
            rev_ms  = ms[::-1]
            (hb_final, cb_final), ys_b_rev = nn.scan(bwd_step,
                                                    variable_broadcast="params",
                                                    length=T,
                                                    split_rngs={"dropout": True}
                                                   )((h_b, c_b), (rev_seq, rev_ms))
            ys_b = ys_b_rev[::-1]

            # concatenate forward and backward outputs at each time
            out = jnp.concatenate([ys_f, ys_b], axis=-1)  # [time, batch, hid*2]
            out = jnp.swapaxes(out, 0, 1)                  # [batch,time,hid*2]

            # apply layer dropout
            out = nn.Dropout(rate=self.layer_dropout)(out, deterministic=False)

            # collect final h,c across layers
            new_h.extend([hf_final, hb_final])
            new_c.extend([cf_final, cb_final])

        h_stacked = jnp.stack(new_h, axis=0)  # [layers*2, batch, hid]
        c_stacked = jnp.stack(new_c, axis=0)
        return out, (h_stacked, c_stacked)


# ------------------------------------------------------------------
# 2) Utility: from “Params”-style dict
# ------------------------------------------------------------------
def make_encoder_from_params(params: dict, seq2vec: bool = False):
    enc = StackedBiLSTM(input_size=params["input_size"],
                        hidden_size=params["hidden_size"],
                        num_layers=params["num_layers"],
                        layer_dropout=params.get("layer_dropout_probability", 0.0),
                        recurrent_dropout=params.get("recurrent_dropout_probability", 0.0))
    if seq2vec:
        # wrap to pick last time-step
        return lambda x, mask: enc(x, mask)[0][:,-1,:]
    else:
        return enc


# ------------------------------------------------------------------
# 3) Test Suite
# ------------------------------------------------------------------
class TestStackedBidirectionalLstmJAX:

    @pytest.mark.parametrize("batch_first", [True])
    def test_forward_pass_masks(self):
        # build sample batched data + mask exactly like your PyTorch test
        B, T, D = 4, 5, 3
        key = jax.random.PRNGKey(0)
        inp = jax.random.uniform(key, (B, T, D))
        # zero out tail elements to emulate padding
        mask = jnp.ones((B, T), dtype=bool)
        mask = mask.at[1,4:].set(False)
        mask = mask.at[2,2:].set(False)
        mask = mask.at[3,1:].set(False)

        encoder = StackedBiLSTM(3,7,3)
        # initialize weights
        init_vars = encoder.init(key, inp, mask)
        out, _ = encoder.apply(init_vars, inp, mask, rngs={"dropout": key})
        # padded outputs should remain zero
        assert jnp.all(out[1,4:,:] == 0.0)
        assert jnp.all(out[2,2:,:] == 0.0)
        assert jnp.all(out[3,1:,:] == 0.0)

    def test_build_from_params_seq2seq(self):
        params = {"type":"stacked_bidirectional_lstm",
                  "input_size":5, "hidden_size":9, "num_layers":3}
        enc = make_encoder_from_params(params, seq2vec=False)
        # we can inspect inside:
        assert enc.keywords["input_size"] == 5
        assert enc.keywords["hidden_size"] == 9

    def test_build_from_params_seq2vec(self):
        params = {"type":"stacked_bidirectional_lstm",
                  "input_size":5, "hidden_size":9, "num_layers":3}
        enc = make_encoder_from_params(params, seq2vec=True)
        # output dim should be hidden*2
        key = jax.random.PRNGKey(1)
        x = jax.random.uniform(key, (2,4,5))
        mask = jnp.ones((2,4), bool)
        out = enc(x, mask)
        assert out.shape[-1] == 18

    @pytest.mark.parametrize("dropout_name", ("layer_dropout_probability","recurrent_dropout_probability"))
    def test_dropout_changes_states(self, dropout_name):
        params = {"input_size":10, "hidden_size":11, "num_layers":3}
        base = make_encoder_from_params(params, seq2vec=False)
        params_d = params.copy()
        params_d[dropout_name] = 0.9
        drop  = make_encoder_from_params(params_d, seq2vec=False)

        key = jax.random.PRNGKey(2)
        x = jax.random.normal(key, (5,7,10))
        mask = jnp.ones((5,7), bool)

        vk = key
        init_base = StackedBiLSTM(**params).init(vk, x, mask)
        out_base, state_base = StackedBiLSTM(**params).apply(init_base, x, mask, rngs={"dropout":vk})

        vk2 = jax.random.PRNGKey(3)
        init_drop = StackedBiLSTM(**params_d).init(vk2, x, mask)
        out_drop, state_drop = StackedBiLSTM(**params_d).apply(init_drop, x, mask, rngs={"dropout":vk2})

        if dropout_name=="layer_dropout_probability":
            # outputs should differ
            assert not jnp.allclose(out_base, out_drop, atol=1e-4)
        else:
            # hidden states should differ
            assert not jnp.allclose(state_base[0], state_drop[0], atol=1e-4)
            assert not jnp.allclose(state_base[1], state_drop[1], atol=1e-4)
