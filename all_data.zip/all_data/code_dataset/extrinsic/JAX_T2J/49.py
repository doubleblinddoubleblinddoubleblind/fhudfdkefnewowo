import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Sequence

class MemN2NConfig:
    hops: int
    vocab_size: int
    embedding_size: int

class MemN2N(nn.Module):
    """Flax/JAX version of the PyTorch MemN2N module."""
    config: MemN2NConfig
    cnn: nn.Module  # assume you've translated your CNN class to a Flax Module

    def setup(self):
        c = self.config
        # Embedding layer
        self.embedding = nn.Embed(
            num_embeddings=c.vocab_size,
            features=c.embedding_size,
            embedding_init=nn.initializers.normal(stddev=0.1)
        )
        # Linear transform for each hop
        self.transform = nn.Dense(
            features=c.embedding_size,
            kernel_init=nn.initializers.xavier_uniform()
        )

    @nn.compact
    def __call__(self, utter: jnp.ndarray, memory: jnp.ndarray) -> jnp.ndarray:
        """
        utter:    [batch, seq_len]        integer token IDs
        memory:   [batch, mem_size, seq_len] integer token IDs
        returns:  [batch, embedding_size]
        """
        c = self.config

        # 1) Encode the query with the CNN encoder
        #    assume `self.cnn` takes shape [batch, seq_len] → [batch, embed]
        query_vec = self.cnn(utter)  # [batch, embed]

        # 2) Encode each memory slot
        #    map over mem_size dimension
        #    flatten to list and re-stack
        mem_list = jnp.split(memory, memory.shape[1], axis=1)  # list of [batch,1,seq_len]
        mem_list = [jnp.squeeze(m,1) for m in mem_list]       # list of [batch,seq_len]
        mem_embs = [self.cnn(m) for m in mem_list]            # list of [batch,embed]
        mem_emb = jnp.stack(mem_embs, axis=1)                 # [batch, mem_size, embed]

        # 3) Multi-hop attention
        context = query_vec  # initial context
        for _ in range(c.hops):
            # compute dot-product attention
            # expand context to [batch, 1, embed] to broadcast
            scores = jnp.sum(mem_emb * context[:, None, :], axis=-1)  # [batch, mem_size]
            attn = jax.nn.softmax(scores, axis=-1)                    # [batch, mem_size]
            # weighted sum of memory embeddings
            read = jnp.sum(mem_emb * attn[:, :, None], axis=1)        # [batch, embed]
            # linear transform + residual
            context = self.transform(context) + read                  # [batch, embed]

        return context
