import jax
import jax.numpy as jnp
from jax import random

class MemTestDataset:
    """
    Generates a series of input timeseries and delayed versions as outputs.
    Delay is given in number of timesteps. Can be used to empirically measure the
    memory capacity of a system.
    """

    def __init__(self, sample_len, n_samples, n_delays=10, seed=None):
        """
        :param sample_len: Length of the time-series in time steps.
        :param n_samples: Number of samples to generate.
        :param n_delays: Number of steps to delay.
        :param seed: Seed for JAX PRNG.
        """
        self.sample_len = sample_len
        self.n_samples = n_samples
        self.n_delays = n_delays

        # Initialize PRNG key
        if seed is not None:
            self._key = random.PRNGKey(seed)
        else:
            self._key = random.PRNGKey(0)

    def __len__(self):
        return self.n_samples

    def __getitem__(self, idx):
        # Split off a subkey for this sample
        self._key, subkey = random.split(self._key)

        # inputs in [0,1), shift to [-0.5,0.5) then scale by 1.6
        inputs = (random.uniform(subkey, shape=(self.sample_len, 1)) - 0.5) * 1.6

        # Prepare an output array of shape (sample_len, n_delays)
        outputs = jnp.zeros((self.sample_len, self.n_delays))

        # For each delay k, prepend k+1 zeros then the inputs up to sample_len-k-1
        for k in range(self.n_delays):
            # slice inputs[:-k-1, 0] has shape (sample_len - k - 1,)
            shifted = jnp.concatenate(
                [jnp.zeros((k + 1,)), inputs[:-k - 1, 0]],
                axis=0
            )
            # write into column k
            outputs = outputs.at[:, k].set(shifted)

        return inputs, outputs

# Example usage:
if __name__ == "__main__":
    ds = MemTestDataset(sample_len=20, n_samples=5, n_delays=5, seed=42)
    print("Dataset length:", len(ds))
    x, y = ds[0]
    print("Inputs shape:", x.shape)      # (20,1)
    print("Outputs shape:", y.shape)     # (20,5)
    print("First few outputs:\n", y[:6])
