import jax
import jax.numpy as jnp
from flax import linen as nn
from ogb.utils.features import get_atom_feature_dims, get_bond_feature_dims 

full_atom_feature_dims = get_atom_feature_dims()
full_bond_feature_dims = get_bond_feature_dims()

class AtomEncoder(nn.Module):
    emb_dim: int
    
    def setup(self):
        self.atom_embedding_list = [nn.Embed(num_embeddings=dim, features=self.emb_dim) for dim in full_atom_feature_dims]

    def __call__(self, x):
        x_embedding = sum(self.atom_embedding_list[i](x[:, i]) for i in range(x.shape[1]))
        return x_embedding


class BondEncoder(nn.Module):
    emb_dim: int
    
    def setup(self):
        self.bond_embedding_list = [nn.Embed(num_embeddings=dim, features=self.emb_dim) for dim in full_bond_feature_dims]

    def __call__(self, edge_attr):
        bond_embedding = sum(self.bond_embedding_list[i](edge_attr[:, i]) for i in range(edge_attr.shape[1]))
        return bond_embedding


if __name__ == '__main__':
    from loader import GraphClassificationPygDataset
    dataset = GraphClassificationPygDataset(name='tox21')
    atom_enc = AtomEncoder(100)
    bond_enc = BondEncoder(100)

    # Initialize parameters
    rng = jax.random.PRNGKey(0)
    atom_params = atom_enc.init(rng, dataset[0].x)
    bond_params = bond_enc.init(rng, dataset[0].edge_attr)

    # Apply the models
    atom_embedding = atom_enc.apply(atom_params, dataset[0].x)
    bond_embedding = bond_enc.apply(bond_params, dataset[0].edge_attr)

    print(atom_embedding)
    print(bond_embedding)