# coding: utf-8

# ## This an example of using JAX equivalent of PyTorch's pack_padded_sequence

import jax
import jax.numpy as jnp
from jax import random
from jax.nn import pad
from typing import Tuple

# create input data
# input size = 4
# seq size = [3, 1]
# batch size = 2
input_data = [[[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]], 
               [[13, 14, 15, 16]]]

# lengths of sequences of input data
seq_lengths = jnp.array(list(map(len, input_data)))

# max length of sequences
max_length = seq_lengths.max()

# create sequence tensor for multi-sequences (4 is input size)
seq_tensor = jnp.zeros((len(input_data), max_length, 4))

# fill sequence tensor tensor with the first sequence
seq_tensor = seq_tensor.at[0, :3].set(jnp.array(input_data[0]))

# fill sequence tensor tensor with the second sequence
seq_tensor = seq_tensor.at[1, :1].set(jnp.array(input_data[1]))

# transpose batch dimension and sequence dimension before padding data
seq_tensor = jnp.transpose(seq_tensor, (1, 0, 2))

# pad sequence tensor for rnn/lstm/gru network
def pack_padded_sequence(seq_tensor: jnp.ndarray, seq_lengths: jnp.ndarray) -> Tuple[jnp.ndarray, jnp.ndarray]:
    batch_size = seq_tensor.shape[1]
    max_len = seq_tensor.shape[0]
    packed_seqs = []
    for i in range(batch_size):
        seq_len = seq_lengths[i]
        packed_seqs.append(seq_tensor[:seq_len, i])
    return jnp.stack(packed_seqs), (len(packed_seqs), max_len)

padded_input = pack_padded_sequence(seq_tensor, seq_lengths)

# Function to unpad sequences
def pad_packed_sequence(packed_input: jnp.ndarray, batch_first=False) -> Tuple[jnp.ndarray, jax.Array]:
    if batch_first:
        raise NotImplementedError("Batch first format not implemented")
    unpadded = pad(packed_input, ((0, 0), (0, seq_tensor.shape[0] - packed_input.shape[0]), (0, 0)), constant_values=0)
    return unpadded, unpadded.shape

unpadded, unpadded_shape = pad_packed_sequence(padded_input[0])

# Print out the results
print("Packed Input:", padded_input)
print("Unpadded Tensor:", unpadded)
print("Unpadded Shape:", unpadded_shape)