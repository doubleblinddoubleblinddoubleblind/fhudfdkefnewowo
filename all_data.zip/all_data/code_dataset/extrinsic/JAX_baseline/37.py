#!/usr/bin/env python
# coding: utf-8

# # Implementation of Conditional GANs
# Reference: https://arxiv.org/pdf/1411.1784.pdf
# https://github.com/Yangyangii/GAN-Tutorial/blob/master/MNIST/Conditional-GAN.ipynb
# In[ ]:


# Run the comment below only when using Google Colab
# !pip install flax jax jaxlib

# In[1]:


import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax
import torchvision.datasets as datasets
import torchvision.transforms as transforms
import numpy as np
import matplotlib.pyplot as plt
import os


# In[5]:

MODEL_NAME = "ConditionalGAN"
DEVICE = jax.devices('gpu')[0] if jax.local_devices() else jax.devices('cpu')[0]


# In[6]:


def to_onehot(x, num_classes=10):
    return jax.nn.one_hot(x, num_classes)


# In[7]:


def get_sample_image(G, n_noise=100):
    """
        save sample 100 images
    """
    img = np.zeros([280, 280])
    for j in range(10):
        c = jax.numpy.zeros([10, 10])
        c = c.at[:, j].set(1)
        z = jax.random.normal(jax.random.PRNGKey(jax.random.randint(jax.random.PRNGKey(0), (1,), 0, 1e6)), z.shape) for _ in range(10)
        y_hat = G(z, c).reshape(10, 28, 28)
        img[j * 28 : (j + 1) * 28] = np.concatenate(y_hat, axis=-1)
    return img


# In[8]:


class Discriminator(nn.Module):
    """
        Simple Discriminator w/ MLP
    """

    def setup(self):
        self.layer = nn.Sequential(
            nn.Dense(512),
            nn.leaky_relu,
            nn.Dense(256),
            nn.leaky_relu,
            nn.Dense(1),
            nn.sigmoid,
        )

    def __call__(self, x, c):
        x = x.reshape((x.shape[0], -1))
        c = c.reshape((c.shape[0], -1)).astype(jnp.float32)
        v = jnp.concatenate((x, c), axis=1)  # v: [input, label] concatenated vector
        return self.layer(v)


# In[9]:


class Generator(nn.Module):
    """
        Simple Generator w/ MLP
    """

    def setup(self):
        self.layer = nn.Sequential(
            nn.Dense(128),
            nn.leaky_relu,
            nn.Dense(256),
            nn.BatchNorm(),
            nn.leaky_relu,
            nn.Dense(512),
            nn.BatchNorm(),
            nn.leaky_relu,
            nn.Dense(1024),
            nn.BatchNorm(),
            nn.leaky_relu,
            nn.Dense(784),
            nn.tanh,
        )

    def __call__(self, x, c):
        x = x.reshape((x.shape[0], -1))
        c = c.reshape((c.shape[0], -1)).astype(jnp.float32)
        v = jnp.concatenate((x, c), axis=1)  # v: [input, label] concatenated vector
        y_ = self.layer(v)
        return y_.reshape((x.shape[0], 1, 28, 28))


# In[10]:


D = Discriminator()
G = Generator()


# In[11]:


transform = transforms.Compose(
    [transforms.ToTensor(), transforms.Normalize(mean=[0.5], std=[0.5])]
)


# In[12]:


mnist = datasets.MNIST(root="../data/", train=True, transform=transform, download=True)


# In[14]:


batch_size = 64
condition_size = 10


# In[15]:


data_loader = DataLoader(
    dataset=mnist, batch_size=batch_size, shuffle=True, drop_last=True
)


# In[16]:


criterion = optax.sigmoid_binary_cross_entropy
D_opt = optax.adam(learning_rate=0.0002, b1=0.5, b2=0.999)
G_opt = optax.adam(learning_rate=0.0002, b1=0.5, b2=0.999)


# In[17]:


max_epoch = 30  # need more than 100 epochs for training generator
step = 0
n_critic = 1  # for training more k steps about Discriminator
n_noise = 100


# In[18]:


D_labels = jnp.ones([batch_size, 1])  # Discriminator Label to real
D_fakes = jnp.zeros([batch_size, 1])  # Discriminator Label to fake


# In[19]:


if not os.path.exists("samples"):
    os.makedirs("samples")


# In[20]:


for epoch in range(max_epoch):
    for idx, (images, labels) in enumerate(data_loader):
        # Training Discriminator
        x = images
        y = labels.reshape(batch_size, 1)
        y = to_onehot(y)
        x_outputs = D(x, y)
        D_x_loss = criterion(D_labels, x_outputs)

        z = jax.random.normal(jax.random.PRNGKey(step), (batch_size, n_noise))
        z_outputs = D(G(z, y), y)
        D_z_loss = criterion(D_fakes, z_outputs)
        D_loss = D_x_loss + D_z_loss

        D_grads = jax.grad(D_loss)(D.params)
        D_state = D_opt.update(D_grads, D.state)
        
        if step % n_critic == 0:
            # Training Generator
            z = jax.random.normal(jax.random.PRNGKey(step), (batch_size, n_noise))
            z_outputs = D(G(z, y), y)
            G_loss = criterion(D_labels, z_outputs)

            G_grads = jax.grad(G_loss)(G.params)
            G_state = G_opt.update(G_grads, G.state)

        if step % 500 == 0:
            print(
                "Epoch: {}/{}, Step: {}, D Loss: {}, G Loss: {}".format(
                    epoch, max_epoch, step, D_loss, G_loss
                )
            )

        if step % 1000 == 0:
            G.eval()
            img = get_sample_image(G, n_noise)
            plt.imsave(
                "samples/{}_step{}.jpg".format(MODEL_NAME, str(step).zfill(3)),
                img,
                cmap="gray",
            )
            G.train()
        step += 1


# ## Sample

# In[22]:


# generation to image
G.eval()
plt.imshow(get_sample_image(G, n_noise), cmap="gray")