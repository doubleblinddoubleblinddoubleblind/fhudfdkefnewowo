import jax
import jax.numpy as jnp
from jax import grad
import pytest
import numpy as onp
import distrax
from jax import random
from jax.experimental import stax

# Test helper to extract a few central moments from samples.
def get_moments(x):
    m1 = jnp.mean(x, axis=0)
    x = x - m1
    xx = jnp.einsum('...i,...j->...ij', x, x)
    m2 = jnp.mean(xx, axis=0)
    return jnp.concatenate([m1.reshape(-1), m2.reshape(-1)])

def sample_gumbel_softmax(key, temperature, logits):
    logits = jax.nn.softmax(logits)
    gumbel_samples = -jnp.log(-jnp.log(random.uniform(key, shape=logits.shape)))
    y = jnp.argmax(logits + gumbel_samples / temperature, axis=-1)
    return y

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_gumbel_softmax(temperature, shape, dim):
    temperature = jnp.array(temperature)
    key = random.PRNGKey(0)
    logits = random.normal(key, shape + (dim,))

    def model(key):
        with distrax.MixtureSameFamily(distrax.Categorical(logits=logits), distrax.RelaxedOneHotCategorical(temperature=temperature)):
            return sample_gumbel_softmax(key, temperature, logits)

    # Generate random samples
    keys = random.split(key, 10000)
    value = jnp.array([model(k) for k in keys])
    expected_probe = get_moments(value)

    # Reparametrization
    reparam_model = lambda k: sample_gumbel_softmax(k, temperature, logits)
    value = jnp.array([reparam_model(k) for k in keys])
    actual_probe = get_moments(value)

    assert jnp.allclose(actual_probe, expected_probe, atol=0.05)

    for actual_m, expected_m in zip(actual_probe, expected_probe):
        expected_grad = grad(lambda log: expected_m)(logits)
        actual_grad = grad(lambda log: actual_m)(logits)
        assert jnp.allclose(actual_grad, expected_grad, atol=0.05)

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_init(temperature, shape, dim):
    temperature = jnp.array(temperature)
    key = random.PRNGKey(0)
    logits = random.normal(key, shape + (dim,))

    def model(key):
        return sample_gumbel_softmax(key, temperature, logits)

    # Initialization check (dummy implementation)
    # Replace with actual implementation of init check
    assert model(key) is not None