import jax
import jax.numpy as jnp
from jax import grad, jit, vmap

def dot(a, b):
    """Compute the dot product between pairs of vectors in 3D arrays.

    Args
    ----
    a: array of shape (B, M, D)
    b: array of shape (B, N, D)

    Returns
    -------
    c: array of shape (B, M, N)
        c[i,j,k] = dot(a[i,j], b[i,k])
    """
    return jnp.einsum('bmd,bnd->bmn', a, b)

class Attention:
    def __init__(self):
        pass

    def __call__(self, query, key, value, dimensions=None):
        ''' Input:
            query vectors q_1, ..., q_m
            key vectors k_1, .., k_n
            value vectors v_1, ..., v_n

            all of equal dimension and batch size.

            Compute the attention weights alpha_ij as follows:

            score_ij = (q_j)^T k_i
            alpha_ij = exp(score_ij) / sum_k exp(score_ik)

            Then apply the attention weights to v_1, ..., v_n as follows:

            output_ij = sum_k (alpha_ik * v_kj)
        '''
        bsk, n_keys, dim_key = key.shape
        bsq, n_queries, dim_query = query.shape
        bsv, n_values, dim_value = value.shape

        if not (bsq == bsk == bsv):
            raise ValueError(f'Mismatch: query batch size = {bsq}, key batch size = {bsk}, value batch size = {bsv} but should be equal')
        if not (dim_key == dim_query == dim_value):
            raise ValueError(f'Mismatch: query data dimension = {dim_query}, key data dimension = {dim_key}, value data dimension = {dim_value} but should be equal')
        
        s = dot(query, key)
        
        if dimensions is None:
            dimensions = jnp.ones((1, 1, 1)) * key.shape[1]
        
        scaling_factor = jnp.sqrt(1 / dimensions)
        alpha = jax.nn.softmax(s / scaling_factor, axis=2)
        
        output = dot(alpha, value)
        return output, alpha