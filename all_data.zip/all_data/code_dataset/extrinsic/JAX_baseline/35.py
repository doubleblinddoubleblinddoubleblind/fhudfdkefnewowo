import logging
import math
from flax import optim
import jax.numpy as jnp
from mlperf_logging.mllog import constants
from seq2seq.utils import log_event


def perhaps_convert_float(param, total):
    if isinstance(param, float):
        param = int(param * total)
    return param


class WarmupMultiStepLR:
    """
    Learning rate scheduler with exponential warmup and step decay.
    """
    def __init__(self, optimizer, iterations, warmup_steps=0,
                 remain_steps=1.0, decay_interval=None, decay_steps=4,
                 decay_factor=0.5, last_epoch=-1):
        """
        Constructor of WarmupMultiStepLR.
        """
        self.optimizer = optimizer
        self.base_lrs = jnp.array([group['lr'] for group in self.optimizer.param_groups])

        self.warmup_steps = perhaps_convert_float(warmup_steps, iterations)
        logging.info(f'Scheduler warmup steps: {self.warmup_steps}')

        self.remain_steps = perhaps_convert_float(remain_steps, iterations)
        logging.info(f'Scheduler remain steps: {self.remain_steps}')

        if decay_interval is None:
            decay_iterations = iterations - self.remain_steps
            self.decay_interval = max(decay_iterations // (decay_steps), 1)
        else:
            self.decay_interval = perhaps_convert_float(decay_interval, iterations)
        logging.info(f'Scheduler decay interval: {self.decay_interval}')

        self.decay_factor = decay_factor
        logging.info(f'Scheduler decay factor: {self.decay_factor}')

        self.decay_steps = decay_steps
        logging.info(f'Scheduler max decay steps: {self.decay_steps}')

        if self.warmup_steps > self.remain_steps:
            logging.warning('warmup_steps should not be larger than remain_steps, setting warmup_steps=remain_steps')
            self.warmup_steps = self.remain_steps

        log_event(key=constants.OPT_LR_ALT_DECAY_FUNC, value=True)
        log_event(key=constants.OPT_LR_ALT_WARMUP_FUNC, value=True)
        log_event(key=constants.OPT_LR_DECAY_INTERVAL, value=self.decay_interval)
        log_event(key=constants.OPT_LR_DECAY_FACTOR, value=self.decay_factor)
        log_event(key=constants.OPT_LR_DECAY_STEPS, value=self.decay_steps)
        log_event(key=constants.OPT_LR_REMAIN_STEPS, value=self.remain_steps)
        log_event(key=constants.OPT_LR_WARMUP_STEPS, value=self.warmup_steps)

        self.last_epoch = last_epoch

    def get_lr(self):
        if self.last_epoch <= self.warmup_steps:
            if self.warmup_steps != 0:
                warmup_factor = math.exp(math.log(0.01) / self.warmup_steps)
            else:
                warmup_factor = 1.0
            inv_decay = warmup_factor ** (self.warmup_steps - self.last_epoch)
            lr = self.base_lrs * inv_decay
        elif self.last_epoch >= self.remain_steps:
            decay_iter = self.last_epoch - self.remain_steps
            num_decay_steps = min(decay_iter // self.decay_interval + 1, self.decay_steps)
            lr = self.base_lrs * (self.decay_factor ** num_decay_steps)
        else:
            lr = self.base_lrs
        return lr