import jax
import jax.numpy as jnp
from flax import linen as nn
import requests
import math
import json

__all__ = [
    'VGG', 'vgg11', 'vgg11_bn', 'vgg13', 'vgg13_bn', 'vgg16', 'vgg16_bn',
    'vgg19_bn', 'vgg19',
]

model_urls = {
    'vgg11': 'https://download.pytorch.org/models/vgg11-bbd30ac9.pth',
    'vgg13': 'https://download.pytorch.org/models/vgg13-c768596a.pth',
    'vgg16': 'https://download.pytorch.org/models/vgg16-397923af.pth',
    'vgg19': 'https://download.pytorch.org/models/vgg19-dcbb9e9d.pth',
    'vgg11_bn': 'https://download.pytorch.org/models/vgg11_bn-6002323d.pth',
    'vgg13_bn': 'https://download.pytorch.org/models/vgg13_bn-abd245e5.pth',
    'vgg16_bn': 'https://download.pytorch.org/models/vgg16_bn-6c64b313.pth',
    'vgg19_bn': 'https://download.pytorch.org/models/vgg19_bn-c79401a0.pth',
}

class VGG(nn.Module):
    features: nn.Module
    num_classes: int = 1000

    @nn.compact
    def __call__(self, x):
        x = self.features(x)
        x = x.reshape(x.shape[0], -1)
        x = self.classifier(x)
        return x

    def classifier(self, x):
        x = nn.Dense(4096)(x)
        x = nn.relu(x)
        x = nn.Dropout(0.5)(x)
        x = nn.Dense(4096)(x)
        x = nn.relu(x)
        x = nn.Dropout(0.5)(x)
        x = nn.Dense(self.num_classes)(x)
        return x

def make_layers(cfg, batch_norm=False):
    layers = []
    in_channels = 3
    for v in cfg:
        if v == 'M':
            layers.append(nn.MaxPool2D(kernel_size=(2, 2), strides=(2, 2)))
        else:
            conv2d = nn.Conv(
                features=v, kernel_size=(3, 3), padding='SAME')
            layers.append(conv2d)
            if batch_norm:
                layers.append(nn.BatchNorm())
            layers.append(nn.relu)
            in_channels = v
    return nn.Sequential(*layers)

cfg = {
    'A': [64, 'M', 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'B': [64, 64, 'M', 128, 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'D': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M'],
    'E': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M'],
}

def load_pretrained_weights(model_name):
    url = model_urls.get(model_name)
    if url:
        response = requests.get(url)
        return jax.tree_util.tree_map(lambda x: x.numpy(), json.loads(response.text))
    return None

def vgg11(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['A']), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg11')
        return model, model_params
    return model

def vgg11_bn(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['A'], batch_norm=True), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg11_bn')
        return model, model_params
    return model

def vgg13(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['B']), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg13')
        return model, model_params
    return model

def vgg13_bn(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['B'], batch_norm=True), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg13_bn')
        return model, model_params
    return model

def vgg16(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['D']), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg16')
        return model, model_params
    return model

def vgg16_bn(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['D'], batch_norm=True), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg16_bn')
        return model, model_params
    return model

def vgg19(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['E']), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg19')
        return model, model_params
    return model

def vgg19_bn(pretrained=False, **kwargs):
    model = VGG(make_layers(cfg['E'], batch_norm=True), **kwargs)
    if pretrained:
        model_params = load_pretrained_weights('vgg19_bn')
        return model, model_params
    return model