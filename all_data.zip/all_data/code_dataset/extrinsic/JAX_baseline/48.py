#! /usr/bin/env python

import jax
import jax.numpy as jnp
import flax.linen as nn
import numpy as np
import os
import gzip
import _pickle as c_pickle
from train_utils import batchify_data, run_epoch, train_model, Flatten
from utils import get_MNIST_data
import onnx
from tqdm import tqdm

class ConvNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(32, (3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2))
        x = nn.Conv(64, (3, 3), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2))
        x = Flatten()(x)
        x = nn.Dense(128)(x)
        x = nn.Dropout(0.5)(x, deterministic=True)
        x = nn.Dense(10)(x)
        return x

def main():
    model = ConvNet()
    params = None

    if os.path.isfile("digits_params.pkl"):
        with open("digits_params.pkl", 'rb') as f:
            params = c_pickle.load(f)
    else:
        num_classes = 10
        X_train, y_train, X_test, y_test = get_MNIST_data()
        X_train = np.reshape(X_train, (X_train.shape[0], 1, 28, 28))
        X_test = np.reshape(X_test, (X_test.shape[0], 1, 28, 28))
        dev_split_index = int(9 * len(X_train) / 10)
        X_dev = X_train[dev_split_index:]
        y_dev = y_train[dev_split_index:]
        X_train = X_train[:dev_split_index]
        y_train = y_train[:dev_split_index]

        permutation = np.random.permutation(len(X_train))
        X_train = X_train[permutation]
        y_train = y_train[permutation]
        
        batch_size = 32
        train_batches = batchify_data(X_train, y_train, batch_size)
        dev_batches = batchify_data(X_dev, y_dev, batch_size)
        test_batches = batchify_data(X_test, y_test, batch_size)
        
        params = train_model(train_batches, dev_batches, model)
        loss, accuracy = run_epoch(test_batches, model.apply(params), None)
        print(f"Loss on test set: {loss} Accuracy on test set: {accuracy}")
        
        with open("digits_params.pkl", 'wb') as f:
            c_pickle.dump(params, f)

    print(model)
    onnxFilename = "digits.onnx"
    dummy_input = jnp.ones((32, 1, 28, 28))
    onnx_model = onnx.parse_model(onnx.helper.make_model(
        model, inputs=[onnx.helper.make_tensor_value_info('input', onnx.TensorProto.FLOAT, dummy_input.shape)],
        outputs=[onnx.helper.make_tensor_value_info('output', onnx.TensorProto.FLOAT, [32, 10])]))
    
    onnx.save(onnx_model, onnxFilename)

    onnx.checker.check_model(onnx_model)
    onnx.helper.printable_graph(onnx_model.graph)


if __name__ == '__main__':
    np.random.seed(12321)  # for reproducibility
    jax.random.PRNGKey(12321)
    main()