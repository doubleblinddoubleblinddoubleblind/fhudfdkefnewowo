import os
import random
import shutil
import tempfile

import numpy as np
import onnx
import optax
import jax
import jax.numpy as jnp
import flax.linen as nn
from flax import linen as nn
from flax.training import train_state
from torchvision import datasets, transforms
from jax import random as rand
from jax import grad, jit, value_and_grad
from jax import device_put
import tensorflow as tf

BATCH_SIZE = 64
EPOCHS = 5
SEED = 42
N = 100
LEARNING_RATE = 0.02

class JaxMNIST(nn.Module):
    n: int

    def setup(self):
        self.l1 = nn.Dense(self.n)
        self.l2 = nn.Dense(10)

    def __call__(self, x):
        x = self.l1(x)
        x = nn.relu(x)
        x = self.l2(x)
        return nn.log_softmax(x)

def create_train_state(rng, model):
    params = model.init(rng, jnp.ones((1, 28 * 28)))  # dummy input
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=optax.sgd(LEARNING_RATE))

def train_epoch(state, train_ds):
    for batch in train_ds:
        data, target = batch
        data = data.view(-1, 28 * 28)
        state, loss = train_step(state, data, target)
    return state

@jax.jit
def train_step(state, data, target):
    def loss_fn(params):
        logits = state.apply_fn({'params': params}, data)
        return -jnp.mean(jnp.sum(logits * one_hot(target), axis=1))

    grad_fn = value_and_grad(loss_fn)
    loss, grads = grad_fn(state.params)
    new_state = state.apply_gradients(grads=grads)
    return new_state, loss

def one_hot(labels):
    return jax.nn.one_hot(labels, num_classes=10)

def test_model(state, test_ds):
    loss_sum = 0.0
    num_correct = 0
    for data, target in test_ds:
        data = data.view(-1, 28 * 28)
        logits = state.apply_fn({'params': state.params}, data)
        loss_sum += -jnp.mean(jnp.sum(logits * one_hot(target), axis=1))
        predictions = jnp.argmax(logits, axis=1)
        num_correct += jnp.sum(predictions == target)

    mean_loss = loss_sum / len(test_ds)
    accuracy = num_correct / len(test_ds.dataset)
    return mean_loss, accuracy

def run():
    # Create temporary directory
    tmpDir = tempfile.mkdtemp()
    dataDir = os.path.join(tmpDir, "data")
    np.random.seed(SEED)
    random.seed(SEED)

    # Load MNIST dataset
    train_ds = datasets.MNIST(dataDir, train=True, download=True,
                               transform=transforms.Compose([
                                   transforms.ToTensor(),
                                   transforms.Normalize((0.1307,), (0.3081,))])),
    
    test_ds = datasets.MNIST(dataDir, train=False, download=True,
                              transform=transforms.Compose([
                                  transforms.ToTensor(),
                                  transforms.Normalize((0.1307,), (0.3081,))]))

    model = JaxMNIST(N)
    rng = rand.PRNGKey(SEED)
    state = create_train_state(rng, model)

    # Training
    for epoch in range(EPOCHS):
        state = train_epoch(state, train_ds)

    # Testing
    loss, accuracy = test_model(state, test_ds)

    print(f'Loss: {loss}, Accuracy: {accuracy}')
    shutil.rmtree(tmpDir)

if __name__ == "__main__":
    run()