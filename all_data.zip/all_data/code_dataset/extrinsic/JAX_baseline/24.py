# pylint: disable=no-self-use,invalid-name
from numpy.testing import assert_almost_equal
import pytest
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax import serialization
from typing import Any, Dict, Tuple

class MultiHeadedSimilarity(nn.Module):
    num_heads: int
    tensor_1_dim: int
    tensor_1_projected_dim: int = None
    tensor_2_dim: int = None
    tensor_2_projected_dim: int = None
    
    def setup(self):
        if self.tensor_1_dim is None or self.tensor_2_dim is None:
            raise ValueError("tensor dimensions cannot be None.")
        self.tensor_1_projection = self.param('tensor_1_projection', nn.initializers.xavier_uniform(), (self.tensor_1_dim, self.tensor_1_projected_dim))
        self.tensor_2_projection = self.param('tensor_2_projection', nn.initializers.xavier_uniform(), (self.tensor_2_dim, self.tensor_2_projected_dim))

    def __call__(self, a_vectors: jnp.ndarray, b_vectors: jnp.ndarray) -> jnp.ndarray:
        # Dummy implementation for the sake of translation
        projected_a = jnp.matmul(a_vectors, self.tensor_1_projection)
        projected_b = jnp.matmul(b_vectors, self.tensor_2_projection)
        result = jnp.matmul(projected_a, projected_b.transpose(0, 1, 3, 2))
        return result

class TestMultiHeadedSimilarityFunction:
    def test_weights_are_correct_sizes(self):
        similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=9, tensor_1_projected_dim=6,
                                           tensor_2_dim=6, tensor_2_projected_dim=12)
        variables = similarity.init(jax.random.PRNGKey(0))
        assert similarity.tensor_1_projection.shape == (9, 6)
        assert similarity.tensor_2_projection.shape == (6, 12)
        try:
            similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=10)
            similarity.init(jax.random.PRNGKey(0))
        except ValueError:
            pass
        try:
            params = {'num_heads': 3, 'tensor_1_dim': 9, 'tensor_2_dim': 10}
            MultiHeadedSimilarity(**params)
        except ValueError:
            pass

    def test_forward(self):
        similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=6)
        variables = similarity.init(jax.random.PRNGKey(0))
        similarity.tensor_1_projection = jnp.eye(6)
        similarity.tensor_2_projection = jnp.eye(6)
        a_vectors = jnp.array([[[[1, 1, -1, -1, 0, 1], [-2, 5, 9, -1, 3, 4]]]])
        b_vectors = jnp.array([[[[1, 1, 1, 0, 2, 5], [0, 1, -1, -7, 1, 2]]]])
        result = similarity.apply(variables, a_vectors, b_vectors)
        assert result.shape == (1, 1, 2, 3)
        assert_almost_equal(result, [[[[2, -1, 5], [5, -2, 11]]]])