import jax
import jax.numpy as jnp
import flax.linen as nn
import torchvision.models as models

from wildcat.pooling import WildcatPool2d, ClassWisePool

class ResNetWSL(nn.Module):
    dense: bool
    pooling: nn.Module

    @nn.compact
    def __call__(self, x):
        features = self.features()
        x = features(x)
        x = self.classifier(x)
        if not self.dense:
            x = self.pooling(x)
        return x

    def features(self):
        return nn.Sequential([
            models.resnet50.conv1,
            models.resnet50.bn1,
            models.resnet50.relu,
            models.resnet50.maxpool,
            models.resnet50.layer1,
            models.resnet50.layer2,
            models.resnet50.layer3,
            models.resnet50.layer4
        ])

    def classifier(self, x):
        num_features = models.resnet50.layer4[1].conv1.in_channels
        return nn.Conv(features=num_classes, kernel_size=(1, 1), use_bias=True)(x)

    def get_config_optim(self, lr, lrp):
        return [
            {'params': self.features().parameters(), 'lr': lr * lrp},
            {'params': self.classifier().parameters()},
            {'params': self.pooling.parameters()}
        ]

def resnet50_wildcat(num_classes, pretrained=True, kmax=1, kmin=None, alpha=1, num_maps=1):
    pooling = nn.Sequential([
        ClassWisePool(num_maps),
        WildcatPool2d(kmax, kmin, alpha)
    ])
    return ResNetWSL(dense=False, pooling=pooling)

def resnet101_wildcat(num_classes, pretrained=True, kmax=1, kmin=None, alpha=1, num_maps=1):
    pooling = nn.Sequential([
        ClassWisePool(num_maps),
        WildcatPool2d(kmax, kmin, alpha)
    ])
    return ResNetWSL(dense=False, pooling=pooling)