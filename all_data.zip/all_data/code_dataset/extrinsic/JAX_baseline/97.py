# Copyright (c) Facebook, Inc. and its affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

import jax
import jax.numpy as jnp
from flax.linen import Module, layer_norm
from flax import struct


class FusedLayerNorm(Module):
    normalized_shape: tuple
    eps: float = 1e-5
    elementwise_affine: bool = True

    def setup(self):
        if self.elementwise_affine:
            self.weight = self.param('weight', self.param_shape, jnp.ones)
            self.bias = self.param('bias', self.param_shape, jnp.zeros)
        else:
            self.weight = None
            self.bias = None

    def __call__(self, x):
        x = jnp.where(jnp.isnan(x), jnp.zeros_like(x), x)  # Handle NaNs
        output = layer_norm(x, self.normalized_shape, self.eps, 
                            self.weight, self.bias)
        return output


class Fp32LayerNorm(Module):
    normalized_shape: tuple
    eps: float = 1e-5
    elementwise_affine: bool = True

    def setup(self):
        if self.elementwise_affine:
            self.weight = self.param('weight', self.param_shape, jnp.ones)
            self.bias = self.param('bias', self.param_shape, jnp.zeros)

    def __call__(self, input):
        output = layer_norm(
            input.astype(jnp.float32),
            self.normalized_shape,
            self.eps,
            self.weight.astype(jnp.float32) if self.weight is not None else None,
            self.bias.astype(jnp.float32) if self.bias is not None else None,
        )
        return output.astype(input.dtype)


def LayerNorm(normalized_shape, eps=1e-5, elementwise_affine=True, export=False):
    return FusedLayerNorm(normalized_shape, eps, elementwise_affine) if export else Fp32LayerNorm(normalized_shape, eps, elementwise_affine)