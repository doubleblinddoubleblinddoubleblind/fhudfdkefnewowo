# Run this code to retrain the action recognition model
# delete secret_sauce/ann.pt before training.
import json
from secret_sauce.action_models import action_train, action_predict
import jax
import jax.numpy as jnp

training_data = []

with open('app/datasets/action_dataset.json') as data_file:
    data = json.load(data_file)

for line in data:
    # fetching training data
    training_data.append(line)

# Ensure fine-tuning can run smoothly
jax.device_put(training_data)
action_train(20000, training_data)  # training the model

# testing with a new input
#print("say whats tinkerhub")
print("intent:" + action_predict("hello"))