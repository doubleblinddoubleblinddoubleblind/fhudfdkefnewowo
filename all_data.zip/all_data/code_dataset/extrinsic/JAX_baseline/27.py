from __future__ import print_function, absolute_import

import os
import numpy as np
import json
import random
import math
import jax.numpy as jnp
import jax
from jax import random as jax_random
from jax import vmap

from pose.utils.osutils import *
from pose.utils.imutils import *
from pose.utils.transforms import *


class Mscoco:
    def __init__(self, is_train=True, **kwargs):
        self.is_train   = is_train  # training set or test set
        self.inp_res    = kwargs['inp_res']
        self.out_res    = kwargs['out_res']
        self.sigma      = kwargs['sigma']
        self.scale_factor = kwargs['scale_factor']
        self.rot_factor = kwargs['rot_factor']
        self.label_type = kwargs['label_type']
        self.year       = kwargs['year']
        self.jsonfile   = kwargs['anno_path']
        img_folder = kwargs['image_path']  # root image folders

        if is_train:
            self.img_folder = '{}/train{}'.format(img_folder, self.year)  # root image folders
        else:
            self.img_folder = '{}/val{}'.format(img_folder, self.year)  # root image folders

        # create train/val split
        with open(self.jsonfile) as anno_file:
            self.anno = json.load(anno_file)

        self.train, self.valid = [], []
        for idx, val in enumerate(self.anno):
            if val['isValidation'] == True:
                self.valid.append(idx)
            else:
                self.train.append(idx)
        self.mean, self.std = self._compute_mean()

    def _compute_mean(self):
        meanstd_file = './data/coco/mean.npz'
        if os.path.isfile(meanstd_file):
            meanstd = np.load(meanstd_file)
        else:
            print('==> compute mean')
            mean = jnp.zeros(3)
            std = jnp.zeros(3)
            cnt = 0
            for index in self.train:
                cnt += 1
                print('    {} | {}'.format(cnt, len(self.train)))
                a = self.anno[index]
                img_path = os.path.join(self.img_folder, a['img_paths'])
                img = load_image(img_path)  # CxHxW
                mean += jnp.mean(img.reshape(img.shape[0], -1), axis=1)
                std += jnp.std(img.reshape(img.shape[0], -1), axis=1)
            mean /= len(self.train)
            std /= len(self.train)
            meanstd = {
                'mean': mean,
                'std': std,
            }
            np.savez(meanstd_file, **meanstd)
        if self.is_train:
            print('    Mean: %.4f, %.4f, %.4f' % (meanstd['mean'][0], meanstd['mean'][1], meanstd['mean'][2]))
            print('    Std:  %.4f, %.4f, %.4f' % (meanstd['std'][0], meanstd['std'][1], meanstd['std'][2]))

        return meanstd['mean'], meanstd['std']

    def __getitem__(self, index):
        sf = self.scale_factor
        rf = self.rot_factor
        if self.is_train:
            a = self.anno[self.train[index]]
        else:
            a = self.anno[self.valid[index]]

        img_path = os.path.join(self.img_folder, a['img_paths'])
        pts = jnp.array(a['joint_self'])

        # c = jnp.array(a['objpos']) - 1
        c = jnp.array(a['objpos'])
        s = a['scale_provided']

        # Adjust center/scale slightly to avoid cropping limbs
        if c[0] != -1:
            c = c.at[1].set(c[1] + 15 * s)
            s *= 1.25

        # For single-person pose estimation with a centered/scaled figure
        nparts = pts.shape[0]
        img = load_image(img_path)  # CxHxW

        r = 0
        if self.is_train:
            s = s * jax_random.normal(jax_random.PRNGKey(random.randint(0, 10000)), (1,)).item() * sf + 1
            r = jax_random.normal(jax_random.PRNGKey(random.randint(0, 10000)), (1,)).item() * rf if random.random() <= 0.6 else 0

            # Flip
            if random.random() <= 0.5:
                img = fliplr(img)
                pts = shufflelr(pts, width=img.shape[2], dataset='mpii')
                c = c.at[0].set(img.shape[2] - c[0])

            # Color
            img[0, :, :] *= random.uniform(0.8, 1.2)
            img[1, :, :] *= random.uniform(0.8, 1.2)
            img[2, :, :] *= random.uniform(0.8, 1.2)

        # Prepare image and groundtruth map
        inp = crop(img, c, s, [self.inp_res, self.inp_res], rot=r)
        inp = color_normalize(inp, self.mean, self.std)

        # Generate ground truth
        tpts = pts
        target = jnp.zeros((nparts, self.out_res, self.out_res))
        target_weight = tpts[:, 2].reshape(nparts, 1)
        for i in range(nparts):
            if tpts[i, 2] > 0:  # COCO visible: 0-no label, 1-label + invisible, 2-label + visible
                tpts = tpts.at[i, 0:2].set(transform(tpts[i, 0:2] + 1, c, s, [self.out_res, self.out_res], rot=r))
                target = target.at[i], vis = draw_labelmap(target[i], tpts[i] - 1, self.sigma, type=self.label_type)
                target_weight = target_weight.at[i, 0].set(vis)

        # Meta info
        meta = {
            'index': index,
            'center': c,
            'scale': s,
            'pts': pts,
            'tpts': tpts,
            'img_path': img_path,
            'target_weight': target_weight
        }

        return inp, target, meta

    def __len__(self):
        if self.is_train:
            return len(self.train)
        else:
            return len(self.valid)


def coco(**kwargs):
    return Mscoco(**kwargs)

coco.njoints = 17  # ugly but works