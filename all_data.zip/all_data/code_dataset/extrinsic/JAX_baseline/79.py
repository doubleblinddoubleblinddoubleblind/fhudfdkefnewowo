#
# es_map.py, doom-net in JAX
#
import jax
import jax.numpy as jnp
from flax import linen as nn

class ESMap(nn.Module):
    screen_feature_num: int = 256
    
    def setup(self):
        self.conv1 = nn.Conv(features=64, kernel_size=(3, 3), strides=(2, 2))
        self.conv2 = nn.Conv(features=128, kernel_size=(3, 3), strides=(2, 2))
        self.conv3 = nn.Conv(features=256, kernel_size=(3, 3), strides=(2, 2))
        self.conv4 = nn.Conv(features=self.screen_feature_num, kernel_size=(1, 3), strides=(1, 1))
        
        layer1_size = 64
        self.action1 = nn.Dense(layer1_size)
        self.action2 = nn.Dense(self.button_num)

    def __call__(self, screen, variables):
        # features
        features = self.conv1(screen)
        features = nn.activation.relu(features)
        features = self.conv2(features)
        features = nn.activation.relu(features)
        features = self.conv3(features)
        features = nn.activation.relu(features)
        features = self.conv4(features)
        features = features.reshape(features.shape[0], -1)
        features = nn.activation.relu(features)

        # action
        action = nn.activation.relu(self.action1(features))
        action = jnp.concatenate([action, variables], axis=1)
        action = self.action2(action)

        action = jnp.argmax(action, axis=1, keepdims=True)

        return action