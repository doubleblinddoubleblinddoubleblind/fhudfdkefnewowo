import argparse
import gym
import numpy as np
from itertools import count
from collections import namedtuple

import jax
import jax.numpy as jnp
from jax import random, jit, grad, vmap
import haiku as hk
import optax

parser = argparse.ArgumentParser(description='JAX actor-critic example')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor (default: 0.99)')
parser.add_argument('--seed', type=int, default=543, metavar='N',
                    help='random seed (default: 1)')
parser.add_argument('--render', action='store_true',
                    help='render the environment')
parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                    help='interval between training status logs (default: 10)')
args = parser.parse_args()

env = gym.make('CartPole-v0')
env.seed(args.seed)
key = random.PRNGKey(args.seed)

SavedAction = namedtuple('SavedAction', ['action', 'value'])

def policy_network(x):
    x = hk.Linear(128)(x)
    x = jax.nn.relu(x)
    action_scores = hk.Linear(2)(x)
    state_values = hk.Linear(1)(x)
    return jax.nn.softmax(action_scores), state_values

model = hk.transform(policy_network)
optimizer = optax.adam(3e-2)

def select_action(state, model_params):
    state = jnp.array(state, dtype=jnp.float32).reshape(1, -1)
    probs, state_value = model.apply(model_params, state)
    action = random.choice(key, jnp.arange(2), shape=(1,), p=probs)
    return action, state_value

def finish_episode(model_params, saved_actions, rewards):
    R = 0
    value_loss = 0
    rewards_list = []
    for r in rewards[::-1]:
        R = r + args.gamma * R
        rewards_list.insert(0, R)
    rewards_array = jnp.array(rewards_list, dtype=jnp.float32)
    rewards_array = (rewards_array - rewards_array.mean()) / (rewards_array.std() + np.finfo(np.float32).eps)

    for (action, value), r in zip(saved_actions, rewards_array):
        reward = r - value[0, 0]
        value_loss += jax.nn.smooth_l1_loss(value, jnp.array([[r]]))
    
    return value_loss, model_params

running_reward = 10
model_params = model.init(key, jnp.ones([1, 4]))
optimizer_state = optimizer.init(model_params)
saved_actions = []
rewards = []

for i_episode in count(1):
    state = env.reset()
    for t in range(10000):
        action, state_value = select_action(state, model_params)
        state, reward, done, _ = env.step(action[0])
        if args.render:
            env.render()
        rewards.append(reward)
        saved_actions.append(SavedAction(action, state_value))
        if done:
            break
    
    running_reward = running_reward * 0.99 + t * 0.01

    value_loss, model_params = finish_episode(model_params, saved_actions, rewards)

    gradients = grad(lambda params: finish_episode(params)[0])(model_params)
    updates, optimizer_state = optimizer.update(gradients, optimizer_state)
    model_params = optax.apply_updates(model_params, updates)

    del rewards[:]
    del saved_actions[:]

    if i_episode % args.log_interval == 0:
        print('Episode {}\tLast length: {:5d}\tAverage length: {:.2f}'.format(
            i_episode, t, running_reward))
    
    if running_reward > env.spec.reward_threshold:
        print("Solved! Running reward is now {} and "
              "the last episode runs to {} time steps!".format(running_reward, t))
        break