"""Hierarchical RNN implementation"""
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax import optim
import jax.random as random

# TODO
# Init. GRU with orthogonal initializer.
class EncoderRNN(nn.Module):
    """Encoder RNN Building"""
    input_size: int
    hidden_size: int
    n_layers: int
    dropout: float = 0.0

    def setup(self):
        self.embedding = nn.Embed(self.input_size, self.hidden_size)
        self.gru = nn.GRUCell(name='gru')

    def init_hidden(self):
        return jnp.zeros((self.n_layers, self.hidden_size))

    def init_weight(self, rng):
        initrange = 0.1
        return random.uniform(rng, (self.input_size, self.hidden_size), minval=-initrange, maxval=initrange)

    def __call__(self, input, hidden):
        embedded = self.embedding(input).reshape(1, 1, -1)
        state = hidden
        output, state = self.gru(state, embedded)
        return output, state


class ContextRNN(nn.Module):
    """Context RNN Building"""
    encoder_hidden_size: int
    hidden_size: int
    n_layers: int
    dropout: float = 0.0

    def setup(self):
        self.gru = nn.GRUCell(name='gru')

    def init_hidden(self):
        return jnp.zeros((self.n_layers, self.hidden_size))

    def __call__(self, input, hidden):
        input = input.reshape(1, 1, -1)
        state = hidden
        output, state = self.gru(state, input)
        return output, state


class DecoderRNN(nn.Module):
    """Decoder RNN Building"""
    context_output_size: int
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float = 0.0

    def setup(self):
        self.embedding = nn.Embed(self.output_size, self.hidden_size)
        self.out = nn.Dense(self.output_size, kernel_init=nn.initializers.xavier_uniform())
        self.gru = nn.GRUCell(name='gru')

    def init_hidden(self):
        return jnp.zeros((self.n_layers, self.hidden_size))

    def __call__(self, context_output, input, hidden):
        context_output = context_output.reshape(1, 1, -1)
        embedded = self.embedding(input)
        input_cat = jnp.concatenate([context_output, embedded], axis=2)
        state = hidden
        output, state = self.gru(state, input_cat)
        output = jax.nn.log_softmax(self.out(output))
        return output, state


class DecoderRNNSeq(nn.Module):
    """Seq2seq's Attention Decoder RNN Building"""
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float = 0.0
    max_length: int = 10

    def setup(self):
        self.embedding = nn.Embed(self.output_size, self.hidden_size)
        self.attn = nn.Dense(self.max_length)
        self.attn_combine = nn.Dense(self.hidden_size)
        self.out = nn.Dense(self.output_size)
        self.gru = nn.GRUCell(name='gru')

    def init_hidden(self):
        return jnp.zeros((self.n_layers, self.hidden_size))

    def __call__(self, input, hidden, encoder_outputs):
        embedded = self.embedding(input).reshape(1, 1, -1)

        attn_weights = jax.nn.softmax(self.attn(jnp.concatenate((embedded[0], hidden[0]), axis=1)))
        attn_applied = jnp.matmul(attn_weights[None, :, None], encoder_outputs[None, :, :])

        output = jnp.concatenate((embedded[0], attn_applied[0]), axis=1)
        output = self.attn_combine(output)[None, :]

        state = hidden
        output, state = self.gru(state, embedded)
        output = jax.nn.log_softmax(self.out(output[0]))
        return output, state, attn_weights