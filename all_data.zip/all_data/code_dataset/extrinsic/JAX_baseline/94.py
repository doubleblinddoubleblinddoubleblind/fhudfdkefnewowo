import jax
import jax.numpy as jnp
import flax.linen as nn
from flax.training import train_state
import numpy as np

class GRUCell(nn.Module):
    hidden_size: int

    def setup(self):
        self.Wz = self.param('Wz', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))
        self.Uz = self.param('Uz', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))
        self.Wr = self.param('Wr', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))
        self.Ur = self.param('Ur', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))
        self.Wh = self.param('Wh', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))
        self.Uh = self.param('Uh', nn.initializers.xavier_uniform(), (self.hidden_size, self.hidden_size))

    def __call__(self, x, h):
        z = jax.nn.sigmoid(jnp.dot(x, self.Wz) + jnp.dot(h, self.Uz))
        r = jax.nn.sigmoid(jnp.dot(x, self.Wr) + jnp.dot(h, self.Ur))
        h_tilde = jax.nn.tanh(jnp.dot(x, self.Wh) + jnp.dot(r * h, self.Uh))
        h_new = (1 - z) * h + z * h_tilde
        return h_new

class Encoder(nn.Module):
    input_size: int
    embedding_size: int
    hidden_size: int
    n_layers: int = 1
    bidirec: bool = False

    def setup(self):
        self.embedding = self.param('embedding', nn.initializers.xavier_uniform(), (self.input_size, self.embedding_size))
        if self.bidirec:
            self.n_direction = 2
            self.gru_cells = [GRUCell(self.hidden_size) for _ in range(self.n_layers * 2)]
        else:
            self.n_direction = 1
            self.gru_cells = [GRUCell(self.hidden_size) for _ in range(self.n_layers)]

    def init_hidden(self, batch_size):
        return jnp.zeros((self.n_layers * self.n_direction, batch_size, self.hidden_size))

    def __call__(self, inputs, input_lengths):
        hidden = self.init_hidden(inputs.shape[0])

        embedded = jnp.dot(inputs, self.embedding)
        outputs = []

        for t in range(embedded.shape[1]):
            h_t = hidden
            for layer in range(self.n_layers):
                for direction in range(self.n_direction):
                    h_t = self.gru_cells[layer + direction * self.n_layers](embedded[:, t, :], h_t)
                outputs.append(h_t)

        output_lengths = jnp.array(input_lengths)
        outputs_padded = self.pad_sequences(outputs, output_lengths)
        
        if self.n_layers > 1:
            if self.n_direction == 2:
                hidden = hidden[-2:]
            else:
                hidden = hidden[-1]

        return outputs_padded, jnp.concatenate(hidden, axis=1).reshape(-1, 1, hidden.shape[-1])

    def pad_sequences(self, outputs, lengths):
        max_len = max(lengths)
        padded_outputs = jnp.zeros((len(lengths), max_len, self.hidden_size))
        for i, output in enumerate(outputs):
            padded_outputs = padded_outputs.at[i, : output.shape[0], :].set(output)
        return padded_outputs