import jax
import jax.numpy as jnp
import flax.linen as nn
import optax
from flax import struct
from jax import random
from torchvision import datasets, transforms
import numpy as np
import argparse

# 定义网络结构
class LeNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(6, (5, 5), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        
        x = nn.Conv(16, (5, 5))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))

        x = x.reshape((x.shape[0], -1))  # flatten
        x = nn.Dense(120)(x)
        x = nn.relu(x)
        x = nn.Dense(84)(x)
        x = nn.relu(x)
        x = nn.Dense(10)(x)
        return x

parser = argparse.ArgumentParser()
parser.add_argument('--outf', default='.', help='folder to output images and model checkpoints')  # 模型保存路径
parser.add_argument('--net', default='.', help="path to netG (to continue training)")  # 模型加载路径
opt = parser.parse_args()

# 超参数设置
EPOCH = 8   # 遍历数据集次数
BATCH_SIZE = 64  # 批处理尺寸(batch_size)
LR = 0.001  # 学习率

# 定义数据预处理方式
transform = transforms.ToTensor()

# 定义训练数据集
trainset = datasets.MNIST(
    root='../mnist/',
    train=True,
    transform=transform,
    download=False)

trainloader = torch.utils.data.DataLoader(
    trainset,
    batch_size=BATCH_SIZE,
    shuffle=True,
)

# 定义测试数据集
testset = datasets.MNIST(
    root='../mnist/',
    train=False,
    transform=transform,
    download=False)

testloader = torch.utils.data.DataLoader(
    testset,
    batch_size=BATCH_SIZE,
    shuffle=False,
)

# 创建JAX的随机种子
rng = random.PRNGKey(0)

# 初始化模型和优化器
model = LeNet()
params = model.init(rng, jnp.ones((1, 1, 28, 28)))  # Initial parameter shape

optimizer = optax.sgd(learning_rate=LR, momentum=0.9)
opt_state = optimizer.init(params)

# 损失函数
def loss_fn(params, inputs, labels):
    logits = model.apply(params, inputs)
    return jnp.mean(optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(labels, 10)))

# 训练
if __name__ == "__main__":
    for epoch in range(EPOCH):
        sum_loss = 0.0
        for i, (inputs, labels) in enumerate(trainloader):
            inputs = jnp.array(np.array(inputs))  # Convert to JAX array
            labels = jnp.array(labels)

            # 执行一个训练步骤
            grads = jax.grad(loss_fn)(params, inputs, labels)
            updates, opt_state = optimizer.update(grads, opt_state)
            params = optax.apply_updates(params, updates)

            loss = loss_fn(params, inputs, labels)
            sum_loss += loss
            if i % 100 == 99:
                print('[%d, %d] loss: %.03f' % (epoch + 1, i + 1, sum_loss / 100))
                sum_loss = 0.0

        # 每跑完一次epoch测试一下准确率
        correct = 0
        total = 0
        for inputs, labels in testloader:
            inputs = jnp.array(np.array(inputs))  # Convert to JAX array
            labels = jnp.array(labels)
            outputs = model.apply(params, inputs)
            predicted = jnp.argmax(outputs, axis=1)
            total += labels.shape[0]
            correct += jnp.sum(predicted == labels)

        print('第%d个epoch的识别准确率为：%d%%' % (epoch + 1, (100 * correct) // total))