import time
import numpy as np
import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
import tensorflow_datasets as tfds

# Precomputed characteristics of the MNIST dataset
MNIST_MEAN = 0.1307
MNIST_STD = 0.3081

class SampleConvNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.relu(nn.Conv(16, (8, 8), strides=(2, 2), padding='SAME')(x))  # -> [B, 16, 14, 14]
        x = nn.max_pool(x, (2, 2), strides=(1, 1))  # -> [B, 16, 13, 13]
        x = nn.relu(nn.Conv(32, (4, 4), strides=(2, 2))(x))  # -> [B, 32, 5, 5]
        x = nn.max_pool(x, (2, 2), strides=(1, 1))  # -> [B, 32, 4, 4]
        x = x.reshape((x.shape[0], -1))  # -> [B, 512]
        x = nn.relu(nn.Dense(32)(x))  # -> [B, 32]
        x = nn.Dense(10)(x)  # -> [B, 10]
        return x

def cross_entropy_loss(logits, labels):
    return -jnp.mean(jax.nn.log_softmax(logits) * jax.nn.one_hot(labels, num_classes=10))

def train_step(optimizer, model, batch):
    data, labels = batch
    def loss_fn(params):
        logits = model.apply(params, data)
        return cross_entropy_loss(logits, labels)
    
    grads = jax.grad(loss_fn)(optimizer.target)
    optimizer = optimizer.apply_gradient(grads)
    return optimizer

def test_step(model, data, labels):
    logits = model.apply({}, data)
    loss = cross_entropy_loss(logits, labels)
    return loss

def main():
    # Training settings
    batch_size = 250
    epochs = 15
    learning_rate = 0.25
    
    # Load MNIST data
    data = tfds.as_numpy(tfds.load('mnist', batch_size=-1))
    train_image = (data['train']['image'].transpose(0, 3, 1, 2) / 255 - MNIST_MEAN) / MNIST_STD
    test_image = (data['test']['image'].transpose(0, 3, 1, 2) / 255 - MNIST_MEAN) / MNIST_STD
    train_label = data['train']['label']
    test_label = data['test']['label']
    
    # Initialize model
    model = SampleConvNet()
    params = model.init(jax.random.PRNGKey(0), jnp.ones((1, 1, 28, 28)))
    optimizer = optax.sgd(learning_rate).init(params)

    # Training loop
    train_time = []
    num_batches = train_image.shape[0] // batch_size
    for epoch in range(epochs):
        start_time = time.time()
        permutation = np.random.permutation(train_image.shape[0])
        for i in range(num_batches):
            idx = permutation[i * batch_size:(i + 1) * batch_size]
            batch = (train_image[idx], train_label[idx])
            optimizer = train_step(optimizer, model, batch)
        epoch_time = time.time() - start_time
        train_time.append(epoch_time)
        print(f'Train Epoch: {epoch} \t took {epoch_time} seconds')

    # Testing
    test_loss = test_step(model, test_image, test_label)
    print(f'Test loss: {test_loss}')

if __name__ == "__main__":
    main()