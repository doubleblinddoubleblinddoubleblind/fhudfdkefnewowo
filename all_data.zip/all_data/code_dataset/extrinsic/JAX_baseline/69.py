from __future__ import print_function
import jax.numpy as jnp
import os
import random
import h5py
from jax import random as jax_random
from pathlib import Path

def default_loader(path):
    with h5py.File(path, 'r') as f:
        imgA = f['input'][:]
        imgB = f['output'][:]
    return imgA / 255.0, imgB / 255.0

class Radars:
    def __init__(self, dataPath='/ldata/radar_20d_2000/', length=-1):
        self.image_list = sorted(Path(dataPath).iterdir())
        self.image_list = self.image_list[:length] if length > 0 else self.image_list
        self.dataPath = dataPath

    def __getitem__(self, index):
        path = str(self.image_list[index])
        imgA, imgB = default_loader(path)  # 512x256
        return imgA, imgB

    def __len__(self):
        return len(self.image_list)