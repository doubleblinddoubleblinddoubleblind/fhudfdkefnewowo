import jax
import jax.numpy as jnp
from flax import linen as nn

class ConvNet(nn.Module):
    in_channels: int
    conv_depth: int = 9
    n_filters: int = 64

    def setup(self):
        self.conv_block = ConvolutionalBlock(self.in_channels, self.n_filters)
        self.residual_blocks = [ResidualBlock(self.n_filters, self.n_filters) for _ in range(self.conv_depth)]
        self.policy_head = PolicyHead(self.n_filters)
        self.value_head = ValueHead(self.n_filters, hidden_units=self.n_filters)

    def __call__(self, x):
        x = self.conv_block(x)
        for block in self.residual_blocks:
            x = block(x)
        x_policy = self.policy_head(x)
        x_value = self.value_head(x)
        return x_policy, x_value


class ConvolutionalBlock(nn.Module):
    in_channels: int
    n_filters: int = 256

    def setup(self):
        self.conv = nn.Conv(len(self.n_filters), (3, 3), padding='same', kernel_init=nn.initializers.xavier_uniform())
        self.batchnorm = nn.BatchNorm()
        self.relu = nn.relu

    def __call__(self, x):
        x = self.conv(x)
        x = self.batchnorm(x)
        return self.relu(x)


class ResidualBlock(nn.Module):
    in_channels: int
    n_filters: int

    def setup(self):
        self.conv1 = nn.Conv(self.n_filters, (3, 3), padding='same', kernel_init=nn.initializers.xavier_uniform())
        self.batchnorm1 = nn.BatchNorm()
        self.conv2 = nn.Conv(self.n_filters, (3, 3), padding='same', kernel_init=nn.initializers.xavier_uniform())
        self.batchnorm2 = nn.BatchNorm()
        self.relu1 = nn.relu
        self.relu2 = nn.relu

    def __call__(self, x):
        residual1 = self.conv1(x)
        residual2 = self.batchnorm1(residual1)
        residual3 = self.relu1(residual2)
        residual4 = self.conv2(residual3)
        residual5 = self.batchnorm2(residual4)
        x = x + residual5
        return self.relu2(x)


class PolicyHead(nn.Module):
    in_channels: int

    def setup(self):
        self.conv = nn.Conv(2, (1, 1), kernel_init=nn.initializers.xavier_uniform())
        self.batchnorm = nn.BatchNorm()
        self.relu = nn.relu
        self.fc = nn.Dense(9 * 9 + 1, kernel_init=nn.initializers.xavier_uniform())

    def __call__(self, x):
        x = self.conv(x)
        x = self.batchnorm(x)
        x = self.relu(x)
        x = x.reshape(-1, 2 * 9 * 9)
        return self.fc(x)


class ValueHead(nn.Module):
    in_channels: int
    hidden_units: int = 256

    def setup(self):
        self.conv = nn.Conv(1, (1, 1), kernel_init=nn.initializers.xavier_uniform())
        self.batchnorm = nn.BatchNorm()
        self.relu1 = nn.relu
        self.fc1 = nn.Dense(self.hidden_units, kernel_init=nn.initializers.xavier_uniform())
        self.relu2 = nn.relu
        self.fc2 = nn.Dense(1, kernel_init=nn.initializers.xavier_uniform())
        self.tanh = jax.nn.tanh

    def __call__(self, x):
        x = self.conv(x)
        x = self.batchnorm(x)
        x = self.relu1(x)
        x = x.reshape(-1, 9 * 9)
        x = self.fc1(x)
        x = self.relu2(x)
        x = self.fc2(x)
        return self.tanh(x)