import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.traverse_util import flatten_dict, unflatten_dict
import numpy as np
from collections import namedtuple

class Vision_M(nn.Module):
    @nn.compact
    def __call__(self, x):
        out = nn.Conv(features=32, kernel_size=(8, 8), strides=(4, 4))(x)
        out = nn.Conv(features=64, kernel_size=(4, 4), strides=(2, 2))(out)
        out = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1))(out)
        return out


class Language_M(nn.Module):
    vocab_size: int = 10
    embed_dim: int = 128
    hidden_size: int = 128

    def setup(self):
        self.embeddings = nn.Embed(self.vocab_size, self.embed_dim)
        self.lstm = nn.LSTMCell(name="lstm")

    def __call__(self, x):
        embedded_input = self.embeddings(x)
        out, (h, c) = self.lstm(embedded_input)
        return h

    def LP(self, x):
        return jnp.dot(x, self.embeddings.params['embedding'].T)
    

class Mixing_M(nn.Module):
    def __call__(self, visual_encoded, instruction_encoded):
        batch_size = visual_encoded.shape[0]
        visual_flatten = visual_encoded.reshape(batch_size, -1)
        instruction_flatten = instruction_encoded.reshape(batch_size, -1)
                
        mixed = jnp.concatenate([visual_flatten, instruction_flatten], axis=1)
        return mixed
    

class Action_M(nn.Module):
    batch_size: int = 1
    hidden_size: int = 256

    def setup(self):
        self.lstm_1 = nn.LSTMCell(name="lstm_1")
        self.lstm_2 = nn.LSTMCell(name="lstm_2")
        
        self.hidden_1 = (jax.random.normal(jax.random.PRNGKey(0), (self.batch_size, self.hidden_size)),
                         jax.random.normal(jax.random.PRNGKey(1), (self.batch_size, self.hidden_size))) 
        
        self.hidden_2 = (jax.random.normal(jax.random.PRNGKey(2), (self.batch_size, self.hidden_size)),
                         jax.random.normal(jax.random.PRNGKey(3), (self.batch_size, self.hidden_size))) 

    def __call__(self, x):
        h1, c1 = self.lstm_1(x, self.hidden_1)
        h2, c2 = self.lstm_2(h1, self.hidden_2)
        
        self.hidden_1 = (h1, c1)
        self.hidden_2 = (h2, c2)
        
        return h2
    
    
SavedAction = namedtuple('SavedAction', ['action', 'value'])

class Policy(nn.Module):
    action_space: int

    def setup(self):
        self.affine1 = nn.Dense(features=128)
        self.action_head = nn.Dense(features=self.action_space)
        self.value_head = nn.Dense(features=1)
        
        self.saved_actions = []
        self.rewards = []

    def __call__(self, x):
        x = nn.relu(self.affine1(x))
        action_scores = self.action_head(x)
        state_values = self.value_head(x)
        
        return action_scores, state_values
    
    def tAE(self, action_logits):
        bias = jnp.expand_dims(self.action_head.bias, axis=0).repeat(action_logits.shape[0], axis=0)
        output = action_logits - bias
        output = jnp.dot(output, self.action_head.kernel.T)
        return output
    

class temporal_AutoEncoder(nn.Module):
    policy_network: Policy
    vision_module: Vision_M

    def setup(self):
        self.linear_1 = nn.Dense(features=64 * 7 * 7)
        self.deconv = nn.Sequential(
            nn.ConvTranspose(features=64, kernel_size=(3, 3), strides=(1, 1)), 
            nn.ConvTranspose(features=32, kernel_size=(4, 4), strides=(2, 2)),
            nn.ConvTranspose(features=3, kernel_size=(8, 8), strides=(4, 4))
        )

    def __call__(self, visual_input, logit_action):
        visual_encoded = self.vision_module(visual_input)
        
        action_out = self.policy_network.tAE(logit_action)  # [1, 128]
        action_out = self.linear_1(action_out)
        action_out = action_out.reshape(action_out.shape[0], 64, 7, 7)
        
        combine = action_out * visual_encoded
        
        out = self.deconv(combine)
        return out        
    
    
class Language_Prediction(nn.Module):
    language_module: Language_M

    def setup(self):
        self.vision_transform = nn.Sequential(
            nn.Dense(features=128),
            nn.relu
        )

    def __call__(self, vision_encoded):
        vision_encoded_flatten = vision_encoded.reshape(vision_encoded.shape[0], -1)
        vision_out = self.vision_transform(vision_encoded_flatten)
        
        language_predict = self.language_module.LP(vision_out)
        
        return language_predict
    
    
class RewardPredictor(nn.Module):
    vision_module: Vision_M
    language_module: Language_M
    mixing_module: Mixing_M

    def __call__(self, x):
        batch_visual = []
        batch_instruction = []
        
        for batch in x:
            visual = np.concatenate([b.visual for b in batch], axis=0)
            instruction = np.concatenate([b.instruction for b in batch], axis=0)
            
            batch_visual.append(visual)
            batch_instruction.append(instruction)
        
        batch_visual_encoded = self.vision_module(jnp.concatenate(batch_visual, axis=0))
        batch_instruction_encoded = self.language_module(jnp.concatenate(batch_instruction, axis=0))
        
        batch_mixed = self.mixing_module(batch_visual_encoded, batch_instruction_encoded)
        batch_mixed = batch_mixed.reshape(len(batch_visual), -1)
        
        out = jnp.dot(batch_mixed, self.linear.kernel) + self.linear.bias
        return out