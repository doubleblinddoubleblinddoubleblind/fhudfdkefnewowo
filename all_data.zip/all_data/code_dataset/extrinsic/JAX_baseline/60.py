import os
import glob
import jax
import jax.numpy as jnp
from jax import random, value_and_grad
from flax import linen as nn
from flax.training import train_state
from torchvision import models, transforms
import cv2
from PIL import Image
import numpy as np

from myimagefolder import MyImageFolder
from mymodel import GradientNet
from myargs import Args


def loadimg(path):
    im = Image.open(path).convert('RGB')
    im = transforms.ToTensor()(im).numpy()
    x = jnp.zeros((1, 3, 416, 1024))
    x = x.at[0, :, :, :].set(im[:, 0:416, 0:1024])
    return x


gpu_num = 2
gradient = False
type2 = 'rgb' if not gradient else 'gd'

res_root = './results/images/'
scenes = glob.glob('/home/lwp/workspace/sintel2/clean/*')
cnt_albedo = 0
cnt_shading = 0

for scene in scenes:
    scene = scene.split('/')[-1]
    res_dir = os.path.join(res_root, scene)
    if not os.path.exists(res_dir):
        os.makedirs(res_dir)
    for type_ in ['albedo', 'shading']:
        root = '/media/lwp/xavier/graduation_results/showcase_model/{}/{}/{}/'.format(scene, type_, type2)
        print(root + 'snapshot-239.pth.tar')
        if not os.path.exists(root + 'snapshot-239.pth.tar'):
            continue
        snapshot = jax.device_put(jnp.load(root + 'snapshot-239.pth.tar', allow_pickle=True))
        state_dict = snapshot['state_dict']
        args = snapshot['args']
        
        densenet = models.__dict__[args.arch](pretrained=True)

        net = None
        num = 40 if scene == 'market_6' else 50
        for ind in range(1, num + 1):
            if net is not None:
                del net

            net = GradientNet(densenet=densenet, growth_rate=32, 
                              transition_scale=2, pretrained_scale=4,
                              gradient=gradient)

            net.apply({'params': state_dict})

            frame = 'frame_%04d.png' % (ind)
            print('/home/lwp/workspace/sintel2/clean/{}/{}'.format(scene, frame))
            im = loadimg('/home/lwp/workspace/sintel2/clean/{}/{}'.format(scene, frame))
            _, mergeRGB = net(im, go_through_merge=True)
            merged = mergeRGB[5]
            merged = merged[0]
            merged = np.array(merged)
            print(merged.shape)
            merged = merged.transpose(1, 2, 0)
            print(merged.shape)
            dx = merged[:, :, 0:3]
            res_frame = 'albedo_%04d.png' % (ind) if type_ == 'albedo' else 'shading_%04d.png' % (ind)
            cv2.imwrite(os.path.join(res_dir, res_frame), (dx[:, :, ::-1] * 255).astype(np.uint8))