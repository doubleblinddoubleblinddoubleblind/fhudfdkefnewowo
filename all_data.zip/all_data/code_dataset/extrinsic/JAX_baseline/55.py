"""
This tutorial script runs a simple ResNet to classify the CIFAR-10 dataset using MeTaL.
The purpose of this particular tutorial is to demonstrate how a standard machine learning
task can be run using MeTaL utilities.

Running this script with settings in run_CIFAR_Tutorial.sh should give performance on the
order of 92-93% dev set accuracy, which is comparable to the performance numbers presented in
the pytorch-cifar repo (https://github.com/kuangliu/pytorch-cifar).  Note that as in the
pytorch-cifar repo, the dev and test set are the same.  This is not generally the case!

Running this script with default parameters should recover ~88% accuracy after 10 epochs.
"""

import argparse
import numpy as np
import jax
import jax.numpy as jnp
import flax.linen as nn
import flax.training.train_state as train_state
from flax import serialization
from flax.training import checkpoints
import optax
from torchvision import transforms
from torchvision.datasets import CIFAR10
import jax.random as random
from jax import lax

from metal.contrib.modules.resnet_cifar10 import ResNet18
from metal import EndModel
from metal.utils import convert_labels

# Parsing command line arguments
parser = argparse.ArgumentParser(description="Training CIFAR 10")

parser.add_argument(
    "--epochs", default=10, type=int, help="number of total epochs to run"
)

parser.add_argument(
    "-b", "--batch-size", default=128, type=int, help="mini-batch size (default: 10)"
)

parser.add_argument(
    "--lr", "--learning-rate", default=0.001, type=float, help="initial learning rate"
)

parser.add_argument("--weight-decay", "--wd", default=1e-4, type=float, help="weight decay (default: 1e-4)")

class MetalCIFARDataset:
    def __init__(self, dataset):
        self.dataset = dataset

    def __getitem__(self, index):
        x, y = self.dataset[index]
        y += 1
        return x, y

    def __len__(self):
        return len(self.dataset)

def preprocess_images(x):
    x = jnp.array(x) / 255.0
    return jnp.clip((x - jnp.array([0.4914, 0.4822, 0.4465])) / jnp.array([0.2023, 0.1994, 0.2010]), 0, 1)

def create_train_state(rng, model, learning_rate):
    params = model.init(rng, jnp.ones([1, 32, 32, 3]))
    tx = optax.adam(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

def train_model():
    global args
    args = parser.parse_args()

    transform_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    transform_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
    ])

    trainset = CIFAR10(root="./data", train=True, download=True, transform=transform_train)
    train_loader = MetalCIFARDataset(trainset)

    testset = CIFAR10(root="./data", train=False, download=True, transform=transform_test)
    test_loader = MetalCIFARDataset(testset)

    classes = (
        "plane", "car", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck",
    )

    model = ResNet18()
    rng = random.PRNGKey(123)
    state = create_train_state(rng, model, args.lr)

    for epoch in range(args.epochs):
        for i in range(len(train_loader) // args.batch_size):
            x_batch, y_batch = train_loader[i*args.batch_size:(i+1)*args.batch_size]
            x_batch = preprocess_images(x_batch)
            y_batch = jnp.array(y_batch)

            def loss_fn(params):
                logits = state.apply_fn({'params': params}, x_batch)
                loss = optax.softmax_cross_entropy(logits, jax.nn.one_hot(y_batch, 10)).mean()
                return loss

            grad_fn = jax.value_and_grad(loss_fn)
            loss, grads = grad_fn(state.params)

            state = state.apply_gradients(grads=grads)
    
    # Later, Implement evaluation similar to how we evaluated in PyTorch

if __name__ == "__main__":
    train_model()