import jax
import jax.numpy as jnp
from flax import linen as nn


class BasicBlock(nn.Module):
    expansion: int = 1

    @nn.compact
    def __call__(self, x):
        conv1 = nn.Conv(features=self.expansion * 64, kernel_size=(3, 3), strides=(1, 1), padding='SAME', use_bias=False)
        bn1 = nn.BatchNorm()
        conv2 = nn.Conv(features=self.expansion * 64, kernel_size=(3, 3), strides=(1, 1), padding='SAME', use_bias=False)
        bn2 = nn.BatchNorm()
        
        out = nn.relu(bn1(conv1(x)))
        out = bn2(conv2(out))
        shortcut = x

        if x.shape[1] != out.shape[1] or x.shape[2] != out.shape[2]:
            shortcut = bn2(nn.Conv(features=self.expansion * 64, kernel_size=(1, 1), strides=(1, 1), use_bias=False)(x))

        out += shortcut
        out = nn.relu(out)
        return out


class Bottleneck(nn.Module):
    expansion: int = 4

    @nn.compact
    def __call__(self, x):
        conv1 = nn.Conv(features=64, kernel_size=(1, 1), use_bias=False)
        bn1 = nn.BatchNorm()
        conv2 = nn.Conv(features=64, kernel_size=(3, 3), padding='SAME', use_bias=False)
        bn2 = nn.BatchNorm()
        conv3 = nn.Conv(features=self.expansion * 64, kernel_size=(1, 1), use_bias=False)
        bn3 = nn.BatchNorm()

        out = nn.relu(bn1(conv1(x)))
        out = nn.relu(bn2(conv2(out)))
        out = bn3(conv3(out))
        shortcut = x

        if x.shape[1] != out.shape[1] or x.shape[2] != out.shape[2]:
            shortcut = bn3(nn.Conv(features=self.expansion * 64, kernel_size=(1, 1), strides=(1, 1), use_bias=False)(x))

        out += shortcut
        out = nn.relu(out)
        return out


class ResNet(nn.Module):
    block: nn.Module
    num_blocks: list
    num_classes: int = 10

    def setup(self):
        self.in_planes = 64
        self.conv1 = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1), padding='SAME', use_bias=False)
        self.bn1 = nn.BatchNorm()
        self.layer1 = self._make_layer(self.block, 64, self.num_blocks[0], stride=1)
        self.layer2 = self._make_layer(self.block, 128, self.num_blocks[1], stride=2)
        self.layer3 = self._make_layer(self.block, 256, self.num_blocks[2], stride=2)
        self.layer4 = self._make_layer(self.block, 512, self.num_blocks[3], stride=2)
        self.linear = nn.Dense(self.num_classes)

    def _make_layer(self, block, planes, num_blocks, stride):
        layers = []
        for _ in range(num_blocks):
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def __call__(self, x):
        out = nn.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = jnp.mean(out, axis=(1, 2))
        out = self.linear(out)
        return out


def ResNet18():
    return ResNet(BasicBlock, [2, 2, 2, 2])


def test():
    net = ResNet18()
    key = jax.random.PRNGKey(0)
    x = jax.random.normal(key, (1, 32, 32, 3))
    y = net(x)
    print(y.shape)

# test()