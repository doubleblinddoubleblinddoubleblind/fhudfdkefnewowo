import jax
import jax.numpy as jnp
import numpy as np
import random
import gym
import time

from flax import linen as nn
from flax.training import train_state
from jax import random as jax_random
from jax import grad, jit, vmap
from jax import value_and_grad
import optax

from model import Model  # Import your model definition

class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []

    def push(self, events):
        for event in zip(*events):
            self.memory.append(event)
            if len(self.memory) > self.capacity:
                del self.memory[0]

    def clear(self):
        self.memory = []

    def sample(self, batch_size):
        samples = zip(*random.sample(self.memory, batch_size))
        return [jnp.concatenate(x, axis=0) for x in samples]

def normal(x, mu, std):
    a = jnp.exp(-1 * (x - mu) ** 2 / (2 * std))
    b = 1 / jnp.sqrt(2 * np.pi * std)
    return a * b

@jax.jit
def train(rank, params, traffic_light, counter, shared_model, shared_grad_buffers, shared_obs_stats, test_n):
    key = jax_random.PRNGKey(params.seed)
    env = gym.make(params.env_name)
    num_inputs = env.observation_space.shape[0]
    num_outputs = env.action_space.shape[0]
    model = Model(num_inputs, num_outputs)

    memory = ReplayMemory(params.exploration_size)

    state = env.reset()
    done = True

    episode_length = 0
    while True:
        episode_length += 1
        model_params = shared_model.params

        w = -1
        av_reward = 0
        nb_runs = 0
        reward_0 = 0
        t = -1
        while w < params.exploration_size:
            t += 1
            states = []
            actions = []
            rewards = []
            values = []
            returns = []
            advantages = []
            av_reward = 0
            cum_reward = 0
            cum_done = 0

            for step in range(params.num_steps):
                w += 1
                # Normalizing the state
                state = shared_obs_stats.normalize(state)
                states.append(state)
                mu, sigma_sq, v = model.apply(model_params, state)
                eps = jax_random.normal(key, mu.shape)
                action = mu + jnp.sqrt(sigma_sq) * eps
                actions.append(action)
                values.append(v)

                env_action = action.squeeze().numpy()
                state, reward, done, _ = env.step(env_action)
                done = (done or episode_length >= params.max_episode_length)
                cum_reward += reward
                reward = max(min(reward, 1), -1)
                rewards.append(reward)
                if done:
                    cum_done += 1
                    av_reward += cum_reward
                    cum_reward = 0
                    episode_length = 0
                    state = env.reset()
                state = state[None, :]  # Reshape for JAX
                if done:
                    break

            R = jnp.zeros(1)
            if not done:
                _, _, v = model.apply(model_params, state)
                R = v
            values.append(R)
            A = jnp.zeros(1)
            for i in reversed(range(len(rewards))):
                td = rewards[i] + params.gamma * values[i + 1] - values[i]
                A = float(td) + params.gamma * params.gae_param * A
                advantages.insert(0, A)
                R = A + values[i]
                returns.insert(0, R)

            memory.push([states, actions, returns, advantages])

        av_reward /= float(cum_done + 1)
        model_old = Model(num_inputs, num_outputs)
        model_old_params = model_params

        if t == 0:
            reward_0 = av_reward - (1e-2)

        for k in range(params.num_epoch):
            model_params = shared_model.params
            signal_init = traffic_light.get()
            batch_states, batch_actions, batch_returns, batch_advantages = memory.sample(params.batch_size)
            mu_old, sigma_sq_old, v_pred_old = model_old.apply(model_old_params, batch_states)
            probs_old = normal(batch_actions, mu_old, sigma_sq_old)
            mu, sigma_sq, v_pred = model.apply(model_params, batch_states)
            probs = normal(batch_actions, mu, sigma_sq)

            ratio = probs / (1e-10 + probs_old)
            surr1 = ratio * jnp.concatenate([batch_advantages] * num_outputs, axis=1)
            surr2 = ratio.clip(1 - params.clip, 1 + params.clip) * jnp.concatenate([batch_advantages] * num_outputs, axis=1)
            loss_clip = -jnp.mean(jnp.min(jnp.stack([surr1, surr2]), axis=0))

            vfloss1 = (v_pred - batch_returns) ** 2
            v_pred_clipped = v_pred_old + (v_pred - v_pred_old).clip(-params.clip, params.clip)
            vfloss2 = (v_pred_clipped - batch_returns) ** 2
            loss_value = 0.5 * jnp.mean(jnp.max(jnp.stack([vfloss1, vfloss2]), axis=0))

            loss_ent = -params.ent_coeff * jnp.mean(probs * jnp.log(probs + 1e-5))
            total_loss = (loss_clip + loss_value + loss_ent)

            model_old_params = model_params
            grads = grad(lambda p: model.loss_fn(p, batch_states, batch_actions, batch_returns, batch_advantages))(model_params)
            shared_grad_buffers.add_gradient(grads)

            counter.increment()

            while traffic_light.get() == signal_init:
                pass

        test_n += 1
        memory.clear()