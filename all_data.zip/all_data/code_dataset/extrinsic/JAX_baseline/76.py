import jax
import jax.numpy as jnp
import jax.random as random
import unittest
import time

def sample(nindices=2*256+2*8, size=(256, 256), var=1.0):
    assert len(size) == 2
    key = random.PRNGKey(0)
    
    indices = jnp.array(random.uniform(key, (nindices, 2), minval=0, maxval=size, dtype=jnp.int32))
    values = random.normal(key, (nindices,)) * var

    return indices, values

class TestTensors(unittest.TestCase):

    def test_sum(self):
        size = (5, 5)

        # create a batch of sparse matrices
        samples = [sample(nindices=3, size=size) for _ in range(3)]
        indices, values = [s[0][None, :, :] for s in samples], [s[1][None, :] for s in samples]

        indices = jnp.concatenate(indices, axis=0)
        values = jnp.concatenate(values, axis=0)

        print(indices)
        print(values)
        print('res', tensors.sum(indices, values, size))

    def test_log_softmax(self):
        size = (5, 5)

        # create a batch of sparse matrices
        samples = [sample(nindices=3, size=size) for _ in range(3)]
        indices, values = [s[0][None, :, :] for s in samples], [s[1][None, :] for s in samples]

        indices = jnp.concatenate(indices, axis=0)
        values = jnp.concatenate(values, axis=0)

        print('res', tensors.logsoftmax(indices, values, size, method='naive').exp())
        print('res', tensors.logsoftmax(indices, values, size, method='iteration').exp())

    def test(self):
        a = jax.Variable(jax.random.normal(random.PRNGKey(0), (1,)), requires_grad=True)
        x = jax.random.normal(random.PRNGKey(1), (15000, 15000))

        x = x * a
        x = x / 2

        loss = x.sum()

        loss.backward()
        time.sleep(600)