import numpy as np
import jax
import jax.numpy as jnp
import flax.linen as nn
from flax import struct

from parcellearning.conv.pairconv import PAIRConv
from parcellearning.conv.gatconv import GATConv


class PAIRGAT(nn.Module):
    num_layers: int
    in_dim: int
    num_hidden: int
    num_classes: int
    num_heads: list
    activation: callable
    feat_drop: float
    attn_drop: float
    negative_slope: float = 0.2
    residual: bool = False
    allow_zero_in_degree: bool = True
    return_attention: bool = False

    def setup(self):
        self.layers = []
        self.num_out_heads = self.num_heads[-1]

        # input layer
        self.layers.append(PAIRConv(in_feats=self.in_dim,
                                    out_feats=self.num_hidden,
                                    num_heads=self.num_heads[0],
                                    feat_drop=self.feat_drop,
                                    attn_drop=self.attn_drop,
                                    negative_slope=self.negative_slope,
                                    activation=self.activation,
                                    allow_zero_in_degree=self.allow_zero_in_degree,
                                    return_attention=False))

        # hidden layers
        for l in range(1, self.num_layers):
            self.layers.append(PAIRConv(in_feats=(self.num_hidden + 1) * self.num_heads[0],
                                        out_feats=self.num_hidden,
                                        num_heads=self.num_heads[0],
                                        feat_drop=self.feat_drop,
                                        attn_drop=self.attn_drop,
                                        negative_slope=self.negative_slope,
                                        activation=self.activation,
                                        allow_zero_in_degree=self.allow_zero_in_degree,
                                        return_attention=False))

        # output layer
        self.output_layer = nn.Dense(self.num_classes, use_bias=True)

    def __call__(self, g, inputs):
        h = inputs
        for layer in self.layers[:-1]:
            h = layer(g, h).flatten(1)

        # output projection
        logits = self.output_layer(h)
        return logits

    def save(self, filename, params):
        with open(filename, 'wb') as f:
            jax.numpy.save(f, params)