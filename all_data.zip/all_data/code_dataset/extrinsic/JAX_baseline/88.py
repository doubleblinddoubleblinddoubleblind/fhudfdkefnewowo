import os
import logging
import sys
import datetime
import gc
import jax.numpy as jnp
import jax
import numpy as np

def get_immediate_subdirectories(a_dir):
    return [name for name in os.listdir(a_dir)
            if os.path.isdir(os.path.join(a_dir, name))]

def get_logfile(exp_dir, silent, verbose):
    logfile = os.path.join(exp_dir, 'log.txt')

    logging.basicConfig(level=logging.INFO, filename=logfile, filemode="a+",
                        format="%(message)s")

    debugfile = os.path.join(exp_dir, 'debug.txt')
    ch_debug = logging.StreamHandler(debugfile)
    ch_debug.setLevel(logging.DEBUG)

    if not silent:
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)
        ch = logging.StreamHandler(sys.stdout)
        if verbose:
            ch.setLevel(logging.INFO)
        else:
            ch.setLevel(logging.WARNING)
        formatter = logging.Formatter('%(message)s')
        ch.setFormatter(formatter)
        root.addHandler(ch)
    return logfile

def timestring():
    dt = datetime.datetime.now()
    d = "{}-{} at {:02d}:{:02d}:{:02d}".format(dt.strftime("%b"), dt.day, dt.hour, dt.minute, dt.second)
    return d


def log_gpu_usage():
    # JAX does not have an equivalent to GPUtil, but you can check with jax.devices()
    devices = jax.devices()
    gpu_available = any(device.device_kind == 'gpu' for device in devices)
    if gpu_available:
        gpu_details = jax.devices('gpu')[0]
        logging.info(f"GPU: {gpu_details.device_id} - {gpu_details.platform} available")
    else:
        pass

def get_tensors_in_memory(ndim=None):
    tensor_list = []
    for obj in gc.get_objects():
        try:
            cond = isinstance(obj, (jax.DeviceArray, np.ndarray))
            if ndim is not None:
                cond = cond and len(obj.shape) == ndim
            if cond:
                tensor_list.append(obj)
        except Exception:
            pass
    return tensor_list

def memory_footprint(x):
    b = np.prod(x.shape) * 4
    return b

def get_bytes(tensor_list):
    total_bytes = 0
    for t in tensor_list:
        b = memory_footprint(t)
        total_bytes += b
    return total_bytes

def see_tensors_in_memory(ndim=None, summary=False, cuda=False):
    tensor_list = get_tensors_in_memory(ndim)
    tensor_list = (filter(lambda x: not isinstance(x, jax.interpreters.xla.DeviceArray), tensor_list))
    
    if cuda:
        tensor_list = list(filter(lambda x: 'gpu' in str(x), tensor_list))
        cuda_or_cpu = 'CUDA'
    else:
        tensor_list = list(filter(lambda x: 'gpu' not in str(x), tensor_list))
        cuda_or_cpu = 'CPU'

    total_bytes = get_bytes(tensor_list)

    logging.info((
        'There are {} instantiated {} tensors in memory, consuming {} total.\n'
        'This does not count internal tensors created by JAX or weights, only things '
        'like variables')
        .format(len(tensor_list), cuda_or_cpu, format_bytes(total_bytes)))

    if not summary:
        logging.info('\n'.join([','.join(list(str(x) for x in t.shape)) for t in tensor_list]))


def compute_model_size(model):
    return sum(memory_footprint(p) for p in model.parameters())

class memory_snapshot:
    def __init__(self, ndim=None, cuda=False, summary=False):
        self.cuda = cuda
        self.ndim = ndim
        self.summary = summary

    def __enter__(self):
        logging.info("BEFORE")
        see_tensors_in_memory(self.ndim, self.summary, self.cuda)

    def __exit__(self, type, value, traceback):
        logging.info("AFTER")
        see_tensors_in_memory(self.ndim, self.summary, self.cuda)


def format_bytes(n):
    n = str(int(n))
    if len(n) < 4:
        return "{} B".format(n)
    elif len(n) < 7:
        return "{} kB".format(n[:-3])
    elif len(n) < 10:
        return "{}.{} MB".format(n[:-6], n[-6:-5])
    elif len(n) < 14:
        return "{}.{} GB".format(n[:-9], n[-9:-8])
    return "{}.{} TB".format(n[:-12], n[-12:-11])