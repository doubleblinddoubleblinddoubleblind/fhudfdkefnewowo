'''Dual Path Networks in JAX.'''
import jax
import jax.numpy as jnp
from jax import random, grad, jit, vmap
from flax import linen as nn
from flax.training import train_state
import optax


class Bottleneck(nn.Module):
    out_planes: int
    dense_depth: int
    in_planes: int
    stride: int
    first_layer: bool

    def setup(self):
        self.conv1 = nn.Conv(features=self.in_planes, kernel_size=(1, 1), use_bias=False)
        self.bn1 = nn.BatchNorm()
        self.conv2 = nn.Conv(features=self.in_planes, kernel_size=(3, 3), strides=(self.stride, self.stride), padding='same', feature_group_count=32, use_bias=False)
        self.bn2 = nn.BatchNorm()
        self.conv3 = nn.Conv(features=self.out_planes + self.dense_depth, kernel_size=(1, 1), use_bias=False)
        self.bn3 = nn.BatchNorm()

        if self.first_layer:
            self.shortcut = nn.Sequential([
                nn.Conv(features=self.out_planes + self.dense_depth, kernel_size=(1, 1), strides=(self.stride, self.stride), use_bias=False),
                nn.BatchNorm()
            ])
        else:
            self.shortcut = lambda x: x

    def __call__(self, x):
        out = nn.relu(self.bn1(self.conv1(x)))
        out = nn.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        shortcut = self.shortcut(x)

        d = self.out_planes
        out = jnp.concatenate([shortcut[:, :d, :, :] + out[:, :d, :, :], shortcut[:, d:, :, :], out[:, d:, :, :]], axis=1)
        out = nn.relu(out)
        return out


class DPN(nn.Module):
    in_planes: tuple
    out_planes: tuple
    num_blocks: tuple
    dense_depth: tuple

    def setup(self):
        self.conv1 = nn.Conv(features=64, kernel_size=(3, 3), padding='same', use_bias=False)
        self.bn1 = nn.BatchNorm()
        self.last_planes = 64
        self.layer1 = self._make_layer(self.in_planes[0], self.out_planes[0], self.num_blocks[0], self.dense_depth[0], stride=1)
        self.layer2 = self._make_layer(self.in_planes[1], self.out_planes[1], self.num_blocks[1], self.dense_depth[1], stride=2)
        self.layer3 = self._make_layer(self.in_planes[2], self.out_planes[2], self.num_blocks[2], self.dense_depth[2], stride=2)
        self.layer4 = self._make_layer(self.in_planes[3], self.out_planes[3], self.num_blocks[3], self.dense_depth[3], stride=2)
        self.linear = nn.Dense(self.out_planes[3] + (self.num_blocks[3] + 1) * self.dense_depth[3], kernel_init=nn.initializers.xavier_uniform())

    def _make_layer(self, in_planes, out_planes, num_blocks, dense_depth, stride):
        layers = []
        strides = [stride] + [1] * (num_blocks - 1)
        for i, stride in enumerate(strides):
            layers.append(Bottleneck(out_planes=out_planes, in_planes=in_planes, dense_depth=dense_depth, stride=stride, first_layer=(i == 0)))
            in_planes = out_planes + (i + 2) * dense_depth
        return nn.Sequential(layers)

    def __call__(self, x):
        out = nn.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = jax.lax.reduce_window(out, jnp.zeros(out.shape[0]), jnp.add, window_dimensions=(out.shape[1], out.shape[2]), strides=(out.shape[1], out.shape[2]))
        out = out.reshape(out.shape[0], -1)
        out = self.linear(out)
        return out


def DPN26():
    cfg = {
        'in_planes': (96, 192, 384, 768),
        'out_planes': (256, 512, 1024, 2048),
        'num_blocks': (2, 2, 2, 2),
        'dense_depth': (16, 32, 24, 128)
    }
    return DPN(**cfg)

def DPN92():
    cfg = {
        'in_planes': (96, 192, 384, 768),
        'out_planes': (256, 512, 1024, 2048),
        'num_blocks': (3, 4, 20, 3),
        'dense_depth': (16, 32, 24, 128)
    }
    return DPN(**cfg)


def test():
    rng = random.PRNGKey(0)
    net = DPN92()
    x = jnp.ones((1, 3, 32, 32))  # use ones to emulate input tensor
    y = net(x)
    print(y)

# test()