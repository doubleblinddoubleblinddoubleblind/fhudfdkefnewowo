import jax
import jax.numpy as jnp
from flax import linen as nn
from torchvision import transforms
from torchvision.datasets import CIFAR10
from jax import random
from jax import device_put
import numpy as np
from sklearn.model_selection import train_test_split

TRAIN_BATCH_SIZE = 64
TEST_BATCH_SIZE = 64
DATA_PATH = './'

transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))
])

# Load dataset
trainset = CIFAR10(root=DATA_PATH + 'cifar-10-batches-py', train=True, download=True, transform=transform)
testset = CIFAR10(root=DATA_PATH + 'cifar-10-batches-py', train=False, download=True, transform=transform)

# Convert to numpy arrays for JAX
train_images, train_labels = np.array(trainset.data), np.array(trainset.targets)
test_images, test_labels = np.array(testset.data), np.array(testset.targets)

# Shuffle train data
rng = random.PRNGKey(0)
indices = jax.random.permutation(rng, len(train_images))
train_images, train_labels = train_images[indices], train_labels[indices]

# Create data loaders
train_loader = [device_put((train_images[i:i + TRAIN_BATCH_SIZE], train_labels[i:i + TRAIN_BATCH_SIZE]))
                for i in range(0, len(train_images), TRAIN_BATCH_SIZE)]
test_loader = [device_put((test_images[i:i + TEST_BATCH_SIZE], test_labels[i:i + TEST_BATCH_SIZE]))
               for i in range(0, len(test_images), TEST_BATCH_SIZE)]

classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')