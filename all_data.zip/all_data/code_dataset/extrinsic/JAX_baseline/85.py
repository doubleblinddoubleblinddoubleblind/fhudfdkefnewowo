import jax.numpy as jnp
from jax import random, grad, jit
from flax import linen as nn
from flax.training import train_state
import flax.linen as nn
import torchvision.models as models
import jax

class HumanPoseNet(nn.Module):
    out_c: int

    def setup(self):
        self.model = models.vgg16_bn(pretrained=True)
        self.model.classifier[0] = nn.Dense(4096)
        self.model.classifier[3] = nn.Dense(4096)
        self.model.classifier[6] = nn.Dense(self.out_c)

    def __call__(self, input):
        assert input.shape[-2:] == (224, 224)
        x = self.model(input)
        return x

def mse_loss(pred, target, weight, weighted_loss=False, size_average=True):
    mask = (weight != 0).astype(jnp.float32)
    if weighted_loss:
        loss = jnp.sum(weight * (pred - target) ** 2)
    else:
        loss = jnp.sum(mask * (pred - target) ** 2)
    if size_average:
        loss /= jnp.sum(mask)
    return loss