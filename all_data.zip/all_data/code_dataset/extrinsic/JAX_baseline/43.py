# Copyright (c) 2017-2019 Uber Technologies, Inc.
# SPDX-License-Identifier: Apache-2.0

import pytest
import jax
import jax.numpy as jnp
from jax import grad, random
from jax import vmap
import numpyro
import numpyro.distributions as dist
from numpyro import handlers
from numpyro.infer.reparam import LocScaleReparam
from tests.common import assert_close

from .util import check_init_reparam

# Test helper to extract a few central moments from samples.
def get_moments(x):
    m1 = jnp.mean(x, axis=0)
    x = x - m1
    xx = x * x
    xxx = x * xx
    xxxx = xx * xx
    m2 = jnp.mean(xx, axis=0)
    m3 = jnp.mean(xxx, axis=0) / m2 ** 1.5
    m4 = jnp.mean(xxxx, axis=0) / m2 ** 2
    return jnp.stack([m1, m2, m3, m4])

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("centered", [0.0, 0.6, 1.0, jnp.array(0.4), None])
@pytest.mark.parametrize("dist_type", ["Normal", "StudentT", "AsymmetricLaplace"])
def test_moments(dist_type, centered, shape):
    key = random.PRNGKey(0)
    loc = random.uniform(key, shape, minval=-1.0, maxval=1.0)
    scale = random.uniform(key, shape, minval=0.5, maxval=1.5)
    if isinstance(centered, jnp.ndarray):
        centered = jnp.broadcast_to(centered, shape)

    def model():
        with handlers plate_stack("plates", shape):
            with handlers plate("particles", 200000):
                if dist_type == "Normal":
                    return numpyro.sample("x", dist.Normal(loc, scale))
                elif dist_type == "StudentT":
                    return numpyro.sample("x", dist.StudentT(df=10.0, loc=loc, scale=scale))
                else:
                    return numpyro.sample("x", dist.AsymmetricLaplace(loc=loc, scale=scale, asymmetry=1.5))

    value = handlers.trace(model).get_trace()['x']['value']
    expected_probe = get_moments(value)

    reparam_model = handlers.reparam(model, {"x": LocScaleReparam(centered)})
    value = handlers.trace(reparam_model).get_trace()['x']['value']
    actual_probe = get_moments(value)

    if centered is not None and centered != 1.0:
        if dist_type == "Normal":
            assert reparam.shape_params == ()
        elif dist_type == "StudentT":
            assert reparam.shape_params == ("df",)
        else:
            assert reparam.shape_params == ("asymmetry",)

    assert_close(actual_probe, expected_probe, atol=0.1, rtol=0.05)

    for actual_m, expected_m in zip(actual_probe, expected_probe):
        expected_grads = grad(jnp.sum(expected_m), [loc, scale], allow_unused=True)
        actual_grads = grad(jnp.sum(actual_m), [loc, scale], allow_unused=True)
        assert_close(actual_grads[0], expected_grads[0], atol=0.1, rtol=0.05)
        assert_close(actual_grads[1], expected_grads[1], atol=0.1, rtol=0.05)

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("centered", [0.0, 0.6, 1.0, jnp.array(0.4), None])
@pytest.mark.parametrize("dist_type", ["Normal", "StudentT", "AsymmetricLaplace"])
def test_init(dist_type, centered, shape):
    key = random.PRNGKey(0)
    loc = random.uniform(key, shape, minval=-1.0, maxval=1.0)
    scale = random.uniform(key, shape, minval=0.5, maxval=1.5)

    def model():
        with handlers plate_stack("plates", shape):
            if dist_type == "Normal":
                return numpyro.sample("x", dist.Normal(loc, scale))
            elif dist_type == "StudentT":
                return numpyro.sample("x", dist.StudentT(df=10.0, loc=loc, scale=scale))
            else:
                return numpyro.sample("x", dist.AsymmetricLaplace(loc=loc, scale=scale, asymmetry=1.5))

    check_init_reparam(model, LocScaleReparam(centered))