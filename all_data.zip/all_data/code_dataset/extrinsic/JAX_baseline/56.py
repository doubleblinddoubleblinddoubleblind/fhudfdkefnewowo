import jax.numpy as jnp
from jax import random, vmap
from flax import linen as nn
from numpy.testing import assert_almost_equal


class CharEmbedding(nn.Module):
    num_embeddings: int
    embedding_dim: int

    def setup(self):
        self.embedding = self.param('embedding', nn.initializers.xavier_uniform(), (self.num_embeddings, self.embedding_dim))

    def __call__(self, indices):
        return self.embedding[indices]


class TimeDistributed(nn.Module):
    module: nn.Module

    def __call__(self, inputs):
        return vmap(self.module)(inputs)


def test_time_distributed_reshapes_correctly():
    char_embedding = CharEmbedding(num_embeddings=2, embedding_dim=2)
    char_embedding_params = {'embedding': jnp.array([[.4, .4], [.5, .5]])}
    distributed_embedding = TimeDistributed(module=char_embedding)

    char_input = jnp.array([[[1, 0], [1, 1]]])
    output = distributed_embedding.apply(char_embedding_params, char_input)
    assert_almost_equal(output, [[[[.5, .5], [.4, .4]], [[.5, .5], [.5, .5]]]])


def test_time_distributed_works_with_multiple_inputs():
    def module(x, y):
        return x + y

    distributed = TimeDistributed(module)

    x_input = jnp.array([[[1, 2], [3, 4]]])
    y_input = jnp.array([[[4, 2], [9, 1]]])
    output = distributed.apply({}, x_input, y_input)
    assert_almost_equal(output, [[[5, 4], [12, 5]]])