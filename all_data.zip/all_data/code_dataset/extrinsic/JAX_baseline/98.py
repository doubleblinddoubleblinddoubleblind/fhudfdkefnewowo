from __future__ import absolute_import, division, print_function

import functools
import inspect
import os
from collections.abc import Mapping
from contextlib import contextmanager

from flax import linen as nn
import jax
import jax.numpy as jnp

# ===========================================================================
# Make the layers accessible through backend
# ===========================================================================
class _nn_meta(type):

    def __getattr__(cls, key):
        fw = get_framework()  # Assuming get_framework() is defined elsewhere
        import tensorflow as tf

        all_objects = {}
        if fw == jax:
            from odin import networks_jax  # Modify import based on JAX equivalent
            all_objects.update(nn.__dict__)
            all_objects.update(networks_jax.__dict__)
        elif fw == tf:
            from odin import networks
            from tensorflow.python.keras.engine import sequential, training
            all_objects.update(tf.keras.layers.__dict__)
            all_objects.update(networks.__dict__)
            all_objects.update(sequential.__dict__)
            all_objects.update(training.__dict__)
        else:
            raise NotImplementedError("No neural networks support for framework: " +
                                      str(fw))
        return all_objects[key]

class NeuralNetwork(metaclass=_nn_meta):
    pass

nn = NeuralNetwork()