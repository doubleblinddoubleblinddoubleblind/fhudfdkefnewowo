from typing import Any, Dict, List, Tuple

import jax.numpy as jnp
from flax import linen as nn
from ray.rllib.models.model import restore_original_dimensions
from ray.rllib.utils.annotations import PublicAPI


@PublicAPI
class JAXModel(nn.Module):
    """Defines an abstract network model for use with RLlib / JAX."""

    obs_space: Any
    num_outputs: int
    options: Dict[str, Any]

    @nn.compact
    def __call__(self, input_dict: Dict[str, jnp.ndarray], hidden_state: List[jnp.ndarray]) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, List[jnp.ndarray]]:
        """Wraps _forward() to unpack flattened Dict and Tuple observations."""
        input_dict["obs"] = jnp.asarray(input_dict["obs"], dtype=jnp.float32)  # Avoid cast
        input_dict["obs"] = restore_original_dimensions(
            input_dict["obs"], self.obs_space, tensorlib=jnp)
        outputs, features, vf, h = self._forward(input_dict, hidden_state)
        return outputs, features, vf, h

    @PublicAPI
    def state_init(self) -> List[jnp.ndarray]:
        """Returns a list of initial hidden state tensors, if any."""
        return []

    @PublicAPI
    def _forward(self, input_dict: Dict[str, jnp.ndarray], hidden_state: List[jnp.ndarray]) -> Tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray, List[jnp.ndarray]]:
        """Forward pass for the model.

        Prefer implementing this instead of __call__() directly for proper
        handling of Dict and Tuple observations.

        Arguments:
            input_dict (dict): Dictionary of tensor inputs, commonly
                including "obs", "prev_action", "prev_reward", each of shape
                [BATCH_SIZE, ...].
            hidden_state (list): List of hidden state tensors, each of shape
                [BATCH_SIZE, h_size].

        Returns:
            (outputs, feature_layer, values, state): Tensors of size
                [BATCH_SIZE, num_outputs], [BATCH_SIZE, desired_feature_size],
                [BATCH_SIZE], and [len(hidden_state), BATCH_SIZE, h_size].
        """
        raise NotImplementedError