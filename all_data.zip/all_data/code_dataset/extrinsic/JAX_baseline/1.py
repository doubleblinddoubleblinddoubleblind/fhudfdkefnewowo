import math
import jax
import jax.numpy as jnp
import flax.linen as nn
from flax import optim

class ConvRec(nn.Module):
    n_classes: int
    vocab: int
    emb_dim: int = 100
    padding_idx: int = None
    out_channels: int = 128
    kernel_sizes: list = (5, 3)
    pool_size: int = 2
    act: str = 'relu'
    conv_type: str = 'wide'
    rnn_layers: int = 1
    hid_dim: int = 128
    cell: str = 'LSTM'
    bidi: bool = True
    dropout: float = 0.0
    
    def setup(self):
        self.embeddings = nn.Embed(
            num_embeddings=self.vocab, features=self.emb_dim, kernel_init=nn.initializers.xavier_uniform())

        self.conv_layers = []
        for layer, W in enumerate(self.kernel_sizes):
            C_i, H = (1, self.emb_dim) if layer == 0 else (self.out_channels, 1)
            padding = (math.floor(W / 2), 0) if self.conv_type == 'wide' else (0, 0)

            conv = nn.Conv(features=self.out_channels, kernel_size=(H, W), padding=padding)
            self.conv_layers.append(conv)

        self.rnn = nn.LSTM if self.cell == 'LSTM' else nn.GRU if self.cell == 'GRU' else nn.RNN

        self.proj = nn.Dense(2 * self.hid_dim * (1 + int(self.bidi)), kernel_init=nn.initializers.xavier_uniform())
    
    def __call__(self, inp, train=True):
        # Embedding
        emb = self.embeddings(inp)
        emb = jnp.transpose(emb, (1, 0, 2))  # (seq_len x batch x emb_dim)
        emb = jnp.expand_dims(emb, axis=1)     # (seq_len x 1 x batch x emb_dim)

        # CNN
        conv_in = emb
        for conv_layer in self.conv_layers:
            conv_out = conv_layer(conv_in)   # (seq_len x out_channels x 1 x new_seq_len)
            conv_out = nn.avg_pool(conv_out, window_shape=(1, self.pool_size), strides=(1, self.pool_size))  # Pooling
            conv_out = getattr(nn, self.act)(conv_out)
            if train:
                conv_out = nn.Dropout(rate=self.dropout)(conv_out, deterministic=not train)
            conv_in = conv_out

        # RNN
        rnn_in = jnp.squeeze(conv_out, axis=2).transpose(0, 2, 1)  # (new_seq_len x batch x out_channels)
        rnn_out, _ = self.rnn(name='rnn_layer')(rnn_in, train)
        rnn_out = jnp.concatenate([jnp.sum(rnn_out[:-1], axis=0), rnn_out[-1:]], axis=1)  # Avg + last step

        # Proj
        out = self.proj(rnn_out)

        return out