# -*- coding: utf-8 -*-
#

# Imports
import jax.numpy as jnp
from jax import random
from flax import linen as nn
from typing import Tuple


# Generates a series of input timeseries and delayed versions as outputs.
class MemTestDataset:
    """
    Generates a series of input timeseries and delayed versions as outputs.
    Delay is given in number of timesteps. Can be used to empirically measure the
    memory capacity of a system.
    """

    # Constructor
    def __init__(self, sample_len: int, n_samples: int, n_delays: int = 10, seed: int = None):
        """
        Constructor
        :param sample_len: Length of the time-series in time steps.
        :param n_samples: Number of samples to generate.
        :param n_delays: Number of step to delay
        :param seed: Seed of random number generator.
        """
        # Properties
        self.sample_len = sample_len
        self.n_samples = n_samples
        self.n_delays = n_delays

        # Init seed if needed
        self.key = random.PRNGKey(seed) if seed is not None else random.PRNGKey(0)
    # end __init__

    # Length
    def __len__(self) -> int:
        """
        Length
        :return:
        """
        return self.n_samples
    # end __len__

    # Get item
    def __getitem__(self, idx: int) -> Tuple[jnp.ndarray, jnp.ndarray]:
        """
        Get item
        :param idx:
        :return:
        """
        self.key, subkey = random.split(self.key)
        inputs = (random.uniform(subkey, (self.sample_len, 1), minval=-0.8, maxval=0.8))
        outputs = jnp.zeros((self.sample_len, self.n_delays))
        for k in range(self.n_delays):
            outputs = outputs.at[:, k].set(jnp.concatenate((jnp.zeros((k + 1, 1)), inputs[:-k - 1, :]), axis=0))
        # end for
        return inputs, outputs
    # end __getitem__

# end MemTestDataset