import jax.numpy as jnp
from jax import random
from flax import linen as nn
from flax.linen import Parameter

class EndpointSpanExtractor(nn.Module):
    input_dim: int
    combination: str = "x,y"
    num_width_embeddings: int = None
    span_width_embedding_dim: int = None
    bucket_widths: bool = False
    use_exclusive_start_indices: bool = False

    def setup(self):
        if self.use_exclusive_start_indices:
            self.start_sentinel = self.param('start_sentinel', nn.initializers.xavier_uniform(), (1, 1, self.input_dim))

    def get_output_dim(self):
        combined_dim = self._get_combined_dim(self.combination, [self.input_dim, self.input_dim])
        if self.span_width_embedding_dim is not None:
            return combined_dim + self.num_width_embeddings
        return combined_dim

    def _embed_spans(self, sequence_tensor, span_indices, sequence_mask=None, span_indices_mask=None):
        span_starts, span_ends = span_indices[:, 0], span_indices[:, 1]

        if span_indices_mask is not None:
            span_starts = span_starts * span_indices_mask[:, 0]
            span_ends = span_ends * span_indices_mask[:, 1]

        if not self.use_exclusive_start_indices:
            if sequence_tensor.shape[-1] != self.input_dim:
                raise ValueError(
                    f"Dimension mismatch expected ({sequence_tensor.shape[-1]}) "
                    f"received ({self.input_dim})."
                )
            start_embeddings = self._batched_index_select(sequence_tensor, span_starts)
            end_embeddings = self._batched_index_select(sequence_tensor, span_ends)
        else:
            exclusive_span_starts = span_starts - 1
            start_sentinel_mask = (exclusive_span_starts == -1).reshape(-1, 1)
            exclusive_span_starts = exclusive_span_starts * (~start_sentinel_mask.reshape(-1))

            if (exclusive_span_starts < 0).any():
                raise ValueError(
                    f"Adjusted span indices must lie inside the the sequence tensor, "
                    f"but found: exclusive_span_starts: {exclusive_span_starts}."
                )

            start_embeddings = self._batched_index_select(sequence_tensor, exclusive_span_starts)
            end_embeddings = self._batched_index_select(sequence_tensor, span_ends)

            start_embeddings = (
                start_embeddings * ~start_sentinel_mask + start_sentinel_mask * self.start_sentinel
            )

        combined_tensors = self._combine_tensors(self.combination, [start_embeddings, end_embeddings])

        return combined_tensors

    def _batched_index_select(self, tensor, indices):
        return jnp.take(tensor, indices, axis=1)

    def _combine_tensors(self, combination, tensors):
        # This function will implement the logic to combine the tensors based on the combination string.
        # For demo purpose, using simple concatenation here. 
        return jnp.concatenate(tensors, axis=-1)

    def _get_combined_dim(self, combination, dims):
        # This function would compute the output dimension based on the combination.
        # For demonstration purposes, using a naive approach assuming all combinations increase dimensions.
        return sum(dims) * len(combination.split(','))