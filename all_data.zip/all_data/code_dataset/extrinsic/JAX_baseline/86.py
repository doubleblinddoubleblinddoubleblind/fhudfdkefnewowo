import numpy as np
import argparse
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax

class Net(nn.Module):
    dropout: float
    fc1_size: int
    fc2_size: int

    def setup(self):
        self.fc1 = nn.Dense(self.fc1_size)
        self.fc2 = nn.Dense(self.fc2_size)
        self.out = nn.Dense(1)
        self.prelu = nn.PReLU(1)

    def __call__(self, input_):
        a1 = self.fc1(input_)
        h1 = nn.relu(a1)
        dout = nn.dropout(h1, rate=self.dropout)
        a2 = self.fc2(dout)
        h2 = self.prelu(a2)
        a3 = self.out(h2)
        return jax.nn.sigmoid(a3)

def model_creator(config):
    return Net(dropout=config["dropout"],
               fc1_size=config["fc1_size"],
               fc2_size=config["fc2_size"])

def get_optimizer(learning_rate):
    return optax.sgd(learning_rate)

def get_train_val_data():
    def get_x_y(size):
        input_size = 50
        x1 = np.random.randn(size // 2, input_size)
        x2 = np.random.randn(size // 2, input_size) + 1.5
        x = np.concatenate([x1, x2], axis=0)
        y1 = np.zeros((size // 2, 1))
        y2 = np.ones((size // 2, 1))
        y = np.concatenate([y1, y2], axis=0)
        return x, y

    train_data = get_x_y(size=1000)
    val_data = get_x_y(size=400)
    return train_data, val_data

def create_linear_search_space():
    from flax import struct
    return {
        "dropout": jax.random.uniform(jax.random.PRNGKey(0), (1,), minval=0.2, maxval=0.3).item(),
        "fc1_size": np.random.choice([50, 64]),
        "fc2_size": np.random.choice([100, 128]),
        "lr": np.random.choice([0.001, 0.003, 0.01]),
        "batch_size": np.random.choice([32, 64])
    }

@jax.jit
def compute_loss(logits, labels):
    return jnp.mean(optax.sigmoid_binary_cross_entropy(logits=logits, labels=labels))

def train_example(args):
    config = create_linear_search_space()
    model = model_creator(config)
    input_shape = (None, 50)  # Modify as per your use case
    params = model.init(jax.random.PRNGKey(0), jnp.ones(input_shape))
    optimizer = get_optimizer(config["lr"])
    state = train_state.TrainState.create(apply_fn=model.apply, params=params, tx=optimizer)

    train_data, val_data = get_train_val_data()

    for epoch in range(args.epochs):
        inputs = jnp.array(train_data[0])
        labels = jnp.array(train_data[1])
        logits = state.apply_fn(state.params, inputs)
        loss = compute_loss(logits, labels)

        grads = jax.grad(compute_loss)(logits, labels)
        state = state.apply_gradients(grads=grads)

    val_inputs = jnp.array(val_data[0])
    val_logits = state.apply_fn(state.params, val_inputs)
    y_hat = jax.nn.sigmoid(val_logits).numpy()

    accuracy = np.mean((y_hat > 0.5) == val_data[1])
    print("Evaluate: accuracy is", accuracy)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        prog='Autoestimator_jax',
        description='Automatically fit the model and return the best model.')
    parser.add_argument('--epochs', type=int, default=1, help="The number of epochs in each trial.")
    parser.add_argument('--trials', type=int, default=4, help="The number of searching trials.")

    args = parser.parse_args()
    train_example(args)