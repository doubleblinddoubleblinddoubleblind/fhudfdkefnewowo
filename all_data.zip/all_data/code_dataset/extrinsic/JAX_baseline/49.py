import jax.numpy as jnp
from jax import random, grad, jit, vmap
from flax import linen as nn
import numpy as np

class CNN(nn.Module):
    param: dict
    embedding: nn.Embed

    def setup(self):
        # Define any sub-layers needed for CNN (not specified in the original code)
        pass

    def __call__(self, x):
        # Implement a forward pass for the CNN (dummy implementation here)
        return jnp.sum(x, axis=-1)

class MemN2N(nn.Module):
    param: dict

    def setup(self):
        self.hops = self.param['hops']
        self.vocab_size = self.param['vocab_size']
        self.embedding_size = self.param['embedding_size']

        self.embedding = nn.Embed(self.vocab_size, self.embedding_size)
        self.cnn = CNN(self.param, embedding=self.embedding)
        self.linear = nn.Dense(self.embedding_size)

    def __call__(self, utter, memory):
        utter_emb_sum = self.cnn(utter)
        contexts = [utter_emb_sum]

        for _ in range(self.hops):
            memory_unbound = jnp.split(memory, memory.shape[1], axis=1)
            memory_emb_sum = jnp.stack([self.cnn(story.squeeze(1)) for story in memory_unbound], axis=1)

            context_temp = jnp.expand_dims(contexts[-1], -1).transpose(0, 2, 1)
            attention = jnp.sum(memory_emb_sum * context_temp, axis=2)
            attention = nn.softmax(attention)

            attention = jnp.expand_dims(attention, -1)
            attn_stories = jnp.sum(attention * memory_emb_sum, axis=1)

            new_context = self.linear(contexts[-1]) + attn_stories
            contexts.append(new_context)

        return new_context

    def weights_init(self, key):
        # weights initialization (only when model is instantiated)
        return key

def init_model(param, key):
    model = MemN2N(param)
    params = model.init(key, jnp.ones((1,)), jnp.ones((1, 3, 10)))
    return model, params

if __name__ == '__main__':
    param = {'hops': 3, "vocab_size": 20, "embedding_size": 20}
    key = random.PRNGKey(0)

    model, params = init_model(param, key)
    memory = jnp.ones((20, 3, 10), dtype=jnp.int32)
    utter = jnp.ones((20, 10), dtype=jnp.int32)

    output = model.apply(params, utter, memory)
    print(output)