#!/usr/bin/env python3

import math
import unittest

import jax
import jax.numpy as jnp
from jax import grad, jit

class TestPeriodicKernel(unittest.TestCase):
    def periodic_kernel(self, a, b, lengthscale, period):
        diff = a[:, None] - b[None, :]
        val = 2 * jnp.power(jnp.sin(math.pi * diff / period), 2) / lengthscale
        return jnp.exp(-val)

    def test_computes_periodic_function(self):
        a = jnp.array([4, 2, 8], dtype=jnp.float32).reshape(3, 1)
        b = jnp.array([0, 2], dtype=jnp.float32).reshape(2, 1)
        lengthscale = 2
        period = 3

        actual = self.periodic_kernel(a, b, lengthscale, period)
        res = actual  # In this case, we compute the kernel directly

        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch(self):
        a = jnp.array([[4, 2, 8], [1, 2, 3]], dtype=jnp.float32).reshape(2, 3, 1)
        b = jnp.array([[0, 2], [-1, 2]], dtype=jnp.float32).reshape(2, 2, 1)
        period = jnp.array(1, dtype=jnp.float32).reshape(1, 1, 1)
        lengthscale = jnp.array(2, dtype=jnp.float32).reshape(1, 1, 1)

        actual = self.periodic_kernel(a, b, lengthscale, period)
        res = actual  # Compute the kernel directly

        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch_separate(self):
        a = jnp.array([[4, 2, 8], [1, 2, 3]], dtype=jnp.float32).reshape(2, 3, 1)
        b = jnp.array([[0, 2], [-1, 2]], dtype=jnp.float32).reshape(2, 2, 1)
        period = jnp.array([1, 2], dtype=jnp.float32).reshape(2, 1, 1)
        lengthscale = jnp.array([2, 1], dtype=jnp.float32).reshape(2, 1, 1)

        actual = self.periodic_kernel(a, b, lengthscale, period)
        res = actual  # Compute the kernel directly

        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

if __name__ == "__main__":
    unittest.main()