import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Callable

class Discriminator(nn.Module):
    feature_maps: int
    image_channels: int

    def setup(self):
        self.disc = nn.Sequential([
            self._make_disc_block(self.image_channels, self.feature_maps, batch_norm=False),
            self._make_disc_block(self.feature_maps, self.feature_maps * 2),
            self._make_disc_block(self.feature_maps * 2, self.feature_maps * 4),
            self._make_disc_block(self.feature_maps * 4, self.feature_maps * 8),
            self._make_disc_block(self.feature_maps * 8, 1, kernel_size=4, stride=1, padding=0, last_block=True),
        ])

    @staticmethod
    def _make_disc_block(in_channels: int, out_channels: int,
                         kernel_size: int = 4, stride: int = 2,
                         padding: int = 1, bias: bool = False,
                         batch_norm: bool = True, last_block: bool = False) -> nn.Module:
        if not last_block:
            return nn.Sequential([
                nn.Conv(features=out_channels, kernel_size=(kernel_size, kernel_size), strides=(stride, stride),
                         padding='SAME', use_bias=bias),
                nn.BatchNorm() if batch_norm else nn.Identity(),
                nn.leaky_relu(0.2),
            ])
        else:
            return nn.Sequential([
                nn.Conv(features=out_channels, kernel_size=(kernel_size, kernel_size), strides=(stride, stride),
                         padding='SAME', use_bias=bias),
                nn.sigmoid,
            ])

    def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
        return self.disc(x).reshape(-1, 1).squeeze(1)

class Generator(nn.Module):
    latent_dim: int
    feature_maps: int
    image_channels: int

    def setup(self):
        self.gen = nn.Sequential([
            self._make_gen_block(self.latent_dim, self.feature_maps * 8, kernel_size=4, stride=1, padding=0),
            self._make_gen_block(self.feature_maps * 8, self.feature_maps * 4),
            self._make_gen_block(self.feature_maps * 4, self.feature_maps * 2),
            self._make_gen_block(self.feature_maps * 2, self.feature_maps),
            self._make_gen_block(self.feature_maps, self.image_channels, last_block=True),
        ])

    @staticmethod
    def _make_gen_block(in_channels: int, out_channels: int,
                        kernel_size: int = 4, stride: int = 2,
                        padding: int = 1, bias: bool = False,
                        last_block: bool = False) -> nn.Module:
        if not last_block:
            return nn.Sequential([
                nn.ConvTranspose(features=out_channels, kernel_size=(kernel_size, kernel_size), strides=(stride, stride),
                                 padding='SAME', use_bias=bias),
                nn.BatchNorm(),
                nn.relu,
            ])
        else:
            return nn.Sequential([
                nn.ConvTranspose(features=out_channels, kernel_size=(kernel_size, kernel_size), strides=(stride, stride),
                                 padding='SAME', use_bias=bias),
                nn.sigmoid,
            ])

    def __call__(self, noise: jnp.ndarray) -> jnp.ndarray:
        return self.gen(noise)

def get_noise(real: jnp.ndarray, configs: dict) -> jnp.ndarray:
    batch_size = real.shape[0]
    noise = jax.random.normal(jax.random.PRNGKey(0), (batch_size, configs["latent_dim"]))
    return noise[:, :, None, None]

def get_sample(generator: Callable, real: jnp.ndarray, configs: dict) -> jnp.ndarray:
    noise = get_noise(real, configs)
    return generator(noise)

def instance_noise(configs: dict, epoch_num: int, real: jnp.ndarray) -> jnp.ndarray:
    if configs["loss_params"]["instance_noise"]:
        noise_level = configs["instance_noise_params"]["noise_level"]
        if configs["instance_noise_params"]["gamma"] is not None:
            noise_level *= (configs["instance_noise_params"]["gamma"] ** epoch_num)
        real += noise_level * jax.random.normal(jax.random.PRNGKey(1), real.shape)
    return real

def top_k(configs: dict, epoch_num: int, preds: jnp.ndarray) -> jnp.ndarray:
    if configs["loss_params"]["top_k"]:
        k = configs["top_k_params"]["k"]
        if configs["top_k_params"]["gamma"] is not None:
            k = int((configs["top_k_params"]["gamma"] ** epoch_num) * k)
        return jnp.sort(preds)[-k:]
    return preds

def disc_loss(configs: dict, discriminator: Callable, generator: Callable, epoch_num: int, real: jnp.ndarray) -> jnp.ndarray:
    real = instance_noise(configs, epoch_num, real)
    real_pred = discriminator(real)
    real_gt = jnp.ones_like(real_pred)
    real_loss = jnp.mean(jnp.binary_crossentropy(real_gt, real_pred))

    fake = get_sample(generator, real, configs["loss_params"])
    fake = instance_noise(configs, epoch_num, fake)
    fake_pred = discriminator(fake)
    fake_pred = top_k(configs, epoch_num, fake_pred)
    fake_gt = jnp.zeros_like(fake_pred)
    fake_loss = jnp.mean(jnp.binary_crossentropy(fake_gt, fake_pred))

    return real_loss + fake_loss

def gen_loss(configs: dict, discriminator: Callable, generator: Callable, epoch_num: int, real: jnp.ndarray) -> jnp.ndarray:
    fake = get_sample(generator, real, configs["loss_params"])
    fake = instance_noise(configs, epoch_num, fake)
    fake_pred = discriminator(fake)
    fake_pred = top_k(configs, epoch_num, fake_pred)
    fake_gt = jnp.ones_like(fake_pred)
    return jnp.mean(jnp.binary_crossentropy(fake_gt, fake_pred))