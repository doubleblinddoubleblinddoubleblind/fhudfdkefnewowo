#!/usr/bin/python
# coding: utf-8

import argparse
import jax
import jax.numpy as jnp
import flax.linen as nn
from jax import random, grad, jit, vmap
from flax import optim, traverse_util
from torchvision import datasets, transforms
from torchvision.transforms import ToTensor, Normalize
import numpy as np
import optax

def seed(args):
    jax.random.PRNGKey(args.seed)

def load_train(args):
    transform = transforms.Compose([
        ToTensor(),
        Normalize((0.1307,), (0.3081,))
    ])
    
    train_dataset = datasets.MNIST('../data', train=True, download=True, transform=transform)
    test_dataset = datasets.MNIST('../data', train=False, transform=transform)

    train_loader = jax.device_put(train_dataset)
    test_loader = jax.device_put(test_dataset)
    return train_loader, test_loader

class Net(nn.Module):
    @nn.compact
    def __call__(self, x, train=True):
        x = nn.Conv(10, kernel_size=(5, 5), padding='SAME')(x)
        x = nn.relu(nn.max_pool(x, (2, 2)))
        x = nn.Conv(20, kernel_size=(5, 5), padding='SAME')(x)
        x = nn.dropout(x, rate=0.5, deterministic=not train)
        x = nn.relu(nn.max_pool(x, (2, 2)))
        x = x.reshape((x.shape[0], -1))
        x = nn.relu(nn.Dense(50)(x))
        x = nn.dropout(x, rate=0.5, deterministic=not train)
        x = nn.Dense(10)(x)
        return nn.log_softmax(x)

def get_model():
    model = Net()
    return model

@jit
def loss_fn(params, model, x, y):
    logits = model.apply(params, x, train=True)
    return -jnp.mean(jax.nn.log_softmax(logits)[jnp.arange(len(y)), y])

@jit
def update(params, x, y, opt):
    grads = grad(loss_fn)(params, model, x, y)
    return opt.update(grads, params)

def train(args, epoch, model, train_loader, optimizer):
    for batch_idx, (data, target) in enumerate(train_loader):
        data = jnp.array(data)
        target = jnp.array(target)
        
        optimizer = update(optimizer.target, data, target, optimizer)
        
        if batch_idx % args.log_interval == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]'.format(
                epoch, batch_idx * len(data), len(train_loader),
                100. * batch_idx / len(train_loader)))

def test(args, epoch, model, test_loader):
    test_loss = 0
    correct = 0
    
    for data, target in test_loader:
        data = jnp.array(data)
        target = jnp.array(target)
        output = model.apply(model.params, data, train=False)
        test_loss += -jnp.mean(jax.nn.log_softmax(output)[jnp.arange(len(target)), target])
        pred = jnp.argmax(output, axis=1)
        correct += jnp.sum(pred == target)

    test_loss = test_loss / len(test_loader)
    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss, correct, len(test_loader), 
        100. * correct / len(test_loader)))

def main():
    parser = argparse.ArgumentParser(description='JAX MNIST Example')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=10, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='enables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    args = parser.parse_args()

    seed(args)

    train_loader, test_loader = load_train(args)

    model = get_model()
    optimizer = optim.create(optim.Adam(learning_rate=args.lr))

    for epoch in range(1, args.epochs + 1):
        train(args, epoch, model, train_loader, optimizer)
        test(args, epoch, model, test_loader)

if __name__ == '__main__':
    main()