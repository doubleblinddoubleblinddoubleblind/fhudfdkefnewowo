import jax
import jax.numpy as jnp
from flax import linen as nn
from jax import random