# Copyright (c) OpenMMLab. All rights reserved.
import bisect
import os.path as osp

import jax
import jax.numpy as jnp
from flax import struct
from flax.training import train_state

def _calc_dynamic_intervals(start_interval, dynamic_interval_list):
    assert isinstance(dynamic_interval_list, list)

    dynamic_milestones = [0]
    dynamic_milestones.extend(
        [dynamic_interval[0] for dynamic_interval in dynamic_interval_list])
    dynamic_intervals = [start_interval]
    dynamic_intervals.extend(
        [dynamic_interval[1] for dynamic_interval in dynamic_interval_list])
    return dynamic_milestones, dynamic_intervals

class EvalHook:
    
    def __init__(self, interval, dynamic_intervals=None):
        self.interval = interval
        self.use_dynamic_intervals = dynamic_intervals is not None
        if self.use_dynamic_intervals:
            self.dynamic_milestones, self.dynamic_intervals = \
                _calc_dynamic_intervals(self.interval, dynamic_intervals)

    def _decide_interval(self, runner):
        if self.use_dynamic_intervals:
            progress = runner.epoch if self.by_epoch else runner.iter
            step = bisect.bisect(self.dynamic_milestones, (progress + 1))
            # Dynamically modify the evaluation interval
            self.interval = self.dynamic_intervals[step - 1]

    def before_train_epoch(self, runner):
        """Evaluate the model only at the start of training by epoch."""
        self._decide_interval(runner)
        # Call to super method would need to be handled by a separate system

    def before_train_iter(self, runner):
        self._decide_interval(runner)
        # Call to super method would need to be handled by a separate system

    def _do_evaluate(self, runner):
        """perform evaluation and save ckpt."""
        if not self._should_evaluate(runner):
            return

        from mmdet.apis import single_device_test
        results = single_device_test(runner.model, self.dataloader, show=False)
        runner.log_buffer.output['eval_iter_num'] = len(self.dataloader)
        key_score = self.evaluate(runner, results)
        if self.save_best and key_score:
            self._save_ckpt(runner, key_score)

class DistEvalHook(EvalHook):

    def __init__(self, interval, dynamic_intervals=None):
        super().__init__(interval, dynamic_intervals)

    def _do_evaluate(self, runner):
        # Handling broadcast for BatchNorm's buffers
        if self.broadcast_bn_buffer:
            model = runner.model
            for name, module in model.named_modules():
                if isinstance(module, flax.linen.BatchNorm) and module.track_running_stats:
                    jax.tree_util.tree_map(lambda v: jax.device_put(v, device=jax.devices('gpu')[0]), module.running_var)
                    jax.tree_util.tree_map(lambda m: jax.device_put(m, device=jax.devices('gpu')[0]), module.running_mean)

        if not self._should_evaluate(runner):
            return

        tmpdir = self.tmpdir
        if tmpdir is None:
            tmpdir = osp.join(runner.work_dir, '.eval_hook')

        from mmdet.apis import multi_device_test
        results = multi_device_test(
            runner.model,
            self.dataloader,
            tmpdir=tmpdir,
            gpu_collect=self.gpu_collect)
        if runner.rank == 0:
            print('\n')
            runner.log_buffer.output['eval_iter_num'] = len(self.dataloader)
            key_score = self.evaluate(runner, results)

            if self.save_best and key_score:
                self._save_ckpt(runner, key_score)