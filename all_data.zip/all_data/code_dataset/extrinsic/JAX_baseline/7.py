#!/usr/bin/env python

import jax
import jax.numpy as jnp
from flax import linen as nn
from flax import optim
from torchvision import models
import functools

def Qestimator_resnet18(num_label):
    model_ft = models.resnet18(weights='DEFAULT')
    num_ftrs = model_ft.fc.in_features
    model_ft.fc = nn.Dense(num_label)
    return model_ft

class Qestimator_naive(nn.Module):
    num_label: int
    input_h: int

    def setup(self):
        self.conv1 = nn.Conv(16, kernel_size=(5, 5), strides=(2, 2))
        self.bn1 = nn.BatchNorm(use_running_average=True)
        self.conv2 = nn.Conv(32, kernel_size=(5, 5), strides=(2, 2))
        self.bn2 = nn.BatchNorm(use_running_average=True)
        self.conv3 = nn.Conv(32, kernel_size=(5, 5), strides=(2, 2))
        self.bn3 = nn.BatchNorm(use_running_average=True)
        
        Hout = (((self.input_h - 4) / 2 - 4) / 2 - 4) / 2
        Flatten = int(32 * Hout**2)  # assuming square input
        self.head = nn.Dense(self.num_label)

    def __call__(self, x):
        x = nn.relu(self.bn1(self.conv1(x)))
        x = nn.relu(self.bn2(self.conv2(x)))
        x = nn.relu(self.bn3(self.conv3(x)))
        x = x.reshape(x.shape[0], -1)  # flatten
        return self.head(x)