import jax
import jax.numpy as jnp
import math

class Piecewise:
    def __init__(self, optimizer, lrs, milestones, last_epoch=-1):
        self.optimizer = optimizer
        assert len(milestones) + 1 == len(lrs)
        self.lrs = lrs
        self.milestones = milestones
        self.last_epoch = last_epoch
        
        gaps = [milestones[0]] + [m2 - m1 for m1, m2 in zip(milestones[:-1], milestones[1:])]
        self.linear_schedulers = [Linear(optimizer, lr1, lr2, m) for lr1, lr2, m in zip(lrs[:-1], lrs[1:], gaps)]
        self.milestone_index = 0
        self.current_sched = self.linear_schedulers[self.milestone_index]

    def get_lr(self):
        return self.current_sched.get_lr()

    def step(self, epoch=None):
        if epoch is None:
            epoch = self.last_epoch + 1

        self.last_epoch = epoch

        if self.last_epoch >= self.milestones[self.milestone_index]:
            self.milestone_index += 1
            self.current_sched = self.linear_schedulers[self.milestone_index]
            epoch = 0

        return self.current_sched.step()

class Linear:
    def __init__(self, optimizer, start_lr, end_lr, interval_length, last_epoch=-1):
        self.optimizer = optimizer
        self.last_epoch = last_epoch
        
        if not isinstance(start_lr, (list, tuple)):
            self.start_lrs = [start_lr] * len(optimizer)
        else:
            if len(start_lr) != len(optimizer):
                raise ValueError("Expected {} lr_lambdas, but got {}".format(len(optimizer), len(start_lr)))
            self.start_lrs = list(start_lr)

        if not isinstance(end_lr, (list, tuple)):
            self.end_lrs = [end_lr] * len(optimizer)
        else:
            if len(end_lr) != len(optimizer):
                raise ValueError("Expected {} lr_lambdas, but got {}".format(len(optimizer), len(end_lr)))
            self.end_lrs = list(end_lr)

        self.lr_lambdas = [lambda epoch, a=a, b=b: a + epoch * (b - a) / interval_length for a, b in zip(self.start_lrs, self.end_lrs)]
        self.step()

    def get_lr(self):
        return [lmbda(self.last_epoch) for lmbda in self.lr_lambdas]

class CosineAnnealingLR:
    def __init__(self, optimizer, T_max, eta_min=0, last_epoch=-1):
        self.optimizer = optimizer
        self.T_max = T_max
        self.eta_min = eta_min
        self.base_lrs = [param['lr'] for param in optimizer]
        self.last_epoch = last_epoch
        self.step()

    def get_lr(self):
        return [self.eta_min + (base_lr - self.eta_min) * (1 + math.cos(math.pi * self.last_epoch / self.T_max)) / 2 for base_lr in self.base_lrs]