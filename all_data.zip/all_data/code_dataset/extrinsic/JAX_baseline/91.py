import jax
import jax.numpy as jnp
import jax.nn
from flax import linen as nn
from flax.training import train_state
import optax
from torchvision import datasets, transforms
from torch.utils.data import DataLoader

class Flatten(nn.Module):
    def setup(self):
        pass

    def __call__(self, x):
        return x.reshape((x.shape[0], -1))

class Net(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(32, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        x = nn.Conv(64, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = nn.Dropout(rate=0.25)(x, deterministic=False)
        x = Flatten()(x)
        x = nn.Dense(128)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=0.5)(x, deterministic=False)
        x = nn.Dense(10)(x)
        return nn.log_softmax(x)

def create_train_state(rng, model, learning_rate):
    params = model.init(rng, jnp.ones((1, 1, 28, 28)))  
    tx = optax.adamw(learning_rate)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

def train(state, train_loader, epoch):
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = jnp.array(data), jnp.array(target)  # Move data to JAX
        def loss_fn(params):
            output = state.apply_fn({'params': params}, data)
            return -jnp.mean(jax.nn.log_softmax(output)[jnp.arange(target.shape[0]), target])

        grad_fn = jax.value_and_grad(loss_fn)
        loss, grads = grad_fn(state.params)
        state = state.apply_gradients(grads=grads)
        if batch_idx % 100 == 0:
            print('Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}'.format(
                epoch, batch_idx*len(data), len(train_loader.dataset),
                100. * batch_idx/len(train_loader), loss))

def test(state, test_loader):
    test_loss, correct = 0, 0
    for data, target in test_loader:
        data, target = jnp.array(data), jnp.array(target)  # Move data to JAX
        output = state.apply_fn({'params': state.params}, data)
        test_loss += -jnp.mean(jax.nn.log_softmax(output)[jnp.arange(target.shape[0]), target])
        pred = jnp.argmax(output, axis=1)
        correct += jnp.sum(pred == target)

    print('\nTest set: Average loss: {:.4f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        test_loss / len(test_loader.dataset), correct, len(test_loader.dataset),
        100. * correct / len(test_loader.dataset)))

batch_size, test_batch_size = 256, 512
epochs, lr = 1, 1e-2

transform = transforms.Compose([transforms.ToTensor(),
                                transforms.Normalize((0.1307,), (0.3081,))])
train_loader = DataLoader(
    datasets.MNIST('../data', train=True, download=True, transform=transform),
    batch_size=batch_size, shuffle=True)
test_loader = DataLoader(
    datasets.MNIST('../data', train=False, transform=transform),
    batch_size=test_batch_size, shuffle=True)

model = Net()
rng = jax.random.PRNGKey(0)
state = create_train_state(rng, model, lr)

if __name__ == '__main__':
    for epoch in range(1, epochs + 1):
        train(state, train_loader, epoch)
        test(state, test_loader)