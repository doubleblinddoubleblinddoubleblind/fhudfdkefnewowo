import numpy as np
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax

from mushroom_rl.algorithms.actor_critic import DDPG, TD3
from mushroom_rl.core import Core, Logger
from mushroom_rl.environments.gym_env import Gym
from mushroom_rl.policy import OrnsteinUhlenbeckPolicy
from mushroom_rl.utils.dataset import compute_J

from tqdm import trange


class CriticNetwork(nn.Module):
    n_features: int

    def setup(self):
        self.h1 = nn.Dense(self.n_features, kernel_init=nn.initializers.xavier_uniform(), kernel_fn=nn.initializers.kaiming_normal())
        self.h2 = nn.Dense(self.n_features, kernel_init=nn.initializers.xavier_uniform(), kernel_fn=nn.initializers.kaiming_normal())
        self.h3 = nn.Dense(1, kernel_init=nn.initializers.xavier_uniform())

    def __call__(self, state, action):
        state_action = jnp.concatenate((state, action), axis=-1)
        features1 = nn.relu(self.h1(state_action))
        features2 = nn.relu(self.h2(features1))
        q = self.h3(features2)
        return jnp.squeeze(q)


class ActorNetwork(nn.Module):
    n_features: int

    def setup(self):
        self.h1 = nn.Dense(self.n_features, kernel_init=nn.initializers.xavier_uniform(), kernel_fn=nn.initializers.kaiming_normal())
        self.h2 = nn.Dense(self.n_features, kernel_init=nn.initializers.xavier_uniform(), kernel_fn=nn.initializers.kaiming_normal())
        self.h3 = nn.Dense(self.output_shape[0], kernel_init=nn.initializers.xavier_uniform())

    def __call__(self, state):
        features1 = nn.relu(self.h1(jnp.squeeze(state, axis=1)))
        features2 = nn.relu(self.h2(features1))
        a = self.h3(features2)
        return a


def create_train_state(rng, model, learning_rate):
    params = model.init(rng, jnp.ones([1, 1]), jnp.ones([1, 1]))
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=optax.adam(learning_rate))


def experiment(alg, n_epochs, n_steps, n_steps_test):
    np.random.seed()

    logger = Logger(alg.__name__, results_dir=None)
    logger.strong_line()
    logger.info('Experiment Algorithm: ' + alg.__name__)

    # MDP
    horizon = 200
    gamma = 0.99
    mdp = Gym('Pendulum-v0', horizon, gamma)

    # Policy
    policy_class = OrnsteinUhlenbeckPolicy
    policy_params = dict(sigma=np.ones(1) * .2, theta=.15, dt=1e-2)

    # Settings
    initial_replay_size = 500
    max_replay_size = 5000
    batch_size = 200
    n_features = 80
    tau = .001

    # Approximator
    actor_input_shape = mdp.info.observation_space.shape
    actor_params = dict(network=ActorNetwork(n_features=n_features),
                        input_shape=actor_input_shape,
                        output_shape=mdp.info.action_space.shape)

    actor_optimizer = {'class': optax.adam,
                       'params': {'lr': .001}}

    critic_input_shape = (actor_input_shape[0] + mdp.info.action_space.shape[0],)
    critic_params = dict(network=CriticNetwork(n_features=n_features),
                         optimizer={'class': optax.adam,
                                    'params': {'lr': .001}},
                         loss=lambda x, y: jnp.mean((x - y) ** 2),
                         input_shape=critic_input_shape,
                         output_shape=(1,))

    # Agent
    agent = alg(mdp.info, policy_class, policy_params,
                actor_params, actor_optimizer, critic_params, batch_size,
                initial_replay_size, max_replay_size, tau)

    # Algorithm
    core = Core(agent, mdp)

    core.learn(n_steps=initial_replay_size, n_steps_per_fit=initial_replay_size)

    # RUN
    dataset = core.evaluate(n_steps=n_steps_test, render=False)
    J = np.mean(compute_J(dataset, gamma))
    R = np.mean(compute_J(dataset))

    logger.epoch_info(0, J=J, R=R)

    for n in trange(n_epochs, leave=False):
        core.learn(n_steps=n_steps, n_steps_per_fit=1)
        dataset = core.evaluate(n_steps=n_steps_test, render=False)
        J = np.mean(compute_J(dataset, gamma))
        R = np.mean(compute_J(dataset))

        logger.epoch_info(n + 1, J=J, R=R)

    logger.info('Press a button to visualize pendulum')
    input()
    core.evaluate(n_episodes=5, render=True)


if __name__ == '__main__':
    algs = [DDPG, TD3]

    for alg in algs:
        experiment(alg=alg, n_epochs=40, n_steps=1000, n_steps_test=2000)