import time
import os
from time import gmtime, strftime
from datetime import datetime
import jax
import jax.numpy as jnp
from jax import random, grad, pmap, vmap
import flax.linen as nn
import util
from dynamicplot import DynamicPlot

from grassdata import GRASSDataset
from grassmodel import GRASSEncoder
from grassmodel import GRASSDecoder
import grassmodel


config = util.get_args()

config.cuda = not config.no_cuda
if config.gpu < 0 and config.cuda:
    config.gpu = 0
if config.cuda:
    print("Using JAX on GPU ", config.gpu)
else:
    print("Not using JAX.")

encoder = GRASSEncoder(config)
decoder = GRASSDecoder(config)

print("Loading data ...... ", end='', flush=True)
grass_data = GRASSDataset(config.data_path)
train_iter = grass_data.get_loader(batch_size=config.batch_size, shuffle=True)
print("DONE")

encoder_opt = jax.experimental.optimizers.adam(1e-3)
decoder_opt = jax.experimental.optimizers.adam(1e-3)

print("Start training ...... ")

start = time.time()

if config.save_snapshot:
    if not os.path.exists(config.save_path):
        os.makedirs(config.save_path)
    snapshot_folder = os.path.join(config.save_path, 'snapshots_' + strftime("%Y-%m-%d_%H-%M-%S", gmtime()))
    if not os.path.exists(snapshot_folder):
        os.makedirs(snapshot_folder)

if config.save_log:
    fd_log = open('training_log.log', mode='a')
    fd_log.write('\n\nTraining log at ' + datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    fd_log.write('\n#epoch: {}'.format(config.epochs))
    fd_log.write('\nbatch_size: {}'.format(config.batch_size))
    fd_log.write('\ncuda: {}'.format(config.cuda))
    fd_log.flush()

header = '     Time    Epoch     Iteration    Progress(%)  ReconLoss  KLDivLoss  TotalLoss'
log_template = ' '.join('{:>9s},{:>5.0f}/{:<5.0f},{:>5.0f}/{:<5.0f},{:>9.1f}%,{:>11.2f},{:>10.2f},{:>10.2f}'.split(','))

total_iter = config.epochs * len(train_iter)

if not config.no_plot:
    plot_x = [x for x in range(total_iter)]
    plot_total_loss = [None for x in range(total_iter)]
    plot_recon_loss = [None for x in range(total_iter)]
    plot_kldiv_loss = [None for x in range(total_iter)]
    dyn_plot = DynamicPlot(title='Training loss over epochs (GRASS)', xdata=plot_x, ydata={'Total_loss': plot_total_loss, 'Reconstruction_loss': plot_recon_loss, 'KL_divergence_loss': plot_kldiv_loss})
    iter_id = 0
    max_loss = 0

def train_step(encoder_params, decoder_params, batch):
    enc_fold_nodes = [grassmodel.encode_structure_fold(encoder, example) for example in batch]
    enc_fold_nodes = jax.vmap(lambda x: encoder.apply(x))(enc_fold_nodes)
    enc_fold_nodes = [jnp.split(fnode, 2, axis=1) for fnode in enc_fold_nodes]

    dec_fold_nodes = [grassmodel.decode_structure_fold(decoder, root_code, example) for (root_code, _), example in zip(enc_fold_nodes, batch)]
    total_loss = jax.vmap(lambda x: decoder.apply(x))(dec_fold_nodes)

    recon_loss = total_loss[0].sum() / len(batch)
    kldiv_loss = total_loss[1].sum() * -0.05 / len(batch)
    total_loss = recon_loss + kldiv_loss

    return encoder_params, decoder_params, total_loss, recon_loss, kldiv_loss

for epoch in range(config.epochs):
    print(header)
    for batch_idx, batch in enumerate(train_iter):
        encoder_params, decoder_params, total_loss, recon_loss, kldiv_loss = train_step(encoder.params, decoder.params, batch)
        
        if batch_idx % config.show_log_every == 0:
            print(log_template.format(strftime("%H:%M:%S", time.gmtime(time.time() - start)),
                epoch, config.epochs, 1 + batch_idx, len(train_iter),
                100. * (1 + batch_idx + len(train_iter) * epoch) / (len(train_iter) * config.epochs),
                recon_loss.item(), kldiv_loss.item(), total_loss.item()))
        
        if not config.no_plot:
            plot_total_loss[iter_id] = total_loss.item()
            plot_recon_loss[iter_id] = recon_loss.item()
            plot_kldiv_loss[iter_id] = kldiv_loss.item()
            max_loss = max(max_loss, total_loss.item(), recon_loss.item(), kldiv_loss.item())
            dyn_plot.setxlim(0., (iter_id + 1) * 1.05)
            dyn_plot.setylim(0., max_loss * 1.05)
            dyn_plot.update_plots(ydata={'Total_loss': plot_total_loss, 'Reconstruction_loss': plot_recon_loss, 'KL_divergence_loss': plot_kldiv_loss})
            iter_id += 1

    if config.save_snapshot and (epoch + 1) % config.save_snapshot_every == 0:
        print("Saving snapshots of the models ...... ", end='', flush=True)
        jax.experimental.save(encoder, os.path.join(snapshot_folder,'vae_encoder_model_epoch_{}_loss_{:.2f}.pkl'.format(epoch+1, total_loss.item())))
        jax.experimental.save(decoder, os.path.join(snapshot_folder,'vae_decoder_model_epoch_{}_loss_{:.2f}.pkl'.format(epoch+1, total_loss.item())))
        print("DONE")
        
    if config.save_log and (epoch + 1) % config.save_log_every == 0:
        fd_log = open('training_log.log', mode='a')
        fd_log.write('\nepoch:{} recon_loss:{:.2f} kld_loss:{:.2f} total_loss:{:.2f}'.format(epoch + 1, recon_loss.item(), kldiv_loss.item(), total_loss.item()))
        fd_log.close()

print("Saving final models ...... ", end='', flush=True)
jax.experimental.save(encoder, os.path.join(config.save_path, 'vae_encoder_model.pkl'))
jax.experimental.save(decoder, os.path.join(config.save_path, 'vae_decoder_model.pkl'))
print("DONE")