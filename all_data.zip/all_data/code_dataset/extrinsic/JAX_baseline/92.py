import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from torchvision import datasets, transforms
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os

# Hyper Parameters
mb_size = 32
z_dim = 100
X_dim = 784
y_dim = 10
h_dim = 128
cnt = 0
d_step = 3
lr = 1e-3
m = 5

# Load Data
train_dataset = datasets.MNIST(root='./data',
                               train=True,
                               transform=transforms.ToTensor(),
                               download=True)

test_dataset = datasets.MNIST(root='./data',
                              train=False,
                              transform=transforms.ToTensor())

train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                           batch_size=mb_size,
                                           shuffle=True)

test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                          batch_size=mb_size,
                                          shuffle=False)

class _netG(nn.Module):
    @nn.compact
    def __call__(self, input):
        x = nn.conv_transpose(input, 28 * 28, (1, 1), strides=(1, 1), use_bias=False)
        x = nn.BatchNorm()(x)
        x = nn.relu(x)
        x = nn.conv_transpose(x, 14 * 14, (2, 2), strides=(2, 2), use_bias=False)
        x = nn.BatchNorm()(x)
        x = nn.relu(x)
        x = nn.conv_transpose(x, 7 * 7, (2, 2), strides=(2, 2), use_bias=False)
        x = nn.BatchNorm()(x)
        x = nn.relu(x)
        x = nn.conv_transpose(x, 1, (7, 7), strides=(7, 7), use_bias=False)
        return nn.sigmoid(x)

class _netD(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.conv(x, ngf, (3, 3), strides=(1, 1))
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2), strides=(2, 2))
        x = nn.conv(x, ngf * 2, (3, 3), strides=(1, 1))
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2), strides=(2, 2))
        x = nn.conv(x, ngf * 4, (3, 3), strides=(1, 1))
        x = nn.relu(x)
        x = nn.conv(x, nz, (3, 3), strides=(1, 1))
        return nn.relu(x)

def D(X):
    X_recon = D_(X)
    return jnp.mean(jnp.sum((X - X_recon)**2, axis=1))

@jax.jit
def reset_grad():
    G_params = G.init(jax.random.PRNGKey(0), jnp.ones((mb_size, z_dim, 1, 1))) 
    D_params = D_.init(jax.random.PRNGKey(0), jnp.ones((mb_size, nc, 28, 28))) 
    return G_params, D_params

D_ = _netD()
G = _netG()

G_params = G.init(jax.random.PRNGKey(0), jnp.ones((mb_size, z_dim, 1, 1)))
D_params = D_.init(jax.random.PRNGKey(0), jnp.ones((mb_size, nc, 28, 28)))

G_optimizer = optax.adam(lr)
D_optimizer = optax.adam(lr)

def train_step(G_params, D_params, images):
    Z = jax.random.normal(jax.random.PRNGKey(0), (mb_size, z_dim, 1, 1))
    X = images

    G_sample = G.apply(G_params, Z)
    D_real = D(X)
    D_fake = D(G_sample)
    
    D_loss = D_real + jax.nn.relu(m - D_fake)
    
    D_grads = jax.grad(lambda D_params: D_loss)(D_params)
    D_params = D_optimizer.update(D_grads, D_params)

    G_sample = G.apply(G_params, Z)
    D_fake = D(G_sample)

    G_loss = D_fake
    G_grads = jax.grad(lambda G_params: G_loss)(G_params)
    G_params = G_optimizer.update(G_grads, G_params)

    return G_params, D_params, D_loss, G_loss

# Training
iter_train = ((i, images) for i, (images, labels) in enumerate(train_loader))

for it in range(10000):
    try:
        (i, images) = next(iter_train)
    except StopIteration:
        iter_train = ((i, images) for i, (images, labels) in enumerate(train_loader))
        continue

    G_params, D_params, D_loss, G_loss = train_step(G_params, D_params, images)

    if it % 100 == 0:
        print('Iter-{}; D_loss: {:.4}; G_loss: {:.4}'.format(it, D_loss, G_loss))

        samples = G.apply(G_params, jax.random.normal(jax.random.PRNGKey(1), (16, z_dim, 1, 1)))

        fig = plt.figure(figsize=(4, 4))
        gs = gridspec.GridSpec(4, 4)
        gs.update(wspace=0.05, hspace=0.05)

        for i, sample in enumerate(samples):
            ax = plt.subplot(gs[i])
            plt.axis('off')
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax.set_aspect('equal')
            plt.imshow(sample.reshape(28, 28), cmap='Greys_r')

        dir_n = 'out_cnn_ebgan/'
        if not os.path.exists(dir_n):
            os.makedirs(dir_n)

        plt.savefig(dir_n + '{}.png'.format(str(cnt).zfill(3)), bbox_inches='tight')
        cnt += 1
        plt.close(fig)