import numpy as np
import pytest
import jax
import jax.numpy as jnp
from jax.nn import relu
from flax import linen as nn
from flax.core import FrozenDict
from flax.training import train_state
from typing import Tuple, Any


class StackedBidirectionalLstm(nn.Module):
    input_size: int
    hidden_size: int
    num_layers: int
    layer_dropout_probability: float = 0.0
    recurrent_dropout_probability: float = 0.0

    def setup(self):
        self.lstm_layers = [
            nn.LSTMCell(name=f'lstm_{i}') for i in range(self.num_layers)
        ]

    def __call__(self, inputs: jnp.ndarray, hidden: Tuple[jnp.ndarray, jnp.ndarray]) -> Tuple[jnp.ndarray, Tuple[jnp.ndarray, jnp.ndarray]]:
        for layer in self.lstm_layers:
            outputs, hidden = layer(hidden, inputs)
            inputs = outputs  # Pass the output to the next layer
        return outputs, hidden


class TestStackedBidirectionalLstm:
    def test_stacked_bidirectional_lstm_completes_forward_pass(self):
        input_tensor = jax.random.normal(jax.random.PRNGKey(0), (4, 5, 3))
        input_tensor = input_tensor.at[1, 4:, :].set(0.0)
        input_tensor = input_tensor.at[2, 2:, :].set(0.0)
        input_tensor = input_tensor.at[3, 1:, :].set(0.0)

        lengths = jnp.array([5, 4, 2, 1])
        packed_input = input_tensor[:lengths.max(), :]

        lstm = StackedBidirectionalLstm(input_size=3, hidden_size=7, num_layers=3)
        initial_hidden = (jnp.zeros((4, 7)), jnp.zeros((4, 7)))  # Initial hidden state
        output, _ = lstm(packed_input, initial_hidden)
        
        numpy.testing.assert_array_equal(output[1, 4:, :], 0.0)
        numpy.testing.assert_array_equal(output[2, 2:, :], 0.0)
        numpy.testing.assert_array_equal(output[3, 1:, :], 0.0)

    def test_stacked_bidirectional_lstm_can_build_from_params(self):
        params = {
            "type": "stacked_bidirectional_lstm",
            "input_size": 5,
            "hidden_size": 9,
            "num_layers": 3,
        }
        encoder = StackedBidirectionalLstm(**params)

        assert encoder.input_size == 5
        assert encoder.hidden_size * encoder.num_layers == 18

    def test_stacked_bidirectional_lstm_can_complete_forward_pass_seq2vec(self):
        params = {
            "type": "stacked_bidirectional_lstm",
            "input_size": 3,
            "hidden_size": 9,
            "num_layers": 3,
        }
        encoder = StackedBidirectionalLstm(**params)
        input_tensor = jax.random.normal(jax.random.PRNGKey(1), (4, 5, 3))
        mask = jnp.ones((4, 5), dtype=bool)
        
        initial_hidden = (jnp.zeros((4, 9)), jnp.zeros((4, 9)))  # Initial hidden state
        output, _ = encoder(input_tensor, initial_hidden)
        assert output.shape == (4, 18)

    @pytest.mark.parametrize(
        "dropout_name", ("layer_dropout_probability", "recurrent_dropout_probability")
    )
    def test_stacked_bidirectional_lstm_dropout_version_is_different(self, dropout_name: str):
        stacked_lstm = StackedBidirectionalLstm(input_size=10, hidden_size=11, num_layers=3)
        if dropout_name == "layer_dropout_probability":
            dropped_stacked_lstm = StackedBidirectionalLstm(
                input_size=10, hidden_size=11, num_layers=3, layer_dropout_probability=0.9
            )
        elif dropout_name == "recurrent_dropout_probability":
            dropped_stacked_lstm = StackedBidirectionalLstm(
                input_size=10, hidden_size=11, num_layers=3, recurrent_dropout_probability=0.9
            )
        else:
            raise ValueError("Do not recognise the following dropout name " f"{dropout_name}")
        
        initial_state = jax.random.normal(jax.random.PRNGKey(2), (3, 5, 11))
        initial_memory = jax.random.normal(jax.random.PRNGKey(3), (3, 5, 11))

        tensor = jax.random.normal(jax.random.PRNGKey(4), (5, 7, 10))
        sequence_lengths = jnp.array([7, 7, 7, 7, 7])

        lstm_input = tensor[:sequence_lengths.max(), :]

        stacked_output, stacked_state = stacked_lstm(lstm_input, (initial_state, initial_memory))
        dropped_output, dropped_state = dropped_stacked_lstm(lstm_input, (initial_state, initial_memory))

        if dropout_name == "layer_dropout_probability":
            with pytest.raises(AssertionError):
                jnp.testing.assert_array_almost_equal(dropped_output, stacked_output, decimal=4)
        if dropout_name == "recurrent_dropout_probability":
            with pytest.raises(AssertionError):
                jnp.testing.assert_array_almost_equal(dropped_state[0], stacked_state[0], decimal=4)
            with pytest.raises(AssertionError):
                jnp.testing.assert_array_almost_equal(dropped_state[1], stacked_state[1], decimal=4)