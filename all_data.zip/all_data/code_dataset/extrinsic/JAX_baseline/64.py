import jax
import jax.numpy as jnp
from flax import linen as nn
from jax.nn import softmax, relu
from jax import random

################################################################################
# Modules #
################################################################################

class StackedBRNN(nn.Module):
    input_size: int
    hidden_size: int
    num_layers: int
    dropout_rate: float = 0.0
    dropout_output: bool = False
    variational_dropout: bool = False
    rnn_type: nn.Module = nn.LSTM
    concat_layers: bool = False
    padding: bool = False
    bidirectional: bool = True
    return_single_timestep: bool = False

    def setup(self):
        self.rnns = []
        for i in range(self.num_layers):
            input_size = self.input_size if i == 0 else (2 * self.hidden_size if self.bidirectional else self.hidden_size)
            self.rnns.append(self.rnn_type(name=f"rnn_{i}", input_size=input_size, hidden_size=self.hidden_size))
    
    def __call__(self, x, x_mask, training):
        if self.padding or self.return_single_timestep or not training:
            return self._forward_padded(x, x_mask, training)
        return self._forward_unpadded(x, x_mask, training)

    def _forward_unpadded(self, x, x_mask, training):
        outputs = [x]
        for i in range(self.num_layers):
            rnn_input = outputs[-1]
            rnn_input = dropout(rnn_input, self.dropout_rate, training)
            rnn_output = self.rnns[i](rnn_input)
            outputs.append(rnn_output)

        if self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=2)
        else:
            output = outputs[-1]

        if self.dropout_output:
            output = dropout(output, self.dropout_rate, training)
        return output

    def _forward_padded(self, x, x_mask, training):
        lengths = jnp.sum(x_mask == 0, axis=1)
        idx_sort = jnp.argsort(lengths, axis=0)[::-1]
        idx_unsort = jnp.argsort(idx_sort)

        lengths = lengths[idx_sort]
        rnn_input = x[idx_sort]

        outputs, single_outputs = [rnn_input], []
        for i in range(self.num_layers):
            rnn_input = outputs[-1]
            if self.dropout_rate > 0:
                rnn_input = dropout(rnn_input, self.dropout_rate, training)
            rnn_input = self.rnns[i].pack(rnn_input, lengths)
            rnn_output, (hn, _) = self.rnns[i](rnn_input)
            rnn_output = self.rnns[i].unpack(rnn_output)
            single_outputs.append(hn[-1])
            outputs.append(rnn_output)

        if self.return_single_timestep:
            output = single_outputs[-1]
        elif self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=2)
        else:
            output = outputs[-1]

        output = output[idx_unsort]

        if self.dropout_output and self.dropout_rate > 0:
            output = dropout(output, self.dropout_rate, training)
        return output


class SeqAttnMatch(nn.Module):
    input_size: int
    identity: bool = False

    def setup(self):
        self.linear = nn.Dense(self.input_size) if not self.identity else None

    def __call__(self, x, y, y_mask):
        if self.linear:
            x_proj = relu(self.linear(x))
            y_proj = relu(self.linear(y))
        else:
            x_proj = x
            y_proj = y

        scores = jnp.einsum('ijk,ikl->ijl', x_proj, jnp.transpose(y_proj, (0, 2, 1)))
        y_mask = jnp.expand_dims(y_mask, 1).repeat(scores.shape[1], axis=1)
        scores = jnp.where(y_mask, -jnp.inf, scores)

        alpha = softmax(scores, axis=-1)
        matched_seq = jnp.einsum('ijk,ikl->ijl', alpha, y)
        return matched_seq


class BilinearSeqAttn(nn.Module):
    x_size: int
    y_size: int
    identity: bool = False

    def setup(self):
        self.linear = nn.Dense(self.x_size) if not self.identity else None

    def __call__(self, x, y, x_mask):
        Wy = self.linear(y) if self.linear is not None else y
        xWy = jnp.einsum('ijk,ik->ij', x, Wy)
        xWy = jnp.where(x_mask, -jnp.inf, xWy)
        alpha = softmax(xWy, axis=-1)
        return alpha


class LinearSeqAttn(nn.Module):
    input_size: int

    def setup(self):
        self.linear = nn.Dense(1)

    def __call__(self, x, x_mask):
        x_flat = x.reshape(-1, x.shape[-1])
        scores = self.linear(x_flat).reshape(x.shape[0], x.shape[1])
        scores = jnp.where(x_mask, -jnp.inf, scores)
        alpha = softmax(scores, axis=-1)
        return alpha

################################################################################
# Functional #
################################################################################

def dropout(x, drop_prob, training):
    if drop_prob == 0 or not training:
        return x
    mask = random.bernoulli(random.PRNGKey(0), p=1. - drop_prob, shape=x.shape)
    mask = mask / (1. - drop_prob)
    return x * mask

def multi_nll_loss(scores, target_mask):
    scores = jnp.exp(scores)
    loss = 0
    for i in range(scores.shape[0]):
        loss += -jnp.log(jnp.sum(jnp.where(target_mask[i], scores[i], 0.)) / jnp.sum(scores[i]))
    return loss

def uniform_weights(x, x_mask):
    raise NotImplementedError

def weighted_avg(x, weights):
    return jnp.einsum('ij,ik->i', weights, x)