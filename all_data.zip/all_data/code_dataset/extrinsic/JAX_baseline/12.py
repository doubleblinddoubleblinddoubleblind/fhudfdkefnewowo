import jax
import jax.numpy as jnp
from jax import grad, jit
from jax import random

from modules.nnd import NNDModule

dist = NNDModule()

key = random.PRNGKey(0)
p1 = random.randn(key, 10, 1000, 3)
p2 = random.randn(key, 10, 1500, 3)
points1 = jax.device_put(p1)  
points2 = jax.device_put(p2)

def compute_loss(points1, points2):
    dist1, dist2 = dist(points1, points2)
    loss = jnp.sum(dist1)
    return loss, dist1, dist2

loss, dist1, dist2 = compute_loss(points1, points2)
print(dist1, dist2)
print(loss)

# Gradient calculation
loss_grad = grad(compute_loss, argnums=0)(points1, points2)[0]
print(loss_grad)

# Moving to GPU
points1 = jax.device_put(p1)  
points2 = jax.device_put(p2)  

loss, dist1, dist2 = compute_loss(points1, points2)
print(dist1, dist2)
print(loss)

# Gradient calculation after moving to GPU
loss_grad = grad(compute_loss, argnums=0)(points1, points2)[0]
print(loss_grad)