from model import cosine_sim
from evaluation import encode_data
import jax.numpy as jnp
import jax.random as jrandom
import random
import heapq
import scipy
import numpy as np
import sys

def select_random(r, model, train_loader):
    if r == 0:
        return random.sample(range(0, len(train_loader.dataset)), 1280)
    else:
        return random.sample(range(0, len(train_loader.dataset)), 128)

def select_margin(r, model, train_loader, primary="image"):
    if r == 0:
        return random.sample(range(0, len(train_loader.dataset)), 1280)
    else:
        model.val_start()
        img_embs, cap_embs = encode_data(model, train_loader)
        primary_embs, secondary_embs = (img_embs, cap_embs) if primary == "image" else (cap_embs, img_embs)

        scores = []

        for i in range(0, len(primary_embs), 128):
            batch_range = min(128, len(primary_embs) - i)
            primary_batch = primary_embs[i: i + batch_range]
            
            primary_secondary_distances = None

            for j in range(0, len(secondary_embs), 128):
                batch_range2 = min(128, len(secondary_embs) - j)
                secondary_batch = secondary_embs[j: j + batch_range2]

                cosine_dist = jnp.dot(primary_batch, secondary_batch.T)

                if j == 0:
                    primary_secondary_distances = cosine_dist
                else:
                    primary_secondary_distances = jnp.concatenate((primary_secondary_distances, cosine_dist), axis=1)

            distances_top2 = jnp.abs(jnp.take_along_axis(primary_secondary_distances, jnp.argsort(primary_secondary_distances, axis=1)[:, :2], axis=1))
            margin = jnp.abs(distances_top2[:, 0] - distances_top2[:, 1])

            scores.extend(margin.tolist())
            print('Selection: {:2.4}%\r'.format((float(i) / float(len(primary_embs))) * 100))

        best_n_indices = [n[0] for n in heapq.nsmallest(128, enumerate(scores), key=lambda x: x[1])]
        return best_n_indices

def select_captionSimilarity(r, model, train_loader, primary="image"):
    if r == 0:
        return random.sample(range(0, len(train_loader.dataset)), 1280)
    else:
        model.val_start()
        img_embs, cap_embs = encode_data(model, train_loader)
        primary_embs, secondary_embs = (img_embs, cap_embs) if primary == "image" else (cap_embs, img_embs)

        scores = []

        for i in range(0, len(cap_embs), 5):
            batch_range = min(5, len(cap_embs) - i)
            primary_batch = cap_embs[i: i + batch_range]
            primary_batch_sum = get_avg_distance(primary_batch)
            scores.append(primary_batch_sum)

        best_n_indices = [n[0] for n in heapq.nsmallest(128, enumerate(scores), key=lambda x: x[1])]
        print(best_n_indices)

        return best_n_indices

def get_avg_distance(caption_set):
    average_cap_vector = jnp.mean(caption_set, axis=0)
    cosine_dist = jnp.dot(average_cap_vector, caption_set.T)
    average_distance = jnp.sum(cosine_dist)
    return average_distance

def select_uncertainty(r, model, train_loader, primary="image"):
    if r == 0:
        return random.sample(range(0, len(train_loader.dataset)), 1280)
    else:
        model.val_start()
        img_embs, cap_embs = encode_data(model, train_loader)
        primary_embs, secondary_embs = (img_embs, cap_embs) if primary == "image" else (cap_embs, img_embs)

        scores = []

        for i in range(0, len(primary_embs), 128):
            batch_range = min(128, len(primary_embs) - i)
            primary_batch = primary_embs[i: i + batch_range]

            for j in range(0, len(secondary_embs), 128):
                batch_range2 = min(128, len(secondary_embs) - j)
                secondary_batch = secondary_embs[j: j + batch_range2]

                cosine_dist = jnp.dot(primary_batch, secondary_batch.T)

                if j == 0:
                    primary_secondary_distances = cosine_dist
                else:
                    primary_secondary_distances = jnp.concatenate((primary_secondary_distances, cosine_dist), axis=1)

            distances_top10_index = jnp.abs(jnp.argsort(primary_secondary_distances, axis=1)[:, :10])

            for row in distances_top10_index.tolist():
                std = np.array([])

                for caption_index in row:
                    std = np.concatenate((std, secondary_embs[caption_index]))
                scores.append(np.std(std))
            print('Selection: {:2.4}%\r'.format((float(i) / float(len(primary_embs))) * 100))

        best_n_indices = [n[0] for n in heapq.nlargest(128, enumerate(scores), key=lambda x: x[1])]
        return best_n_indices

def select_hybrid(r, model, train_loader):
    if r == 0:
        return random.sample(range(0, len(train_loader.dataset)), 1280)
    elif r % 2 == 0:
        return select_uncertainty(r, model, train_loader)
    else:
        return select_margin(r, model, train_loader)

def select_all(r, model, train_loader):
    if r == 0:
        size = ((len(train_loader)*128)-128)
        return range(0, size)
    else:
        sys.exit("Done!")