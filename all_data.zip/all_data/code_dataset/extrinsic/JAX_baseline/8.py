import jax
import jax.numpy as jnp
import flax.linen as nn
from flax import optim
import argparse
import os
import random
import time

from helpers import *
from model import *
from generate import *

# Parse command line arguments
argparser = argparse.ArgumentParser()
argparser.add_argument('filename', type=str)
argparser.add_argument('--n_epochs', type=int, default=2000)
argparser.add_argument('--print_every', type=int, default=100)
argparser.add_argument('--hidden_size', type=int, default=50)
argparser.add_argument('--n_layers', type=int, default=2)
argparser.add_argument('--learning_rate', type=float, default=0.01)
argparser.add_argument('--chunk_len', type=int, default=200)
args = argparser.parse_args()

file, file_len = read_file(args.filename)

def random_training_set(chunk_len):
    start_index = random.randint(0, file_len - chunk_len)
    end_index = start_index + chunk_len + 1
    chunk = file[start_index:end_index]
    inp = char_tensor(chunk[:-1])
    target = char_tensor(chunk[1:])
    return inp, target

decoder = RNN(n_characters, args.hidden_size, n_characters, args.n_layers)
decoder_optimizer = optim.Adam(learning_rate=args.learning_rate).create(decoder)
loss_fn = jax.nn.softmax_cross_entropy

start = time.time()
all_losses = []
loss_avg = 0

@jax.jit
def train(inp, target, state):
    def loss_fn(params):
        hidden = state.hidden
        loss = 0
        for c in range(args.chunk_len):
            output, hidden = decoder.apply({'params': params}, inp[c], hidden)
            loss += jnp.sum(loss_fn(target[c], output))
        return loss / args.chunk_len

    grad_fn = jax.value_and_grad(loss_fn)
    loss, grads = grad_fn(decoder_optimizer.target)
    decoder_optimizer = decoder_optimizer.apply_gradient(grads)
    return loss, decoder_optimizer, state.replace(hidden=hidden)

state = decoder.initialize_carry(jax.random.PRNGKey(0), 1, args.n_layers, args.hidden_size)

try:
    print("Training for %d epochs..." % args.n_epochs)
    for epoch in range(1, args.n_epochs + 1):
        inp, target = random_training_set(args.chunk_len)
        loss, decoder_optimizer, state = train(inp, target, state)
        loss_avg += loss

        if epoch % args.print_every == 0:
            print('[%s (%d %d%%) %.4f]' % (time_since(start), epoch, epoch / args.n_epochs * 100, loss))
            print(generate(decoder, 'Wh', 100), '\n')

    print("Saving...")
    save_filename = os.path.splitext(os.path.basename(args.filename))[0] + '.flax'
    with open(save_filename, 'wb') as f:
        f.write(decoder_optimizer.target)

except KeyboardInterrupt:
    print("Saving before quit...")
    save()