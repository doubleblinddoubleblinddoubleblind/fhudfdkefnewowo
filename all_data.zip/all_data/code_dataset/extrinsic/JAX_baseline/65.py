import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import numpy as np

class CategoricalMLPPolicy(nn.Module):
    observation_dim: int
    num_actions: int
    hidden_sizes: tuple = (32, 32)
    hidden_nonlinearity: nn.Module = nn.tanh

    def setup(self):
        sizes = [self.observation_dim] + list(self.hidden_sizes)
        self.layers = []
        for index, size in enumerate(sizes):
            if index != len(sizes) - 1:
                self.layers.append(nn.Dense(sizes[index + 1]))
    
    def __call__(self, observations):
        x = observations
        for layer in self.layers:
            x = self.hidden_nonlinearity(layer(x))
        logits = jax.nn.Dense(self.num_actions)(x)
        prob = jax.nn.softmax(logits)
        return prob

    def get_action(self, observation, deterministic=False):
        prob = self.__call__(jnp.array(observation))
        if deterministic:
            action = jnp.argmax(prob)
        else:
            action = jax.random.choice(jax.random.PRNGKey(0), self.num_actions, p=prob)
        return action, {'prob': prob}

    def get_internal_params(self):
        return self.params

    def get_internal_named_params(self):
        return self.named_params

    def get_policy_distribution(self, obs):
        prob = self.__call__(obs)
        return Categorical.from_dict(prob)

    def distribution(self, dist_info):
        prob = dist_info['prob']
        return Categorical.from_dict(prob)

# Categorical distribution class definition needs to be completed separately based on requirements.