import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax
from jax import random, grad, jit, vmap

class Autoencoder(nn.Module):
    encoder: nn.Module
    decoder: nn.Module

    def __call__(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded

class AE:
    defaults = {
        'data': {
            'batch_size': {'train': 64, 'test': 64},
            'inputs': {'inputs': 'images'}
        },
        'optimizer': {
            'optimizer': 'Adam',
            'learning_rate': 1e-4
        },
        'train': {
            'save_on_lowest': 'losses.ae'
        }
    }

    def __init__(self):
        self.nets = {}

    def build(self, dim_z=64, dim_encoder_out=64):
        encoder = nn.Sequential([
            nn.Dense(256),
            nn.relu,
            nn.Dense(28),
            nn.relu
        ])
        decoder = nn.Sequential([
            nn.Dense(256),
            nn.relu,
            nn.Dense(28),
            nn.sigmoid
        ])
        self.nets['ae'] = Autoencoder(encoder=encoder, decoder=decoder)

    def routine(self, inputs):
        encoded = self.nets['ae'].encoder(inputs)
        outputs = self.nets['ae'].decoder(encoded)
        r_loss = jnp.mean((outputs - inputs) ** 2)
        self.losses = {'ae': r_loss}

    def visualize(self, inputs):
        encoded = self.nets['ae'].encoder(inputs)
        outputs = self.nets['ae'].decoder(encoded)
        self.add_image(outputs, name='reconstruction')
        self.add_image(inputs, name='ground truth')

    def add_image(self, images, name):
        # Placeholder function to match the original functionality
        pass

def run(model):
    # Placeholder function to simulate running the model
    pass

if __name__ == '__main__':
    autoencoder = AE()
    autoencoder.build()
    run(model=autoencoder)