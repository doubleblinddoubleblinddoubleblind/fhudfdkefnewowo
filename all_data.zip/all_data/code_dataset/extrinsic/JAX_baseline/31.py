#
#   Base lightnet network module structure
#   Copyright EAVISE
#

import jax
import jax.numpy as jnp
import flax.linen as nn
import time
import logging as log

__all__ = ['Lightnet']


class Lightnet(nn.Module):
    """ This class provides an abstraction layer on top of :class:`flax.linen.Module` and is used as a base for every network implemented in this framework.
    There are 2 basic ways of using this class:

    - Override the ``__call__`` function.
      This makes :class:`lightnet.network.Lightnet` networks behave just like JAX modules.
    - Define ``self.loss`` and ``self.postprocess`` as functions and override the ``_forward()`` function.
      This class will then automatically call the loss and postprocess functions on the output of ``_forward()``,
      depending whether the network is training or evaluating.

    Attributes:
        self.seen (int): The number of images the network has processed to train *(used by engine)*

    Note:
        If you define **self.layers** as a :class:`flax.linen.Sequential` or :class:`flax.linen.ModuleList`,
        the default ``_forward()`` function can use these layers automatically to run the network.

    Warning:
        If you use your own ``__call__`` function, you need to update the **self.seen** parameter
        whenever the network is training.
    """
    layers: nn.Module = None
    loss: list = None
    postprocess: list = None
    seen: int = 0
    training: bool = True

    def _forward(self, x):
        log.debug('Running default forward functions')
        if isinstance(self.layers, nn.Sequential):
            return self.layers(x)
        elif isinstance(self.layers, list):
            log.warning('No _forward function defined, looping sequentially over modulelist')
            for module in self.layers:
                x = module(x)
            return x
        else:
            raise NotImplementedError(f'No _forward function defined and no default behaviour for this type of layers [{type(self.layers)}]')

    def __call__(self, x, target=None):
        """ This default call function will compute the output of the network as ``self._forward(x)``.
        Then, depending on whether you are training or evaluating, it will pass that output to ``self.loss()`` or ``self.postprocess()``. |br|
        This function also increments the **self.seen** variable.

        Args:
            x (jax.numpy.ndarray): Input variable
            target (jax.numpy.ndarray, optional): Target for the loss function; Required if training and optional otherwise (see note)

        Note:
            If you are evaluating your network and you pass a target variable, the network will return a (output, loss) tuple.
            This is useful for testing your network, as you usually want to know the validation loss.
        """
        if self.training:
            self.seen += x.shape[0]
            t1 = time.time()
            outputs = self._forward(x)
            t2 = time.time()

            assert len(outputs) == len(self.loss)

            loss = 0
            for idx in range(len(outputs)):
                assert callable(self.loss[idx])
                t1 = time.time()
                loss += self.loss[idx](outputs[idx], target)
                t2 = time.time()
            return loss
        else:
            outputs = self._forward(x)
            loss = None
            dets = []

            tdets = []
            for idx in range(len(outputs)):
                assert callable(self.postprocess[idx])
                tdets.append(self.postprocess[idx](outputs[idx]))

            batch = len(tdets[0])
            for b in range(batch):
                single_dets = []
                for op in range(len(outputs)):
                    single_dets.extend(tdets[op][b])
                dets.append(single_dets)

            if loss is not None:
                return dets, loss
            else:
                return dets, 0.0

    def modules_recurse(self, mod=None):
        """ This function will recursively loop over all module children.

        Args:
            mod (flax.linen.Module, optional): Module to loop over; Default **self**
        """
        if mod is None:
            mod = self

        for module in mod.children():
            if isinstance(module, (nn.ModuleList, nn.Sequential)):
                yield from self.modules_recurse(module)
            else:
                yield module

    def init_weights(self, mode='fan_in', slope=0):
        info_list = []
        for m in self.modules():
            if isinstance(m, nn.Conv):
                info_list.append(str(m))
                nn.initializers.kaiming_normal(m.weight, a=slope, mode=mode)
                if m.bias is not None:
                    m.bias = nn.initializers.Constant(0)
            elif isinstance(m, nn.BatchNorm):
                info_list.append(str(m))
                m.weight = nn.initializers.Constant(1)
                m.bias = nn.initializers.Constant(0)
            elif isinstance(m, nn.Dense):
                info_list.append(str(m))
                m.weight = nn.initializers.Normal(0, 0.01)
                m.bias = nn.initializers.Constant(0)
        log.info('Init weights\n\n%s\n' % '\n'.join(info_list))

    def load_weights(self, weights_file, clear=False):
        """ This function will load the weights from a file.
        It also allows to load in weights file with only a part of the weights in.

        Args:
            weights_file (str): path to file
        """
        old_state = self.state_dict()
        state = jax.tree_util.tree_map(lambda x: jnp.array(x), jax.jax_utils.load(weights_file))
        self.seen = 0 if clear else state['seen']
        self.load_state_dict(state['weights'])

        if getattr(self.loss, 'seen', None) is not None:
            self.loss.seen = self.seen

        log.info(f'Loaded weights from {weights_file}')

    def save_weights(self, weights_file, seen=None):
        """ This function will save the weights to a file.

        Args:
            weights_file (str): path to file
            seen (int, optional): Number of images trained on; Default **self.seen**
        """
        if seen is None:
            seen = self.seen

        state = {
            'seen': seen,
            'weights': self.state_dict()
        }
        jax.jax_utils.save(state, weights_file)

        log.info(f'Saved weights as {weights_file}')