#
# Copyright 2016 The BigDL Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
from flax.training import checkpoints
from jax import random
import ray
import horovod.jax as hvd

from bigdl.chronos.model.tcmf.local_model import TemporalConvNet

# build data creator
def get_tcmf_data_loader(config):
    from bigdl.chronos.model.tcmf.data_loader import TCMFDataLoader
    tcmf_data_loader = TCMFDataLoader(
        Ymat=ray.get(config["Ymat_id"]),
        vbsize=config["vbsize"],
        hbsize=config["hbsize"],
        end_index=config["end_index"],
        val_len=config["val_len"],
        covariates=ray.get(config["covariates_id"]),
        Ycov=ray.get(config["Ycov_id"]),
    )
    return tcmf_data_loader

class TcmfTrainDatasetDist:
    def __init__(self, config):
        self.tcmf_data_loader = get_tcmf_data_loader(config)
        self.last_epoch = 0

    def __iter__(self):
        while self.tcmf_data_loader.epoch == self.last_epoch:
            yield self.get_next_batch()
        self.last_epoch += 1

    def get_next_batch(self):
        inp, out, _, _ = self.tcmf_data_loader.next_batch()
        if hvd.size() > 1:
            num_workers = hvd.size()
            per_worker = inp.shape[0] // num_workers
            inp_parts = jnp.split(inp, num_workers)
            out_parts = jnp.split(out, num_workers)
            worker_id = hvd.rank()
            inp = inp_parts[worker_id]
            out = out_parts[worker_id]
        return inp, out

class TcmfValDataset:
    def __init__(self, config):
        self.tcmf_data_loader = get_tcmf_data_loader(config)

    def __iter__(self):
        inp, out, _, _ = self.tcmf_data_loader.supply_test()
        yield inp, out

def data_creator(config):
    train_loader = iter(TcmfTrainDatasetDist(config))
    val_loader = iter(TcmfValDataset(config))
    return train_loader, val_loader

def train_data_creator(config):
    return iter(TcmfTrainDatasetDist(config))

def val_data_creator(config):
    return iter(TcmfValDataset(config))

# build loss creator
def tcmf_loss(out, target):
    return jnp.mean(jnp.abs(out - target)) / jnp.abs(target).mean()

def loss_creator(config):
    return tcmf_loss

# build optimizer creator
def create_optimizer(model, config):
    return train_state.TrainState.create(
        apply_fn=model.apply,
        params=model.init(random.PRNGKey(0)),
        tx=optimizers.adam(config["lr"]),
    )

# build model creator
def model_creator(config):
    return TemporalConvNet(
        num_inputs=config["num_inputs"],
        num_channels=config["num_channels"],
        kernel_size=config["kernel_size"],
        dropout=config["dropout"],
        init=True,
    )

def train_yseq_hvd(workers_per_node, epochs, **config):
    from bigdl.orca.learn.flax import Estimator
    estimator = Estimator.from_flax(
        model=model_creator,
        optimizer=create_optimizer,
        loss=loss_creator,
        workers_per_node=workers_per_node,
        config=config, backend="horovod")

    stats = estimator.fit(train_data_creator, epochs=epochs)
    for s in stats:
        for k, v in s.items():
            print(f"{k}: {v}")
    val_stats = estimator.evaluate(val_data_creator)
    val_loss = val_stats['val_loss']

    # retrieve the model
    yseq = estimator.get_model()
    estimator.shutdown()
    return yseq, val_loss