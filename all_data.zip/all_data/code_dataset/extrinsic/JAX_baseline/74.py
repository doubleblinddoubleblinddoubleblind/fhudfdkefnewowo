import jax.numpy as jnp
import jax
from flax import linen as nn
from flax import initializers


def init(module, weight_init, bias_init, gain=1):
    module.kernel = weight_init(module.kernel.shape, gain=gain)
    module.bias = bias_init(module.bias.shape)

    return module


class Flatten(nn.Module):
    def __call__(self, x):
        return x.reshape(x.shape[0], -1)


class CNNBase(nn.Module):
    num_inputs: int
    use_gru: bool

    @nn.compact
    def __call__(self, inputs, states, masks):
        init_ = lambda m: init(
            m,
            initializers.orthogonal(),
            initializers.constant(0),
            nn.initializers.variance_scaling(1.0, 'fan_in', 'truncated_normal')
        )

        x = init_(nn.Conv(features=32, kernel_size=(8, 8), strides=(4, 4)))(inputs / 255.0)
        x = nn.relu(x)
        x = init_(nn.Conv(features=64, kernel_size=(4, 4), strides=(2, 2)))(x)
        x = nn.relu(x)
        x = init_(nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1)))(x)
        x = nn.relu(x)
        x = Flatten()(x)
        x = init_(nn.Dense(features=512))(x)
        x = nn.relu(x)

        if self.use_gru:
            gru_cell = nn.GRUCell(name='gru')
            hidden_size = 512
            states = jnp.zeros((inputs.shape[0], hidden_size))

            if inputs.shape[0] == states.shape[0]:
                x, states = gru_cell(states * masks, x)
            else:
                x = x.reshape(-1, states.shape[0], x.shape[-1])
                masks = masks.reshape(-1, states.shape[0], 1)
                outputs = []

                for i in range(x.shape[0]):
                    hx, states = gru_cell(states * masks[i], x[i])
                    outputs.append(hx)

                x = jnp.concatenate(outputs, axis=0)

        critic_linear = init_(nn.Dense(1))
        return critic_linear(x), x, states


# Use this `CNNBase` class with an appropriate initialization to test it