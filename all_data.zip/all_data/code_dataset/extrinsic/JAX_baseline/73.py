# coding=utf-8
# Copyright 2022 The Google Research Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import jax
import jax.numpy as jnp
from jax import lax
from typing import Iterable

class RM3:
    """Implements RM3 (median of 3) algorithm.

    Args:
    params (iterable): iterable of parameters to optimize or dicts defining
      parameter groups
    lr (float): learning rate
    weight_decay (float, optional): weight decay (L2 penalty) (default: 0)
    """

    def __init__(self, params: Iterable, lr: float, weight_decay: float = 0):
        if lr < 0.0:
            raise ValueError('Invalid learning rate: {}'.format(lr))
        if weight_decay < 0.0:
            raise ValueError('Invalid weight_decay value: {}'.format(weight_decay))

        self.lr = lr
        self.weight_decay = weight_decay
        self.params = params
        self.ringbuffer_size = 3
        self.state = {id(p): {'gradients_buffer': [jnp.zeros_like(p) for _ in range(self.ringbuffer_size)],
                              'gradients_counter': 0} for p in self.params}

    def step(self, grads):
        for p, d_p in zip(self.params, grads):
            if d_p is None:
                continue

            if self.weight_decay != 0:
                d_p = d_p + self.weight_decay * p

            param_state = self.state[id(p)]
            param_state['gradients_buffer'][param_state['gradients_counter'] % self.ringbuffer_size] = d_p
            param_state['gradients_counter'] += 1

            gradients_buffer = param_state['gradients_buffer']

            # If we have 3 gradients already, compute median and update weights
            if param_state['gradients_counter'] >= self.ringbuffer_size:
                sum_gradients = jnp.sum(jnp.array(gradients_buffer), axis=0)
                min_gradients = jnp.min(jnp.array(gradients_buffer), axis=0)
                max_gradients = jnp.max(jnp.array(gradients_buffer), axis=0)
                median_of_3 = sum_gradients - min_gradients - max_gradients
                p -= self.lr * median_of_3