""" Linear layer (alternate definition)
"""
import jax.numpy as jnp
from jax import random, grad, jit, vmap
from flax import linen as nn

class Linear(nn.Module):
    features: int

    @nn.compact
    def __call__(self, x):
        weight = self.param('weight', nn.initializers.xavier_uniform(), (x.shape[-1], self.features))
        bias = self.param('bias', nn.initializers.zeros, (self.features,))
        y = jnp.dot(x, weight) + bias
        return y