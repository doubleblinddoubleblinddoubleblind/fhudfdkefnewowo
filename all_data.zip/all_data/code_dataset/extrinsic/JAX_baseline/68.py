import jax
import jax.numpy as jnp
import flax.linen as nn
from flax.training import train_state
import torchvision.models as models

class CNNEncoderBase(nn.Module):
    """docstring for CNNEncoder."""

    context_transform: int
    context_size: int
    spatial_context: bool
    finetune: bool = True

    def setup(self):
        if hasattr(self, 'context_transform'):
            if self.spatial_context:
                self.context_transform = nn.Conv(1, self.context_transform, kernel_size=(1, 1))
            else:
                self.context_transform = nn.Dense(self.context_transform)
            self.context_nonlinearity = None

    def toggle_grad(self):
        # In JAX, we typically don't toggle grads like in PyTorch. 
        pass  # Placeholder as JAX generally does not have this concept.

    def named_parameters(self):
        # Placeholder function for parameter management example.
        return self.params  # Assuming that parameters would be collected as necessary.

class ResNetEncoder(CNNEncoderBase):
    model: nn.Module

    def setup(self):
        self.model = models.resnet50(pretrained=True)
        del self.model.fc
        super().setup()

    def __call__(self, x):
        if self.finetune:
            x = self.model.conv1(x)
            x = self.model.bn1(x)
            x = self.model.relu(x)
            x = self.model.maxpool(x)

            x = self.model.layer1(x)
            x = self.model.layer2(x)
            x = self.model.layer3(x)
            x = self.model.layer4(x)

        if not self.spatial_context:
            x = jax.nn.avg_pool(x, window_shape=(1, 1), stride=(1, 1), padding='VALID').reshape(x.shape[0], -1)
        if hasattr(self, 'context_transform'):
            x = self.context_transform(x)
        if hasattr(self, 'context_nonlinearity'):
            x = self.context_nonlinearity(x)
        return x

class DenseNetEncoder(CNNEncoderBase):
    model: nn.Module

    def setup(self):
        self.model = models.densenet121(pretrained=True)
        del self.model.classifier
        super().setup()

    def __call__(self, x):
        if self.finetune:
            features = self.model.features(x)
            x = jax.nn.relu(features)
        if not self.spatial_context:
            x = jax.nn.avg_pool(x, window_shape=(1, 1), stride=(1, 1), padding='VALID').reshape(x.shape[0], -1)
        if hasattr(self, 'context_transform'):
            x = self.context_transform(x)
        if hasattr(self, 'context_nonlinearity'):
            x = self.context_nonlinearity(x)
        return x

class VGGEncoder(CNNEncoderBase):
    model: nn.Module

    def setup(self):
        self.model = models.vgg16(pretrained=True)
        del self.model.classifier
        super().setup()

    def __call__(self, x):
        if self.finetune:
            x = self.model.features(x)
        if hasattr(self, 'context_transform'):
            x = self.context_transform(x)
        if hasattr(self, 'context_nonlinearity'):
            x = self.context_nonlinearity(x)
        return x

class AlexNetEncoder(CNNEncoderBase):
    model: nn.Module

    def setup(self):
        self.model = models.alexnet(pretrained=True)
        del self.model.classifier
        super().setup()

    def __call__(self, x):
        if self.finetune:
            x = self.model.features(x)
        if hasattr(self, 'context_transform'):
            x = self.context_transform(x)
        if hasattr(self, 'context_nonlinearity'):
            x = self.context_nonlinearity(x)
        return x

class SqueezeNetEncoder(CNNEncoderBase):
    model: nn.Module

    def setup(self):
        self.model = models.squeezenet1_1(pretrained=True)
        del self.model.classifier
        super().setup()

    def __call__(self, x):
        if self.finetune:
            x = self.model.features(x)
        if hasattr(self, 'context_transform'):
            x = self.context_transform(x)
        if hasattr(self, 'context_nonlinearity'):
            x = self.context_nonlinearity(x)
        return x