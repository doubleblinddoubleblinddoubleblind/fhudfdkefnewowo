import jax
import jax.numpy as jnp
from jax import random, grad, jit
from flax import linen as nn

class Inception(nn.Module):
    in_planes: int
    n1x1: int
    n3x3red: int
    n3x3: int
    n5x5red: int
    n5x5: int
    pool_planes: int

    @nn.compact
    def __call__(self, x):
        # 1x1 conv branch
        y1 = nn.Sequential([
            nn.Conv(features=self.n1x1, kernel_size=(1, 1)),
            nn.BatchNorm(),
            nn.relu,
        ])(x)

        # 1x1 conv -> 3x3 conv branch
        y2 = nn.Sequential([
            nn.Conv(features=self.n3x3red, kernel_size=(1, 1)),
            nn.BatchNorm(),
            nn.relu,
            nn.Conv(features=self.n3x3, kernel_size=(3, 3), padding='same'),
            nn.BatchNorm(),
            nn.relu,
        ])(x)

        # 1x1 conv -> 5x5 conv branch
        y3 = nn.Sequential([
            nn.Conv(features=self.n5x5red, kernel_size=(1, 1)),
            nn.BatchNorm(),
            nn.relu,
            nn.Conv(features=self.n5x5, kernel_size=(3, 3), padding='same'),
            nn.BatchNorm(),
            nn.relu,
            nn.Conv(features=self.n5x5, kernel_size=(3, 3), padding='same'),
            nn.BatchNorm(),
            nn.relu,
        ])(x)

        # 3x3 pool -> 1x1 conv branch
        y4 = nn.Sequential([
            nn.max_pool(x, (3, 3), (1, 1), padding='same'),
            nn.Conv(features=self.pool_planes, kernel_size=(1, 1)),
            nn.BatchNorm(),
            nn.relu,
        ])(x)

        return jnp.concatenate([y1, y2, y3, y4], axis=1)

class GoogLeNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        out = nn.Sequential([
            nn.Conv(features=192, kernel_size=(3, 3), padding='same'),
            nn.BatchNorm(),
            nn.relu,
        ])(x)

        out = Inception(192, 64, 96, 128, 16, 32, 32)(out)
        out = Inception(256, 128, 128, 192, 32, 96, 64)(out)

        out = nn.max_pool(out, (3, 3), (2, 2), padding='same')

        out = Inception(480, 192, 96, 208, 16, 48, 64)(out)
        out = Inception(512, 160, 112, 224, 24, 64, 64)(out)
        out = Inception(512, 128, 128, 256, 24, 64, 64)(out)
        out = Inception(512, 112, 144, 288, 32, 64, 64)(out)
        out = Inception(528, 256, 160, 320, 32, 128, 128)(out)

        out = nn.max_pool(out, (3, 3), (2, 2), padding='same')
        
        out = Inception(832, 256, 160, 320, 32, 128, 128)(out)
        out = Inception(832, 384, 192, 384, 48, 128, 128)(out)

        out = nn.avg_pool(out, (8, 8), (1, 1))
        out = out.reshape(out.shape[0], -1)
        out = nn.Dense(features=10)(out)
        return out

# Example usage:
# net = GoogLeNet()
# rng = random.PRNGKey(0)
# x = jnp.ones((1, 3, 32, 32))
# y = net.apply({'params': net.init(rng, x)}, x)
# print(y.shape)