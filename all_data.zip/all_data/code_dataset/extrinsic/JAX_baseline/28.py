import numpy as np
import jax.numpy as jnp
from flax import linen as nn
import jax

def add_sparse_linear_layer(network, suffix, input_size, linear_n, dropout, use_batch_norm, weight_sparsity, percent_on, k_inference_factor, boost_strength, boost_strength_factor, duty_cycle_period, consolidated_sparse_weights):
    # Functionality of add_sparse_linear_layer needs to be implemented
    # This is a placeholder for demonstration purposes
    pass

class StandardMLP(nn.Module):
    input_size: tuple
    num_classes: int
    hidden_sizes: tuple = (100, 100)

    def setup(self):
        layers = [
            nn.Flatten(),
            nn.Dense(self.hidden_sizes[0], kernel_init=nn.initializers.xavier_uniform()),
            nn.relu
        ]
        for idx in range(1, len(self.hidden_sizes)):
            layers.extend([
                nn.Dense(self.hidden_sizes[idx], kernel_init=nn.initializers.xavier_uniform()),
                nn.relu
            ])
        layers.append(nn.Dense(self.num_classes, kernel_init=nn.initializers.xavier_uniform()))
        self.classifier = nn.Sequential(layers)

    def __call__(self, x):
        return self.classifier(x)

class ModifiedInitStandardMLP(StandardMLP):
    def setup(self):
        super().setup()
        weight_density = 1.0
        input_flag = False
        
        for layer in self.classifier.layers:
            if isinstance(layer, nn.Dense):
                input_density = 1.0 if not input_flag else 0.5
                input_flag = True

                fan_in = layer.kernel.shape[0]
                bound = 1.0 / np.sqrt(input_density * weight_density * fan_in)
                layer.kernel = jax.random.uniform(jax.random.PRNGKey(0), shape=layer.kernel.shape, minval=-bound, maxval=bound)

class SparseMLP(nn.Sequential):
    def __init__(self, input_size, output_size, 
                 kw_percent_on=(0.1,),
                 weight_sparsity=(0.6,),
                 boost_strength=1.67,
                 boost_strength_factor=0.9,
                 duty_cycle_period=1000,
                 k_inference_factor=1.5,
                 use_batch_norm=True,
                 dropout=0.0,
                 consolidated_sparse_weights=False,
                 hidden_sizes=(100,)):
        super().__init__()
        self.flatten = nn.Flatten()
        # Add Sparse Linear layers
        for i in range(len(hidden_sizes)):
            add_sparse_linear_layer(
                network=self,
                suffix=i + 1,
                input_size=input_size,
                linear_n=hidden_sizes[i],
                dropout=dropout,
                use_batch_norm=use_batch_norm,
                weight_sparsity=weight_sparsity[i],
                percent_on=kw_percent_on[i],
                k_inference_factor=k_inference_factor,
                boost_strength=boost_strength,
                boost_strength_factor=boost_strength_factor,
                duty_cycle_period=duty_cycle_period,
                consolidated_sparse_weights=consolidated_sparse_weights,
            )
            input_size = hidden_sizes[i]
        self.output = nn.Dense(output_size, kernel_init=nn.initializers.xavier_uniform())