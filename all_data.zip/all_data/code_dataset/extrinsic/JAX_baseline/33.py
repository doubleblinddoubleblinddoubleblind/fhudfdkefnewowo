import jax.numpy as jnp
from flax import linen as nn

class RefineNet(nn.Module):
    """
    RefineNet: Multi-Path Refinement Networks for High-Resolution Semantic Segmentation
    URL: https://arxiv.org/abs/1611.06612

    References:
    1) Original Author's MATLAB code: https://github.com/guosheng/refinenet
    2) TF implementation by @eragonruan: https://github.com/eragonruan/refinenet-image-segmentation
    """

    n_classes: int = 21

    def __call__(self, x):
        pass