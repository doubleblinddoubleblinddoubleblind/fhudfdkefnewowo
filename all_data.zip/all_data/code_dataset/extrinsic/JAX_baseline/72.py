# coding: utf-8

import jax
import jax.numpy as jnp
from jax import random, grad, jit, vmap
import matplotlib.pyplot as plt

# jax.numpy.linspace 表示在 -1和1之间等距采取100各点 
x = jnp.expand_dims(jnp.linspace(-1, 1, 100), axis=1)  # x data (array), shape=(100, 1)
key = random.PRNGKey(0)
y = x**2 + 0.2 * random.uniform(key, shape=x.shape)     # noisy y data (array), shape=(100, 1)

# # 画图
# # scatter 打印散点图
# plt.scatter(x, y)
# plt.show()


# 继承 torch 的 Model
class Net:
    # 初始化-搭建神经网络层所需要的信息
    def __init__(self, n_feature, n_hidden, n_output):
        self.W1 = random.normal(random.PRNGKey(1), (n_feature, n_hidden))
        self.b1 = jnp.zeros((n_hidden,))
        self.W2 = random.normal(random.PRNGKey(2), (n_hidden, n_output))
        self.b2 = jnp.zeros((n_output,))

    # 搭建-神经网络前向传播的过程
    def __call__(self, x):
        x_h_o = jax.nn.relu(jnp.dot(x, self.W1) + self.b1)  # Hidden layer
        y = jnp.dot(x_h_o, self.W2) + self.b2               # Output layer
        return y


net = Net(n_feature=1, n_hidden=10, n_output=1)
print(net)

# optimizer 等价处理
lr_schedule = [0.5] * 30 + [0.005] * 50 + [0.0005] * 20

loss_func = lambda y_pred, y_true: jnp.mean((y_pred - y_true) ** 2)  # MSE Loss

plt.ion()   # 画图

for t in range(100):
    prediction = net(x)     # 喂给 net 训练数据 x, 输出预测值
    loss = loss_func(prediction, y)     # 计算两者的误差

    # 计算梯度
    loss_grad = grad(loss_func, argnums=0)(prediction, y)
    net.W1 -= lr_schedule[t] * jnp.dot(x.T, loss_grad)  # Update weights (W1)
    net.W2 -= lr_schedule[t] * jnp.dot(jax.nn.relu(jnp.dot(x, net.W1) + net.b1).T, loss_grad)  # Update weights (W2)

    # 接着上面来
    if t % 5 == 0:
        # plot and show learning process
        plt.cla()
        plt.scatter(x, y)
        plt.plot(x, prediction, 'r-', lw=5)
        plt.text(0.5, 0, 'Loss=%.4f' % loss, fontdict={'size': 20, 'color': 'red'})
        # 刷新频率
        plt.pause(0.1)

plt.ioff()
plt.show()