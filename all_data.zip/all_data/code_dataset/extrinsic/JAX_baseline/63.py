#!/usr/bin/env python3

from abc import ABC, abstractproperty

import jax
import jax.numpy as jnp
from flax import linen as nn

from .. import settings
from ..distributions import Delta, MultivariateNormal
from ..module import Module
from ..utils.broadcasting import _mul_broadcast_shape
from ..utils.memoize import cached, clear_cache_hook


class _VariationalStrategy(Module, ABC):
    """
    Abstract base class for all Variational Strategies.
    """

    def __init__(self, model, inducing_points, variational_distribution, learn_inducing_locations=True):
        super().__init__()

        # Model
        self.model = model

        # Inducing points
        inducing_points = jax.device_put(inducing_points)
        if inducing_points.ndim == 1:
            inducing_points = jnp.expand_dims(inducing_points, -1)
        self.inducing_points = nn.variable(
            "inducing_points", inducing_points if not learn_inducing_locations else None
        )
        if not learn_inducing_locations:
            self.inducing_points = inducing_points

        # Variational distribution
        self._variational_distribution = variational_distribution
        self.variational_params_initialized = jnp.array(0)

    def _expand_inputs(self, x, inducing_points):
        """
        Pre-processing step in __call__ to make x the same batch_shape as the inducing points
        """
        batch_shape = _mul_broadcast_shape(inducing_points.shape[:-2], x.shape[:-2])
        inducing_points = jnp.broadcast_to(inducing_points, (*batch_shape, *inducing_points.shape[-2:]))
        x = jnp.broadcast_to(x, (*batch_shape, *x.shape[-2:]))
        return x, inducing_points

    @abstractproperty
    @cached(name="prior_distribution_memo")
    def prior_distribution(self):
        raise NotImplementedError

    @property
    @cached(name="variational_distribution_memo")
    def variational_distribution(self):
        return self._variational_distribution()

    def forward(self, x, inducing_points, inducing_values, variational_inducing_covar=None):
        raise NotImplementedError

    def kl_divergence(self):
        with settings.max_preconditioner_size(0):
            kl_divergence = jnp.kl_divergence(self.variational_distribution, self.prior_distribution)
        return kl_divergence

    def train(self, mode=True):
        # Make sure we are clearing the cache if we change modes
        if (self.training and not mode) or mode:
            clear_cache_hook(self)
        return super().train(mode=mode)

    def __call__(self, x, prior=False):
        # If we're in prior mode, then we're done!
        if prior:
            return self.model.forward(x)

        # Delete previously cached items from the training distribution
        if self.training:
            clear_cache_hook(self)
        # (Maybe) initialize variational distribution
        if not self.variational_params_initialized.item():
            prior_dist = self.prior_distribution
            self._variational_distribution.initialize_variational_distribution(prior_dist)
            self.variational_params_initialized = jnp.array(1)

        # Ensure inducing_points and x are the same size
        inducing_points = self.inducing_points
        if inducing_points.shape[:-2] != x.shape[:-2]:
            x, inducing_points = self._expand_inputs(x, inducing_points)

        # Get p(u)/q(u)
        variational_dist_u = self.variational_distribution

        # Get q(f)
        if isinstance(variational_dist_u, MultivariateNormal):
            return super().__call__(
                x,
                inducing_points,
                inducing_values=variational_dist_u.mean,
                variational_inducing_covar=variational_dist_u.lazy_covariance_matrix,
            )
        elif isinstance(variational_dist_u, Delta):
            return super().__call__(
                x, inducing_points, inducing_values=variational_dist_u.mean, variational_inducing_covar=None
            )
        else:
            raise RuntimeError(
                f"Invalid variational distribution ({type(variational_dist_u)}). "
                "Expected a multivariate normal or a delta distribution."
            )