import jax
import jax.numpy as jnp
from torchvision import datasets
import numpy as np
from torch.utils.data import DataLoader
from torchvision.transforms import Compose, ToTensor, Normalize
from CONSTANT import TRAIN_BATCH_SIZE, TEST_BATCH_SIZE, DATA_PATH

transform = Compose(
    [ToTensor(), Normalize(mean=(0.5, 0.5, 0.5), std=(0.5, 0.5, 0.5))])

trainset = datasets.CIFAR10(root=DATA_PATH + 'cifar-10-batches-py', train=True, download=True, transform=transform)
trainloader = DataLoader(trainset, batch_size=TRAIN_BATCH_SIZE, shuffle=True, num_workers=2)

testset = datasets.CIFAR10(root=DATA_PATH + 'cifar-10-batches-py', train=False, download=True, transform=transform)
testloader = DataLoader(testset, batch_size=TEST_BATCH_SIZE, shuffle=False, num_workers=2)

classes = ('plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck')