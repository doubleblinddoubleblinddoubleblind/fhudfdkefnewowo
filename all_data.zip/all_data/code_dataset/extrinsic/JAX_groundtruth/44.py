import io
import itertools
import pickle
import tempfile
import unittest
from pathlib import Path

import numpy as np
import jax
import jax.numpy as jnp
import flax.linen as nn
from flax.core import freeze, unfreeze
from flax.training import checkpoints

from nupic.research.frameworks.jax.model_utils import (
    serialize_state_dict,
    set_random_seed,
)
from nupic.research.frameworks.jax.restore_utils import (
    get_linear_param_names,
    get_nonlinear_param_names,
    load_multi_state,
)
from nupic.jax.models import MNISTSparseCNN
from nupic.jax.modules import KWinners


@jax.jit
def lower_forward(model, x):
    variables = freeze(model.init(jax.random.PRNGKey(0), x))
    y = model.apply(variables, x, method=model.cnn1)
    y = model.apply(variables, y, method=model.cnn1_maxpool)
    y = model.apply(variables, y, method=model.cnn1_kwinner)
    y = model.apply(variables, y, method=model.cnn2)
    y = model.apply(variables, y, method=model.cnn2_maxpool)
    y = model.apply(variables, y, method=model.cnn2_kwinner)
    y = model.apply(variables, y, method=model.flatten)
    return y


@jax.jit
def upper_forward(model, x):
    variables = freeze(model.init(jax.random.PRNGKey(0), x))
    y = model.apply(variables, x, method=model.linear)
    y = model.apply(variables, y, method=model.linear_kwinner)
    y = model.apply(variables, y, method=model.output)
    y = model.apply(variables, y, method=model.softmax)
    return y


@jax.jit
def full_forward(model, x):
    y = lower_forward(model, x)
    y = upper_forward(model, y)
    return y


class RestoreUtilsTest1(unittest.TestCase):

    def setUp(self):

        set_random_seed(20)
        self.model = MNISTSparseCNN()
        self.variables = self.model.init(jax.random.PRNGKey(0), jnp.ones((2, 1, 28, 28)))

        # Make all params twice as large to differentiate it from an init-ed model.
        new_variables = unfreeze(self.variables)
        for name, param in new_variables["params"].items():
            if ("cnn" in name or "linear" in name) and ("kernel" in name):
                new_variables["params"][name] = param * 2
        self.variables = freeze(new_variables)

        self.in_1 = jax.random.uniform(jax.random.PRNGKey(0), (2, 1, 28, 28))
        self.in_2 = jax.random.uniform(jax.random.PRNGKey(1), (2, 1024))
        self.out_full = full_forward(self.model, self.in_1)
        self.out_lower = lower_forward(self.model, self.in_1)
        self.out_upper = upper_forward(self.model, self.in_2)

        self.tempdir = tempfile.TemporaryDirectory()
        self.results_dir = Path(self.tempdir.name) / Path("results")
        self.results_dir.mkdir()

        state = {"variables": self.variables}
        self.checkpoint_path = self.results_dir / Path("mymodel")
        with open(self.checkpoint_path, "wb") as f:
            pickle.dump(state, f)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_get_param_names(self):
        linear_params = get_linear_param_names(self.model, self.variables)
        expected_linear_params = [
            "output.kernel",
            "linear.kernel",
        ]
        self.assertTrue(set(linear_params) == set(expected_linear_params))

        nonlinear_params = get_nonlinear_param_names(self.model, self.variables)
        expected_nonlinear_params = []
        for param, _ in itertools.chain(
            self.model.named_parameters(), self.model.named_buffers()
        ):
            if param not in expected_linear_params:
                expected_nonlinear_params.append(param)

        self.assertTrue(set(nonlinear_params) == set(expected_nonlinear_params))

    def test_load_full(self):

        set_random_seed(33)
        model = MNISTSparseCNN()
        variables = model.init(jax.random.PRNGKey(0), jnp.ones((2, 1, 28, 28)))

        for param1, param2 in zip(variables["params"].values(), self.variables["params"].values()):
            tot_eq = (param1 == param2).sum()
            self.assertNotEqual(tot_eq, param1.size)

        variables = load_multi_state(variables, restore_full_model=self.checkpoint_path)

        for param1, param2 in zip(variables["params"].values(), self.variables["params"].values()):
            tot_eq = (param1 == param2).sum()
            self.assertEqual(tot_eq, param1.size)

        out = full_forward(model, self.in_1)
        num_matches = (jnp.isclose(out, self.out_full, atol=1e-2, rtol=0)).sum()
        self.assertEqual(num_matches, 20)

        out = lower_forward(model, self.in_1)
        num_matches = (jnp.isclose(out, self.out_lower, atol=1e-2, rtol=0)).sum()
        self.assertEqual(num_matches, 2048)

        out = upper_forward(model, self.in_2)
        num_matches = (jnp.isclose(out, self.out_upper, atol=1e-2, rtol=0)).sum()
        self.assertEqual(num_matches, 20)

    def test_load_nonlinear(self):
        set_random_seed(33)
        model = MNISTSparseCNN()
        variables = model.init(jax.random.PRNGKey(0), jnp.ones((2, 1, 28, 28)))

        for param1, param2 in zip(variables["params"].values(), self.variables["params"].values()):
            tot_eq = (param1 == param2).sum()
            self.assertNotEqual(tot_eq, param1.size)

        variables = load_multi_state(variables, restore_nonlinear=self.checkpoint_path)

        out = lower_forward(model, self.in_1)
        num_matches = (jnp.isclose(out, self.out_lower, atol=1e-2, rtol=0)).sum()
        self.assertEqual(num_matches, 2048)

    def test_load_linear(self):
        set_random_seed(33)
        model = MNISTSparseCNN()
        variables = model.init(jax.random.PRNGKey(0), jnp.ones((2, 1, 28, 28)))

        for param1, param2 in zip(variables["params"].values(), self.variables["params"].values()):
            tot_eq = (param1 == param2).sum()
            self.assertNotEqual(tot_eq, param1.size)

        variables = load_multi_state(variables, restore_linear=self.checkpoint_path)

        out = upper_forward(model, self.in_2)
        num_matches = (jnp.isclose(out, self.out_upper, atol=1e-2, rtol=0)).sum()
        self.assertEqual(num_matches, 20)


class RestoreUtilsTest2(unittest.TestCase):

    def setUp(self):
        set_random_seed(20)
        self.model = nn.Sequential(
            layers=[
                nn.Dense(8),
                KWinners(8, percent_on=0.1)
            ]
        )
        self.variables = self.model.init(jax.random.PRNGKey(0), jnp.ones((8,)))

        self.tempdir = tempfile.TemporaryDirectory()
        self.results_dir = Path(self.tempdir.name) / Path("results")
        self.results_dir.mkdir()

        state = {"variables": self.variables}
        self.checkpoint_path = self.results_dir / Path("mymodel")
        with open(self.checkpoint_path, "wb") as f:
            pickle.dump(state, f)

    def tearDown(self):
        self.tempdir.cleanup()

    def test_permuted_model_loading(self):
        model = nn.Sequential(
            layers=[
                KWinners(8, percent_on=0.1),
                nn.Dense(8)
            ]
        )
        variables = model.init(jax.random.PRNGKey(0), jnp.ones((8,)))

        param_map = {
            "Dense_0.kernel": "Dense_1.kernel",
            "Dense_0.bias": "Dense_1.bias",
            "KWinners_1.boost_strength": "KWinners_0.boost_strength",
            "KWinners_1.duty_cycle": "KWinners_0.duty_cycle"
        }

        variables = load_multi_state(
            variables,
            restore_linear=self.checkpoint_path,
            param_map=param_map,
        )

        variables = load_multi_state(
            variables,
            restore_full_model=self.checkpoint_path,
            param_map=param_map,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)