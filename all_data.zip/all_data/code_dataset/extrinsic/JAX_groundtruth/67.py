from parcellearning.conv.pairconv import PAIRConv
from parcellearning.conv.gatconv import GATConv
import numpy as np

import dgl
from dgl import data
from dgl.data import DGLDataset
import dgl.function as fn

import flax.linen as nn
import jax.numpy as jnp
import jax

class PAIRGAT(nn.Module):
    num_layers: int
    in_dim: int
    num_hidden: int
    num_classes: int
    num_heads: list
    activation: callable
    feat_drop: float
    attn_drop: float
    negative_slope: float = 0.2
    residual: bool = False
    allow_zero_in_degree: bool = True
    return_attention: bool = False

    def setup(self):
        self.num_heads = self.num_heads[0]
        self.num_out_heads = self.num_heads[-1]
        self.layers = []

        # input layer
        self.layers.append(PAIRConv(in_feats=self.in_dim,
                                    out_feats=self.num_hidden,
                                    num_heads=self.num_heads,
                                    feat_drop=self.feat_drop,
                                    attn_drop=self.attn_drop,
                                    negative_slope=self.negative_slope,
                                    activation=self.activation,
                                    allow_zero_in_degree=self.allow_zero_in_degree,
                                    return_attention=False))

        # hidden layers
        for l in range(1, self.num_layers):
            self.layers.append(PAIRConv(in_feats=(self.num_hidden + 1) * self.num_heads,
                                        out_feats=self.num_hidden,
                                        num_heads=self.num_heads,
                                        feat_drop=self.feat_drop,
                                        attn_drop=self.attn_drop,
                                        negative_slope=self.negative_slope,
                                        activation=self.activation,
                                        allow_zero_in_degree=self.allow_zero_in_degree,
                                        return_attention=False))
        
        # output layer
        self.layers.append(nn.Dense(features=self.num_classes, use_bias=True))

        print(self.layers)

    def __call__(self, g=None, inputs=None, **kwds):
        h = inputs
        for l in range(self.num_layers - 1):
            h = jax.tree_util.tree_map(lambda layer, x: layer(g, x).flatten(1), self.layers[l], h)
        
        # output projection
        logits = self.layers[-1](h)
        return logits

    def save(self, filename):
        # You'll need to implement saving mechanism separately for JAX
        print("Save state to", filename)