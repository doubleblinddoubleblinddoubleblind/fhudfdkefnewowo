import jax.numpy as jnp
from jax import grad, jit, vmap
from jax import random
from jax.example_libraries import optimizers
import matplotlib.pyplot as plt


key = random.PRNGKey(0)

# Generate data
x = jnp.linspace(-1, 1, 100).reshape(-1, 1)  # x data (tensor), shape=(100, 1)
y = x ** 2 + 0.2 * random.uniform(key, x.shape)  # noisy y data (tensor), shape=(100, 1)

def init_network_params(sizes, key):
    keys = random.split(key, len(sizes))
    return [(random.normal(k, (m, n)) * jnp.sqrt(2.0 / m),
             jnp.zeros(n))
            for m, n, k in zip(sizes[:-1], sizes[1:], keys)]

layer_sizes = [1, 10, 1]
params = init_network_params(layer_sizes, key)

def relu(x):
    return jnp.maximum(0, x)

def predict(params, x):
    activations = x
    for w, b in params[:-1]:
        outputs = jnp.dot(activations, w) + b
        activations = relu(outputs)

    final_w, final_b = params[-1]
    y = jnp.dot(activations, final_w) + final_b
    return y

def loss(params, x, y):
    preds = predict(params, x)
    return jnp.mean((preds - y) ** 2)

opt_init, opt_update, get_params = optimizers.sgd(0.5)
opt_state = opt_init(params)

@jit
def update(step, opt_state, x, y):
    params = get_params(opt_state)
    grads = grad(loss)(params, x, y)
    return opt_update(step, grads, opt_state)

# Plot data
plt.ion()
for t in range(100):
    opt_state = update(t, opt_state, x, y)
    params = get_params(opt_state)

    if t % 5 == 0:
        plt.cla()
        plt.scatter(x, y)
        plt.plot(x, predict(params, x), 'r-', lw=5)
        plt.text(0.5, 0, 'Loss=%.4f' % loss(params, x, y).item(), fontdict={'size': 20, 'color': 'red'})
        plt.pause(0.1)

plt.ioff()
plt.show()