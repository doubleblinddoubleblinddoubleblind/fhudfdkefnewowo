import jax
from jax import numpy as jnp
from sklearn.metrics import matthews_corrcoef, confusion_matrix
import datasets
from tqdm import tqdm
import os
import sys
from functools import partial
import multiprocessing

import flax.linen as nn
import transformers
from flax.training import train_state
from flax.training.common_utils import shard

import optax
import logging

logging.basicConfig(level=logging.INFO)

# Transformer module used for classification
class FlaxBertForSequenceClassification(nn.Module):
    config: transformers.BertConfig
    num_labels: int

    def setup(self):
        self.model = transformers.FlaxBertModel(self.config, name="bert")
        self.classifier = nn.Dense(self.num_labels, name="classifier")

    def __call__(self, input_ids, attention_mask, token_type_ids):
        outputs = self.model(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
        logits = self.classifier(outputs.pooler_output)
        return logits

device = jax.devices('gpu' if jax.lib.xla_bridge.get_backend().platform == 'gpu' else 'cpu')[0]

TASK_NAME = sys.argv[1]

if sys.argv[2] == 'reg':
    OUTPUT_MODE = 'regression'
    OUTPUT_DIR = 'outputs/' + TASK_NAME + '_reg/'
    REPORTS_DIR = 'reports/' + TASK_NAME + '_reg/'
    report_logits = False
elif sys.argv[2] == 'cla':
    OUTPUT_MODE = 'classification'
    OUTPUT_DIR = 'outputs/' + TASK_NAME + '/'
    REPORTS_DIR = 'reports/' + TASK_NAME + '/'
    report_logits = True
else:
    print('Unexpected output mode.')
    sys.exit(0)

DATA_DIR = f'data/{TASK_NAME}/'
CACHE_DIR = 'cache/'

MAX_SEQ_LENGTH = 512
EVAL_BATCH_SIZE = 8
LEARNING_RATE = 2e-5
NUM_TRAIN_EPOCHS = 1
RANDOM_SEED = 42

def get_eval_report(task_name, labels, preds):
    mcc = matthews_corrcoef(labels, preds)
    tn, fp, fn, tp = confusion_matrix(labels, preds).ravel()
    return {
        "task": task_name,
        "mcc": mcc,
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn
    }

def compute_metrics(task_name, labels, preds):
    assert len(preds) == len(labels)
    return get_eval_report(task_name, labels, preds)

tokenizer = transformers.BertTokenizer.from_pretrained(OUTPUT_DIR + 'vocab.txt', do_lower_case=True)

processor = datasets.load_dataset('glue', TASK_NAME)
eval_examples = processor['validation']
label_list = processor['train'].features['label'].names
num_labels = len(label_list)

label_map = {label: i for i, label in enumerate(label_list)}

# Note: No direct jax parallel processing equivalent, instead using map on eval examples
def convert_example_to_feature(example):
    return tokenizer.encode_plus(
        example['sentence'], max_length=MAX_SEQ_LENGTH, padding='max_length', truncation=True
    )

eval_features = list(map(convert_example_to_feature, eval_examples))

all_input_ids = jnp.array([f['input_ids'] for f in eval_features], dtype=jnp.int32)
all_input_mask = jnp.array([f['attention_mask'] for f in eval_features], dtype=jnp.int32)
all_segment_ids = jnp.array([f['token_type_ids'] for f in eval_features], dtype=jnp.int32)

if OUTPUT_MODE == "classification":
    all_label_ids = jnp.array([f['label'] for f in eval_examples], dtype=jnp.int32)
elif OUTPUT_MODE == "regression":
    all_label_ids = jnp.array([f['label'] for f in eval_examples], dtype=jnp.float32)

# Initialize the model
transformers.logging.set_verbosity_error()
bert_config = transformers.BertConfig.from_dict({'num_labels': num_labels})
model = FlaxBertForSequenceClassification(bert_config, num_labels)

params = model.init(jax.random.PRNGKey(0), all_input_ids, all_input_mask, all_segment_ids)

@partial(jax.jit, static_argnames=["model"])
def forward_pass(model, params, input_ids, attention_mask, token_type_ids):
    return model.apply(params, input_ids, attention_mask, token_type_ids)

preds = []
eval_loss = 0
nb_eval_steps = 0

for i in tqdm(range(0, len(all_input_ids), EVAL_BATCH_SIZE), desc="Evaluating"):
    input_ids = all_input_ids[i:i + EVAL_BATCH_SIZE]
    input_mask = all_input_mask[i:i + EVAL_BATCH_SIZE]
    segment_ids = all_segment_ids[i:i + EVAL_BATCH_SIZE]
    label_ids = all_label_ids[i:i + EVAL_BATCH_SIZE]

    logits = forward_pass(model, params, input_ids, input_mask, segment_ids)

    # create eval loss and other metric required by the task
    if OUTPUT_MODE == "classification":
        loss_fct = optax.softmax_cross_entropy
        tmp_eval_loss = jnp.mean(loss_fct(logits, jax.nn.one_hot(label_ids, num_labels)))
    elif OUTPUT_MODE == "regression":
        loss_fct = optax.l2_loss
        tmp_eval_loss = jnp.mean(loss_fct(logits.flatten(), label_ids.flatten()))

    eval_loss += tmp_eval_loss
    nb_eval_steps += 1

    preds.append(logits)

eval_loss = eval_loss / nb_eval_steps
preds_np = jax.device_get(jnp.concatenate(preds, axis=0))

if OUTPUT_MODE == "classification":
    preds_np = jnp.argmax(preds_np, axis=1)
elif OUTPUT_MODE == "regression":
    preds_np = preds_np.squeeze()

if not os.path.exists(REPORTS_DIR):
    os.makedirs(REPORTS_DIR)

reports_path = REPORTS_DIR + 'predictions.tsv'
logits_path = REPORTS_DIR + 'logits.tsv'

with open(reports_path, mode='w', encoding='utf-8') as f:
    for alabel, apred in zip(all_label_ids, preds_np):
        f.write(str(alabel) + '\t' + str(apred) + '\n')

if report_logits:
    with open(logits_path, mode='w', encoding='utf-8') as f:
        for alabel, alogit in zip(all_label_ids, preds_np):
            f.write(str(alabel) + '\t' + str(alogit) + '\n')

if OUTPUT_MODE == 'regression':
    preds4result = jnp.round(preds_np)
    labels4result = all_label_ids.astype(jnp.int8)
else:
    labels4result = all_label_ids
    preds4result = preds_np

result = compute_metrics(TASK_NAME, labels4result, preds4result)
result['eval_loss'] = eval_loss

output_eval_file = os.path.join(REPORTS_DIR, "eval_results.txt")
with open(output_eval_file, "w") as writer:
    logging.info("***** Eval results *****")
    for key in (result.keys()):
        logging.info("  %s = %s", key, str(result[key]))
        writer.write("%s = %s\n" % (key, str(result[key])))