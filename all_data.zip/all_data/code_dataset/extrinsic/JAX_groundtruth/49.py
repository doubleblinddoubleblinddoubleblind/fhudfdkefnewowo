import jax
import jax.numpy as jnp
from jax import random
from jax.nn import softmax
import haiku as hk
import numpy as np

from model.cnn import CNN  # assumed to be a defined CNN model

class MemN2N(hk.Module):

    def __init__(self, param, name=None):
        super().__init__(name=name)
        self.param = param

        self.hops = self.param['hops']
        self.vocab_size = param['vocab_size']
        self.embedding_size = param['embedding_size']

        self.embedding = hk.Embed(self.vocab_size, self.embedding_size)
        self.cnn = CNN(param, embedding=self.embedding)
        self.linear = hk.Linear(self.embedding_size, with_bias=False)
    
    def __call__(self, utter, memory):
        # Embed and sum utterance
        utter_emb_sum = self.cnn(utter)
        contexts = [utter_emb_sum]

        # Perform hops
        for _ in range(self.hops):
            # Unbind and process memory
            memory_unbound = jnp.split(memory, memory.shape[1], axis=1)
            memory_emb_sum = [self.cnn(story.squeeze(1)) for story in memory_unbound]
            memory_emb_sum = jnp.stack(memory_emb_sum, axis=1)

            # Compute attention
            context_temp = jnp.expand_dims(contexts[-1], -1).transpose((0, 2, 1))
            attention = jnp.sum(memory_emb_sum * context_temp, axis=2)
            attention = softmax(attention, axis=-1)

            attention_expanded = jnp.expand_dims(attention, -1)
            attn_stories = jnp.sum(attention_expanded * memory_emb_sum, axis=1)

            new_context = self.linear(contexts[-1]) + attn_stories
            contexts.append(new_context)

        return new_context

def create_memn2n(param):
    def forward_fn(utter, memory):
        model = MemN2N(param)
        return model(utter, memory)
    return hk.transform(forward_fn)

if __name__ == '__main__':
    param = {'hops': 3, "vocab_size": 20, "embedding_size": 20}
    
    model_transformed = create_memn2n(param)

    rng = jax.random.PRNGKey(42)
    utter = np.ones((20, 10), dtype=int)
    memory = np.ones((20, 3, 10), dtype=int)
    
    params = model_transformed.init(rng, utter, memory)
    output = model_transformed.apply(params, rng, utter, memory)
    print(output)