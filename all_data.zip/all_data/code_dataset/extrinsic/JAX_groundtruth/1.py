import math

import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Sequence

class ConvRec(nn.Module):
    n_classes: int
    vocab: int
    emb_dim: int = 100
    padding_idx: Any = None
    out_channels: int = 128
    kernel_sizes: tuple = (5, 3)
    pool_size: int = 2
    act: str = 'relu'
    conv_type: str = 'wide'
    rnn_layers: int = 1
    hid_dim: int = 128
    cell: str = 'LSTM'
    bidi: bool = True
    dropout: float = 0.0

    @nn.compact
    def __call__(self, inp, training=True):
        # Embedding
        embedding_init = jax.nn.initializers.normal()
        embeddings = self.param('embeddings', embedding_init, (self.vocab, self.emb_dim))
        emb = jnp.take(embeddings, inp, axis=0)
        emb = jnp.transpose(emb, (0, 2, 1))
        emb = jnp.expand_dims(emb, 1)

        # CNN
        conv_in = emb
        for layer, W in enumerate(self.kernel_sizes):
            C_i, H = (1, self.emb_dim) if layer == 0 else (self.out_channels, 1)
            padding = math.floor(W / 2) * 2 if self.conv_type == 'wide' else 0

            conv = nn.Conv(features=self.out_channels, kernel_size=(H, W), padding=((0, 0), (0, padding)))
            conv_out = conv(conv_in)
            conv_out = nn.max_pool(conv_out, (1, self.pool_size), strides=(1, self.pool_size))
            conv_out = getattr(jax.nn, self.act)(conv_out)
            conv_out = nn.Dropout(rate=self.dropout)(conv_out, deterministic=not training)
            conv_in = conv_out

        # RNN
        rnn_in = jnp.transpose(conv_out.squeeze(2), (2, 0, 1))
        rnn_cell = getattr(nn, self.cell)

        rnn = rnn_cell(hidden_size=self.hid_dim // 2 if self.bidi else self.hid_dim,
                       num_layers=self.rnn_layers, bidirectional=self.bidi,
                       dropout=self.dropout if training else 0.)
        rnn_out, _ = rnn(rnn_in)

        rnn_out = jnp.concatenate([jnp.sum(rnn_out[:-1], axis=0), rnn_out[-1]], axis=1)

        # Proj
        proj = nn.Dense(features=self.n_classes)
        out = nn.log_softmax(proj(rnn_out))

        return out