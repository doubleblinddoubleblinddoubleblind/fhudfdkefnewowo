import os
import sys
import numpy as np
import random
import gym
import math
import time

import jax
import jax.numpy as jnp
from jax import random as jax_random
from jax import grad, jit, vmap
import optax

from model import Model

class ReplayMemory(object):
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = []

    def push(self, events):
        for event in zip(*events):
            self.memory.append(event)
            if len(self.memory) > self.capacity:
                del self.memory[0]

    def clear(self):
        self.memory = []

    def sample(self, batch_size):
        samples = zip(*random.sample(self.memory, batch_size))
        return map(lambda x: jnp.concatenate(x, 0), samples)

def normal(x, mu, std):
    a = jnp.exp(-1 * (x - mu) ** 2 / (2 * std))
    b = 1 / jnp.sqrt(2 * std * np.pi)
    return a * b

def train(rank, params, traffic_light, counter, shared_model, shared_grad_buffers, shared_obs_stats, test_n):
    rng = jax_random.PRNGKey(params.seed)
    env = gym.make(params.env_name)
    num_inputs = env.observation_space.shape[0]
    num_outputs = env.action_space.shape[0]
    model = Model(num_inputs, num_outputs)

    memory = ReplayMemory(params.exploration_size)

    state = env.reset()
    state = jnp.expand_dims(jnp.array(state), 0)
    done = True

    episode_length = 0
    while True:
        episode_length += 1
        shared_model_params = shared_model.get_params()
        model.set_params(shared_model_params)

        w = -1
        av_reward = 0
        nb_runs = 0
        reward_0 = 0
        t = -1
        while w < params.exploration_size:
            t += 1
            states = []
            actions = []
            rewards = []
            values = []
            returns = []
            advantages = []
            av_reward = 0
            cum_reward = 0
            cum_done = 0

            for step in range(params.num_steps):
                w += 1
                shared_obs_stats.observes(state)
                state = shared_obs_stats.normalize(state)
                states.append(state)
                mu, sigma_sq, v = model(state)
                key, subkey = jax_random.split(rng)
                eps = jax_random.normal(subkey, mu.shape)
                action = mu + jnp.sqrt(sigma_sq) * eps
                actions.append(action)
                values.append(v)
                env_action = jnp.squeeze(action)
                state, reward, done, _ = env.step(env_action)
                done = done or (episode_length >= params.max_episode_length)
                cum_reward += reward
                reward = max(min(reward, 1), -1)
                rewards.append(reward)
                if done:
                    cum_done += 1
                    av_reward += cum_reward
                    cum_reward = 0
                    episode_length = 0
                    state = env.reset()
                state = jnp.expand_dims(jnp.array(state), 0)
                if done:
                    break

            R = jnp.zeros((1, 1))
            if not done:
                _, _, v = model(state)
                R = v

            values.append(jnp.array(R))
            A = jnp.zeros((1, 1))
            for i in reversed(range(len(rewards))):
                td = rewards[i] + params.gamma * values[i + 1][0, 0] - values[i][0, 0]
                A = td + params.gamma * params.gae_param * A
                advantages.insert(0, A)
                R = A + values[i]
                returns.insert(0, R)

            memory.push([states, actions, returns, advantages])

        av_reward /= float(cum_done + 1)
        model_old = Model(num_inputs, num_outputs)
        model_old.set_params(model.get_params())
        if t == 0:
            reward_0 = av_reward - 1e-2

        for k in range(params.num_epoch):
            model.set_params(shared_model.get_params())
            batch_states, batch_actions, batch_returns, batch_advantages = memory.sample(params.batch_size)
            mu_old, sigma_sq_old, v_pred_old = model_old(batch_states)
            probs_old = normal(batch_actions, mu_old, sigma_sq_old)
            mu, sigma_sq, v_pred = model(batch_states)
            probs = normal(batch_actions, mu, sigma_sq)
            ratio = probs / (1e-10 + probs_old)
            surr1 = ratio * jnp.concatenate([batch_advantages] * num_outputs, 1)
            surr2 = jnp.clip(ratio, 1 - params.clip, 1 + params.clip) * jnp.concatenate([batch_advantages] * num_outputs, 1)
            loss_clip = -jnp.mean(jnp.minimum(surr1, surr2))
            vfloss1 = (v_pred - batch_returns) ** 2
            v_pred_clipped = v_pred_old + jnp.clip(v_pred - v_pred_old, -params.clip, params.clip)
            vfloss2 = (v_pred_clipped - batch_returns) ** 2
            loss_value = 0.5 * jnp.mean(jnp.maximum(vfloss1, vfloss2))
            loss_ent = -params.ent_coeff * jnp.mean(probs * jnp.log(probs + 1e-5))
            total_loss = loss_clip + loss_value + loss_ent
            grad_fn = grad(lambda p: total_loss)
            grads = grad_fn(model.get_params())
            shared_grad_buffers.add_gradient(grads)

            counter.increment()
            signal_init = traffic_light.get()
            while traffic_light.get() == signal_init:
                pass

        test_n += 1
        memory.clear()