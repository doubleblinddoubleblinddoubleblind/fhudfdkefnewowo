import numpy as np
import cv2
import jax
import jax.numpy as jnp
from flax import linen as nn
from torchvision import models
from tvm import relay
from tvm.runtime.vm import VirtualMachine
from tvm.relay.frontend import from_pytorch
from tvm.contrib.download import download

in_size = 300

def process_image(img):
    img = cv2.imread(img).astype("float32")
    img = cv2.resize(img, (in_size, in_size))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img / 255.0
    img = jnp.array(img).transpose(2, 0, 1)
    img = jnp.expand_dims(img, axis=0)
    return img

def dict_to_tuple(out_dict):
    if "masks" in out_dict.keys():
        return out_dict["boxes"], out_dict["scores"], out_dict["labels"], out_dict["masks"]
    return out_dict["boxes"], out_dict["scores"], out_dict["labels"]

class TraceWrapper(nn.Module):
    model: nn.Module

    def __call__(self, inp):
        out = self.model(inp)
        return dict_to_tuple(out[0])

def generate_jit_model(index):
    model_funcs = [
        models.detection.fasterrcnn_resnet50_fpn,
        models.detection.maskrcnn_resnet50_fpn,
    ]

    model_func = model_funcs[index]
    model = model_func(pretrained=True, rpn_pre_nms_top_n_test=1000)

    def infer_model(img):
        model.eval()
        with jax.disable_jit():
            return model(img)

    inp = jnp.array(np.random.uniform(0.0, 250.0, size=(1, 3, in_size, in_size)))
    out = infer_model(inp)

    script_module = jax.jit(infer_model)
    script_out = script_module(inp)

    assert len(out[0]) > 0 and len(script_out[0]) > 0
    return script_module

def test_detection_models():
    img = "test_street_small.jpg"
    img_url = (
        "https://raw.githubusercontent.com/dmlc/web-data/"
        "master/gluoncv/detection/street_small.jpg"
    )
    download(img_url, img)

    input_shape = (1, 3, in_size, in_size)
    input_name = "input0"
    shape_list = [(input_name, input_shape)]

    scripted_model = generate_jit_model(1)
    mod, params = from_pytorch(scripted_model, shape_list)

    data = process_image(img)
    data_np = np.array(data)

    def compile_and_run_vm(mod, params, data_np, target):
        with tvm.transform.PassContext(opt_level=3):
            vm_exec = relay.vm.compile(mod, target=target, params=params)

        dev = tvm.device(target, 0)
        vm = VirtualMachine(vm_exec, dev)
        vm.set_input("main", **{input_name: data_np})
        return vm.run()

    for target in ["llvm"]:
        tvm_res = compile_and_run_vm(mod, params, data_np, target)

        # As you would normally test for equality, here I kept same tests as no FLAX Mask RCNN
        pt_res = scripted_model(data)

        assert np.allclose(pt_res[0], tvm_res[0].numpy(), rtol=1e-5, atol=1e-5)
        assert np.allclose(pt_res[1], tvm_res[1].numpy(), rtol=1e-5, atol=1e-5)
        assert np.array_equal(pt_res[2], tvm_res[2].numpy())

        score_threshold = 0.9
        print("Num boxes:", pt_res[0].shape[0])
        print("Num valid boxes:", np.sum(pt_res[1] >= score_threshold))

    before = mod["main"]
    mod = rewrite_nms_to_batched_nms(mod)
    after = mod["main"]
    assert not tvm.ir.structural_equal(after, before)

    before = mod["main"]
    mod = rewrite_scatter_to_gather(mod, 4)
    after = mod["main"]
    assert not tvm.ir.structural_equal(after, before)

    tvm_res_after_rewrite = compile_and_run_vm(mod, params, data_np, "llvm")

    for res1, res2 in zip(tvm_res, tvm_res_after_rewrite):
        assert np.allclose(res1.numpy(), res2.numpy(), rtol=1e-5, atol=1e-5)