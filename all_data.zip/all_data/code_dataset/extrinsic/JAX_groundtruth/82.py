import jax.numpy as jnp
from jax import jit
from flax import linen as nn

class Linear(nn.Module):
    features: int
    
    def setup(self):
        self.weight = self.param('weight', nn.initializers.lecun_normal(), (self.features,))
        self.bias = self.param('bias', nn.initializers.zeros, (self.features,))
    
    @nn.compact
    def __call__(self, input):
        weight = self.weight.astype(input.dtype)
        bias = self.bias.astype(input.dtype)
        output = jnp.dot(input, weight.T) + bias
        return output