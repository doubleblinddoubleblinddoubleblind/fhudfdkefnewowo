import jax.numpy as jnp
import jax.random as random
from flax import linen as nn
from ogb.utils.features import get_atom_feature_dims, get_bond_feature_dims

full_atom_feature_dims = get_atom_feature_dims()
full_bond_feature_dims = get_bond_feature_dims()

class AtomEncoder(nn.Module):
    emb_dim: int

    def setup(self):
        self.atom_embeddings = [
            self.param(f'emb_{i}', random.uniform, (dim, self.emb_dim), scale=jnp.sqrt(6 / (dim + self.emb_dim))) 
            for i, dim in enumerate(full_atom_feature_dims)
        ]

    def __call__(self, x):
        x_embedding = jnp.zeros((x.shape[0], self.emb_dim))
        for i in range(x.shape[1]):
            x_embedding += self.atom_embeddings[i][x[:, i]]
        return x_embedding


class BondEncoder(nn.Module):
    emb_dim: int

    def setup(self):
        self.bond_embeddings = [
            self.param(f'emb_{i}', random.uniform, (dim, self.emb_dim), scale=jnp.sqrt(6 / (dim + self.emb_dim))) 
            for i, dim in enumerate(full_bond_feature_dims)
        ]

    def __call__(self, edge_attr):
        bond_embedding = jnp.zeros((edge_attr.shape[0], self.emb_dim))
        for i in range(edge_attr.shape[1]):
            bond_embedding += self.bond_embeddings[i][edge_attr[:, i]]
        return bond_embedding


if __name__ == '__main__':
    from loader import GraphClassificationPygDataset
    dataset = GraphClassificationPygDataset(name='tox21')
    atom_enc = AtomEncoder(emb_dim=100)
    bond_enc = BondEncoder(emb_dim=100)

    x = dataset[0].x
    edge_attr = dataset[0].edge_attr

    print(atom_enc().apply({}, x))
    print(bond_enc().apply({}, edge_attr))