import datetime
import os
import time

import jax
import jax.numpy as jnp
import optax
from flax import linen as nn
from flax.training import train_state
import tensorflow_datasets as tfds

import ray
from filelock import FileLock
from ray.util.sgd.torch.examples.segmentation.coco_utils import get_coco
import ray.util.sgd.torch.examples.segmentation.utils as utils
from ray.util.sgd.torch import TrainingOperator
from ray.util.sgd import TorchTrainer

class SegModel(nn.Module):
    num_classes: int
    aux_loss: bool

    def setup(self):
        self.backbone = nn.Dense(self.num_classes)
        self.classifier = nn.Dense(self.num_classes)

    def __call__(self, x):
        x = self.backbone(x)
        out = self.classifier(x)
        return {'out': out}

def get_dataset(name, split, transform, num_classes_only=False):
    paths = {
        "voc": ("voc/2007", None, 21),
        "voc_aug": ("voc/2012", None, 21),
        "coco": ("coco/2017", None, 21),
    }
    dataset_name, _, num_classes = paths[name]
    if num_classes_only:
        return None, num_classes

    ds = tfds.load(dataset_name, split=split, as_supervised=True)
    ds = ds.map(transform)
    return ds, num_classes

def criterion(params, inputs, target, model):
    outputs = model.apply({'params': params}, inputs)
    out = outputs["out"]
    losses = nn.softmax_cross_entropy(out, target, axis=-1)
    return jnp.mean(losses)

def get_transform(train):
    def transform(image, label):
        image = tf.image.resize(image, [520, 520]) if train else tf.image.resize(image, [480, 480])
        image = tf.image.random_flip_left_right(image) if train else image
        image = tf.image.per_image_standardization(image)
        return image, label
    return transform

def create_train_state(rng, learning_rate, model):
    params = model.init(rng, jnp.ones([1, 520, 520, 3]))['params']
    tx = optax.sgd(learning_rate=learning_rate, momentum=0.9, weight_decay=1e-4)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

class SegOperator(TrainingOperator):
    def setup(self, config):
        args = config["args"]
        with FileLock(".ray.lock"):
            dataset, num_classes = get_dataset(args.dataset, "train", get_transform(train=True))
            config["num_classes"] = num_classes
            dataset_test, _ = get_dataset(args.dataset, "val", get_transform(train=False))

        model = SegModel(num_classes=config["num_classes"], aux_loss=args.aux_loss)
        rng = jax.random.PRNGKey(0)
        self.state = create_train_state(rng, args.lr, model)

    def train_batch(self, batch, batch_info):
        image, target = batch
        def loss_fn(params):
            return criterion(params, image, target, self.state.apply_fn)
        grads = jax.grad(loss_fn)(self.state.params)
        self.state = self.state.apply_gradients(grads=grads)
        lr = self.state.tx.opt_state[0].hyperparams['learning_rate']
        return {"loss": loss_fn(self.state.params), "lr": lr, "num_samples": len(batch)}

    def validate(self, data_loader, info=None):
        self.state.apply_fn.eval()
        confmat = utils.ConfusionMatrix(self.config["num_classes"])
        for image, target in data_loader:
            output = self.state.apply_fn({'params': self.state.params}, image)
            confmat.update(target.flatten(), jnp.argmax(output["out"], axis=-1).flatten())
        return confmat

def main(args):
    os.makedirs(args.output_dir, exist_ok=True)
    print(args)
    start_time = time.time()
    config = {"args": args, "num_workers": args.num_workers}
    trainer = TorchTrainer(
        training_operator_cls=SegOperator,
        use_tqdm=True,
        num_workers=config["num_workers"],
        config=config,
        use_gpu=jax.devices("gpu"),
    )

    for epoch in range(args.epochs):
        trainer.train()
        confmat = trainer.validate(reduce_results=False)[0]
        print(confmat)
        state_dict = trainer.model.state_dict()
        state_dict.update(epoch=epoch, args=args)
        os.makedirs(args.output_dir, exist_ok=True)
        with open(os.path.join(args.output_dir, f"model-{epoch}.params"), 'wb') as f:
            f.write(jax.serialization.to_bytes(state_dict))

    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print(f"Training time {total_time_str}")

def parse_args():
    import argparse

    parser = argparse.ArgumentParser(description="JAX Segmentation Training with RaySGD")
    parser.add_argument("--address", required=False, default=None, help="the address to use for connecting to a Ray cluster.")
    parser.add_argument("--dataset", default="voc", help="dataset")
    parser.add_argument("--model", default="SegModel", help="model")
    parser.add_argument("--aux-loss", action="store_true", help="auxiliary loss")
    parser.add_argument("--device", default="cuda", help="device")
    parser.add_argument("-b", "--batch-size", default=8, type=int)
    parser.add_argument("-n", "--num-workers", default=1, type=int, help="GPU parallelism")
    parser.add_argument("--epochs", default=30, type=int, metavar="N", help="number of total epochs to run")
    parser.add_argument("--data-workers", default=16, type=int, metavar="N", help="number of data loading workers (default: 16)")
    parser.add_argument("--lr", default=0.01, type=float, help="initial learning rate")
    parser.add_argument("--momentum", default=0.9, type=float, metavar="M", help="momentum")
    parser.add_argument("--wd", "--weight-decay", default=1e-4, type=float, metavar="W", help="weight decay (default: 1e-4)", dest="weight_decay")
    parser.add_argument("--output-dir", default=".", help="path where to save")
    parser.add_argument("--pretrained", dest="pretrained", help="Use pre-trained models from the modelzoo", action="store_true")

    args = parser.parse_args()
    return args

if __name__ == "__main__":
    args = parse_args()
    ray.init(address=args.address)
    main(args)