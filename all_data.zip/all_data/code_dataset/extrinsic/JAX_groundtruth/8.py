import jax
import jax.numpy as jnp
import numpy as np
from flax import linen as nn
from flax.training import train_state
import optax
import argparse
import os
import random
from helpers import *
from model import *
from generate import *

# Parse command line arguments
argparser = argparse.ArgumentParser()
argparser.add_argument('filename', type=str)
argparser.add_argument('--n_epochs', type=int, default=2000)
argparser.add_argument('--print_every', type=int, default=100)
argparser.add_argument('--hidden_size', type=int, default=50)
argparser.add_argument('--n_layers', type=int, default=2)
argparser.add_argument('--learning_rate', type=float, default=0.01)
argparser.add_argument('--chunk_len', type=int, default=200)
args = argparser.parse_args()

file, file_len = read_file(args.filename)

def random_training_set(chunk_len):
    start_index = random.randint(0, file_len - chunk_len)
    end_index = start_index + chunk_len + 1
    chunk = file[start_index:end_index]
    inp = char_tensor(chunk[:-1])
    target = char_tensor(chunk[1:])
    return inp, target

class RNN(nn.Module):
    # Assume RNN is a flax module with a similar interface to the PyTorch class
    n_characters: int
    hidden_size: int
    n_layers: int
    
    @nn.compact
    def __call__(self, x, hidden):
        new_hidden, output = hidden, x # Model computation logic here
        return output, new_hidden

key = jax.random.PRNGKey(0)
decoder = RNN(n_characters=n_characters, hidden_size=args.hidden_size, n_layers=args.n_layers)
params = decoder.init(key, jnp.zeros((1,)), jnp.zeros((args.hidden_size,)))

optimizer = optax.adam(args.learning_rate)
state = train_state.TrainState.create(apply_fn=decoder.apply, params=params, tx=optimizer)
criterion = optax.softmax_cross_entropy_with_integer_labels

def train(state, inp, target):
    def loss_fn(params):
        hidden = jnp.zeros((args.n_layers, args.hidden_size))
        loss = 0.0
        for c in range(args.chunk_len):
            output, hidden = decoder.apply({'params': params}, inp[c], hidden)
            loss += criterion(output, target[c]).mean()
        return loss / args.chunk_len

    loss, grads = jax.value_and_grad(loss_fn)(state.params)
    state = state.apply_gradients(grads=grads)
    return state, loss

def save(params, filename):
    save_filename = os.path.splitext(os.path.basename(filename))[0] + '.npz'
    jnp.savez(save_filename, **params)
    print(f'Saved as {save_filename}')

try:
    start = time.time()
    all_losses = []
    loss_avg = 0

    print("Training for %d epochs..." % args.n_epochs)
    for epoch in range(1, args.n_epochs + 1):
        inp, target = random_training_set(args.chunk_len)
        state, loss = train(state, inp, target)
        loss_avg += loss

        if epoch % args.print_every == 0:
            print('[%s (%d %d%%) %.4f]' % (time_since(start), epoch, epoch / args.n_epochs * 100, loss))
            print(generate(decoder, 'Wh', 100), '\n')

    print("Saving...")
    save(state.params, args.filename)

except KeyboardInterrupt:
    print("Saving before quit...")
    save(state.params, args.filename)