'''GoogLeNet with JAX.'''
import jax
import jax.numpy as jnp
from jax.experimental import stax

def ConvBlock(kernel_size, filters, strides=(1, 1), padding='VALID'):
    return stax.Sequential([
        stax.Conv(filters, kernel_size, strides=strides, padding=padding),
        stax.BatchNorm(axis=(0, 1, 2)),
        stax.Relu
    ])

def Inception(in_planes, n1x1, n3x3red, n3x3, n5x5red, n5x5, pool_planes):
    b1 = ConvBlock((1, 1), n1x1)
    
    b2 = stax.Sequential([
        ConvBlock((1, 1), n3x3red),
        ConvBlock((3, 3), n3x3, padding='SAME')
    ])

    b3 = stax.Sequential([
        ConvBlock((1, 1), n5x5red),
        ConvBlock((3, 3), n5x5, padding='SAME'),
        ConvBlock((3, 3), n5x5, padding='SAME')
    ])

    b4 = stax.Sequential([
        stax.MaxPool((3, 3), strides=(1, 1), padding='SAME'),
        ConvBlock((1, 1), pool_planes)
    ])

    return stax.Serial(stax.FanOut(4),
                       stax.parallel(b1, b2, b3, b4),
                       stax.FanInConcat(axis=3))

def GoogLeNet():
    return stax.serial(
        ConvBlock((3, 3), 192, padding='SAME'),
        Inception(192, 64, 96, 128, 16, 32, 32),
        Inception(256, 128, 128, 192, 32, 96, 64),
        stax.MaxPool((3, 3), strides=(2, 2), padding='SAME'),
        Inception(480, 192, 96, 208, 16, 48, 64),
        Inception(512, 160, 112, 224, 24, 64, 64),
        Inception(512, 128, 128, 256, 24, 64, 64),
        Inception(512, 112, 144, 288, 32, 64, 64),
        Inception(528, 256, 160, 320, 32, 128, 128),
        stax.MaxPool((3, 3), strides=(2, 2), padding='SAME'),
        Inception(832, 256, 160, 320, 32, 128, 128),
        Inception(832, 384, 192, 384, 48, 128, 128),
        stax.AvgPool((8, 8), strides=(1, 1), padding='VALID'),
        stax.Flatten,
        stax.Dense(10)
    )

# Initialize the model
init_fun, apply_fun = GoogLeNet()
rng_key = jax.random.PRNGKey(0)
input_shape = (-1, 32, 32, 3)  # JAX expects NHWC
output_shape, params = init_fun(rng_key, input_shape)

# Example to verify the model works
x = jax.random.normal(rng_key, (1, 32, 32, 3))
y = apply_fun(params, x)
print(y.shape)