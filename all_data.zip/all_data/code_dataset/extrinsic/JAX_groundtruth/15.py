import os
import sys
import argparse
import logging

import jax
import jax.numpy as jnp
import pandas as pd
from jax.experimental import host_callback
from flax.training import checkpoints

from new_semantic_parsing import cli_utils
from new_semantic_parsing import EncoderDecoderWPointerModel, TopSchemaTokenizer
from new_semantic_parsing.data import (
    make_dataset,
    make_test_dataset,
    Seq2SeqDataCollator,
    PointerDataset,
)

os.environ["TOKENIZERS_PARALLELISM"] = "false"

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=logging.INFO,
    stream=sys.stdout,
)
logger = logging.getLogger(os.path.basename(__file__))


def parse_args(args=None):
    parser = argparse.ArgumentParser()

    parser.add_argument("--data", required=True, help="path to data file")
    parser.add_argument("--model", required=True, help="path to a model checkpoint")
    parser.add_argument("--output-file", required=True,
                        help="file to save preprocessed data")
    parser.add_argument("--schema-tokenizer", default=None,
                        help="path to a saved tokenizer (note that schema tokenizer includes text tokenizer), "
                             "by default --data/tokenizer is used")
    parser.add_argument("--batch-size", default=32, type=int)
    parser.add_argument("--num-beams", default=4, type=int)
    parser.add_argument("--src-max-len", default=63, type=int,
                        help="maximum length of the source sequence in tokens, "
                             "63 for TOP train set and bert-base-cased tokenizer")
    parser.add_argument("--tgt-max-len", default=98, type=int,
                        help="maximum length of the target sequence in tokens, "
                             "98 for TOP train set and bert-base-cased tokenizer")
    parser.add_argument("--device", default=None,
                        help="Use GPU if available by default")
    parser.add_argument("--seed", default=34, type=int)

    args = parser.parse_args(args)
    args.schema_tokenizer = args.schema_tokenizer or args.model

    if os.path.exists(args.output_file):
        raise ValueError(f"output file {args.output_file} already exists")

    if args.device is None:
        args.device = "cuda" if jax.lib.xla_bridge.get_backend().platform == 'gpu' else "cpu"

    return args


if __name__ == "__main__":
    args = parse_args()

    logger.info("Loading tokenizers")
    schema_tokenizer = TopSchemaTokenizer.load(args.schema_tokenizer)
    text_tokenizer = schema_tokenizer.src_tokenizer

    logger.info("Loading data")

    dataset: PointerDataset = make_test_dataset(
        args.data, schema_tokenizer, max_len=args.src_max_len
    )
    dataloader = jax_utils.prefetch_to_device(
        Seq2SeqDataCollator(pad_id=text_tokenizer.pad_token_id).collate_batch(dataset), buffer_size=2)

    logger.info(f"Maximum source text length {dataset.get_max_len()[0]}")

    model = EncoderDecoderWPointerModel.load(args.model)  # Replace torch.load() with appropriate JAX code

    model.eval()

    predictions_ids, predictions_str = cli_utils.iterative_prediction(
        model=model,
        dataloader=dataloader,
        schema_tokenizer=schema_tokenizer,
        max_len=args.tgt_max_len,
        num_beams=args.num_beams,
        device=args.device,
    )

    predictions_str = [schema_tokenizer.postprocess(p) for p in predictions_str]

    with open(args.output_file, "w") as f:
        for pred in predictions_str:
            f.write(pred + "\n")

    with open(args.output_file + ".ids", "w") as f:
        for pred in predictions_ids:
            f.write(str(pred) + "\n")

    logger.info(f"Prediction finished, results saved to {args.output_file}")
    logger.info(f'Ids saved to {args.output_file + ".ids"}')

    logger.info(f"Computing some metrics...")

    try:
        data_df = pd.read_table(args.data, names=["text", "tokens", "schema"])
        dataset_with_labels = make_dataset(args.data, schema_tokenizer)
        targets_str = list(data_df.schema)

        exact_match_str = sum(int(p == t) for p, t in zip(predictions_str, targets_str)) / len(
            targets_str
        )
        logger.info(f"Exact match: {exact_match_str}")

        targets_ids = [list(ex.labels.numpy()[:-1]) for ex in dataset_with_labels]
        exact_match_ids = sum(
            int(str(p) == str(l)) for p, l in zip(predictions_ids, targets_ids)
        ) / len(targets_str)
        logger.info(f"Exact match (ids): {exact_match_ids}")

    except FileNotFoundError as e:
        logger.warning(e)