"""Hierarchical RNN implementation with JAX"""
import jax
import jax.numpy as jnp
from jax import random
from flax import linen as nn
from flax.linen import initializers

# Encoder RNN Building
class EncoderRNN(nn.Module):
    input_size: int
    hidden_size: int
    n_layers: int
    dropout: float

    def setup(self):
        self.embedding = nn.Embed(self.input_size, self.hidden_size)
        self.gru = nn.GRUCell()

    def init_hidden(self, batch_size=1):
        return jnp.zeros((self.n_layers, batch_size, self.hidden_size))

    def __call__(self, input, hidden):
        embedded = self.embedding(input).reshape(1, -1)
        output, hidden = self.gru(embedded, hidden)
        return output, hidden

# Context RNN Building
class ContextRNN(nn.Module):
    encoder_hidden_size: int
    hidden_size: int
    n_layers: int
    dropout: float

    def setup(self):
        self.gru = nn.GRUCell()

    def init_hidden(self, batch_size=1):
        return jnp.zeros((self.n_layers, batch_size, self.hidden_size))

    def __call__(self, input, hidden):
        input = input.reshape(1, -1)
        output, hidden = self.gru(input, hidden)
        return output, hidden

# Decoder RNN Building
class DecoderRNN(nn.Module):
    context_output_size: int
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float

    def setup(self):
        self.embedding = nn.Embed(self.output_size, self.hidden_size)
        self.out = nn.Dense(self.output_size)
        self.gru = nn.GRUCell()

    def init_hidden(self, batch_size=1):
        return jnp.zeros((self.n_layers, batch_size, self.hidden_size))

    def __call__(self, context_output, input, hidden):
        context_output = context_output.reshape(1, -1)
        input_cat = jnp.concatenate([context_output, self.embedding(input)], axis=1)
        output, hidden = self.gru(input_cat, hidden)
        output = nn.log_softmax(self.out(output))
        return output, hidden

# Seq2seq's Attention Decoder RNN Building
class DecoderRNNSeq(nn.Module):
    hidden_size: int
    output_size: int
    n_layers: int
    dropout: float
    max_length: int

    def setup(self):
        self.embedding = nn.Embed(self.output_size, self.hidden_size)
        self.attn = nn.Dense(self.max_length)
        self.attn_combine = nn.Dense(self.hidden_size)
        self.out = nn.Dense(self.output_size)
        self.gru = nn.GRUCell()

    def init_hidden(self, batch_size=1):
        return jnp.zeros((self.n_layers, batch_size, self.hidden_size))

    def __call__(self, input, hidden, encoder_outputs):
        embedded = self.embedding(input).reshape(1, -1)

        attn_weights = nn.softmax(self.attn(jnp.concatenate((embedded, hidden[0]), axis=1)))
        attn_applied = jnp.bmm(attn_weights[:, None, :], encoder_outputs[:, None, :])

        output = jnp.concatenate((embedded, attn_applied[0]), axis=1)
        output = self.attn_combine(output).reshape(1, -1)

        output, hidden = self.gru(output, hidden)
        output = nn.log_softmax(self.out(output))
        return output, hidden, attn_weights