import functools
import jax.numpy as jnp
import jax
import haiku as hk
import flax.linen as nn

# Assuming WildcatPool2d and ClassWisePool are also converted to JAX compatible modules

class ResNetWSL(hk.Module):

    def __init__(self, model, num_classes, pooling=None, dense=False):
        super().__init__()
        self.dense = dense
        self.model = model
        self.classifier = hk.Conv2D(output_channels=num_classes, kernel_shape=1, stride=1, padding='VALID', with_bias=True)
        self.spatial_pooling = pooling
        self.image_normalization_mean = jnp.array([0.485, 0.456, 0.406])
        self.image_normalization_std = jnp.array([0.229, 0.224, 0.225])

    def __call__(self, x):
        x = self.model(x, is_training=True)
        x = self.classifier(x)
        if not self.dense:
            x = self.spatial_pooling(x)
        return x

def resnet50_wildcat(num_classes, pretrained=True, kmax=1, kmin=None, alpha=1, num_maps=1):
    def forward_fn(x):
        resnet_haiku = hk.nets.ResNet50(num_classes=None, resnet_v2=False)
        features = resnet_haiku(x, is_training=pretrained)
        return ResNetWSL(resnet_haiku, num_classes * num_maps, pooling=JAXWildcatPool2d(kmax, kmin, alpha))(features)

    return hk.transform(forward_fn)

def resnet101_wildcat(num_classes, pretrained=True, kmax=1, kmin=None, alpha=1, num_maps=1):
    def forward_fn(x):
        resnet_haiku = hk.nets.ResNet101(num_classes=None, resnet_v2=False)
        features = resnet_haiku(x, is_training=pretrained)
        return ResNetWSL(resnet_haiku, num_classes * num_maps, pooling=JAXWildcatPool2d(kmax, kmin, alpha))(features)

    return hk.transform(forward_fn)

# Note: Make sure JAXWildcatPool2d and JAXClassWisePool are implemented replacements for WildcatPool2d and ClassWisePool respectively.