import flax.linen as nn
import jax
import jax.numpy as jnp
import logging as log
import numpy as np
import optax

__all__ = ['LightNet']

class LightNet(nn.Module):
    layers: nn.Module = None
    loss: list = None
    postprocess: list = None
    seen: int = 0

    def _forward(self, x):
        log.debug('Running default forward functions')
        if isinstance(self.layers, nn.Sequential):
            return self.layers(x)
        elif isinstance(self.layers, nn.ModuleList):
            log.warn('No _forward function defined, looping sequentially over modulelist')
            for module in self.layers:
                x = module(x)
            return x
        else:
            raise NotImplementedError(f'No _forward function defined and no default behaviour for this type of layers [{type(self.layers)}]')

    def __call__(self, x, target=None, training=False):
        if training:
            self.seen += x.shape[0]
            outputs = self._forward(x)

            assert len(outputs) == len(self.loss)

            total_loss = 0
            for idx, loss_fn in enumerate(self.loss):
                assert callable(loss_fn)
                total_loss += loss_fn(outputs[idx], target)
            return total_loss
        else:
            outputs = self._forward(x)
            dets = []

            tdets = [postprocess_fn(outputs[idx]) for idx, postprocess_fn in enumerate(self.postprocess)]
            batch_size = len(tdets[0])

            for b in range(batch_size):
                single_dets = []
                for op in range(len(outputs)):
                    single_dets.extend(tdets[op][b])
                dets.append(single_dets)

            return dets, 0.0

    def init_weights(self, params, mode='fan_in', slope=0.0):
        # Note: JAX/Flax will usually manage parameter initialization through the module's setup and init functions.
        info_list = []
        for name, param in params.items():
            if 'Conv' in name:
                info_list.append(str(name))
                params[name] = nn.initializers.kaiming_normal(a=slope, mode=mode)(jax.random.PRNGKey(0), param.shape, param.dtype)
            elif 'BatchNorm' in name:
                info_list.append(str(name))
                params[name] = jnp.ones_like(param)
            elif 'Dense' in name:
                info_list.append(str(name))
                params[name] = nn.initializers.normal(0.01)(jax.random.PRNGKey(0), param.shape, param.dtype)
        log.info('Initialized weights\n\n%s\n' % '\n'.join(info_list))
        return params

    def save_weights(self, params, seen, weights_file):
        np.savez(weights_file, seen=seen, **params)
        log.info(f'Saved weights as {weights_file}')

    def load_weights(self, weights_file, params, clear=False):
        with np.load(weights_file, allow_pickle=True) as data:
            seen = data["seen"] if not clear else 0
            weights = {k: data[k] for k in data.files if k != "seen"}

            updated_params = {**params, **weights}  # Perform partial update if needed
            log.info(f'Loaded weights from {weights_file}')
        
        return updated_params, seen