import os
import random
import shutil
import tempfile

import numpy as np
import onnx
import onnx_tf
import tensorflow as tf
from tensorflow import keras
from torchvision import datasets, transforms
import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from flax.training import train_state
import jax.random

BATCH_SIZE = 64
EPOCHS = 5
SEED = 42
N = 100
LEARNING_RATE = 0.02
MOMENTUM = 0.25

class JAXMNIST(nn.Module):
    n: int

    @nn.compact
    def __call__(self, x):
        x = nn.Dense(features=self.n)(x)
        x = nn.relu(x)
        x = nn.Dense(features=10)(x)
        x = jax.nn.log_softmax(x, axis=1)
        return x

def create_train_state(rng, model, learning_rate):
    params = model.init(rng, jnp.ones([1, 28 * 28]))['params']
    tx = optax.sgd(learning_rate, momentum=MOMENTUM)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

def train_epoch(state, train_ds, batch_size, rng):
    train_ds_size = len(train_ds.dataset)
    steps_per_epoch = train_ds_size // batch_size

    perms = jax.random.permutation(rng, train_ds_size)
    perms = perms[:steps_per_epoch * batch_size]
    perms = perms.reshape((steps_per_epoch, batch_size))

    epoch_loss = 0
    for perm in perms:
        batch_data = jnp.take(train_ds.dataset.data.view(-1, 28*28), perm, axis=0)
        batch_targets = jnp.take(train_ds.dataset.targets, perm, axis=0)

        def loss_fn(params):
            logits = state.apply_fn({'params': params}, batch_data)
            loss = optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(batch_targets, 10))
            return jnp.mean(loss)

        grad_fn = jax.value_and_grad(loss_fn)
        loss, grads = grad_fn(state.params)
        state = state.apply_gradients(grads=grads)
        epoch_loss += loss

    return state, epoch_loss / steps_per_epoch

def compute_metrics(logits, labels):
    loss = optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(labels, 10))
    accuracy = jnp.mean(jnp.argmax(logits, -1) == labels)
    return {'loss': jnp.mean(loss), 'accuracy': accuracy}

def eval_model(state, test_ds):
    logits = state.apply_fn({'params': state.params}, test_ds.dataset.data.view(-1, 28*28))
    metrics = compute_metrics(logits, test_ds.dataset.targets)
    return metrics['loss'], metrics['accuracy']

class ImportExportModelTest(tf.test.TestCase):
    def setUp(self):
        self.tmpDir = tempfile.mkdtemp()
        self.dataDir = os.path.join(self.tmpDir, "data")
        np.random.seed(SEED)
        random.seed(SEED)

    def tearDown(self):
        shutil.rmtree(self.tmpDir)

    def testImportFromPytorch(self):
        # Datasets
        train_ds = datasets.MNIST(self.dataDir, train=True, download=True,
                                  transform=transforms.Compose([
                                      transforms.ToTensor(),
                                      transforms.Normalize((0.1307,), (0.3081,))]))
        test_ds = datasets.MNIST(self.dataDir, train=False, download=True,
                                 transform=transforms.Compose([
                                     transforms.ToTensor(),
                                     transforms.Normalize((0.1307,), (0.3081,))]))

        # Initialize JAX model
        rng = jax.random.PRNGKey(SEED)
        model = JAXMNIST(N)
        state = create_train_state(rng, model, LEARNING_RATE)

        # Train
        for _ in range(EPOCHS):
            rng, input_rng = jax.random.split(rng)
            state, train_loss = train_epoch(state, train_ds, BATCH_SIZE, input_rng)

        # Evaluate
        test_loss, test_accuracy = eval_model(state, test_ds)

        self.assertAlmostEqual(test_accuracy, SOME_EXPECTED_ACCURACY, places=4)

if __name__ == "__main__":
    tf.test.main()