import numpy as np
import argparse
import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import train_state
import optax
from jax.random import PRNGKey

class Net(nn.Module):
    dropout: float
    fc1_size: int
    fc2_size: int

    def setup(self):
        self.fc1 = nn.Dense(self.fc1_size)
        self.relu1 = nn.relu
        self.dropout_layer = nn.Dropout(self.dropout)
        self.fc2 = nn.Dense(self.fc2_size)
        self.prelu = nn.PReLU()
        self.out = nn.Dense(1)
        self.out_act = nn.sigmoid

    def __call__(self, input_, train=False):
        a1 = self.fc1(input_)
        h1 = self.relu1(a1)
        dout = self.dropout_layer(h1, deterministic=not train)
        a2 = self.fc2(dout)
        h2 = self.prelu(a2)
        a3 = self.out(h2)
        y = self.out_act(a3)
        return y

def model_creator(config):
    return Net(dropout=config["dropout"], fc1_size=config["fc1_size"], fc2_size=config["fc2_size"])

def get_optimizer(config):
    return optax.sgd(learning_rate=config["lr"])

def get_train_val_data():
    def get_x_y(size):
        input_size = 50
        x1 = np.random.randn(size // 2, input_size)
        x2 = np.random.randn(size // 2, input_size) + 1.5
        x = np.concatenate([x1, x2], axis=0)
        y1 = np.zeros((size // 2, 1))
        y2 = np.ones((size // 2, 1))
        y = np.concatenate([y1, y2], axis=0)
        return x, y

    train_data = get_x_y(size=1000)
    val_data = get_x_y(size=400)
    return train_data, val_data

def mse_loss_fn(model, params, batch, rng, train=False):
    inputs, targets = batch
    preds = model.apply({"params": params}, inputs, rngs={"dropout": rng}, train=train)
    return jnp.mean(optax.sigmoid_binary_cross_entropy(preds, targets))

def train_example(args):
    train_data, val_data = get_train_val_data()
    
    rng = PRNGKey(0)
    rng, init_rng = jax.random.split(rng)
    
    init_data = jnp.array(train_data[0][:1])
    search_space = create_linear_search_space()
    best_accuracy = 0
    best_params = None
    for _ in range(args.trials):
        trial_config = {key: np.random.choice(values) if isinstance(values, list) else values.sample() for key, values in search_space.items()}
        model = model_creator(trial_config)
        params = model.init(init_rng, init_data, train=True)['params']
        optimizer = get_optimizer(trial_config)
        state = train_state.TrainState.create(apply_fn=model.apply, params=params, tx=optimizer)
        
        for epoch in range(args.epochs):
            state = train_epoch(state, (jnp.array(train_data[0]), jnp.array(train_data[1])), rng)
            
        y_hat = model.apply({"params": state.params}, jnp.array(val_data[0]))
        accuracy = jnp.mean(jnp.round(y_hat) == jnp.array(val_data[1]))
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_params = state.params

    print("Evaluate: accuracy is", best_accuracy)

def create_linear_search_space():
    return {
        "dropout": jax.random.uniform(PRNGKey(0), shape=(1,), minval=0.2, maxval=0.3),
        "fc1_size": [50, 64],
        "fc2_size": [100, 128],
        "lr": [0.001, 0.003, 0.01],
        "batch_size": [32, 64]
    }

def train_epoch(state, train_data, rng):
    def train_step(state, batch, rng):
        grad_fn = jax.value_and_grad(mse_loss_fn)
        loss, grads = grad_fn(state.apply_fn, state.params, batch, rng, train=True)
        state = state.apply_gradients(grads=grads)
        return state

    batch_size = 32
    num_batches = len(train_data[0]) // batch_size
    for i in range(num_batches):
        batch = (train_data[0][i * batch_size:(i + 1) * batch_size], train_data[1][i * batch_size:(i + 1) * batch_size])
        state = train_step(state, batch, rng)
    return state

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog='Autoestimator_jax', description='Automatically fit the model and return the best model.')
    parser.add_argument("--epochs", type=int, default=1, help="The number of epochs in each trial.")
    parser.add_argument('--trials', type=int, default=4, help="The number of searching trials.")
    args = parser.parse_args()
    train_example(args)