import numpy as np
import jax.numpy as jnp
from flax import linen as nn
from nupic.research.frameworks.jax.models.le_sparse_net import (
    add_sparse_linear_layer,
)

class StandardMLP(nn.Module):
    input_size: tuple
    num_classes: int
    hidden_sizes: tuple = (100, 100)

    @nn.compact
    def __call__(self, x):
        x = jnp.reshape(x, (x.shape[0], -1))  # Flatten layer
        for hidden_size in self.hidden_sizes:
            x = nn.Dense(hidden_size)(x)
            x = nn.relu(x)
        x = nn.Dense(self.num_classes)(x)
        return x


class ModifiedInitStandardMLP(StandardMLP):

    def setup(self):
        super().setup()  # Call the parent setup

        # Custom weight initialization considering input density and weight density
        weight_density = 1.0
        input_flag = False

        def init_function(key, shape, dtype=jnp.float32):
            nonlocal input_flag
            input_density = 1.0 if not input_flag else 0.5
            input_flag = True
            fan_in, _ = shape
            bound = 1.0 / np.sqrt(input_density * weight_density * fan_in)
            return jax.random.uniform(key, shape, dtype, minval=-bound, maxval=bound)

        self.param = self.param.replace(self, {})  # A workaround to hold our custom init


class SparseMLP(nn.Module):
    input_size: tuple
    output_size: int
    kw_percent_on: tuple = (0.1,)
    weight_sparsity: tuple = (0.6,)
    boost_strength: float = 1.67
    boost_strength_factor: float = 0.9
    duty_cycle_period: int = 1000
    k_inference_factor: float = 1.5
    use_batch_norm: bool = True
    dropout: float = 0.0
    consolidated_sparse_weights: bool = False
    hidden_sizes: tuple = (100,)

    @nn.compact
    def __call__(self, x):
        x = jnp.reshape(x, (x.shape[0], -1))  # Flatten layer
        for i, hidden_size in enumerate(self.hidden_sizes):
            add_sparse_linear_layer(
                network=self, 
                layer_name=f"sparse_layer_{i + 1}",
                input_size=self.input_size,
                linear_n=hidden_size,
                dropout=self.dropout,
                use_batch_norm=self.use_batch_norm,
                weight_sparsity=self.weight_sparsity[i],
                percent_on=self.kw_percent_on[i],
                k_inference_factor=self.k_inference_factor,
                boost_strength=self.boost_strength,
                boost_strength_factor=self.boost_strength_factor,
                duty_cycle_period=self.duty_cycle_period,
                consolidated_sparse_weights=self.consolidated_sparse_weights,
            )
            self.input_size = hidden_size
        x = nn.Dense(self.output_size)(x)
        return x