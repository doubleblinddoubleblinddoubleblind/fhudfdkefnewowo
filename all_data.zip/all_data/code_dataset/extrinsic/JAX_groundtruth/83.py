import unittest

from transformers import CTRLConfig, is_flax_available
from transformers.testing_utils import require_flax, slow

from ..generation.test_generation_utils import GenerationTesterMixin
from ..test_configuration_common import ConfigTester
from ..test_modeling_common import FlaxModelTesterMixin, ids_tensor

if is_flax_available():
    from transformers import (
        CTRL_PRETRAINED_MODEL_ARCHIVE_LIST,
        FlaxCTRLForSequenceClassification,
        FlaxCTRLLMHeadModel,
        FlaxCTRLModel,
    )


class CTRLModelTester:
    def __init__(
        self,
        parent,
    ):
        self.parent = parent
        self.batch_size = 14
        self.seq_length = 7
        self.is_training = True
        self.use_token_type_ids = True
        self.use_labels = True
        self.use_mc_token_ids = True
        self.vocab_size = 99
        self.hidden_size = 32
        self.num_hidden_layers = 5
        self.num_attention_heads = 4
        self.intermediate_size = 37
        self.hidden_act = "gelu"
        self.hidden_dropout_prob = 0.1
        self