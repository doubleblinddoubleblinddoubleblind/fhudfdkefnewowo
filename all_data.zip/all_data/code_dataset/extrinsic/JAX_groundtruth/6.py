import argparse
import jax
import jax.numpy as jnp
import optax
import flax.linen as nn
from flax.training import train_state
from torchvision import datasets, transforms
from functools import partial


def seed(args):
    jax.random.PRNGKey(args.seed)


def keywords(args):
    return {'num_workers': 0, 'pin_memory': True} if args.cuda else {}


def load_train(args, kwargs):
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])
    train_loader = torch.utils.data.DataLoader(
        datasets.MNIST('../data', train=True, download=True, transform=transform),
        batch_size=args.batch_size, shuffle=True, **kwargs)
    test_loader = torch.utils.data.DataLoader(
        datasets.MNIST('../data', train=False, transform=transform),
        batch_size=args.batch_size, shuffle=False, **kwargs)
    return train_loader, test_loader


class Net(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=10, kernel_size=(5, 5))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = nn.Conv(features=20, kernel_size=(5, 5))(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=0.5)(x, deterministic=False)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = x.reshape((x.shape[0], -1))
        x = nn.Dense(features=50)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=0.5)(x, deterministic=False)
        x = nn.Dense(features=10)(x)
        return nn.log_softmax(x, axis=-1)


def get_model(args):
    model = Net()
    rng = jax.random.PRNGKey(0)
    dummy_input = jnp.ones((1, 28, 28, 1))
    variables = model.init(rng, dummy_input)
    optimizer = optax.sgd(learning_rate=args.lr, momentum=args.momentum)
    state = train_state.TrainState.create(apply_fn=model.apply, params=variables['params'], tx=optimizer)
    return state


@jax.jit
def apply_model(state, images, labels):
    def loss_fn(params):
        logits = state.apply_fn(params, images)
        loss = optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(labels, 10))
        return jnp.mean(loss), logits
    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    (loss, logits), grads = grad_fn(state.params)
    return grads, loss, logits


def update_model(state, grads):
    return state.apply_gradients(grads=grads)


def compute_accuracy(logits, labels):
    predictions = jnp.argmax(logits, axis=-1)
    return jnp.mean(predictions == labels)


def train_epoch(state, train_loader):
    loss_list = []
    accuracy_list = []
    for batch_idx, (data, target) in enumerate(train_loader):
        data = jnp.expand_dims(data.numpy(), axis=-1)
        grad, loss, logits = apply_model(state, data, target.numpy())
        state = update_model(state, grad)
        loss_list.append(loss)
        accuracy = compute_accuracy(logits, target.numpy())
        accuracy_list.append(accuracy)
    train_loss = jnp.mean(jnp.array(loss_list))
    train_accuracy = jnp.mean(jnp.array(accuracy_list))
    return state, train_loss, train_accuracy


@jax.jit
def test_epoch(state, test_loader):
    test_loss = 0
    correct = 0
    for data, target in test_loader:
        data = jnp.expand_dims(data.numpy(), axis=-1)
        _, loss, logits = apply_model(state, data, target.numpy())
        test_loss += loss
        correct += jnp.sum(jnp.argmax(logits, axis=-1) == target.numpy())
    test_loss /= len(test_loader)
    test_accuracy = correct / len(test_loader.dataset)
    return test_loss, test_accuracy


def main():
    parser = argparse.ArgumentParser(description='JAX MNIST Example')
    parser.add_argument('--batch-size', type=int, default=64, metavar='N',
                        help='input batch size for training (default: 64)')
    parser.add_argument('--test-batch-size', type=int, default=1000, metavar='N',
                        help='input batch size for testing (default: 1000)')
    parser.add_argument('--epochs', type=int, default=10, metavar='N',
                        help='number of epochs to train (default: 10)')
    parser.add_argument('--lr', type=float, default=0.01, metavar='LR',
                        help='learning rate (default: 0.01)')
    parser.add_argument('--momentum', type=float, default=0.5, metavar='M',
                        help='SGD momentum (default: 0.5)')
    parser.add_argument('--no-cuda', action='store_true', default=False,
                        help='enables CUDA training')
    parser.add_argument('--seed', type=int, default=1, metavar='S',
                        help='random seed (default: 1)')
    parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                        help='how many batches to wait before logging training status')
    args = parser.parse_args()
    args.cuda = not args.no_cuda and jax.local_devices()[0].device_kind == 'tpu'
    
    seed(args)

    kwargs = keywords(args)
    print(kwargs)
    train_loader, test_loader = load_train(args, kwargs)

    state = get_model(args)

    for epoch in range(1, args.epochs + 1):
        state, train_loss, train_accuracy = train_epoch(state, train_loader)
        test_loss, test_accuracy = test_epoch(state, test_loader)
        print(f'Epoch {epoch}:\nTrain loss: {train_loss:.4f}, Train accuracy: {train_accuracy:.2%}')
        print(f'Test loss: {test_loss:.4f}, Test accuracy: {test_accuracy:.2%}\n')

if __name__ == '__main__':
    main()