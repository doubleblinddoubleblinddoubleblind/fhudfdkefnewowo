import argparse
import gym
import numpy as np
from itertools import count
from collections import namedtuple

import jax
import jax.numpy as jnp
from jax import random, grad, jit, vmap
from flax import linen as nn
from flax.training import train_state
import optax


parser = argparse.ArgumentParser(description='JAX actor-critic example')
parser.add_argument('--gamma', type=float, default=0.99, metavar='G',
                    help='discount factor (default: 0.99)')
parser.add_argument('--seed', type=int, default=543, metavar='N',
                    help='random seed (default: 1)')
parser.add_argument('--render', action='store_true',
                    help='render the environment')
parser.add_argument('--log-interval', type=int, default=10, metavar='N',
                    help='interval between training status logs (default: 10)')
args = parser.parse_args()


env = gym.make('CartPole-v0')
env.seed(args.seed)
key = random.PRNGKey(args.seed)


SavedAction = namedtuple('SavedAction', ['action', 'value'])

class Policy(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.relu(nn.Dense(128)(x))
        action_scores = nn.Dense(2)(x)
        state_values = nn.Dense(1)(x)
        return nn.softmax(action_scores), state_values


model = Policy()
params = model.init(key, jnp.ones((4,)))

optimizer = optax.adam(learning_rate=3e-2)
opt_state = optimizer.init(params)


def select_action(state, params, key):
    state = jnp.array(state)
    probs, state_value = model.apply(params, state)
    key, subkey = random.split(key)
    action = jax.random.categorical(subkey, jnp.log(probs))
    return action, SavedAction(action, state_value)


@jit
def update(params, opt_state, saved_actions, rewards):
    def loss_fn(params):
        value_loss = 0
        for (action, value), r in zip(saved_actions, rewards):
            reward = r - value
            value_loss += (r - value) ** 2  # Mean squared error for value prediction
        return value_loss

    grads = grad(loss_fn)(params)
    updates, opt_state = optimizer.update(grads, opt_state)
    params = optax.apply_updates(params, updates)
    return params, opt_state


running_reward = 10
for i_episode in count(1):
    state = env.reset()
    saved_actions = []
    rewards = []

    for t in range(10000): # Don't infinite loop while learning
        action, saved_action = select_action(state, params, key)
        state, reward, done, _ = env.step(int(action))
        if args.render:
            env.render()
        saved_actions.append(saved_action)
        rewards.append(reward)
        if done:
            break

    # Compute the discounted reward
    R = 0
    discounted_rewards = []
    for r in rewards[::-1]:
        R = r + args.gamma * R
        discounted_rewards.insert(0, R)
        
    discounted_rewards = np.array(discounted_rewards)
    discounted_rewards = (discounted_rewards - discounted_rewards.mean()) / (discounted_rewards.std() + np.finfo(np.float32).eps)

    # Update policy and value functions
    params, opt_state = update(params, opt_state, saved_actions, discounted_rewards)

    running_reward = running_reward * 0.99 + t * 0.01
    if i_episode % args.log_interval == 0:
        print('Episode {}\tLast length: {:5d}\tAverage length: {:.2f}'.format(
            i_episode, t, running_reward))
    if running_reward > env.spec.reward_threshold:
        print("Solved! Running reward is now {} and "
              "the last episode runs to {} time steps!".format(running_reward, t))
        break