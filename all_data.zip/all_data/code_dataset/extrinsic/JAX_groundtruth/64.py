import jax
import jax.numpy as jnp
from jax import lax
from flax import linen as nn

################################################################################
# Modules #
################################################################################

class StackedBRNN(nn.Module):
    input_size: int
    hidden_size: int
    num_layers: int
    dropout_rate: float = 0
    dropout_output: bool = False
    variational_dropout: bool = False
    rnn_type: type = nn.LSTM
    concat_layers: bool = False
    padding: bool = False
    bidirectional: bool = True
    return_single_timestep: bool = False

    def setup(self):
        self.rnns = [
            nn.LSTMCell(input_size if i == 0 else (2 * self.hidden_size if self.bidirectional else self.hidden_size), self.hidden_size) 
            for i in range(self.num_layers)
        ]

    def __call__(self, x, x_mask, rng, training: bool = False):
        if self.padding or self.return_single_timestep or not training:
            return self._forward_padded(x, x_mask, rng, training)
        return self._forward_unpadded(x, x_mask, rng, training)

    def _forward_unpadded(self, x, x_mask, rng, training: bool):
        outputs = [x]
        for i in range(self.num_layers):
            rnn_input = outputs[-1]
            rnn_input = dropout(rnn_input, self.dropout_rate, rng, 
                                shared_axes=(1,) if self.variational_dropout else (), training=training)
            rnn_output, _ = nn.scan(self.rnns[i])(rnn_input, training=training)
            outputs.append(rnn_output)

        if self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=2)
        else:
            output = outputs[-1]

        if self.dropout_output:
            output = dropout(output, self.dropout_rate, rng, 
                             shared_axes=(1,) if self.variational_dropout else (), training=training)
        return output

    def _forward_padded(self, x, x_mask, rng, training: bool):
        lengths = jnp.sum(x_mask == 0, axis=1)
        idx_sort = jnp.argsort(-lengths)
        idx_unsort = jnp.argsort(idx_sort)
        lengths = lengths[idx_sort]
        rnn_input = x[idx_sort]

        outputs, single_outputs = [rnn_input], []
        for i in range(self.num_layers):
            rnn_input = outputs[-1]
            if self.dropout_rate > 0:
                rnn_input = dropout(rnn_input, self.dropout_rate, rng, 
                                    shared_axes=(1,) if self.variational_dropout else (), training=training)
            rnn_output, final_state = nn.LSTMCell(rnn_input, training=training)
            rnn_output = jax.lax.stop_gradient(rnn_output)
            rnn_output = nn.utils.rnn.pad_packed_sequence(rnn_output, total_length=x.shape[1])
            single_outputs.append(final_state[-1])
            outputs.append(rnn_output)

        if self.return_single_timestep:
            output = single_outputs[-1]
        elif self.concat_layers:
            output = jnp.concatenate(outputs[1:], axis=2)
        else:
            output = outputs[-1]

        output = output[idx_unsort]

        if self.dropout_output and self.dropout_rate > 0:
            output = dropout(output, self.dropout_rate, rng, 
                             shared_axes=(1,) if self.variational_dropout else (), training=training)
        return output

class SeqAttnMatch(nn.Module):
    input_size: int
    identity: bool

    def setup(self):
        if not self.identity:
            self.linear = nn.Dense(self.input_size)
        else:
            self.linear = None

    def __call__(self, x, y, y_mask):
        if self.linear:
            x_proj = nn.relu(self.linear(x))
            y_proj = nn.relu(self.linear(y))
        else:
            x_proj = x
            y_proj = y

        scores = jnp.einsum('bih,bjh->bij', x_proj, y_proj)
        y_mask = jnp.expand_dims(y_mask, axis=1).repeat(scores.shape[1], axis=1)
        scores = scores - jnp.where(y_mask, jnp.inf, 0)

        alpha = nn.softmax(scores, axis=-1)
        matched_seq = jnp.einsum('bij,bjd->bid', alpha, y)
        return matched_seq

class BilinearSeqAttn(nn.Module):
    x_size: int
    y_size: int
    identity: bool

    def setup(self):
        if not self.identity:
            self.linear = nn.Dense(self.x_size)
        else:
            self.linear = None

    def __call__(self, x, y, x_mask):
        Wy = self.linear(y) if self.linear is not None else y
        xWy = jnp.einsum('bih,bd->bi', x, Wy)
        xWy = xWy - jnp.where(x_mask, jnp.inf, 0)
        alpha = nn.log_softmax(xWy, axis=-1)
        return alpha

class LinearSeqAttn(nn.Module):
    input_size: int

    def setup(self):
        self.linear = nn.Dense(1)

    def __call__(self, x, x_mask):
        x_flat = x.reshape(-1, x.shape[-1])
        scores = self.linear(x_flat).reshape(x.shape[0], x.shape[1])
        scores = scores - jnp.where(x_mask, jnp.inf, 0)
        alpha = nn.softmax(scores, axis=-1)
        return alpha

################################################################################
# Functional #
################################################################################

def dropout(x, drop_prob, rng, shared_axes=(), training=False):
    if drop_prob == 0 or not training:
        return x

    keep_prob = 1.0 - drop_prob
    mask_shape = list(x.shape)
    for axis in shared_axes:
        mask_shape[axis] = 1
    rng, dropout_rng = jax.random.split(rng)
    mask = jax.random.bernoulli(dropout_rng, keep_prob, shape=mask_shape)
    return lax.select(mask, x / keep_prob, jnp.zeros_like(x))

def multi_nll_loss(scores, target_mask):
    scores = jnp.exp(scores)
    loss = 0
    for i in range(scores.shape[0]):
        prob = (scores[i] * target_mask[i]).sum() / scores[i].sum()
        loss += -jnp.log(prob)
    return loss

def weighted_avg(x, weights):
    return jnp.einsum('bp,bph->bh', weights, x)