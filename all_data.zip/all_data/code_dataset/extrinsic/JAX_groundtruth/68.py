import jax.numpy as jnp
import flax.linen as nn
from flax.core import freeze, unfreeze
from functools import partial

from torchvision.models import resnet, densenet, vgg, alexnet, squeezenet

class CNNEncoderBase(nn.Module):
    model: nn.Module
    context_size: int
    context_transform: nn.Module = None
    context_nonlinearity: str = None
    spatial_context: bool = True
    finetune: bool = True

    def setup(self):
        if self.context_transform is not None:
            if self.spatial_context:
                self.context_transform = nn.Conv(
                    features=self.context_transform, kernel_size=(1, 1)
                )
            else:
                self.context_transform = nn.Dense(features=self.context_transform)
            
            if self.context_nonlinearity is not None:
                self.context_nonlinearity = getattr(nn.activation, self.context_nonlinearity)

    def __call__(self, variables, x, training=False):
        if not self.finetune:
            def freeze_fn(d):
                for key in d:
                    d[key] = freeze(d[key], batch=True)
            freeze_fn(variables)
        
        variables = self.model.variables
        x = self.model.apply(variables, x, training=training)

        if not self.spatial_context:
            x = nn.avg_pool(x, window_shape=(x.shape[-2:]))
        if self.context_transform:
            x = self.context_transform(x)
        if self.context_nonlinearity:
            x = self.context_nonlinearity(x)
        return x

class ResNetEncoder(CNNEncoderBase):

    def __init__(self, model='resnet50', pretrained=True, **kwargs):
        model_def = resnet.__dict__[model]
        super().__init__(model=model_def, context_size=model_def.fc.in_features, **kwargs)

    def setup(self):
        super().setup()
        del self.model.fc

    def __call__(self, variables, x, training=False):
        x = self.model.apply(variables, x, training=training, method=self.model.forward_features)
        return super().__call__(variables, x, training)

class DenseNetEncoder(CNNEncoderBase):

    def __init__(self, model='densenet121', pretrained=True, **kwargs):
        model_def = densenet.__dict__[model]
        super().__init__(model=model_def, context_size=model_def.classifier.in_features, **kwargs)

    def setup(self):
        super().setup()
        del self.model.classifier

    def __call__(self, variables, x, training=False):
        x = self.model.apply(variables, x, training=training, method=self.model.features)
        return super().__call__(variables, x, training)

class VGGEncoder(CNNEncoderBase):

    def __init__(self, model='vgg16', pretrained=True, **kwargs):
        model_def = vgg.__dict__[model]
        super().__init__(model=model_def, context_size=model_def.classifier.in_features, **kwargs)

    def setup(self):
        super().setup()
        del self.model.classifier

    def __call__(self, variables, x, training=False):
        x = self.model.apply(variables, x, training=training, method=self.model.features)
        return super().__call__(variables, x, training)

class AlexNetEncoder(CNNEncoderBase):

    def __init__(self, model='alexnet', pretrained=True, **kwargs):
        model_def = alexnet.__dict__[model]
        super().__init__(model=model_def, context_size=model_def.classifier.in_features, **kwargs)

    def setup(self):
        super().setup()
        del self.model.classifier

    def __call__(self, variables, x, training=False):
        x = self.model.apply(variables, x, training=training, method=self.model.features)
        return super().__call__(variables, x, training)

class SqueezeNetEncoder(CNNEncoderBase):

    def __init__(self, model='squeezenet1_1', pretrained=True, **kwargs):
        model_def = squeezenet.__dict__[model]
        super().__init__(model=model_def, context_size=model_def.classifier.in_features, **kwargs)

    def setup(self):
        super().setup()
        del self.model.classifier

    def __call__(self, variables, x, training=False):
        x = self.model.apply(variables, x, training=training, method=self.model.features)
        return super().__call__(variables, x, training)