import numpy as np
import jax
import jax.numpy as jnp
from jax import random

# Create input data
# input size = 4
# seq size = [3, 1]
# batch size = 2
input = [[[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]], 
         [[13, 14, 15, 16]]]

# Lengths of sequences of input data
seq_lengths = jnp.array(list(map(len, input)))

# Max length of sequences
max_length = seq_lengths.max()

# Create sequence tensor for multi-sequences (4 is input size)
seq_tensor = jnp.zeros((len(input), max_length, 4))

# Fill sequence tensor with the first sequence
seq_tensor = seq_tensor.at[0, :3].set(jnp.asarray(input[0]))

# Fill sequence tensor with the second sequence
seq_tensor = seq_tensor.at[1, :1].set(jnp.asarray(input[1]))

# Transpose batch dimension and sequence dimension before padding data
seq_tensor = jnp.transpose(seq_tensor, (1, 0, 2))

# Helper function to pack padded sequence
def pack_padded_sequence(seq_tensor, seq_lengths):
    ordered_indices = jnp.argsort(-seq_lengths)
    seq_tensor = seq_tensor[:, ordered_indices, :]
    seq_lengths = seq_lengths[ordered_indices]
    packed_tensor = []
    for i in range(max_length):
        for j in range(len(input)):
            if i < seq_lengths[j]:
                packed_tensor.append(seq_tensor[i, j, :])
    return jnp.array(packed_tensor), seq_lengths

# Pack padded sequence
packed_input, sorted_seq_lengths = pack_padded_sequence(seq_tensor, seq_lengths)

# Helper function to unpack packed sequence
def pad_packed_sequence(packed_input, sorted_seq_lengths):
    unpadded = jnp.zeros((max_length, len(input), 4))
    index = 0
    for t in range(max_length):
        for batch_idx in range(len(sorted_seq_lengths)):
            if t < sorted_seq_lengths[batch_idx]:
                unpadded = unpadded.at[t, batch_idx, :].set(packed_input[index, :])
                index += 1
    return unpadded

# Unpad sequence tensor after training rnn/lstm/gru
unpadded = pad_packed_sequence(packed_input, sorted_seq_lengths)

# View shape of unpadded tensor
unpadded_shape = unpadded.shape