import pytest
import jax
import jax.numpy as jnp
from jax import grad, random
import numpyro
import numpyro.distributions as dist
from numpyro.infer.reparam import LocScaleReparam
from numpyro.handlers import reparam, trace

from tests.common import assert_close_jax as assert_close

# Test helper to extract a few central moments from samples.
def get_moments(x):
    m1 = jnp.mean(x, axis=0)
    x = x - m1
    xx = x * x
    xxx = x * xx
    xxxx = xx * xx
    m2 = jnp.mean(xx, axis=0)
    m3 = jnp.mean(xxx, axis=0) / m2 ** 1.5
    m4 = jnp.mean(xxxx, axis=0) / m2 ** 2
    return jnp.stack([m1, m2, m3, m4])

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("centered", [0.0, 0.6, 1.0, 0.4, None])
@pytest.mark.parametrize("dist_type", ["Normal", "StudentT", "AsymmetricLaplace"])
def test_moments(dist_type, centered, shape):
    key = random.PRNGKey(0)
    loc = random.uniform(key, shape, minval=-1.0, maxval=1.0)
    loc = loc.at[jax.numpy.array([])].set(jax.numpy.array([]))
    scale = random.uniform(key, shape, minval=0.5, maxval=1.5)
    scale = scale.at[jax.numpy.array([])].set(jax.numpy.array([]))
    if centered is not None and isinstance(centered, float):
        centered = jnp.full(shape, centered)
        
    def model():
        with numpyro.plate_stack("plates", shape):
            with numpyro.plate("particles", 200000):
                if dist_type == "Normal":
                    numpyro.sample("x", dist.Normal(loc, scale))
                elif dist_type == "StudentT":
                    numpyro.sample("x", dist.StudentT(10.0, loc, scale))
                else:
                    numpyro.sample("x", dist.AsymmetricLaplace(loc, scale, 1.5))

    tr = trace(model).get_trace()
    value = tr["x"]["value"]
    expected_probe = get_moments(value)

    reparam_obj = LocScaleReparam(centered)
    reparam_model = reparam(model, {"x": reparam_obj})
    tr = trace(reparam_model).get_trace()
    value = tr["x"]["value"]
    actual_probe = get_moments(value)

    if centered is not None and centered != 1.0:
        if dist_type == "Normal":
            assert reparam_obj.shape_params == ()
        elif dist_type == "StudentT":
            assert reparam_obj.shape_params == ("df",)
        else:
            assert reparam_obj.shape_params == ("asymmetry",)

    assert_close(actual_probe, expected_probe, atol=0.1, rtol=0.05)

    for actual_m, expected_m in zip(actual_probe, expected_probe):
        expected_grads = grad(lambda loc, scale: jnp.sum(expected_m))(loc, scale)
        actual_grads = grad(lambda loc, scale: jnp.sum(actual_m))(loc, scale)
        assert_close(actual_grads[0], expected_grads[0], atol=0.1, rtol=0.05)
        assert_close(actual_grads[1], expected_grads[1], atol=0.1, rtol=0.05)

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("centered", [0.0, 0.6, 1.0, 0.4, None])
@pytest.mark.parametrize("dist_type", ["Normal", "StudentT", "AsymmetricLaplace"])
def test_init(dist_type, centered, shape):
    key = random.PRNGKey(0)
    loc = random.uniform(key, shape, minval=-1.0, maxval=1.0)
    scale = random.uniform(key, shape, minval=0.5, maxval=1.5)

    def model():
        with numpyro.plate_stack("plates", shape):
            if dist_type == "Normal":
                return numpyro.sample("x", dist.Normal(loc, scale))
            elif dist_type == "StudentT":
                return numpyro.sample("x", dist.StudentT(10.0, loc, scale))
            else:
                return numpyro.sample("x", dist.AsymmetricLaplace(loc, scale, 1.5))
    
    check_init_reparam_jax(model, LocScaleReparam(centered))