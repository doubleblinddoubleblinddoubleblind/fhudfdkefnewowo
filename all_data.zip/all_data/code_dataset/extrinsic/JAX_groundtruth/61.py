import pytest
import jax
import jax.numpy as jnp
from jax import grad, random
import numpyro
import numpyro.distributions as dist
from numpyro import handlers
from numpyro.infer.reparam import GumbelSoftmaxReparam
from numpy.testing import assert_allclose

# Test helper to extract a few central moments from samples.
def get_moments(x):
    m1 = jnp.mean(x, axis=0)
    x = x - m1
    xx = x[..., None] * x[..., None, :]
    m2 = jnp.mean(xx, axis=0)
    return jnp.concatenate([m1.reshape(-1), m2.reshape(-1)])

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_gumbel_softmax(temperature, shape, dim):
    temperature = jnp.array(temperature)
    rng_key = random.PRNGKey(0)
    logits = random.normal(rng_key, shape + (dim,))

    def model():
        with handlers.plate_stack("plates", shape):
            with handlers.plate("particles", 10000):
                numpyro.sample(
                    "x", dist.RelaxedOneHotCategorical(temperature, logits=logits)
                )

    trace_model = handlers.trace(model).get_trace()
    value = trace_model["x"]["value"]
    expected_probe = get_moments(value)

    reparam_model = handlers.reparam(model, config={"x": GumbelSoftmaxReparam()})
    trace_reparam_model = handlers.trace(reparam_model).get_trace()
    value = trace_reparam_model["x"]["value"]
    actual_probe = get_moments(value)
    assert_allclose(actual_probe, expected_probe, atol=0.05)

    logits_grad_fn = grad(lambda l: get_moments(handlers.seed(lambda _: model(), rng_key)()[0]), argnums=0)
    expected_grad = logits_grad_fn(logits)
    actual_grad = logits_grad_fn(logits)
    assert_allclose(actual_grad, expected_grad, atol=0.05)

@pytest.mark.parametrize("shape", [(), (4,), (3, 2)], ids=str)
@pytest.mark.parametrize("temperature", [0.01, 0.1, 1.0])
@pytest.mark.parametrize("dim", [2, 3])
def test_init(temperature, shape, dim):
    temperature = jnp.array(temperature)
    rng_key = random.PRNGKey(0)
    logits = random.normal(rng_key, shape + (dim,))

    def model():
        with handlers.plate_stack("plates", shape):
            return numpyro.sample(
                "x", dist.RelaxedOneHotCategorical(temperature, logits=logits)
            )

    check_init_reparam(model, GumbelSoftmaxReparam())