import numpy
import pytest
import jax
import jax.numpy as jnp
from flax import linen as nn
from jax.nn import initializers
from jax import random

class StackedBidirectionalLstm(nn.Module):
    input_size: int
    hidden_size: int
    num_layers: int
    layer_dropout_probability: float = 0.0
    recurrent_dropout_probability: float = 0.0

    def setup(self):
        self.lstm_layers = [
            nn.LSTMCell(
                hidden_size=self.hidden_size,
                kernel_init=initializers.orthogonal()
            ) for _ in range(self.num_layers)
        ]

    def __call__(self, inputs, initial_state):
        hidden_states, cell_states = initial_state
        output = []
        for layer in self.lstm_layers:
            outputs, (hidden_states, cell_states) = jax.lax.scan(lambda carry, x: layer(carry[0], x), 
                                                                 (hidden_states, cell_states), 
                                                                 inputs)
            output.append(outputs)
        return jnp.concatenate(output, axis=-1), (hidden_states, cell_states)

def pack_padded_sequence(input_tensor, lengths, batch_first=True):
    # Placeholder function for pack_padded_sequence
    return input_tensor

def pad_packed_sequence(sequence, batch_first=True):
    # Placeholder function for pad_packed_sequence
    return sequence, None

def sort_batch_by_length(tensor, sequence_length):
    # Placeholder function for sort_batch_by_length
    return tensor, sequence_length, None, None

def test_stacked_bidirectional_lstm_completes_forward_pass():
    input_tensor = random.uniform(random.PRNGKey(0), (4, 5, 3))
    input_tensor = pack_padded_sequence(input_tensor, [5, 4, 2, 1], batch_first=True)
    lstm = StackedBidirectionalLstm(3, 7, 3)
    output, _ = lstm(input_tensor, (jnp.zeros((3, 7)), jnp.zeros((3, 7))))
    output_sequence, _ = pad_packed_sequence(output, batch_first=True)
    numpy.testing.assert_array_equal(output_sequence[1, 4:, :], 0.0)
    numpy.testing.assert_array_equal(output_sequence[2, 2:, :], 0.0)
    numpy.testing.assert_array_equal(output_sequence[3, 1:, :], 0.0)

@pytest.mark.parametrize("dropout_name", ("layer_dropout_probability", "recurrent_dropout_probability"))
def test_stacked_bidirectional_lstm_dropout_version_is_different(dropout_name: str):
    stacked_lstm = StackedBidirectionalLstm(input_size=10, hidden_size=11, num_layers=3)
    if dropout_name == "layer_dropout_probability":
        dropped_stacked_lstm = StackedBidirectionalLstm(
            input_size=10, hidden_size=11, num_layers=3, layer_dropout_probability=0.9
        )
    elif dropout_name == "recurrent_dropout_probability":
        dropped_stacked_lstm = StackedBidirectionalLstm(
            input_size=10, hidden_size=11, num_layers=3, recurrent_dropout_probability=0.9
        )
    else:
        raise ValueError(f"Do not recognise the following dropout name {dropout_name}")

    initial_state = random.normal(random.PRNGKey(0), [3, 5, 11])
    initial_memory = random.normal(random.PRNGKey(1), [3, 5, 11])

    tensor = random.uniform(random.PRNGKey(2), [5, 7, 10])
    sequence_lengths = jnp.array([7, 7, 7, 7, 7])

    sorted_tensor, sorted_sequence, _, _ = sort_batch_by_length(tensor, sequence_lengths)
    lstm_input = pack_padded_sequence(sorted_tensor, sorted_sequence.tolist(), batch_first=True)

    stacked_output, stacked_state = stacked_lstm(lstm_input, (initial_state, initial_memory))
    dropped_output, dropped_state = dropped_stacked_lstm(lstm_input, (initial_state, initial_memory))
    dropped_output_sequence, _ = pad_packed_sequence(dropped_output, batch_first=True)
    stacked_output_sequence, _ = pad_packed_sequence(stacked_output, batch_first=True)

    if dropout_name == "layer_dropout_probability":
        with pytest.raises(AssertionError):
            numpy.testing.assert_array_almost_equal(
                dropped_output_sequence, stacked_output_sequence, decimal=4,
            )
    if dropout_name == "recurrent_dropout_probability":
        with pytest.raises(AssertionError):
            numpy.testing.assert_array_almost_equal(
                dropped_state[0], stacked_state[0], decimal=4
            )
        with pytest.raises(AssertionError):
            numpy.testing.assert_array_almost_equal(
                dropped_state[1], stacked_state[1], decimal=4
            )

# Additional necessary code for initializing module states
test_stacked_bidirectional_lstm_completes_forward_pass()