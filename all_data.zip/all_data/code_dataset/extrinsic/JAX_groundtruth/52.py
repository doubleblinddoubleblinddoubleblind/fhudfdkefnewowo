import jax
import jax.numpy as jnp
from jax import grad, jit, random
import flax.linen as nn
import flax
from flax.training import train_state
import optax
import argparse
import tensorflow_datasets as tfds
from collections import namedtuple

# 定义是否使用GPU
device = jax.devices("gpu")[0] if jax.lib.xla_bridge.get_backend("gpu") else jax.devices("cpu")[0]

# 定义网络结构
class LeNet(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=6, kernel_size=(5, 5), strides=(1, 1), padding='SAME')(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = nn.Conv(features=16, kernel_size=(5, 5))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = x.reshape((x.shape[0], -1))
        x = nn.Dense(features=120)(x)
        x = nn.relu(x)
        x = nn.Dense(features=84)(x)
        x = nn.relu(x)
        x = nn.Dense(features=10)(x)
        return x

def cross_entropy_loss(logits, labels):
    one_hot_labels = jax.nn.one_hot(labels, num_classes=10)
    return -jnp.mean(jnp.sum(one_hot_labels * nn.log_softmax(logits), axis=-1))

def compute_metrics(logits, labels):
    loss = cross_entropy_loss(logits, labels)
    accuracy = jnp.mean(jnp.argmax(logits, -1) == labels)
    return {'loss': loss, 'accuracy': accuracy}

def train_epoch(state, train_ds, batch_size, rng):
    train_ds_size = len(train_ds['image'])
    steps_per_epoch = train_ds_size // batch_size

    perms = jax.random.permutation(rng, len(train_ds['image']))
    perms = perms[:steps_per_epoch * batch_size]
    perms = perms.reshape((steps_per_epoch, batch_size))

    batch_metrics = []

    for perm in perms:
        batch_images = train_ds['image'][perm, ...]
        batch_labels = train_ds['label'][perm, ...]
        state, metrics = train_step(state, batch_images, batch_labels)
        batch_metrics.append(metrics)

    return state, batch_metrics

@jax.jit
def train_step(state, images, labels):
    def loss_fn(params):
        logits = LeNet().apply({'params': params}, images)
        loss = cross_entropy_loss(logits, labels)
        return loss, logits

    grad_fn = jax.value_and_grad(loss_fn, has_aux=True)
    (loss, logits), grads = grad_fn(state.params)
    state = state.apply_gradients(grads=grads)
    metrics = compute_metrics(logits, labels)
    return state, metrics

@jax.jit
def eval_step(params, images, labels):
    logits = LeNet().apply({'params': params}, images)
    return compute_metrics(logits, labels)

def create_train_state(rng, learning_rate):
    model = LeNet()
    params = model.init(rng, jnp.ones([1, 28, 28, 1]))['params']
    tx = optax.sgd(learning_rate, momentum=0.9)
    return train_state.TrainState.create(apply_fn=model.apply, params=params, tx=tx)

def evaluate_model(state, test_ds):
    test_ds_size = len(test_ds['image'])
    e_data = tfds.as_numpy(test_ds)
    images, labels = e_data['image'], e_data['label']
    metrics = eval_step(state.params, images, labels)
    return metrics

#使得我们能够手动输入命令行参数，就是让风格变得和Linux命令行差不多
parser = argparse.ArgumentParser()
parser.add_argument('--outf', default='.', help='folder to output images and model checkpoints') #模型保存路径
opt = parser.parse_args()

# 超参数设置
EPOCH = 8   #遍历数据集次数
BATCH_SIZE = 64      #批处理尺寸(batch_size)
LR = 0.001        #学习率

# Loading MNIST dataset
train_ds = tfds.load('mnist', split='train', batch_size=-1, as_supervised=True)
test_ds = tfds.load('mnist', split='test', batch_size=-1, as_supervised=True)
train_data = tfds.as_numpy(train_ds)
test_data = tfds.as_numpy(test_ds)

# Preprocessing
train_data['image'] = train_data['image'].astype(jnp.float32) / 255.0
test_data['image'] = test_data['image'].astype(jnp.float32) / 255.0

# Training
if __name__ == "__main__":
    rng = jax.random.PRNGKey(0)
    state = create_train_state(rng, LR)

    for epoch in range(EPOCH):
        rng, input_rng = jax.random.split(rng)
        state, train_metrics = train_epoch(state, train_data, BATCH_SIZE, input_rng)
        test_metrics = evaluate_model(state, test_data)

        train_loss = jnp.mean(jnp.array([m['loss'] for m in train_metrics]))
        print(f"Train Epoch {epoch + 1}, Loss: {train_loss:.3f}")
        print(f"Test Accuracy: {test_metrics['accuracy']:.3f}")

    model_bytes = flax.serialization.to_bytes(state.params)
    with open(f"{opt.outf}/net_{EPOCH:03d}.params", 'wb') as f:
        f.write(model_bytes)