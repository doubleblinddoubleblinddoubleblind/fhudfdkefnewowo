import numpy as np
import jax
import jax.numpy as jnp
from jax import random, jit, vmap
import flax.linen as nn
from pytorchrl.core.parameterized import Parameterized
from pytorchrl.distributions.categorical import Categorical
from pytorchrl.policies.base import StochasticPolicy


class CategoricalMLPPolicy(StochasticPolicy, Parameterized):
    def __init__(
        self,
        observation_dim,
        num_actions,
        hidden_sizes=(32, 32),
        hidden_nonlinearity=nn.tanh,
    ):
        super(CategoricalMLPPolicy, self).__init__()
        self.observation_dim = int(observation_dim)
        self.num_actions = num_actions

        # Create the network
        layers = []
        for size in hidden_sizes:
            layers.append(nn.Dense(size))
            layers.append(hidden_nonlinearity)

        layers.append(nn.Dense(self.num_actions))
        self.model = nn.Sequential(layers)

        self.dist_cls = Categorical

    def forward(self, params, observations):
        logits = self.model.apply(params, observations)
        prob = nn.softmax(logits)
        return prob

    def get_action(self, params, observation, rng, deterministic=False):
        prob = self.forward(params, observation)
        if deterministic:
            action = jnp.argmax(prob)
        else:
            key, subkey = random.split(rng)
            action = random.choice(subkey, self.num_actions, p=prob)

        return action, dict(prob=prob)

    def get_internal_params(self):
        return self.model.init(random.PRNGKey(0), jnp.ones((self.observation_dim,)))

    def get_internal_named_params(self):
        # In JAX, named parameters are handled differently.
        # Returning parameters with their respective layer names.
        params = self.get_internal_params()
        return [(name, param) for name, param in params.items()]

    def get_policy_distribution(self, params, obs_var):
        prob = self.forward(params, obs_var)
        return self.dist_cls.from_dict(prob)

    def distribution(self, dist_info):
        prob = dist_info['prob']
        if isinstance(prob, np.ndarray):
            prob = jnp.array(prob)

        return self.dist_cls.from_dict(prob)