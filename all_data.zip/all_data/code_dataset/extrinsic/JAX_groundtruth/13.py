import jax
import jax.numpy as jnp
from jax import random
from flax import linen as nn

def dot(a, b):
    """Compute the dot product between pairs of vectors in 3D arrays.

    Args
    ----
    a: array of size (B, M, D)
    b: array of size (B, N, D)

    Returns
    -------
    c: array of size (B, M, N)
        c[i,j,k] = dot(a[i,j], b[i,k])
    """
    return jnp.einsum('bmd,bnd->bmn', a, b)

class Attention(nn.Module):
    @nn.compact
    def __call__(self, query, key, value, dimensions=None):
        ''' Input:
            query vectors q_1, ..., q_m
            key vectors k_1, .., k_n
            value vectors v_1, ..., v_n

            all of equal dimension and batch size.

            Compute the attention weights alpha_ij as follows:

            score_ij = (q_j)^T k_i
            alpha_ij = exp(score_ij) / sum_k exp(score_ik)

            Then apply the attention weights to v_1, ..., v_n as follows:

            output_ij = sum_k (alpha_ik * v_kj)
        '''
        bsk, n_keys, dim_key = key.shape
        bsq, n_queries, dim_query = query.shape
        bsv, n_queries, dim_value = value.shape

        assert bsq == bsk == bsv, 'Batch sizes should be equal'
        assert dim_key == dim_query == dim_value, 'Dimensions should be equal'

        s = dot(query, key)
        if dimensions is None:
            dimensions = jnp.array(key.shape[1], dtype=jnp.float32).reshape(1, 1, 1).repeat(s.shape, axis=0)
        
        scaling_factor = jnp.sqrt(1 / dimensions)
        alpha = jax.nn.softmax(s / scaling_factor, axis=2)
        output = jnp.einsum('bmn,bnd->bmd', alpha, value)
        return output, alpha