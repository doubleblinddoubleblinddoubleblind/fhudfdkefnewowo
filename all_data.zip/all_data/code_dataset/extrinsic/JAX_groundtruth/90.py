import jax.numpy as jnp
from flax import linen as nn
import flax.linen.initializers as initializers
import math


class VGG(nn.Module):
    features: nn.Module
    num_classes: int = 1000
    init_weights: bool = False

    def setup(self):
        self.classifier = nn.Sequential(
            [nn.Dense(4096, kernel_init=initializers.lecun_normal(), bias_init=initializers.zeros),
             nn.relu,
             nn.dropout,  # Default dropout rate in flax is 0.5
             nn.Dense(4096, kernel_init=initializers.lecun_normal(), bias_init=initializers.zeros),
             nn.relu,
             nn.dropout,
             nn.Dense(self.num_classes, kernel_init=initializers.lecun_normal(), bias_init=initializers.zeros)]
        )
        if self.init_weights:
            self.initialize_weights()

    def __call__(self, x, train=True):
        x = self.features(x)
        x = x.reshape((x.shape[0], -1))
        x = self.classifier(x, train=train)
        return x

    def initialize_weights(self):
        # Initialization logic is handled via initializers in Flax
        pass


def make_layers(cfg, batch_norm=False):
    layers = []
    in_channels = 3
    for v in cfg:
        if v == 'M':
            layers.append(nn.max_pool)
        else:
            Conv2D = nn.Conv(features=v, kernel_size=(3, 3), padding='SAME', kernel_init=initializers.lecun_normal(), bias_init=initializers.zeros)
            if batch_norm:
                layers.extend([Conv2D, nn.BatchNorm(True), nn.relu])
            else:
                layers.extend([Conv2D, nn.relu])
    return nn.Sequential(layers)


cfg = {
    'A': [64, 'M', 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'B': [64, 64, 'M', 128, 128, 'M', 256, 256, 'M', 512, 512, 'M', 512, 512, 'M'],
    'D': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M'],
    'E': [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 256, 'M', 512, 512, 512, 512, 'M', 512, 512, 512, 512, 'M'],
}


def vgg11(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['A']), **kwargs)
    return model


def vgg11_bn(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['A'], batch_norm=True), **kwargs)
    return model


def vgg13(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['B']), **kwargs)
    return model


def vgg13_bn(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['B'], batch_norm=True), **kwargs)
    return model


def vgg16(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['D']), **kwargs)
    return model


def vgg16_bn(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['D'], batch_norm=True), **kwargs)
    return model


def vgg19(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['E']), **kwargs)
    return model


def vgg19_bn(pretrained=False, **kwargs):
    model = VGG(features=make_layers(cfg['E'], batch_norm=True), **kwargs)
    return model