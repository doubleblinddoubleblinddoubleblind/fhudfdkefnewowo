import jax
import jax.numpy as jnp
import flax.linen as nn
import optax
from flax.training import train_state
from functools import partial
from torchvision.datasets import MNIST
from torchvision import transforms
from torch.utils.data import DataLoader

class Net(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=32, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        x = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = nn.Dropout(rate=0.25, deterministic=False)(x, deterministic=False)
        x = x.reshape((x.shape[0], -1))  # Flatten the image
        x = nn.Dense(features=128)(x)
        x = nn.relu(x)
        x = nn.Dropout(rate=0.5, deterministic=False)(x, deterministic=False)
        x = nn.Dense(features=10)(x)
        x = nn.log_softmax(x)
        return x

def create_train_state(rng, learning_rate, model, input_shape):
    params = model.init(rng, jnp.ones(input_shape))['params']
    tx = optax.adamw(learning_rate)
    return train_state.TrainState.create(
        apply_fn=model.apply, params=params, tx=tx)

@jax.jit
def train_step(state, batch):
    def loss_fn(params):
        logits = state.apply_fn({'params': params}, batch['data'])
        loss = optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(batch['target'], 10)).mean()
        return loss

    grads = jax.grad(loss_fn)(state.params)
    state = state.apply_gradients(grads=grads)
    return state

@jax.jit
def eval_step(state, batch):
    logits = state.apply_fn({'params': state.params}, batch['data'])
    loss = optax.softmax_cross_entropy(logits=logits, labels=jax.nn.one_hot(batch['target'], 10)).mean()
    accuracy = jnp.mean(jnp.argmax(logits, -1) == batch['target'])
    return loss, accuracy

def train_epoch(state, train_loader):
    for batch_idx, (data, target) in enumerate(train_loader):
        data = jnp.array(data.numpy(), dtype=jnp.float32)
        target = jnp.array(target.numpy(), dtype=jnp.int32)
        state = train_step(state, {'data': data, 'target': target})
        if batch_idx % 100 == 0:
            print(f'Train Epoch: [{batch_idx * len(data)}/{len(train_loader.dataset)}]\tLoss: {state.metrics["loss"]}')
    return state

def test_model(state, test_loader):
    test_loss = 0
    correct = 0
    for data, target in test_loader:
        data = jnp.array(data.numpy(), dtype=jnp.float32)
        target = jnp.array(target.numpy(), dtype=jnp.int32)
        loss, accuracy = eval_step(state, {'data': data, 'target': target})
        test_loss += loss.item()
        correct += accuracy.item() * len(data)
    test_loss /= len(test_loader.dataset)
    accuracy = correct / len(test_loader.dataset)
    print(f'\nTest set: Average loss: {test_loss:.4f}, Accuracy: {correct}/{len(test_loader.dataset)} ({100. * accuracy:.0f}%)\n')

batch_size, test_batch_size = 256, 512
epochs, lr = 1, 1e-2

transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize((0.1307,), (0.3081,))])
train_loader = DataLoader(MNIST('../data', train=True, download=True, transform=transform), batch_size=batch_size, shuffle=True)
test_loader = DataLoader(MNIST('../data', train=False, transform=transform), batch_size=test_batch_size, shuffle=False)

rng = jax.random.PRNGKey(0)
model = Net()
state = create_train_state(rng, lr, model, (-1, 28, 28, 1))

for epoch in range(1, epochs + 1):
    state = train_epoch(state, train_loader)
    test_model(state, test_loader)