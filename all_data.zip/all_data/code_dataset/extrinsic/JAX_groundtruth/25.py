import jax
import jax.numpy as jnp
from jax import grad, jit
import numpy as np
import optax
import time
import ray
from ray import tune


def sq(x):
    m2 = 1.
    m1 = -20.
    m0 = 50.
    return m2 * x * x + m1 * x + m0


def qu(x):
    m3 = 10.
    m2 = 5.
    m1 = -20.
    m0 = -5.
    return m3 * x * x * x + m2 * x * x + m1 * x + m0


class Net:
    def __init__(self, params, mode="sq"):
        self.params = params
        self.mode = mode

    def forward(self, x):
        if self.mode == "square":
            return x * x + self.params[0] * x + self.params[1]
        else:
            return_val = 10 * x * x * x
            return_val += self.params[0] * x * x
            return_val += self.params[1] * x + self.params[2]
            return return_val


def loss_fn(params, x, y, mode):
    net = Net(params, mode)
    preds = net.forward(x)
    return jnp.mean((preds - y) ** 2)


@jax.jit
def train_step(optimizer, params, x, y, mode):
    loss, grads = jax.value_and_grad(loss_fn)(params, x, y, mode)
    updates, opt_state = optimizer.update(grads, optimizer.state)
    new_params = optax.apply_updates(params, updates)
    return new_params, opt_state, loss


def train(config):
    mode = config["mode"]
    if mode == "square":
        params = jnp.array([1.0, -1.0])
    else:
        params = jnp.array([1.0, -1.0, 1.0])

    optimizer = optax.sgd(config["lr"])
    opt_state = optimizer.init(params)

    num_steps = 5
    np.random.seed(1)
    x_max = config["x_max"]

    start = time.time()
    
    for step in range(1, num_steps + 1):
        features = jnp.array(np.random.rand(1) * 2 * x_max - x_max)
        if mode == "square":
            labels = sq(features)
        else:
            labels = qu(features)
        
        params, opt_state, loss = train_step(optimizer, params, features, labels, mode)
        
        time.sleep(0.1)
        tune.report(loss=loss)

    total = time.time() - start
    print(f"Took {total:0.3f} s. Avg: {total / num_steps:0.3f} s.")


def tune_jax(num_samples, mode="square", x_max=1.):
    jax_trainable = tune.with_parameters(
        train,
        mode=mode
    )
    analysis = tune.run(
        jax_trainable,
        config={
            "lr": tune.uniform(0.1, 1.0),
            "mode": mode,
            "x_max": x_max
        },
        num_samples=num_samples,
        fail_fast=True
    )
    print("Best hyperparameters found were: ", analysis.best_config)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode", type=str, default="square", choices=["square", "cubic"])
    parser.add_argument(
        "--learning_rate", type=float, default=0.1, dest="learning_rate")
    parser.add_argument("--x_max", type=float, default=1., dest="x_max")
    parser.add_argument("--smoke-test", action="store_true")
    args, _ = parser.parse_known_args()

    ray.init(num_cpus=2 if args.smoke_test else None)

    tune_jax(
        num_samples=2 if args.smoke_test else 10,
        mode=args.mode,
        x_max=args.x_max
    )