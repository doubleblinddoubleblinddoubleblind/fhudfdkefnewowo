from __future__ import print_function
import jax.numpy as jnp
import numpy as np
from os import listdir
from os.path import join
import os
import h5py

def default_loader(path):
    with h5py.File(path, 'r') as f:
        imgA = f['input'][:]
        imgB = f['output'][:]
    return jnp.array(imgA) / 255.0, jnp.array(imgB) / 255.0

class Radars:
    def __init__(self, dataPath='/ldata/radar_20d_2000/', length=-1):
        l = listdir(dataPath)
        l.sort()
        self.image_list = [x for x in l][:length]
        self.dataPath = dataPath

    def __getitem__(self, index):
        # 1. Read one data from file
        path = os.path.join(self.dataPath, self.image_list[index])
        imgA, imgB = default_loader(path)  # 512x256
        # 2. Return image A and B
        return imgA, imgB

    def __len__(self):
        # Return total size of dataset
        return len(self.image_list)