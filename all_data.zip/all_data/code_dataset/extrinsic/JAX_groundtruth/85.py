import jax
import jax.numpy as jnp
from flax import linen as nn
from flax.training import common_utils
import tensorflow as tf
import tensorflow_datasets as tfds

class HumanPoseNet(nn.Module):
    out_c: int
    vgg_pretrained: bool = True
    
    def setup(self):
        vgg = tf.keras.applications.VGG16(include_top=False, weights="imagenet" if self.vgg_pretrained else None)
        self.base_model = tf.function(lambda x: vgg(x, training=False))
        self.fc1 = nn.Dense(features=4096)
        self.fc2 = nn.Dense(features=4096)
        self.fc3 = nn.Dense(features=self.out_c)

    def __call__(self, input):
        assert input.shape[-2:] == (224, 224), "Input must be of shape (224, 224)"
        
        x = self.base_model(input)
        x = jnp.reshape(x, (x.shape[0], -1))  # Flatten
        x = self.fc1(x)
        x = nn.relu(x)
        x = self.fc2(x)
        x = nn.relu(x)
        x = self.fc3(x)
        
        return x

def mse_loss(pred, target, weight, weighted_loss=False, size_average=True):
    mask = (weight != 0).astype(jnp.float32)
    if weighted_loss:
        loss = jnp.sum(weight * (pred - target) ** 2)
    else:
        loss = jnp.sum(mask * (pred - target) ** 2)
    if size_average:
        loss /= jnp.sum(mask)
    return loss