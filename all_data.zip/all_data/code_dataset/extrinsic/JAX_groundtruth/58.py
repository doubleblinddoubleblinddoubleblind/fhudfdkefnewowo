import jax
import jax.numpy as jnp
import optax

class Piecewise:
    def __init__(self, schedule_fn, lrs, milestones):
        self.schedule_fn = schedule_fn
        assert len(milestones) + 1 == len(lrs)
        self.lrs = lrs
        self.milestones = milestones
        
        gaps = [milestones[0]] + [m2 - m1 for m1, m2 in zip(milestones[:-1], milestones[1:])]
        self.linear_schedulers = [Linear(lr1, lr2, m) for lr1, lr2, m in zip(lrs[:-1], lrs[1:], gaps)]
        self.milestone_index = 0
        self.current_sched = self.linear_schedulers[self.milestone_index]

    def get_lr(self):
        return self.current_sched.get_lr()

    def step(self, epoch):
        if epoch >= self.milestones[self.milestone_index]:
            self.milestone_index += 1
            self.current_sched = self.linear_schedulers[self.milestone_index]
            epoch = 0

        return self.current_sched.step(epoch)


class Linear:
    def __init__(self, start_lr, end_lr, interval_length):
        self.start_lr = start_lr
        self.end_lr = end_lr
        self.interval_length = interval_length

    def get_lr(self, epoch):
        return self.start_lr + epoch * (self.end_lr - self.start_lr) / self.interval_length

    def step(self, epoch):
        return self.get_lr(epoch)


class CosineAnnealingLR:
    def __init__(self, base_lrs, T_max, eta_min=0):
        self.T_max = T_max
        self.eta_min = eta_min
        self.base_lrs = base_lrs

    def get_lr(self, epoch):
        return [self.eta_min + (base_lr - self.eta_min) *
                (1 + jnp.cos(jnp.pi * epoch / self.T_max)) / 2
                for base_lr in self.base_lrs]

    def step(self, epoch):
        return self.get_lr(epoch)