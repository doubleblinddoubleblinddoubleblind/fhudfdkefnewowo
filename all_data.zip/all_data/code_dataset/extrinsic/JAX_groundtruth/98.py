import functools
import inspect
import os
from collections.abc import Mapping
from contextlib import contextmanager

from odin.backend import (interpolation, keras_callbacks, keras_helpers, losses,
                          metrics)
from odin.backend.alias import *
from odin.backend.maths import *
from odin.backend.tensor import *
from odin.backend.types_helpers import *
from odin.utils import as_tuple, is_path, is_string
from six import add_metaclass
from six.moves import builtins, cPickle

# ===========================================================================
# Make the layers accessible through backend
# ===========================================================================
class _nn_meta(type):

  def __getattr__(cls, key):
    fw = get_framework()
    import tensorflow as tf
    import jax

    all_objects = {}
    if fw == jax:
      from odin import networks_jax
      from jax.experimental import stax
      all_objects.update(stax.__dict__)
      all_objects.update(networks_jax.__dict__)
    elif fw == tf:
      from odin import networks
      from tensorflow.python.keras.engine import sequential, training
      all_objects.update(tf.keras.layers.__dict__)
      all_objects.update(networks.__dict__)
      all_objects.update(sequential.__dict__)
      all_objects.update(training.__dict__)
    else:
      raise NotImplementedError("No neural networks support for framework: " +
                                str(fw))
    return all_objects[key]


@add_metaclass(_nn_meta)
class nn:
  pass