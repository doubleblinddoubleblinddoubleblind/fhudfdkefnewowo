"""ResNet in JAX.

For Pre-activation ResNet, see 'preact_resnet.py'.

Reference:
[1] Kaiming He, Xiangyu Zhang, Shaoqing Ren, Jian Sun
   Deep Residual Learning for Image Recognition. arXiv:1512.03385
"""
import jax
import jax.numpy as jnp
from jax import random
from flax import linen as nn

class BasicBlock(nn.Module):
    in_planes: int
    planes: int
    stride: int = 1
    expansion: int = 1

    def setup(self):
        self.conv1 = nn.Conv(features=self.planes, kernel_size=(3, 3), strides=(self.stride, self.stride), padding=((1, 1), (1, 1)), use_bias=False)
        self.bn1 = nn.BatchNorm(use_running_average=False)
        self.conv2 = nn.Conv(features=self.planes, kernel_size=(3, 3), strides=(1, 1), padding=((1, 1), (1, 1)), use_bias=False)
        self.bn2 = nn.BatchNorm(use_running_average=False)

        self.shortcut = lambda x: x
        if self.stride != 1 or self.in_planes != self.expansion * self.planes:
            self.shortcut = nn.Sequential([
                nn.Conv(features=self.expansion * self.planes, kernel_size=(1, 1), strides=(self.stride, self.stride), use_bias=False),
                nn.BatchNorm(use_running_average=False)
            ])

    def __call__(self, x):
        out = jax.nn.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = jax.nn.relu(out)
        return out


class Bottleneck(nn.Module):
    in_planes: int
    planes: int
    stride: int = 1
    expansion: int = 4

    def setup(self):
        self.conv1 = nn.Conv(features=self.planes, kernel_size=(1, 1), use_bias=False)
        self.bn1 = nn.BatchNorm(use_running_average=False)
        self.conv2 = nn.Conv(features=self.planes, kernel_size=(3, 3), strides=(self.stride, self.stride), padding=((1, 1), (1, 1)), use_bias=False)
        self.bn2 = nn.BatchNorm(use_running_average=False)
        self.conv3 = nn.Conv(features=self.expansion * self.planes, kernel_size=(1, 1), use_bias=False)
        self.bn3 = nn.BatchNorm(use_running_average=False)

        self.shortcut = lambda x: x
        if self.stride != 1 or self.in_planes != self.expansion * self.planes:
            self.shortcut = nn.Sequential([
                nn.Conv(features=self.expansion * self.planes, kernel_size=(1, 1), strides=(self.stride, self.stride), use_bias=False),
                nn.BatchNorm(use_running_average=False)
            ])

    def __call__(self, x):
        out = jax.nn.relu(self.bn1(self.conv1(x)))
        out = jax.nn.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        out += self.shortcut(x)
        out = jax.nn.relu(out)
        return out


class ResNet(nn.Module):
    block: nn.Module
    num_blocks: list
    num_classes: int = 10
    in_planes: int = 64

    def setup(self):
        self.conv1 = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1), padding=((1, 1), (1, 1)), use_bias=False)
        self.bn1 = nn.BatchNorm(use_running_average=False)
        self.layer1 = self._make_layer(self.block, 64, self.num_blocks[0], stride=1)
        self.layer2 = self._make_layer(self.block, 128, self.num_blocks[1], stride=2)
        self.layer3 = self._make_layer(self.block, 256, self.num_blocks[2], stride=2)
        self.layer4 = self._make_layer(self.block, 512, self.num_blocks[3], stride=2)
        self.linear = nn.Dense(features=self.num_classes)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(layers)

    def __call__(self, x):
        out = jax.nn.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = jnp.mean(out, axis=(1, 2))
        out = self.linear(out)
        return out


def ResNet18():
    return ResNet(BasicBlock, [2, 2, 2, 2])

def ResNet34():
    return ResNet(BasicBlock, [3, 4, 6, 3])

def ResNet50():
    return ResNet(Bottleneck, [3, 4, 6, 3])

def ResNet101():
    return ResNet(Bottleneck, [3, 4, 23, 3])

def ResNet152():
    return ResNet(Bottleneck, [3, 8, 36, 3])


def test():
    rng = random.PRNGKey(0)
    x = random.normal(rng, (1, 32, 32, 3))
    net = ResNet18()
    variables = net.init(rng, x)
    y = net.apply(variables, x)
    print(y.shape)

# test()