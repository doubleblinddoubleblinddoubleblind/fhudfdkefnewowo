import os
import jax
import jax.numpy as jnp
import flax
from flax.training import common_utils
from flax.jax_utils import replicate
import tensorflow_datasets as tfds
from functools import partial
import itertools

def get_dataset(name, split='train', transform=None, target_transform=None, download=True, datasets_path='~/Datasets'):
    train = (split == 'train')
    root = os.path.join(os.path.expanduser(datasets_path), name)
    
    def decode_image(record_bytes):
        # Function to decode images
        image_feature_description = {
            'image': tf.io.FixedLenFeature([], tf.string),
            'label': tf.io.FixedLenFeature([], tf.int64),
        }
        example = tf.io.parse_single_example(record_bytes, image_feature_description)
        image = tf.io.decode_raw(example['image'], tf.uint8)
        image = tf.cast(image, jnp.float32) / 255.0
        if transform:
            image = transform(image)
        return image, example['label']

    ds = tfds.load(name, split=split, data_dir=root, download=download)
    ds = ds.map(decode_image)
    return ds

class DataRegime:
    def __init__(self, regime, defaults={}):
        self.regime = regime  # Define custom Regime class logic based on your design
        self.epoch = 0
        self.steps = None
        self.get_loader(True)

    def get_setting(self):
        return {'data': self.regime}  # Mock behavior with assumptions

    def get_loader(self, force_update=False, override_settings=None, subset_indices=None):
        if force_update:
            setting = self.get_setting()
            self._data = get_dataset(setting['data']['name'])
            self._loader = flax.jax_utils.replicate(self._data)  # Assume a logical wrapped use of replicate
        return self._loader

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __len__(self):
        return len(self._data)

class SampledDataLoader:
    def __init__(self, dl_list):
        self.dl_list = dl_list
        self.epoch = 0

    def generate_order(self):
        order = [[idx]*len(dl) for idx, dl in enumerate(self.dl_list)]
        order = list(itertools.chain.from_iterable(order))
        rng = jax.random.PRNGKey(self.epoch)
        perm = jax.random.permutation(rng, len(order))
        return list(jnp.asarray(order)[perm])

    def __len__(self):
        return sum([len(dl) for dl in self.dl_list])

    def __iter__(self):
        order = self.generate_order()
        iterators = [iter(dl) for dl in self.dl_list]
        for idx in order:
            yield next(iterators[idx])
        return

class SampledDataRegime(DataRegime):
    def __init__(self, data_regime_list,  probs, split_data=True):
        self.probs = probs
        self.data_regime_list = data_regime_list
        self.split_data = split_data

    def get_loader(self, force_update=False):
        loaders = [data_regime.get_loader(force_update=force_update) for data_regime in self.data_regime_list]
        self._loader = SampledDataLoader(loaders)
        self._loader.epoch = self.epoch

    def set_epoch(self, epoch):
        self.epoch = epoch
        for data_regime in self.data_regime_list:
            data_regime.set_epoch(epoch)

    def __len__(self):
        return sum([len(data_regime._data) for data_regime in self.data_regime_list])

if __name__ == '__main__':
    reg1 = DataRegime(None, {'name': 'imagenet', 'batch_size': 16})
    reg2 = DataRegime(None, {'name': 'imagenet', 'batch_size': 32})
    reg1.set_epoch(0)
    reg2.set_epoch(0)
    mreg = SampledDataRegime([reg1, reg2])

    for x, _ in mreg.get_loader():
        print(x.shape)