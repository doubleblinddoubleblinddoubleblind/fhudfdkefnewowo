import argparse

import numpy as np
import jax
import jax.numpy as jnp
from jax import grad, jit, random
from jax.experimental import stax
from jax.experimental.stax import Dense, Relu, LogSoftmax
from jax.experimental.optimizers import adam
from jax import random as jax_random
import torch.utils.data.dataloader as dataloader
from torch.utils.data import Dataset
from torchvision import transforms
from torchvision.datasets import CIFAR10

# Placeholder for MeTaL utilities in JAX - Adjust these as per actual usage
def convert_labels(labels):
    return labels

class EndModel:
    def __init__(self, layer_dims, input_module=None, seed=None, **kwargs):
        init_random_params, self.predict = stax.serial(
            Dense(512), Relu, Dense(layer_dims[-1]), LogSoftmax
        )
        rng = random.PRNGKey(seed if seed else 0)
        _, self.params = init_random_params(rng, (-1, 32*32*3))

    def train_model(self, train_data, valid_data, l2, lr, n_epochs, log_train_every, validation_metric):
        opt_init, opt_update, get_params = adam(lr)
        opt_state = opt_init(self.params)
        
        def loss(params, batch):
            inputs, targets = batch
            preds = self.predict(params, inputs)
            return -jnp.mean(preds * targets) + 0.5 * l2 * sum(jnp.sum(p ** 2) for p in jax.tree_leaves(params))
        
        def accuracy(params, batch):
            inputs, targets = batch
            predicted_class = jnp.argmax(self.predict(params, inputs), axis=1)
            target_class = jnp.argmax(targets, axis=1)
            return jnp.mean(predicted_class == target_class)

        @jit
        def update(i, opt_state, batch):
            params = get_params(opt_state)
            grads = grad(loss)(params, batch)
            return opt_update(i, grads, opt_state)

        for epoch in range(n_epochs):
            for i, batch in enumerate(train_data):
                opt_state = update(i, opt_state, batch)
            if epoch % log_train_every == 0:
                print(f'Epoch {epoch}, Training accuracy: {accuracy(get_params(opt_state), next(iter(valid_data)))}')

    def score(self, test_loader, metric):
        params = self.params
        batch = next(iter(test_loader))
        print(f'Test {metric[0]}: {accuracy(params, batch)}')

# Custom Dataset
class MetalCIFARDataset(Dataset):
    def __init__(self, dataset):
        self.dataset = dataset

    def __getitem__(self, index):
        x, y = self.dataset[index]
        y += 1
        return tuple([x, np.eye(10)[y]])

    def __len__(self):
        return len(self.dataset)

def train_model():

    global args
    args = parser.parse_args()

    transform_train = transforms.Compose(
        [
            transforms.RandomCrop(32, padding=4),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
        ]
    )

    transform_test = transforms.Compose(
        [
            transforms.ToTensor(),
            transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
        ]
    )

    trainset = CIFAR10(
        root="./data", train=True, download=True, transform=transform_train
    )
    train_loader = dataloader.DataLoader(
        MetalCIFARDataset(trainset),
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=2,
    )

    testset = CIFAR10(
        root="./data", train=False, download=True, transform=transform_test
    )
    test_loader = dataloader.DataLoader(
        MetalCIFARDataset(testset),
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=2,
    )

    classes = (
        "plane",
        "car",
        "bird",
        "cat",
        "deer",
        "dog",
        "frog",
        "horse",
        "ship",
        "truck",
    )

    encode_dim = 512
    end_model = EndModel(
        [encode_dim, len(classes)],
        seed=123,
    )

    end_model.train_model(
        train_data=train_loader,
        valid_data=test_loader,
        l2=args.weight_decay,
        lr=args.lr,
        n_epochs=args.epochs,
        log_train_every=1,
        validation_metric="accuracy",
    )

    end_model.score(test_loader, metric=["accuracy", "precision", "recall", "f1"])

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Training CIFAR 10")
    parser.add_argument("--epochs", default=10, type=int, help="number of total epochs to run")
    parser.add_argument("-b", "--batch-size", default=128, type=int, help="mini-batch size (default: 10)")
    parser.add_argument("--lr", "--learning-rate", default=0.001, type=float, help="initial learning rate")
    parser.add_argument("--momentum", default=0.9, type=float, help="momentum")
    parser.add_argument("--weight-decay", "--wd", default=1e-4, type=float, help="weight decay (default: 1e-4)")
    train_model()