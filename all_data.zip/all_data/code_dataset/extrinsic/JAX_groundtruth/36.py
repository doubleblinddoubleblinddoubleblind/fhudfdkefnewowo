import jax.numpy as jnp
from jax import jit


@jit
def calculate_distances(p0: jnp.ndarray, p1: jnp.ndarray) -> jnp.ndarray:
    # ReLU prevents negative numbers in sqrt
    Dij = jnp.sqrt(jnp.maximum(jnp.sum((p0 - p1) ** 2, -1), 0))
    return Dij


def calculate_torsions(p0: jnp.ndarray, p1: jnp.ndarray, p2: jnp.ndarray, p3: jnp.ndarray) -> jnp.ndarray:
    b0 = -1.0 * (p1 - p0)
    b1 = p2 - p1
    b2 = p3 - p2

    if p0.ndim == 1:
        b1 /= jnp.linalg.norm(b1)
    else:
        b1 /= jnp.linalg.norm(b1, axis=1)[:, None]

    v = b0 - jnp.sum(b0 * b1, axis=-1, keepdims=True) * b1
    w = b2 - jnp.sum(b2 * b1, axis=-1, keepdims=True) * b1

    x = jnp.sum(v * w, axis=-1)
    y = jnp.sum(jnp.cross(b1, v) * w, axis=-1)

    return jnp.arctan2(y, x)


# %%
if __name__ == '__main__':
    # %%
    coords = jnp.array([[10.396, 18.691, 19.127],
                        [9.902, 18.231, 20.266],
                        [8.736, 17.274, 20.226],
                        [7.471, 18.048, 19.846]])
    coords2 = jnp.array([[7.471, 18.048, 19.846],
                         [6.67, 17.583, 18.852],
                         [5.494, 18.412, 18.503],
                         [4.59, 18.735, 19.711]])

    print(calculate_torsions(*coords))
    print(calculate_torsions(*coords2))
    # %%
    # calculate_torsions(*coords[:, None, :])
    a = jnp.concatenate((coords, coords2), axis=1).reshape(4, -1, 3)
    print(calculate_torsions(*a))