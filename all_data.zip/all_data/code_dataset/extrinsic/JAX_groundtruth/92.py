import jax
import jax.numpy as jnp
import optax
from flax import linen as nn
from jax import random
from torchvision import datasets, transforms
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import os

# Hyper Parameters

mb_size = 32
z_dim = 100
X_dim = 784
y_dim = 10
h_dim = 128
cnt = 0
d_step = 3
lr = 1e-3
m = 5

# Load Data

# MNIST Dataset
train_dataset = datasets.MNIST(root='./data',
                               train=True,
                               transform=transforms.ToTensor(),
                               download=True)

test_dataset = datasets.MNIST(root='./data',
                              train=False,
                              transform=transforms.ToTensor())

# Data Loader (Input Pipeline)
train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                           batch_size=mb_size,
                                           shuffle=True)

test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                          batch_size=mb_size,
                                          shuffle=False)

# CNN-Based EBGAN

ngpu = 1
ngf = 4  # ngf = 64
nz = z_dim  # 100 --> batchsize, 100, 1, 1
nc = 1

class netG(nn.Module):
    @nn.compact
    def __call__(self, z):
        x = nn.ConvTranspose(features=28 * 28, kernel_size=(1, 1), strides=(1, 1), use_bias=False)(z)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=14 * 14, kernel_size=(2, 2), strides=(2, 2), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=7 * 7, kernel_size=(2, 2), strides=(2, 2), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=1, kernel_size=(7, 7), strides=(7, 7), use_bias=False)(x)
        x = nn.sigmoid(x)
        return x

class netD(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=ngf, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2), (2, 2))
        x = nn.Conv(features=ngf * 2, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        x = nn.max_pool(x, (2, 2), (2, 2))
        x = nn.Conv(features=ngf * 4, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        x = nn.Conv(features=nz, kernel_size=(3, 3), strides=(1, 1))(x)
        x = nn.relu(x)
        
        x = nn.ConvTranspose(features=ngf * 4, kernel_size=(1, 1), strides=(1, 1), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=ngf * 2, kernel_size=(1, 1), strides=(1, 1), use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=ngf, kernel_size=(4, 4), strides=(2, 2), padding='SAME', use_bias=False)(x)
        x = nn.BatchNorm(use_running_average=False)(x)
        x = nn.relu(x)
        x = nn.ConvTranspose(features=nc, kernel_size=(4, 4), strides=(2, 2), padding='SAME', use_bias=False)(x)
        x = nn.tanh(x)
        return x

def loss_fn(paramsD, paramsG, rng, real_images):
    z = random.normal(rng, (mb_size, nz, 1, 1))
    G_sample = netG().apply({'params': paramsG}, z)
    X_recon = netD().apply({'params': paramsD}, real_images)
    D_real = jnp.mean(jnp.sum((real_images - X_recon) ** 2, axis=[1,2,3]))
    D_fake = jnp.mean(jnp.sum((G_sample - real_images) ** 2, axis=[1,2,3]))
    D_loss = D_real + jax.nn.relu(m - D_fake)
    G_loss = D_fake
    return D_loss, G_loss

key = random.PRNGKey(0)
paramsG = netG().init(key, jnp.ones([1, nz, 1, 1]))['params']
paramsD = netD().init(key, jnp.ones([1, nc, 28, 28]))['params']

optG = optax.adam(lr)
optD = optax.adam(lr)
opt_stateG = optG.init(paramsG)
opt_stateD = optD.init(paramsD)

for it in range(10000):
    try:
        (i, images, labels) = next(iter_train)
    except StopIteration:
        iter_train = ((i, images, labels)
                      for i, (images, labels) in enumerate(train_loader))
        continue
    
    images = jnp.array(images.numpy())
    
    key, rng = random.split(key)
    D_loss_val, G_loss_val, opt_stateG, paramsG, opt_stateD, paramsD = jax.lax.fori_loop(
        0, 1, lambda j, state: (lambda D_loss_val, G_loss_val, opt_stateG, paramsG, opt_stateD, paramsD: (
            jnp.array(loss_fn(paramsD, paramsG, rng, images)),
            optG.update(jax.grad(loss_fn, argnums=1)(paramsD, paramsG, rng, images), opt_stateG, paramsG),
            optD.update(jax.grad(loss_fn)(paramsD, paramsG, rng, images)[0], opt_stateD, paramsD))
        )(*state), (jax.lax.stop_gradient(D_loss_val), jax.lax.stop_gradient(G_loss_val), opt_stateG, paramsG, opt_stateD, paramsD))

    if it % 100 == 0:
        print(f'Iter-{it}; D_loss: {D_loss_val:.4f}; G_loss: {G_loss_val:.4f}')
        
        samples = netG().apply({'params': paramsG}, jnp.array(random.normal(rng, (16, nz, 1, 1)))).reshape(-1, 28, 28)
        
        fig = plt.figure(figsize=(4, 4))
        gs = gridspec.GridSpec(4, 4)
        gs.update(wspace=0.05, hspace=0.05)
        
        for i, sample in enumerate(samples):
            ax = plt.subplot(gs[i])
            plt.axis('off')
            ax.set_xticklabels([])
            ax.set_yticklabels([])
            ax.set_aspect('equal')
            plt.imshow(sample, cmap='Greys_r')
        
        dir_n = 'out_cnn_ebgan/'
        if not os.path.exists(dir_n):
            os.makedirs(dir_n)
        
        plt.savefig(f'{dir_n}{str(cnt).zfill(3)}.png', bbox_inches='tight')
        cnt += 1
        plt.close(fig)