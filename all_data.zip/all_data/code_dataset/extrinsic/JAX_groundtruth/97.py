import jax
import jax.numpy as jnp
from flax import linen as nn
from typing import Any, Optional

class LayerNorm(nn.Module):
    normalized_shape: Any
    eps: float = 1e-5
    use_affine: bool = True

    @nn.compact
    def __call__(self, x):
        is_tracing_or_cpu = not jax.lib.xla_bridge.get_backend().platform == "gpu"
        x_dtype = x.dtype
        if is_tracing_or_cpu or not self.use_affine:
            x = jnp.asarray(x, dtype=jnp.float32)
            mean = jnp.mean(x, axis=-1, keepdims=True)
            variance = jnp.mean(jnp.square(x - mean), axis=-1, keepdims=True)
            normed = (x - mean) / jnp.sqrt(variance + self.eps)
            return jnp.asarray(normed, dtype=x_dtype)
        else:
            raise NotImplementedError("FusedLayerNorm is not implemented for GPUs in this translation")

class Fp32LayerNorm(nn.Module):
    normalized_shape: Any
    eps: float = 1e-5
    use_affine: bool = True

    @nn.compact
    def __call__(self, x):
        x = jnp.asarray(x, dtype=jnp.float32)
        mean = jnp.mean(x, axis=-1, keepdims=True)
        variance = jnp.mean(jnp.square(x - mean), axis=-1, keepdims=True)
        normed = (x - mean) / jnp.sqrt(variance + self.eps)
        if self.use_affine:
            scale = self.param('scale', nn.initializers.ones, self.normalized_shape)
            bias = self.param('bias', nn.initializers.zeros, self.normalized_shape)
            normed = normed * scale + bias
        return normed.astype(x.dtype)