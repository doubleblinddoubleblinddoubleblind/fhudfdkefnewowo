import jax
import jax.numpy as jnp
from jax import random, jit
from flax import linen as nn

class Encoder(nn.Module):
    input_size: int
    embedding_size: int
    hidden_size: int
    n_layers: int = 1
    bidirec: bool = False

    def setup(self):
        self.n_direction = 2 if self.bidirec else 1

        self.embedding = nn.Embed(num_embeddings=self.input_size, features=self.embedding_size)

        self.gru = nn.GRUCell(hidden_size=self.hidden_size)

    def init_hidden(self, batch_size, key):
        hidden = jnp.zeros((self.n_layers * self.n_direction, batch_size, self.hidden_size))
        return hidden

    def init_weight(self, key):
        embedding_key, hh_key, ih_key = random.split(key, 3)
        self.embedding.params = random.uniform(embedding_key, self.embedding.embedding.shape, minval=-1.0, maxval=1.0)
        self.gru.params['hh'] = random.uniform(hh_key, self.gru.params['hh'].shape, minval=-1.0, maxval=1.0)
        self.gru.params['ih'] = random.uniform(ih_key, self.gru.params['ih'].shape, minval=-1.0, maxval=1.0)

    @nn.compact
    def __call__(self, inputs, input_lengths, key):
        batch_size, seq_len = inputs.shape
        hidden = self.init_hidden(batch_size, key)

        embedded = self.embedding(inputs)
        
        # Packing and padding sequences is not directly available in JAX. 
        # Users need to manually handle masking or batching.
        
        outputs = []
        for t in range(seq_len):
            hidden, _ = self.gru(hidden, embedded[:, t, :])
            outputs.append(hidden)

        outputs = jnp.stack(outputs, axis=1)
        
        if self.n_layers > 1:
            if self.n_direction == 2:
                hidden = hidden[-2:]
            else:
                hidden = hidden[-1]
                
        return outputs, jnp.concatenate(hidden, 1).reshape(batch_size, 1, -1)

# Note: The logic for handling packed sequences and batch_first may require additional implementation details in JAX 
# as it does not directly support 'pack_padded_sequence'. Users can use jax.lax.scan or other approaches to handle this.