# Reinforcement learning using unreal 

import gym
import math
import random
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from collections import namedtuple
from itertools import count
from copy import deepcopy
from PIL import Image

import jax
import jax.numpy as jnp
from jax import random as jrandom

env = gym.make("LunarLander-v2").unwrapped

Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

# Test to see if it still runs
env.reset()

for _ in range(1000):
    env.render()
    env.step(env.action_space.sample())  # take a random action