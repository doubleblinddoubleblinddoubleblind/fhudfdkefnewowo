from collections import OrderedDict

import numpy as np
import optax
import jax.numpy as jnp
from jax import value_and_grad, jit, random

import rlkit.jax.jax_util as jxu
from rlkit.core.eval_util import create_stats_ordered_dict
from rlkit.jax.jax_rl_algorithm import JaxTrainer


def update(params, opt_state, grads, optimizer):
    updates, opt_state = optimizer.update(grads, opt_state, params)
    params = optax.apply_updates(params, updates)
    return params, opt_state

class DDPGTrainer(JaxTrainer):
    """
    Deep Deterministic Policy Gradient
    """
    def __init__(
            self,
            qf,
            target_qf,
            policy,
            target_policy,

            discount=0.99,
            reward_scale=1.0,

            policy_learning_rate=1e-4,
            qf_learning_rate=1e-3,
            qf_weight_decay=0,
            target_hard_update_period=1000,
            tau=1e-2,
            use_soft_update=False,
            qf_criterion=None,
            policy_pre_activation_weight=0.,
            optimizer_class=optax.adam,

            min_q_value=-jnp.inf,
            max_q_value=jnp.inf,
    ):
        super().__init__()
        if qf_criterion is None:
            qf_criterion = lambda q_pred, q_target: jnp.mean((q_pred - q_target) ** 2)
        self.qf_params = qf
        self.target_qf_params = target_qf
        self.policy_params = policy
        self.target_policy_params = target_policy

        self.discount = discount
        self.reward_scale = reward_scale

        self.policy_learning_rate = policy_learning_rate
        self.qf_learning_rate = qf_learning_rate
        self.qf_weight_decay = qf_weight_decay
        self.target_hard_update_period = target_hard_update_period
        self.tau = tau
        self.use_soft_update = use_soft_update
        self.qf_criterion = qf_criterion
        self.policy_pre_activation_weight = policy_pre_activation_weight
        self.min_q_value = min_q_value
        self.max_q_value = max_q_value

        self.policy_optimizer = optimizer_class(self.policy_learning_rate)
        self.qf_optimizer = optimizer_class(self.qf_learning_rate)
        self.policy_opt_state = self.policy_optimizer.init(self.policy_params)
        self.qf_opt_state = self.qf_optimizer.init(self.qf_params)

        self.eval_statistics = OrderedDict()
        self._n_train_steps_total = 0
        self._need_to_update_eval_statistics = True

    def train_from_jax(self, batch):
        rewards = batch['rewards']
        terminals = batch['terminals']
        obs = batch['observations']
        actions = batch['actions']
        next_obs = batch['next_observations']

        def policy_loss_fn(policy_params):
            if self.policy_pre_activation_weight > 0:
                policy_actions, pre_tanh_value = self.policy(obs, policy_params, return_preactivations=True)
                pre_activation_policy_loss = jnp.mean(jnp.sum(pre_tanh_value**2, axis=1))
                q_output = self.qf(obs, policy_actions, self.qf_params)
                raw_policy_loss = -jnp.mean(q_output)
                policy_loss = raw_policy_loss + pre_activation_policy_loss * self.policy_pre_activation_weight
            else:
                policy_actions = self.policy(obs, policy_params)
                q_output = self