'''Dual Path Networks in JAX.'''
import jax
import jax.numpy as jnp
import flax.linen as nn

class Bottleneck(nn.Module):
    last_planes: int
    in_planes: int
    out_planes: int
    dense_depth: int
    stride: int
    first_layer: bool

    @nn.compact
    def __call__(self, x):
        out_planes = self.out_planes
        dense_depth = self.dense_depth

        conv1 = nn.Conv(features=self.in_planes, kernel_size=(1, 1), use_bias=False)
        bn1 = nn.BatchNorm(use_running_average=False, momentum=0.9)
        conv2 = nn.Conv(features=self.in_planes, kernel_size=(3, 3), strides=(self.stride, self.stride),
                        padding='SAME', feature_group_count=32, use_bias=False)
        bn2 = nn.BatchNorm(use_running_average=False, momentum=0.9)
        conv3 = nn.Conv(features=out_planes + dense_depth, kernel_size=(1, 1), use_bias=False)
        bn3 = nn.BatchNorm(use_running_average=False, momentum=0.9)

        out = jax.nn.relu(bn1(conv1(x)))
        out = jax.nn.relu(bn2(conv2(out)))
        out = bn3(conv3(out))

        if self.first_layer:
            shortcut = nn.Conv(features=out_planes + dense_depth, kernel_size=(1, 1), strides=(self.stride, self.stride),
                               use_bias=False)
            bn_shortcut = nn.BatchNorm(use_running_average=False, momentum=0.9)
            x = bn_shortcut(shortcut(x))

        d = out_planes
        out = jnp.concatenate([x[:, :, :, :d] + out[:, :, :, :d], x[:, :, :, d:], out[:, :, :, d:]], axis=3)
        out = jax.nn.relu(out)
        return out


class DPN(nn.Module):
    cfg: dict

    @nn.compact
    def __call__(self, x):
        in_planes, out_planes = self.cfg['in_planes'], self.cfg['out_planes']
        num_blocks, dense_depth = self.cfg['num_blocks'], self.cfg['dense_depth']

        conv1 = nn.Conv(features=64, kernel_size=(3, 3), padding='SAME', use_bias=False)
        bn1 = nn.BatchNorm(use_running_average=False, momentum=0.9)

        x = jax.nn.relu(bn1(conv1(x)))
        x = self._make_layer(0, x, in_planes[0], out_planes[0], num_blocks[0], dense_depth[0], stride=1)
        x = self._make_layer(1, x, in_planes[1], out_planes[1], num_blocks[1], dense_depth[1], stride=2)
        x = self._make_layer(2, x, in_planes[2], out_planes[2], num_blocks[2], dense_depth[2], stride=2)
        x = self._make_layer(3, x, in_planes[3], out_planes[3], num_blocks[3], dense_depth[3], stride=2)

        x = nn.avg_pool(x, window_shape=(4, 4), strides=(1, 1)).reshape((x.shape[0], -1))
        linear = nn.Dense(features=10)
        return linear(x)

    def _make_layer(self, layer_index, x, in_planes, out_planes, num_blocks, dense_depth, stride):
        for i in range(num_blocks):
            x = Bottleneck(last_planes=x.shape[-1], 
                           in_planes=in_planes, 
                           out_planes=out_planes, 
                           dense_depth=dense_depth, 
                           stride=stride if i == 0 else 1, 
                           first_layer=(i == 0))(x)
        return x


def DPN26():
    cfg = {
        'in_planes': (96, 192, 384, 768),
        'out_planes': (256, 512, 1024, 2048),
        'num_blocks': (2, 2, 2, 2),
        'dense_depth': (16, 32, 24, 128)
    }
    return DPN(cfg)


def DPN92():
    cfg = {
        'in_planes': (96, 192, 384, 768),
        'out_planes': (256, 512, 1024, 2048),
        'num_blocks': (3, 4, 20, 3),
        'dense_depth': (16, 32, 24, 128)
    }
    return DPN(cfg)


def test():
    key1, key2 = jax.random.split(jax.random.PRNGKey(0), 2)
    model = DPN92()
    x = jax.random.normal(key1, (1, 32, 32, 3))
    variables = model.init(key2, x)
    y = model.apply(variables, x)
    print(y)

# test()