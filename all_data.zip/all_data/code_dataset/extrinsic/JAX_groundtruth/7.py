import jax
import jax.numpy as jnp
from flax import linen as nn
import tensorflow as tf
import tensorflow_hub as hub

class QestimatorResNet18:
    def __init__(self, num_label):
        self.model = hub.KerasLayer("https://tfhub.dev/tensorflow/resnet_50/classification/1")
        self.num_label = num_label
        self.fc_weights = jax.random.normal(jax.random.PRNGKey(0), (2048, num_label))
        self.fc_bias = jax.random.normal(jax.random.PRNGKey(0), (num_label,))

    def __call__(self, x):
        x = self.model(x)
        x = jnp.dot(x, self.fc_weights) + self.fc_bias
        return x

class QestimatorNaive(nn.Module):
    num_label: int
    input_h: int

    def setup(self):
        self.conv1 = nn.Conv(features=16, kernel_size=(5, 5), strides=(2, 2))
        self.bn1 = nn.BatchNorm(use_running_average=False)
        self.conv2 = nn.Conv(features=32, kernel_size=(5, 5), strides=(2, 2))
        self.bn2 = nn.BatchNorm(use_running_average=False)
        self.conv3 = nn.Conv(features=32, kernel_size=(5, 5), strides=(2, 2))
        self.bn3 = nn.BatchNorm(use_running_average=False)

        Hout = (((self.input_h-4)/2 -4 )/2 -4)/2
        Flatten = int(32*Hout**2) # assuming square input
        self.head = nn.Dense(features=self.num_label)

    def __call__(self, x):
        x = nn.relu(self.bn1(self.conv1(x)))
        x = nn.relu(self.bn2(self.conv2(x)))
        x = nn.relu(self.bn3(self.conv3(x)))
        x = x.reshape(x.shape[0], -1)  # flatten
        return self.head(x)