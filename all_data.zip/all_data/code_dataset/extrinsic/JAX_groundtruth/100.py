import time
import os
from time import gmtime, strftime
from datetime import datetime
import jax
from jax import numpy as jnp
import jax.random as random
from jax import grad, jit, vmap, value_and_grad
from flax import linen as nn
from grassdata import GRASSDataset
from grassmodel import GRASSEncoder
from grassmodel import GRASSDecoder
import grassmodel

import optax
import util
from dynamicplot import DynamicPlot


config = util.get_args()

print("Loading data ...... ", end='', flush=True)
grass_data = GRASSDataset(config.data_path)

def my_collate(batch):
    return batch

train_iter = grass_data.batch(config.batch_size, drop_last=True)
print("DONE")

encoder = GRASSEncoder(config)
decoder = GRASSDecoder(config)

encoder_opt = optax.adam(1e-3)
decoder_opt = optax.adam(1e-3)

encoder_params = encoder.init(random.PRNGKey(0), jnp.ones([1, *encoder.input_shape()]))
decoder_params = decoder.init(random.PRNGKey(0), jnp.ones([1, *decoder.input_shape()]))

encoder_opt_state = encoder_opt.init(encoder_params)
decoder_opt_state = decoder_opt.init(decoder_params)

print("Start training ...... ")

start = time.time()

if config.save_snapshot:
    if not os.path.exists(config.save_path):
        os.makedirs(config.save_path)
    snapshot_folder = os.path.join(config.save_path, 'snapshots_'+strftime("%Y-%m-%d_%H-%M-%S",gmtime()))
    if not os.path.exists(snapshot_folder):
        os.makedirs(snapshot_folder)

if config.save_log:
    fd_log = open('training_log.log', mode='a')
    fd_log.write('\n\nTraining log at '+datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    fd_log.write('\n#epoch: {}'.format(config.epochs))
    fd_log.write('\nbatch_size: {}'.format(config.batch_size))
    fd_log.write('\ncuda: {}'.format(config.cuda))
    fd_log.flush()

header = '     Time    Epoch     Iteration    Progress(%)  ReconLoss  KLDivLoss  TotalLoss'
log_template = ' '.join('{:>9s},{:>5.0f}/{:<5.0f},{:>5.0f}/{:<5.0f},{:>9.1f}%,{:>11.2f},{:>10.2f},{:>10.2f}'.split(','))

total_iter = config.epochs * len(list(train_iter))

if not config.no_plot:
    plot_x = [x for x in range(total_iter)]
    plot_total_loss = [None for x in range(total_iter)]
    plot_recon_loss = [None for x in range(total_iter)]
    plot_kldiv_loss = [None for x in range(total_iter)]
    dyn_plot = DynamicPlot(title='Training loss over epochs (GRASS)', xdata=plot_x, ydata={'Total_loss':plot_total_loss, 'Reconstruction_loss':plot_recon_loss, 'KL_divergence_loss':plot_kldiv_loss})
    iter_id = 0
    max_loss = 0

@jit
def compute_loss(encoder_params, decoder_params, batch):
    encodes = vmap(lambda x: encoder.apply(encoder_params, x))(batch)
    decodes, kldivs = zip(*[grassmodel.decode_structure(jnp.split(e, 2, axis=-1)[0], ex) for e, ex in zip(encodes, batch)])
    recon_loss = sum(decodes) / len(batch)
    kldiv_loss = sum(kldivs) * -0.05 / len(batch)
    total_loss = recon_loss + kldiv_loss
    return total_loss, recon_loss, kldiv_loss

for epoch in range(config.epochs):
    print(header)
    for batch_idx, batch in enumerate(train_iter):
        loss, recon_loss, kldiv_loss = compute_loss(encoder_params, decoder_params, batch)
        grads_encoder, grads_decoder = grad(compute_loss, has_aux=True, argnums=(0, 1))(encoder_params, decoder_params, batch)

        encoder_updates, encoder_opt_state = encoder_opt.update(grads_encoder, encoder_opt_state)
        decoder_updates, decoder_opt_state = decoder_opt.update(grads_decoder, decoder_opt_state)
        encoder_params = optax.apply_updates(encoder_params, encoder_updates)
        decoder_params = optax.apply_updates(decoder_params, decoder_updates)

        if batch_idx % config.show_log_every == 0:
            print(log_template.format(strftime("%H:%M:%S",time.gmtime(time.time()-start)),
                epoch, config.epochs, 1+batch_idx, len(list(train_iter)),
                100. * (1+batch_idx+len(list(train_iter))*epoch) / (len(list(train_iter))*config.epochs),
                recon_loss, kldiv_loss, loss))

        if not config.no_plot:
            plot_total_loss[iter_id] = loss
            plot_recon_loss[iter_id] = recon_loss
            plot_kldiv_loss[iter_id] = kldiv_loss
            max_loss = max(max_loss, loss, recon_loss, kldiv_loss)
            dyn_plot.setxlim(0., (iter_id+1)*1.05)
            dyn_plot.setylim(0., max_loss*1.05)
            dyn_plot.update_plots(ydata={'Total_loss':plot_total_loss, 'Reconstruction_loss':plot_recon_loss, 'KL_divergence_loss':plot_kldiv_loss})
            iter_id += 1

    if config.save_snapshot and (epoch+1) % config.save_snapshot_every == 0 :
        print("Saving snapshots of the models ...... ", end='', flush=True)
        encoder_filename = f'{snapshot_folder}vae_encoder_model_epoch_{epoch+1}_loss_{loss:.2f}.ckpt'
        decoder_filename = f'{snapshot_folder}vae_decoder_model_epoch_{epoch+1}_loss_{loss:.2f}.ckpt'
        jax.device_put(encoder_params, encoder_filename)
        jax.device_put(decoder_params, decoder_filename)
        print("DONE")

    if config.save_log and (epoch+1) % config.save_log_every == 0 :
        fd_log = open('training_log.log', mode='a')
        fd_log.write('\nepoch:{} recon_loss:{:.2f} kld_loss:{:.2f} total_loss:{:.2f}'.format(epoch+1, recon_loss, kldiv_loss, loss))
        fd_log.close()

print("Saving final models ...... ", end='', flush=True)
encoder_final = config.save_path + 'vae_encoder_model.ckpt'
decoder_final = config.save_path + 'vae_decoder_model.ckpt'
jax.device_put(encoder_params, encoder_final)
jax.device_put(decoder_params, decoder_final)
print("DONE")