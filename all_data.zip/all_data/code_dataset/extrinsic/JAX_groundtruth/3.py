import jax.numpy as jnp
from flax import linen as nn
from . import jax_layers

class RnnDocReader(nn.Module):
    RNN_TYPES = {'lstm': nn.LSTMCell, 'gru': nn.GRUCell, 'rnn': nn.RNNCell}

    def setup(self):
        # Store config
        self.opt = self.opt

        # Word embeddings (+1 for padding)
        self.embedding = nn.Embed(
            num_embeddings=self.opt['vocab_size'],
            features=self.opt['embedding_dim'],
            embedding_init=nn.initializers.normal(),
        )

        # Projection for attention weighted question
        if self.opt['use_qemb']:
            self.qemb_match = jax_layers.SeqAttnMatch(self.opt['embedding_dim'])

        # Input size to RNN: word emb + question emb + manual features
        doc_input_size = self.opt['embedding_dim'] + self.opt['num_features']
        if self.opt['use_qemb']:
            doc_input_size += self.opt['embedding_dim']

        # RNN document encoder
        self.doc_rnn = jax_layers.StackedBRNN(
            input_size=doc_input_size,
            hidden_size=self.opt['hidden_size'],
            num_layers=self.opt['doc_layers'],
            dropout_rate=self.opt['dropout_rnn'],
            rnn_type=self.RNN_TYPES[self.opt['rnn_type']],
        )

        # RNN question encoder
        self.question_rnn = jax_layers.StackedBRNN(
            input_size=self.opt['embedding_dim'],
            hidden_size=self.opt['hidden_size'],
            num_layers=self.opt['question_layers'],
            dropout_rate=self.opt['dropout_rnn'],
            rnn_type=self.RNN_TYPES[self.opt['rnn_type']],
        )

        # Output sizes of rnn encoders
        doc_hidden_size = 2 * self.opt['hidden_size']
        question_hidden_size = 2 * self.opt['hidden_size']
        if self.opt['concat_rnn_layers']:
            doc_hidden_size *= self.opt['doc_layers']
            question_hidden_size *= self.opt['question_layers']

        # Question merging
        if self.opt['question_merge'] not in ['avg', 'self_attn']:
            raise NotImplementedError('merge_mode = %s' % self.opt['merge_mode'])
        if self.opt['question_merge'] == 'self_attn':
            self.self_attn = jax_layers.LinearSeqAttn(question_hidden_size)

        # Bilinear attention for span start/end
        self.start_attn = jax_layers.BilinearSeqAttn(
            doc_hidden_size,
            question_hidden_size,
        )
        self.end_attn = jax_layers.BilinearSeqAttn(
            doc_hidden_size,
            question_hidden_size,
        )

    def __call__(self, x1, x1_f, x1_mask, x2, x2_mask, training=True):
        x1_emb = self.embedding(x1)
        x2_emb = self.embedding(x2)

        # Dropout on embeddings
        if self.opt['dropout_emb'] > 0:
            x1_emb = nn.dropout(x1_emb, rate=self.opt['dropout_emb'], deterministic=not training)
            x2_emb = nn.dropout(x2_emb, rate=self.opt['dropout_emb'], deterministic=not training)

        # Add attention-weighted question representation
        if self.opt['use_qemb']:
            x2_weighted_emb = self.qemb_match(x1_emb, x2_emb, x2_mask)
            drnn_input = jnp.concatenate([x1_emb, x2_weighted_emb, x1_f], axis=-1)
        else:
            drnn_input = jnp.concatenate([x1_emb, x1_f], axis=-1)

        # Encode document with RNN
        doc_hiddens = self.doc_rnn(drnn_input, x1_mask)

        # Encode question with RNN + merge hiddens
        question_hiddens = self.question_rnn(x2_emb, x2_mask)
        if self.opt['question_merge'] == 'avg':
            q_merge_weights = jax_layers.uniform_weights(question_hiddens, x2_mask)
        elif self.opt['question_merge'] == 'self_attn':
            q_merge_weights = self.self_attn(question_hiddens, x2_mask)
        question_hidden = jax_layers.weighted_avg(question_hiddens, q_merge_weights)

        # Predict start and end positions
        start_scores = self.start_attn(doc_hiddens, question_hidden, x1_mask)
        end_scores = self.end_attn(doc_hiddens, question_hidden, x1_mask)
        return start_scores, end_scores