import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from bigdl.chronos.model.tcmf.local_model import TemporalConvNet
import ray
from bigdl.orca.learn.jax import Estimator

# Build data creator
def get_tcmf_data_loader(config):
    from bigdl.chronos.model.tcmf.data_loader import TCMFDataLoader
    tcmf_data_loader = TCMFDataLoader(
        Ymat=ray.get(config["Ymat_id"]),
        vbsize=config["vbsize"],
        hbsize=config["hbsize"],
        end_index=config["end_index"],
        val_len=config["val_len"],
        covariates=ray.get(config["covariates_id"]),
        Ycov=ray.get(config["Ycov_id"]),
    )
    return tcmf_data_loader


class TcmfTrainDatasetDist:
    def __init__(self, config):
        self.tcmf_data_loader = get_tcmf_data_loader(config)
        self.last_epoch = 0

    def __iter__(self):
        while self.tcmf_data_loader.epoch == self.last_epoch:
            yield self.get_next_batch()
        self.last_epoch += 1

    def get_next_batch(self):
        inp, out, _, _ = self.tcmf_data_loader.next_batch()
        return inp, out


class TcmfValDataset:
    def __init__(self, config):
        self.tcmf_data_loader = get_tcmf_data_loader(config)

    def __iter__(self):
        inp, out, _, _ = self.tcmf_data_loader.supply_test()
        yield inp, out


def data_creator(config):
    train_dataset = TcmfTrainDatasetDist(config)
    val_dataset = TcmfValDataset(config)
    return iter(train_dataset), iter(val_dataset)


def train_data_creator(config, batch_size):
    train_dataset = TcmfTrainDatasetDist(config)
    return iter(train_dataset)


def val_data_creator(config, batch_size):
    val_dataset = TcmfValDataset(config)
    return iter(val_dataset)


# Build loss creator
def tcmf_loss(out, target):
    return jnp.mean(jnp.abs(out - target)) / jnp.mean(jnp.abs(target))


def loss_creator(config):
    return tcmf_loss


# Build optimizer creator
def optimizer_creator(lr):
    """Returns optimizer."""
    return optax.adam(lr)


# Build model creator
def model_creator(config):
    return TemporalConvNet(
        num_inputs=config["num_inputs"],
        num_channels=config["num_channels"],
        kernel_size=config["kernel_size"],
        dropout=config["dropout"],
        init=True,
    )


def train_yseq(workers_per_node, epochs, **config):
    estimator = Estimator.from_jax(
        model_creator=model_creator,
        optimizer_creator=optimizer_creator,
        loss_creator=loss_creator,
        workers_per_node=workers_per_node,
        config=config
    )

    stats = estimator.fit(train_data_creator, epochs=epochs)
    for s in stats:
        for k, v in s.items():
            print(f"{k}: {v}")
    val_stats = estimator.evaluate(val_data_creator)
    val_loss = val_stats['val_loss']

    # retrieve the model
    yseq = estimator.get_model()
    estimator.shutdown()
    return yseq, val_loss