import functools
import jax
import jax.numpy as jnp
from jax.example_libraries import optimizers

@optimizers.optimizer
def rm3(step_size, weight_decay=0.0):
  
    def init(params):
        gradients_buffer = jax.tree_map(lambda _: [jnp.zeros_like(_) for _ in range(3)], params)
        gradients_counter = jax.tree_map(lambda _: 0, params)
        return params, (gradients_buffer, gradients_counter)

    def update(i, opt_state, grads):
        params, (gradients_buffer, gradients_counter) = opt_state
        def update_fn(param, grad, g_buffer, g_counter):
            if weight_decay != 0.0:
                grad = grad + weight_decay * param
            # Update the ring buffer and the counter
            idx = g_counter % 3
            g_buffer[idx] = grad
            g_counter += 1

            # Compute update if buffer is full
            if g_counter >= 3:
                sum_gradients = functools.reduce(jnp.add, g_buffer)
                min_gradients = functools.reduce(jnp.minimum, g_buffer)
                max_gradients = functools.reduce(jnp.maximum, g_buffer)
                median_of_3 = sum_gradients - min_gradients - max_gradients
                param = param - step_size * median_of_3

            return param, (g_buffer, g_counter)
        
        new_params, new_buffers = jax.tree_map(update_fn, params, grads, gradients_buffer, gradients_counter)
        return new_params, new_buffers

    return init, update

# Usage Example:
# Initialize optimizer
# opt = rm3(step_size=0.001, weight_decay=0.01)
# opt_state = opt.init(params)
# for step in range(num_steps):
#     grads = compute_gradients(params)
#     opt_state = opt.update(step, opt_state, grads)
#     params = opt.params(opt_state)