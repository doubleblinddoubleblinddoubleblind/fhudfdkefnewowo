import jax
import jax.numpy as jnp
from flax import linen as nn
import numpy as np
import flax.linen.initializers as init

class ResNeXtBottleneck(nn.Module):
    expansion: int = 4
    inplanes: int
    planes: int
    cardinality: int
    base_width: int
    stride: int = 1
    downsample: nn.Module = None

    def setup(self):
        D = int(np.floor(self.planes * (self.base_width/64.0)))
        C = self.cardinality

        self.conv_reduce = nn.Conv(features=D*C, kernel_size=(1, 1), strides=(1, 1), use_bias=False)
        self.bn_reduce = nn.BatchNorm(use_running_average=False)

        self.conv_conv = nn.Conv(features=D*C, kernel_size=(3, 3), strides=(self.stride, self.stride), padding=((1, 1), (1, 1)), feature_group_count=C, use_bias=False)
        self.bn = nn.BatchNorm(use_running_average=False)

        self.conv_expand = nn.Conv(features=self.planes*4, kernel_size=(1, 1), strides=(1, 1), use_bias=False)
        self.bn_expand = nn.BatchNorm(use_running_average=False)
        
    def __call__(self, x):
        residual = x

        bottleneck = self.conv_reduce(x)
        bottleneck = nn.relu(self.bn_reduce(bottleneck))

        bottleneck = self.conv_conv(bottleneck)
        bottleneck = nn.relu(self.bn(bottleneck))

        bottleneck = self.conv_expand(bottleneck)
        bottleneck = self.bn_expand(bottleneck)

        if self.downsample is not None:
            residual = self.downsample(x)
        return nn.relu(residual + bottleneck)

class CifarResNeXt(nn.Module):
    block: nn.Module
    depth: int
    cardinality: int
    base_width: int
    num_classes: int

    def setup(self):
        assert (self.depth - 2) % 9 == 0, 'depth should be one of 29, 38, 47, 56, 101'
        self.layer_blocks = (self.depth - 2) // 9

        self.conv_1_3x3 = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1), padding=((1, 1), (1, 1)), use_bias=False)
        self.bn_1 = nn.BatchNorm(use_running_average=False)

        self.inplanes = 64
        self.stage_1 = self._make_layer(64, 1)
        self.stage_2 = self._make_layer(128, 2)
        self.stage_3 = self._make_layer(256, 2)
        self.avgpool = nn.avg_pool
        self.classifier = nn.Dense(features=self.num_classes)

    def _make_layer(self, planes, stride=1):
        downsample = None
        exp_planes = planes * self.block.expansion
        if stride != 1 or self.inplanes != exp_planes:
            downsample = nn.Sequential([
                nn.Conv(features=exp_planes, kernel_size=(1, 1), strides=(stride, stride), use_bias=False),
                nn.BatchNorm(use_running_average=False),
            ])

        layers = [self.block(self.inplanes, planes, self.cardinality, self.base_width, stride, downsample)]
        self.inplanes = exp_planes
        for _ in range(1, self.layer_blocks):
            layers.append(self.block(self.inplanes, planes, self.cardinality, self.base_width))

        return nn.Sequential(layers)

    def __call__(self, x):
        x = self.conv_1_3x3(x)
        x = nn.relu(self.bn_1(x))
        x = self.stage_1(x)
        x = self.stage_2(x)
        x = self.stage_3(x)
        x = self.avgpool(x, window_shape=(x.shape[1], x.shape[2]), strides=(1, 1))
        x = x.reshape(x.shape[0], -1)
        return nn.log_softmax(self.classifier(x))

def resnext29_16_64(num_classes=10):
    model = CifarResNeXt(ResNeXtBottleneck, 29, 16, 64, num_classes)
    return model

def resnext29_8_64(num_classes=10):
    model = CifarResNeXt(ResNeXtBottleneck, 29, 8, 64, num_classes)
    return model