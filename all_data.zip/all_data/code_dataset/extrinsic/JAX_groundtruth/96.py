#!/usr/bin/env python3

import math
import unittest

import jax
import jax.numpy as jnp
from jax.config import config
from jax import grad, jit, vmap

config.update("jax_enable_x64", True)

class PeriodicKernel:
    def __init__(self, batch_shape=None):
        self.batch_shape = batch_shape
        self.lengthscale = None
        self.period_length = None

    def initialize(self, lengthscale, period_length):
        self.lengthscale = lengthscale
        self.period_length = period_length
        return self

    def eval(self):
        return self

    def __call__(self, X, Y):
        if self.lengthscale is None or self.period_length is None:
            raise ValueError("Kernel parameters not initialized")
        return self.K(X, Y)

    def K(self, X, Y):
        def periodic_fn(x, y, lengthscale, period):
            diff = math.pi * (x - y) / period
            val = 2 * jnp.power(jnp.sin(diff), 2) / lengthscale
            return jnp.exp(-val)
        
        if self.batch_shape:
            fn = vmap(vmap(vmap(periodic_fn, (0, 0, None, None)), (0, 0, None, None)), (0, 0, 0, 0))
        else:
            fn = vmap(vmap(periodic_fn, (0, 0, None, None)), (0, 0, None, None))

        return fn(X, Y, self.lengthscale, self.period_length)


class TestPeriodicKernel(unittest.TestCase):
    def test_computes_periodic_function(self):
        a = jnp.array([4, 2, 8], dtype=jnp.float64).reshape(3, 1)
        b = jnp.array([0, 2], dtype=jnp.float64).reshape(2, 1)
        lengthscale = 2
        period = 3
        kernel = PeriodicKernel().initialize(lengthscale=lengthscale, period_length=period)
        kernel.eval()

        actual = jnp.zeros((3, 2))
        for i in range(3):
            for j in range(2):
                val = 2 * jnp.power(jnp.sin(math.pi * (a[i] - b[j]) / period), 2) / lengthscale
                actual = actual.at[i, j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch(self):
        a = jnp.array([[4, 2, 8], [1, 2, 3]], dtype=jnp.float64).reshape(2, 3, 1)
        b = jnp.array([[0, 2], [-1, 2]], dtype=jnp.float64).reshape(2, 2, 1)
        period = jnp.array(1, dtype=jnp.float64).reshape(1, 1, 1)
        lengthscale = jnp.array(2, dtype=jnp.float64).reshape(1, 1, 1)
        kernel = PeriodicKernel().initialize(lengthscale=lengthscale, period_length=period)
        kernel.eval()

        actual = jnp.zeros((2, 3, 2))
        for k in range(2):
            for i in range(3):
                for j in range(2):
                    val = 2 * jnp.power(jnp.sin(math.pi * (a[k, i] - b[k, j]) / period), 2) / lengthscale
                    actual = actual.at[k, i, j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

    def test_batch_separate(self):
        a = jnp.array([[4, 2, 8], [1, 2, 3]], dtype=jnp.float64).reshape(2, 3, 1)
        b = jnp.array([[0, 2], [-1, 2]], dtype=jnp.float64).reshape(2, 2, 1)
        period = jnp.array([1, 2], dtype=jnp.float64).reshape(2, 1, 1)
        lengthscale = jnp.array([2, 1], dtype=jnp.float64).reshape(2, 1, 1)
        kernel = PeriodicKernel(batch_shape=(2,)).initialize(lengthscale=lengthscale, period_length=period)
        kernel.eval()

        actual = jnp.zeros((2, 3, 2))
        for k in range(2):
            for i in range(3):
                for j in range(2):
                    val = 2 * jnp.power(jnp.sin(math.pi * (a[k, i] - b[k, j]) / period[k]), 2) / lengthscale[k]
                    actual = actual.at[k, i, j].set(jnp.exp(-val))

        res = kernel(a, b)
        self.assertLess(jnp.linalg.norm(res - actual), 1e-5)

if __name__ == "__main__":
    unittest.main()