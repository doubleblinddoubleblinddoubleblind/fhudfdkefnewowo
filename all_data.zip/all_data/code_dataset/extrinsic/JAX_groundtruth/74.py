import jax
import jax.numpy as jnp
from flax import linen as nn
from jax.nn.initializers import orthogonal, zeros
from jax.nn import relu

class Flatten(nn.Module):
    @nn.compact
    def __call__(self, x):
        return x.reshape(x.shape[0], -1)


def init(module, weight_init, bias_init, input_shape, dtype=jnp.float32):
    weights_key, bias_key = jax.random.split(jax.random.PRNGKey(0), 2)
    module.kernel_init = lambda key, shape, dtype: weight_init(key, shape, dtype, gain=nn.relu)
    module.bias_init = lambda key, shape, dtype: bias_init(key, shape, dtype)
    return module, module.init(weights_key, jnp.ones(input_shape, dtype))


class CNNBase(nn.Module):
    num_inputs: int
    use_gru: bool

    def setup(self):
        self.main = nn.Sequential([
            nn.Conv(features=32, kernel_size=(8, 8), strides=(4, 4),
                    kernel_init=orthogonal(), bias_init=zeros),
            nn.relu,
            nn.Conv(features=64, kernel_size=(4, 4), strides=(2, 2),
                    kernel_init=orthogonal(), bias_init=zeros),
            nn.relu,
            nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1),
                    kernel_init=orthogonal(), bias_init=zeros),
            nn.relu,
            Flatten(),
            nn.Dense(features=512, kernel_init=orthogonal(), bias_init=zeros),
            nn.relu
        ])

        if self.use_gru:
            self.gru = nn.GRUCell(gate_fn=nn.sigmoid, update_fn=nn.tanh)

        self.critic_linear = nn.Dense(features=1, kernel_init=orthogonal(), bias_init=zeros)

    @property
    def state_size(self):
        return 512 if self.use_gru else 1

    @property
    def output_size(self):
        return 512

    def __call__(self, inputs, states, masks):
        x = self.main(inputs / 255.0)

        if self.use_gru:
            if inputs.shape[0] == states.shape[0]:
                x, states = self.gru(x, states * masks)
            else:
                x = x.reshape(-1, states.shape[0], x.shape[-1])
                masks = masks.reshape(-1, states.shape[0], 1)
                outputs = []

                for i in range(x.shape[0]):
                    hx, states = self.gru(x[i], states * masks[i])
                    outputs.append(hx)

                x = jnp.concatenate(outputs, axis=0)

        return self.critic_linear(x), x, states