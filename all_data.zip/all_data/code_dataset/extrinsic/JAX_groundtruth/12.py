import jax
import jax.numpy as jnp
from jax import grad, jit
from jax import random

from modules.nnd_jax import NNDModuleJax

dist = NNDModuleJax()

key1, key2 = random.split(random.PRNGKey(0))
p1 = random.uniform(key1, (10, 1000, 3))
p2 = random.uniform(key2, (10, 1500, 3))

@jit
def compute_dist_and_grads(p1, p2):
    dist1, dist2 = dist(p1, p2)
    loss = jnp.sum(dist1)
    grads = grad(lambda x: jnp.sum(dist(x, p2)[0]))(p1)
    return dist1, dist2, loss, grads

dist1, dist2, loss, grads = compute_dist_and_grads(p1, p2)
print(dist1, dist2)
print(loss)
print(grads)

# Assuming GPU operation is automatically managed by JAX
dist1, dist2, loss, grads = compute_dist_and_grads(p1, p2)
print(dist1, dist2)
print(loss)
print(grads)