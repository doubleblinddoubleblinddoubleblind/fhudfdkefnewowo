import jax
import jax.numpy as jnp
from jax import random
from numpy.testing import assert_almost_equal
from functools import partial
from jax.experimental import stax

class TestTimeDistributed:
    def test_time_distributed_reshapes_correctly(self):
        rng_key = random.PRNGKey(0)
        char_embedding = jnp.array([[0.4, 0.4], [0.5, 0.5]])

        def embedding(params, inputs):
            return params[inputs]

        distributed_embedding = jax.vmap(jax.vmap(embedding, in_axes=(None, 0)), in_axes=(None, 0))
        
        char_input = jnp.array([[[1, 0], [1, 1]]])
        output = distributed_embedding(char_embedding, char_input)
        assert_almost_equal(output, [[[[0.5, 0.5], [0.4, 0.4]], [[0.5, 0.5], [0.5, 0.5]]]], decimal=6)

    def test_time_distributed_works_with_multiple_inputs(self):
        def add(x, y):
            return x + y

        distributed = jax.vmap(jax.vmap(add, in_axes=(0, 0)), in_axes=(0, 0))
        
        x_input = jnp.array([[[1, 2], [3, 4]]])
        y_input = jnp.array([[[4, 2], [9, 1]]])
        output = distributed(x_input, y_input)
        assert_almost_equal(output, [[[5, 4], [12, 5]]], decimal=6)

test = TestTimeDistributed()
test.test_time_distributed_reshapes_correctly()
test.test_time_distributed_works_with_multiple_inputs()