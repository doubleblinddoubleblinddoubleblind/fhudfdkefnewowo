from flax import linen as nn
import jax
import jax.numpy as jnp
import optax

from cortex.plugins import ModelPlugin
from cortex.main import run


class Autoencoder(nn.Module):
    """
    Encapsulation of an encoder and a decoder.
    """

    encoder: nn.Module
    decoder: nn.Module

    @nn.compact
    def __call__(self, x, nonlinearity=None):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded


class AE(ModelPlugin):
    """
    Autoencoder designed with JAX components.
    """
    defaults = dict(
        data=dict(
            batch_size=dict(train=64, test=64), inputs=dict(inputs='images')),
        optimizer=dict(optimizer='Adam', learning_rate=1e-4),
        train=dict(save_on_lowest='losses.ae'))

    def __init__(self):
        super().__init__()

    def build(self, dim_z=64, dim_encoder_out=64):
        """
        Build AE with an encoder and decoder and attribute
        an Autoencoder to self.nets.
        Args:
            dim_z: int
            dim_encoder_out: int

        Returns: None

        """
        encoder = nn.Sequential([
            nn.Dense(256),
            nn.relu,
            nn.Dense(28),
            nn.relu
        ])
        decoder = nn.Sequential([
            nn.Dense(256),
            nn.relu,
            nn.Dense(28),
            nn.sigmoid
        ])
        self.nets.ae = Autoencoder(encoder=encoder, decoder=decoder)

    def routine(self, inputs, ae_criterion=None):
        """
        Training routine and loss computing.
        Args:
            inputs: jnp.ndarray
            ae_criterion: function

        Returns: None

        """
        if ae_criterion is None:
            ae_criterion = lambda outputs, inputs: jnp.mean((outputs - inputs) ** 2)

        encoded = self.nets.ae.encoder(inputs)
        outputs = self.nets.ae.decoder(encoded)
        r_loss = ae_criterion(outputs, inputs) / inputs.shape[0]
        self.losses.ae = r_loss

    def visualize(self, inputs):
        """
        Adding generated images and base images to
        visualization.
        Args:
            inputs: jnp.ndarray
        Returns: None

        """
        encoded = self.nets.ae.encoder(inputs)
        outputs = self.nets.ae.decoder(encoded)
        self.add_image(outputs, name='reconstruction')
        self.add_image(inputs, name='ground truth')


if __name__ == '__main__':
    autoencoder = AE()
    run(model=autoencoder)