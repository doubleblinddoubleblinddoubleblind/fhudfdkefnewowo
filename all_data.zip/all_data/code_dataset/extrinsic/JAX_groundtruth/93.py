import jax
import jax.numpy as jnp
from flax import linen as nn
import optax
from functools import partial


class Discriminator(nn.Module):
    feature_maps: int
    image_channels: int

    @nn.compact
    def __call__(self, x):
        x = self._make_disc_block(self.image_channels, self.feature_maps, batch_norm=False)(x)
        x = self._make_disc_block(self.feature_maps, self.feature_maps * 2)(x)
        x = self._make_disc_block(self.feature_maps * 2, self.feature_maps * 4)(x)
        x = self._make_disc_block(self.feature_maps * 4, self.feature_maps * 8)(x)
        x = self._make_disc_block(self.feature_maps * 8, 1, kernel_size=4, stride=1, padding=0, last_block=True)(x)
        return x.reshape(x.shape[0])  # .squeeze(1)

    @staticmethod
    def _make_disc_block(
        in_channels: int,
        out_channels: int,
        kernel_size: int = 4,
        stride: int = 2,
        padding: int = 1,
        batch_norm: bool = True,
        last_block: bool = False,
    ):
        def block(x):
            x = nn.Conv(out_channels, (kernel_size, kernel_size), (stride, stride), padding='SAME', use_bias=False)(x)
            x = nn.LayerNorm()(x) if batch_norm else x
            x = nn.leaky_relu(x, negative_slope=0.2)
            if last_block:
                x = nn.sigmoid(x)
            return x

        return block


class Generator(nn.Module):
    latent_dim: int
    feature_maps: int
    image_channels: int

    @nn.compact
    def __call__(self, z):
        z = self._make_gen_block(self.latent_dim, self.feature_maps * 8, kernel_size=4, stride=1, padding=0)(z)
        z = self._make_gen_block(self.feature_maps * 8, self.feature_maps * 4)(z)
        z = self._make_gen_block(self.feature_maps * 4, self.feature_maps * 2)(z)
        z = self._make_gen_block(self.feature_maps * 2, self.feature_maps)(z)
        z = self._make_gen_block(self.feature_maps, self.image_channels, last_block=True)(z)
        return z

    @staticmethod
    def _make_gen_block(
        in_channels: int,
        out_channels: int,
        kernel_size: int = 4,
        stride: int = 2,
        padding: int = 1,
        last_block: bool = False,
    ):
        def block(x):
            x = nn.ConvTranspose(out_channels, (kernel_size, kernel_size), (stride, stride), padding='SAME')(x)
            x = nn.BatchNorm()(x)
            x = nn.relu(x)
            if last_block:
                x = nn.sigmoid(x)
            return x

        return block


def get_noise(key, real, config):
    batch_size = real.shape[0]
    latent_dim = config["latent_dim"]
    noise = jax.random.normal(key, (batch_size, latent_dim, 1, 1))
    return noise


@partial(jax.jit, static_argnums=(0,))
def get_sample(generator_fn, key, real, config):
    noise = get_noise(key, real, config)
    fake = generator_fn(noise)
    return fake


def instance_noise(config, epoch_num, real):
    if config["loss_params"]["instance_noise"]:
        gamma = config["instance_noise_params"].get("gamma", None)
        noise_level = config["instance_noise_params"]["noise_level"]
        if gamma:
            noise_level *= gamma ** epoch_num
        noise = jnp.random.normal(real.shape) * noise_level
        real += noise
    return real


def top_k(config, epoch_num, preds):
    if config["loss_params"]["top_k"]:
        gamma = config["top_k_params"].get("gamma", None)
        k = config["top_k_params"]["k"]
        if gamma:
            k = int(k * (gamma ** epoch_num))
        preds = jnp.sort(preds)[:k]
    return preds


def disc_loss(config, discriminator_fn, generator_fn, key, epoch_num, real):
    real = instance_noise(config, epoch_num, real)
    real_pred = discriminator_fn(real)
    real_gt = jnp.ones_like(real_pred)
    real_loss = optax.sigmoid_binary_cross_entropy(real_pred, real_gt).mean()

    fake = get_sample(generator_fn, key, real, config["loss_params"])
    fake = instance_noise(config, epoch_num, fake)
    fake_pred = discriminator_fn(fake)
    fake_pred = top_k(config, epoch_num, fake_pred)
    fake_gt = jnp.zeros_like(fake_pred)
    fake_loss = optax.sigmoid_binary_cross_entropy(fake_pred, fake_gt).mean()

    return real_loss + fake_loss


def gen_loss(config, discriminator_fn, generator_fn, key, epoch_num, real):
    fake = get_sample(generator_fn, key, real, config["loss_params"])
    fake = instance_noise(config, epoch_num, fake)
    fake_pred = discriminator_fn(fake)
    fake_pred = top_k(config, epoch_num, fake_pred)
    fake_gt = jnp.ones_like(fake_pred)
    return optax.sigmoid_binary_cross_entropy(fake_pred, fake_gt).mean()