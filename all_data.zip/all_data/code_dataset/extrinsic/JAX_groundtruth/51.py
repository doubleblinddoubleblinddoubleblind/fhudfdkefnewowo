import numpy as np
import random
import jax
from jax import random as jax_random
import jax.numpy as jnp
import optax
import argparse
import os

# Fake placeholders for the Elektronn3 components
class ModelNet40:
    def __init__(self, *args, **kwargs):
        pass

def Trainer3d(*args, **kwargs):
    pass

class CellCloudData:
    def __init__(self, *args, **kwargs):
        pass

class Backup:
    def __init__(self, *args, **kwargs):
        pass

class metrics:
    class Accuracy: pass
    class Precision: pass
    class Recall: pass
    class DSC: pass
    class IoU: pass

def Compose(transforms):
    return transforms

def RandomVariation(*args, **kwargs):
    pass

def Center(*args, **kwargs):
    pass

def Normalization(*args, **kwargs):
    pass

def RandomRotate(*args, **kwargs):
    pass

def ElasticTransform(*args, **kwargs):
    pass

def RandomScale(*args, **kwargs):
    pass

# ARGS
parser = argparse.ArgumentParser(description='Train a network.')
parser.add_argument('--na', type=str, help='Experiment name', default=None)
parser.add_argument('--sr', type=str, help='Save root', default=None)
parser.add_argument('--bs', type=int, default=10, help='Batch size')
parser.add_argument('--sp', type=int, default=50000, help='Number of sample points')
parser.add_argument('--scale_norm', type=int, default=2000, help='Scale factor for normalization')
parser.add_argument('--co', action='store_true', help='Disable CUDA')
parser.add_argument('--seed', default=0, help='Random seed', type=int)
parser.add_argument('--ctx', default=20000, help='Context size in nm', type=int)
parser.add_argument('--use_bias', default=True, help='Use bias parameter in Convpoint layers.', type=bool)
parser.add_argument('--use_syntype', default=True, help='Use synapse type', type=bool)
parser.add_argument('-j', '--jit', metavar='MODE', default='disabled',
    choices=['disabled', 'train', 'onsave'], help="JIT options")
parser.add_argument('--cval', default=None, help='Cross-validation split indicator.', type=int)
args = parser.parse_args()

# SET UP ENVIRONMENT
random_seed = args.seed
np.random.seed(random_seed)
random.seed(random_seed)

# JAX uses PRNG keys for random, so we create one here
key = jax_random.PRNGKey(random_seed)

# Parameters
use_cuda = not args.co
name = args.na
batch_size = args.bs
npoints = args.sp
scale_norm = args.scale_norm
save_root = args.sr
cval = args.cval or 0
ctx = args.ctx
use_bias = args.use_bias
use_syntype = args.use_syntype
lr = 5e-4
lr_stepsize = 100
lr_dec = 0.992
max_steps = 200000
eval_nr = random_seed
cellshape_only = False
dr = 0.3
track_running_stats = False
use_norm = 'gn'
num_classes = 8
onehot = True
act = 'swish'

if name is None:
    name = f'celltype_pts_scale{scale_norm}_nb{npoints}_ctx{ctx}_{act}'
    if cellshape_only:
        name += '_cellshapeOnly'
    if not use_syntype:
        name += '_noSyntype'
if onehot:
    input_channels = 5 if use_syntype else 4
else:
    input_channels = 1
    name += '_flatinp'
if use_norm is False:
    name += '_noBN'
    if track_running_stats:
        name += '_trackRunStats'
else:
    name += f'_{use_norm}'
if not use_bias:
    name += '_noBias'

device = jax.devices('gpu' if use_cuda else 'cpu')[0]
print(f'Running on device: {device}')

if save_root is None:
    save_root = '~/e3_training_convpoint/'
save_root = os.path.expanduser(save_root)

model = ModelNet40(input_channels, num_classes, dropout=dr, use_norm=use_norm,
                   track_running_stats=track_running_stats, act=act, use_bias=use_bias)
name += f'_CV{cval}_eval{eval_nr}'

# JAX does not use torch.jit so we skip trace equivalents
enable_save_trace = False  # Placeholder for JAX equivalent

train_transform = Compose([RandomVariation((-40, 40), distr='normal'),
                           Center(), 
                           Normalization(scale_norm), 
                           RandomRotate(apply_flip=True), 
                           ElasticTransform(res=(40, 40, 40), sigma=6), 
                           RandomScale(distr_scale=0.1, distr='uniform')])
valid_transform = Compose([Center(), Normalization(scale_norm)])

train_ds = CellCloudData(npoints=npoints, transform=train_transform, cv_val=cval,
                         cellshape_only=cellshape_only, use_syntype=use_syntype,
                         onehot=onehot, batch_size=batch_size, ctx_size=ctx)
valid_ds = CellCloudData(npoints=npoints, transform=valid_transform, train=False,
                         cv_val=cval, cellshape_only=cellshape_only,
                         use_syntype=use_syntype, onehot=onehot, batch_size=batch_size,
                         ctx_size=ctx)

optimizer = optax.adam(lr)
lr_sched = optax.exponential_decay(lr, transition_steps=lr_stepsize, decay_rate=lr_dec)

valid_metrics = {
    'val_accuracy_mean': metrics.Accuracy(),
    'val_precision_mean': metrics.Precision(),
    'val_recall_mean': metrics.Recall(),
    'val_DSC_mean': metrics.DSC(),
    'val_IoU_mean': metrics.IoU(),
}

trainer = Trainer3d(
    model=model,
    criterion=None,
    optimizer=optimizer,
    device=device,
    train_dataset=train_ds,
    valid_dataset=valid_ds,
    batchsize=1,
    num_workers=5,
    valid_metrics=valid_metrics,
    save_root=save_root,
    enable_save_trace=enable_save_trace,
    exp_name=name,
    schedulers={"lr": lr_sched},
    num_classes=num_classes,
    dataloader_kwargs=dict(collate_fn=lambda x: x[0]),
    nbatch_avg=10,
)

bk = Backup(script_path=__file__, save_path=trainer.save_path).archive_backup()

trainer.run(max_steps)