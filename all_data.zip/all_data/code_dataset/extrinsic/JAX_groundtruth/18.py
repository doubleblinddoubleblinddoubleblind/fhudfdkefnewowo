import jax
import jax.numpy as jnp
from jax import random
from flax import linen as nn


class Vision_M(nn.Module):
    @nn.compact
    def __call__(self, x):
        x = nn.Conv(features=32, kernel_size=(8, 8), strides=(4, 4))(x)
        x = nn.Conv(features=64, kernel_size=(4, 4), strides=(2, 2))(x)
        x = nn.Conv(features=64, kernel_size=(3, 3), strides=(1, 1))(x)
        return x


class Language_M(nn.Module):
    vocab_size: int = 10
    embed_dim: int = 128
    hidden_size: int = 128

    def setup(self):
        self.embedding = nn.Embed(num_embeddings=self.vocab_size, features=self.embed_dim)
        self.lstm = nn.OptimizedLSTMCell(embed_dim=self.embed_dim, hidden_size=self.hidden_size)

    def __call__(self, x, initial_state):
        x = self.embedding(x)
        _, hn = self.lstm(x, initial_state)
        h, c = hn
        return h

    def LP(self, x):
        return nn.Dense(features=self.vocab_size, use_bias=False)(x)


class Mixing_M(nn.Module):
    @nn.compact
    def __call__(self, visual_encoded, instruction_encoded):
        batch_size = visual_encoded.shape[0]
        visual_flatten = jnp.reshape(visual_encoded, [batch_size, -1])
        instruction_flatten = jnp.reshape(instruction_encoded, [batch_size, -1])
        mixed = jnp.concatenate([visual_flatten, instruction_flatten], axis=1)
        return mixed


class Action_M(nn.Module):
    batch_size: int = 1
    hidden_size: int = 256

    def setup(self):
        self.lstm_1 = nn.OptimizedLSTMCell(input_size=3264, hidden_size=256)
        self.lstm_2 = nn.OptimizedLSTMCell(input_size=256, hidden_size=256)
        self.hidden_1 = (random.normal(random.PRNGKey(0), (self.batch_size, self.hidden_size)),
                         random.normal(random.PRNGKey(1), (self.batch_size, self.hidden_size)))
        self.hidden_2 = (random.normal(random.PRNGKey(2), (self.batch_size, self.hidden_size)),
                         random.normal(random.PRNGKey(3), (self.batch_size, self.hidden_size)))

    def __call__(self, x):
        h1, c1 = self.lstm_1(x, self.hidden_1)
        h2, c2 = self.lstm_2(h1, self.hidden_2)
        self.hidden_1 = (h1, c1)
        self.hidden_2 = (h2, c2)
        return h2


class Policy(nn.Module):
    action_space: int

    def setup(self):
        self.affine1 = nn.Dense(features=128)
        self.action_head = nn.Dense(features=self.action_space)
        self.value_head = nn.Dense(features=1)
        self.saved_actions = []
        self.rewards = []

    def __call__(self, x):
        x = nn.relu(self.affine1(x))
        action_scores = self.action_head(x)
        state_values = self.value_head(x)
        return action_scores, state_values

    def tAE(self, action_logits):
        output = action_logits - self.action_head.bias
        output = jnp.dot(output, self.action_head.kernel.T)
        return output


class temporal_AutoEncoder(nn.Module):
    policy_network: Policy
    vision_module: Vision_M

    def setup(self):
        self.linear_1 = nn.Dense(features=64 * 7 * 7)

        self.deconv = nn.Sequential([
            nn.ConvTranspose(features=64, kernel_size=(3, 3), strides=(1, 1)),
            nn.ConvTranspose(features=32, kernel_size=(4, 4), strides=(2, 2)),
            nn.ConvTranspose(features=3, kernel_size=(8, 8), strides=(4, 4))])

    def __call__(self, visual_input, logit_action):
        visual_encoded = self.vision_module(visual_input)

        action_out = self.policy_network.tAE(logit_action)
        action_out = self.linear_1(action_out)
        action_out = jnp.reshape(action_out, [action_out.shape[0], 64, 7, 7])

        combine = jnp.multiply(action_out, visual_encoded)

        out = self.deconv(combine)
        return out


class Language_Prediction(nn.Module):
    language_module: Language_M

    def setup(self):
        self.vision_transform = nn.Sequential([
            nn.Dense(features=128),
            nn.relu])

    def __call__(self, vision_encoded):
        vision_encoded_flatten = jnp.reshape(vision_encoded, [vision_encoded.shape[0], -1])
        vision_out = self.vision_transform(vision_encoded_flatten)
        language_predict = self.language_module.LP(vision_out)
        return language_predict


class RewardPredictor(nn.Module):
    vision_module: Vision_M
    language_module: Language_M
    mixing_module: Mixing_M

    def setup(self):
        self.linear = nn.Dense(features=1)

    def __call__(self, x):
        batch_visual = []
        batch_instruction = []

        for batch in x:
            visual = [b.visual for b in batch]
            instruction = [b.instruction for b in batch]

            batch_visual.append(jnp.concatenate(visual, axis=0))
            batch_instruction.append(jnp.concatenate(instruction, axis=0))

        batch_visual_encoded = self.vision_module(jnp.concatenate(batch_visual, axis=0))
        batch_instruction_encoded = self.language_module(jnp.concatenate(batch_instruction, axis=0))

        batch_mixed = self.mixing_module(batch_visual_encoded, batch_instruction_encoded)
        batch_mixed = jnp.reshape(batch_mixed, [len(batch_visual), -1])

        out = self.linear(batch_mixed)
        return out