# pylint: disable=no-self-use,invalid-name
from numpy.testing import assert_almost_equal
import pytest
import jax
import jax.numpy as jnp
from jax import random
import flax.linen as nn
from flax.core import freeze, unfreeze
from flax.training import common_utils

from allennlp.common import Params
from allennlp.common.checks import ConfigurationError
from allennlp.common.testing import AllenNlpTestCase
from allennlp.modules.similarity_functions import MultiHeadedSimilarity

class TestMultiHeadedSimilarityFunction(AllenNlpTestCase):
    def test_weights_are_correct_sizes(self):
        # pylint: disable=protected-access
        similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=9, tensor_1_projected_dim=6,
                                           tensor_2_dim=6, tensor_2_projected_dim=12)
        params = similarity.init(random.PRNGKey(0))
        assert params['params']['_tensor_1_projection'].shape == (9, 6)
        assert params['params']['_tensor_2_projection'].shape == (6, 12)
        with pytest.raises(ConfigurationError):
            similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=10)
        with pytest.raises(ConfigurationError):
            params = Params({'num_heads': 3, 'tensor_1_dim': 9, 'tensor_2_dim': 10})
            MultiHeadedSimilarity.from_params(params)

    def test_forward(self):
        # pylint: disable=protected-access
        similarity = MultiHeadedSimilarity(num_heads=3, tensor_1_dim=6)
        params = similarity.init(random.PRNGKey(1))
        params['params']['_tensor_1_projection'] = jnp.eye(6)
        params['params']['_tensor_2_projection'] = jnp.eye(6)
        a_vectors = jnp.array([[[[1, 1, -1, -1, 0, 1], [-2, 5, 9, -1, 3, 4]]]], dtype=jnp.float32)
        b_vectors = jnp.array([[[[1, 1, 1, 0, 2, 5], [0, 1, -1, -7, 1, 2]]]], dtype=jnp.float32)
        result = similarity.apply(params, a_vectors, b_vectors).reshape((1, 1, 2, 3))
        assert result.shape == (1, 1, 2, 3)
        assert_almost_equal(result, jnp.array([[[[2, -1, 5], [5, -2, 11]]]], dtype=jnp.float32))