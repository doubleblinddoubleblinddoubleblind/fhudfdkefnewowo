import numpy as np

import jax
import jax.numpy as jnp
import flax.linen as nn
import optax
from flax.training import train_state

from mushroom_rl.algorithms.actor_critic import DDPG, TD3
from mushroom_rl.core import Core, Logger
from mushroom_rl.environments.gym_env import Gym
from mushroom_rl.policy import OrnsteinUhlenbeckPolicy
from mushroom_rl.utils.dataset import compute_J

from tqdm import trange

# JAX requires explicit setup for pseudo-random key
key = jax.random.PRNGKey(0)

def init_params(layers, key):
    params = []
    for i, (in_dim, out_dim) in enumerate(zip(layers[:-1], layers[1:])):
        key, subkey = jax.random.split(key)
        weight = jax.random.normal(subkey, (in_dim, out_dim)) * jnp.sqrt(2/(in_dim + out_dim))
        bias = jnp.zeros(out_dim)
        params.append((weight, bias))
    return params

def relu(x):
    return jnp.maximum(0, x)

def linear(params, x):
    for w, b in params[:-1]:
        x = relu(jnp.dot(x, w) + b)
    final_w, final_b = params[-1]
    return jnp.dot(x, final_w) + final_b

class CriticNetwork:
    def __init__(self, input_shape, output_shape, n_features, **kwargs):
        self.params = init_params([input_shape[-1], n_features, n_features, output_shape[0]], key)

    def __call__(self, state, action):
        state_action = jnp.concatenate((state, action), axis=-1)
        q = linear(self.params, state_action)
        return jnp.squeeze(q)

class ActorNetwork:
    def __init__(self, input_shape, output_shape, n_features, **kwargs):
        self.params = init_params([input_shape[-1], n_features, n_features, output_shape[0]], key)

    def __call__(self, state):
        x = jnp.squeeze(state, axis=1)
        return linear(self.params, x)

def experiment(alg, n_epochs, n_steps, n_steps_test):
    np.random.seed()

    logger = Logger(alg.__name__, results_dir=None)
    logger.strong_line()
    logger.info('Experiment Algorithm: ' + alg.__name__)

    # MDP
    horizon = 200
    gamma = 0.99
    mdp = Gym('Pendulum-v0', horizon, gamma)

    # Policy
    policy_class = OrnsteinUhlenbeckPolicy
    policy_params = dict(sigma=np.ones(1) * .2, theta=.15, dt=1e-2)

    # Settings
    initial_replay_size = 500
    max_replay_size = 5000
    batch_size = 200
    n_features = 80
    tau = .001

    # Approximator
    actor_input_shape = mdp.info.observation_space.shape
    actor_params = dict(network=ActorNetwork,
                        n_features=n_features,
                        input_shape=actor_input_shape,
                        output_shape=mdp.info.action_space.shape)

    actor_optimizer = optax.adam(learning_rate=0.001)

    critic_input_shape = (actor_input_shape[0] + mdp.info.action_space.shape[0],)
    critic_params = dict(network=CriticNetwork,
                         optimizer=optax.adam(learning_rate=0.001),
                         loss=optax.mean_squared_error,
                         n_features=n_features,
                         input_shape=critic_input_shape,
                         output_shape=(1,))

    # Agent
    agent = alg(mdp.info, policy_class, policy_params,
                actor_params, actor_optimizer, critic_params, batch_size,
                initial_replay_size, max_replay_size, tau)

    # Algorithm
    core = Core(agent, mdp)

    core.learn(n_steps=initial_replay_size, n_steps_per_fit=initial_replay_size)

    # RUN
    dataset = core.evaluate(n_steps=n_steps_test, render=False)
    J = np.mean(compute_J(dataset, gamma))
    R = np.mean(compute_J(dataset))

    logger.epoch_info(0, J=J, R=R)

    for n in trange(n_epochs, leave=False):
        core.learn(n_steps=n_steps, n_steps_per_fit=1)
        dataset = core.evaluate(n_steps=n_steps_test, render=False)
        J = np.mean(compute_J(dataset, gamma))
        R = np.mean(compute_J(dataset))

        logger.epoch_info(n+1, J=J, R=R)

    logger.info('Press a button to visualize pendulum')
    input()
    core.evaluate(n_episodes=5, render=True)


if __name__ == '__main__':
    algs = [DDPG, TD3]

    for alg in algs:
        experiment(alg=alg, n_epochs=40, n_steps=1000, n_steps_test=2000)