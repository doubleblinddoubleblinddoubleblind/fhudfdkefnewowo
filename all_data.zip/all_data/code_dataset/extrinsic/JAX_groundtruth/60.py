import os
import glob
import datetime
import cv2
from PIL import Image
import numpy as np
from myimagefolder import MyImageFolder
from mymodel import GradientNet
from myargs import Args
import jax.numpy as jnp
from jax import jit, random, device_put
from flax.core import freeze, unfreeze
from flax.training import checkpoints

def loadimg(path):
    im = Image.open(path).convert('RGB')
    print(im.size)
    im = np.array(im).astype(np.float32) / 255.0
    im = jnp.transpose(im, (2, 0, 1))
    x = jnp.zeros((1, 3, 416, 1024), dtype=jnp.float32)
    x = x.at[0, :, :416, :1024].set(im[:, :416, :1024])
    return x

gpu_num = 2
gradient = False
type2 = 'rgb' if gradient == False else 'gd'

res_root = './results/images/'
scenes = glob.glob('/home/lwp/workspace/sintel2/clean/*')
key = random.PRNGKey(0)

for scene in scenes:
    scene = scene.split('/')[-1]
    res_dir = os.path.join(res_root, scene)
    os.makedirs(res_dir, exist_ok=True)
    for type_ in ['albedo', 'shading']:
        root = f'/media/lwp/xavier/graduation_results/showcase_model/{scene}/{type_}/{type2}/'
        snapshot_path = os.path.join(root, 'snapshot-239.pth.tar')
        if not os.path.exists(snapshot_path):
            continue
        
        # Load the snapshot using checkpoints from flax.training
        snapshot = checkpoints.restore_checkpoint(root, target=None)
        state_dict = snapshot['state_dict']
        args = snapshot['args']
        
        # Initialize model using jax
        densenet = models.__dict__[args.arch](pretrained=True)
        net = None
        num = 40 if scene == 'market_6' else 50
        for ind in range(1, num + 1):
            if net is not None:
                del net
            
            # Initialize fresh model with JAX and load weights
            # Assume `GradientNet` is implemented in JAX-compatible library
            
            net = GradientNet(densenet=densenet, growth_rate=32, 
                              transition_scale=2, pretrained_scale=4,
                              gradient=gradient)
            
            # Restore parameters into this newly initialized net
            net = checkpoints.restore_checkpoint(root, target=net)
            
            # Assuming you have implemented a forward function for your model
            frame_path = f'/home/lwp/workspace/sintel2/clean/{scene}/frame_{ind:04d}.png'
            print(frame_path)
            im = loadimg(frame_path)
            mergeRGB = net(im, go_through_merge=True)
            merged = mergeRGB[5][0]
            merged = np.array(merged)
            print(merged.shape)
            merged = np.transpose(merged, (1, 2, 0))
            print(merged.shape)
            dx = merged[:, :, :3]
            res_frame = f'albedo_{ind:04d}.png' if type_ == 'albedo' else f'shading_{ind:04d}.png'
            cv2.imwrite(os.path.join(res_dir, res_frame), (dx[:, :, ::-1] * 255).astype(np.uint8))