#! /usr/bin/env python

import numpy as np
from tqdm import tqdm
import os.path
import sys
import gzip
import _pickle as c_pickle
from train_utils import batchify_data, run_epoch, train_model, Flatten
from utils import *
import utils
import onnx
from onnx import version_converter
import jax
import jax.numpy as jnp
from jax import random
import flax.linen as nn

sys.path.append("..")

# Define model using Flax (a neural network library built on JAX)
class ConvNet(nn.Module):
    def setup(self):
        self.conv1 = nn.Conv(features=32, kernel_size=(3, 3))
        self.conv2 = nn.Conv(features=64, kernel_size=(3, 3))
        self.linear1 = nn.Dense(features=128)
        self.linear2 = nn.Dense(features=10)
        self.flatten = Flatten()

    def __call__(self, x, dropout_rng=None, train=True):
        x = self.conv1(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = self.conv2(x)
        x = nn.relu(x)
        x = nn.max_pool(x, window_shape=(2, 2), strides=(2, 2))
        x = self.flatten(x)
        x = self.linear1(x)
        if train:
            x = nn.Dropout(0.5)(x, deterministic=not train, rng=dropout_rng)
        x = self.linear2(x)
        return x

def main():
    # Initialize model
    model = ConvNet()

    # Check if model file exists
    model_file = "digits.npz"
    if os.path.isfile(model_file):
        with open(model_file, 'rb') as f:
            params = jnp.load(f)
    else:
        X_train, y_train, X_test, y_test = get_MNIST_data()
        X_train = np.reshape(X_train, (X_train.shape[0], 1, 28, 28))
        X_test = np.reshape(X_test, (X_test.shape[0], 1, 28, 28))
        dev_split_index = int(9 * len(X_train) / 10)
        X_dev = X_train[dev_split_index:]
        y_dev = y_train[dev_split_index:]
        X_train = X_train[:dev_split_index]
        y_train = y_train[:dev_split_index]
        permutation = np.arange(len(X_train))
        np.random.shuffle(permutation)
        X_train = [X_train[i] for i in permutation]
        y_train = [y_train[i] for i in permutation]
        batch_size = 32
        train_batches = batchify_data(X_train, y_train, batch_size)
        dev_batches = batchify_data(X_dev, y_dev, batch_size)
        test_batches = batchify_data(X_test, y_test, batch_size)
        key = random.PRNGKey(0)
        subkey = random.split(key)
        params = model.init(subkey, jnp.ones((1, 1, 28, 28)))
        train_model(train_batches, dev_batches, model, params, nesterov=True, rng_key=key)
        loss, accuracy = run_epoch(test_batches, model, params, train=False)
        print(f"Loss on test set: {loss} Accuracy on test set: {accuracy}")
        with open(model_file, 'wb') as f:
            jnp.savez(f, **params)

    print(model)

if __name__ == '__main__':
    # Specify seed for deterministic behavior, then shuffle. Do not change seed for official submissions to edx
    np.random.seed(12321)  # for reproducibility
    key = random.PRNGKey(12321)
    main()