#!/usr/bin/env python
# coding: utf-8

import jax
import jax.numpy as jnp
from jax import random, grad, jit, vmap
from flax import linen as nn
from flax.training import train_state
import optax
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from matplotlib.pyplot import imshow, imsave
import numpy as np
import os

key = random.PRNGKey(0)

MODEL_NAME = "ConditionalGAN"
DEVICE = jax.devices("gpu")[0] if jax.local_devices(backend='gpu') else jax.devices("cpu")[0]

def to_onehot(x, num_classes=10):
    c = np.zeros((x.size, num_classes), dtype=np.int32)
    c[np.arange(x.size), x] = 1
    return c

def get_sample_image(generator_apply, params, n_noise=100):
    """
        save sample 100 images
    """
    img = np.zeros([280, 280])
    for j in range(10):
        c = jnp.eye(10)[[j] * 10]
        z = random.normal(key, (10, n_noise))
        y_hat = generator_apply(params, z, c).reshape(10, 28, 28)
        result = np.array(y_hat)
        img[j * 28 : (j + 1) * 28] = np.concatenate([x for x in result], axis=-1)
    return img

class Discriminator(nn.Module):
    input_size: int = 784
    condition_size: int = 10
    num_classes: int = 1

    @nn.compact
    def __call__(self, x, c):
        x = x.reshape((x.shape[0], -1))
        v = jnp.concatenate((x, c), axis=1)
        x = nn.Dense(features=512)(v)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=256)(x)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=self.num_classes)(x)
        return nn.sigmoid(x)

class Generator(nn.Module):
    input_size: int = 100
    condition_size: int = 10
    num_classes: int = 784

    @nn.compact
    def __call__(self, x, c):
        x = x.reshape((x.shape[0], -1))
        v = jnp.concatenate((x, c), axis=1)
        x = nn.Dense(features=128)(v)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=256)(x)
        x = nn.BatchNorm(use_running_average=True, momentum=0.9, epsilon=1e-5)(x)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=512)(x)
        x = nn.BatchNorm(use_running_average=True, momentum=0.9, epsilon=1e-5)(x)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=1024)(x)
        x = nn.BatchNorm(use_running_average=True, momentum=0.9, epsilon=1e-5)(x)
        x = nn.leaky_relu(x, negative_slope=0.2)
        x = nn.Dense(features=self.num_classes)(x)
        return nn.tanh(x)

transform = transforms.Compose(
    [transforms.ToTensor(), transforms.Normalize(mean=[0.5], std=[0.5])]
)

mnist = datasets.MNIST(root="../data/", train=True, transform=transform, download=True)

batch_size = 64
condition_size = 10

data_loader = DataLoader(
    dataset=mnist, batch_size=batch_size, shuffle=True, drop_last=True
)

cross_entropy_loss = lambda logits, labels: -jnp.mean(jnp.sum(labels * jnp.log(logits) + (1. - labels) * jnp.log(1. - logits), axis=1))

max_epoch = 30
step = 0
n_critic = 1
n_noise = 100

D_labels = jnp.ones((batch_size, 1))
D_fakes = jnp.zeros((batch_size, 1))

if not os.path.exists("samples"):
    os.makedirs("samples")

discriminator = Discriminator()
generator = Generator()

D_params = discriminator.init(key, jnp.ones((batch_size, 784)), jnp.ones((batch_size, 10)))
G_params = generator.init(key, jnp.ones((batch_size, n_noise)), jnp.ones((batch_size, 10)))

D_state = train_state.TrainState.create(apply_fn=discriminator.apply, params=D_params, tx=optax.adam(learning_rate=0.0002, b1=0.5, b2=0.999))
G_state = train_state.TrainState.create(apply_fn=generator.apply, params=G_params, tx=optax.adam(learning_rate=0.0002, b1=0.5, b2=0.999))

for epoch in range(max_epoch):
    for idx, (images, labels) in enumerate(data_loader):
        x = jnp.array(images.numpy())
        y = to_onehot(labels.numpy()).astype(jnp.float32)

        def D_loss_fn(D_params, G_params, x, y):
            logits_real = discriminator.apply(D_params, x, y)
            D_x_loss = cross_entropy_loss(logits_real, D_labels)
            
            z = random.normal(key, (batch_size, n_noise))
            fake_images = generator.apply(G_params, z, y)
            logits_fake = discriminator.apply(D_params, fake_images, y)
            D_z_loss = cross_entropy_loss(logits_fake, D_fakes)
            
            return D_x_loss + D_z_loss

        grads = jax.grad(D_loss_fn)(D_state.params, G_state.params, x, y)
        D_state = D_state.apply_gradients(grads=grads)

        if step % n_critic == 0:
            def G_loss_fn(G_params, D_params, y):
                z = random.normal(key, (batch_size, n_noise))
                fake_images = generator.apply(G_params, z, y)
                logits_fake = discriminator.apply(D_params, fake_images, y)
                return cross_entropy_loss(logits_fake, D_labels)

            grads = jax.grad(G_loss_fn)(G_state.params, D_state.params, y)
            G_state = G_state.apply_gradients(grads=grads)

        if step % 500 == 0:
            print(
                "Epoch: {}/{}, Step: {}, D Loss: {}, G Loss: {}".format(
                    epoch, max_epoch, step, D_loss_fn(D_state.params, G_state.params, x, y), G_loss_fn(G_state.params, D_state.params, y)
                )
            )

        if step % 1000 == 0:
            img = get_sample_image(generator.apply, G_state.params, n_noise)
            imsave(
                "samples/{}_step{}.jpg".format(MODEL_NAME, str(step).zfill(3)),
                img,
                cmap="gray",
            )

        step += 1

# ## Sample

img = get_sample_image(generator.apply, G_state.params, n_noise)
imshow(img, cmap="gray")