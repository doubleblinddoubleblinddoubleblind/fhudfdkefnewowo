import unittest
import jax
import jax.numpy as jnp
from jax import random, grad
import tensors_jax as tensors  # Assuming equivalent tensors functionality exists for JAX
import time


def sample(nindices=2*256+2*8, size=(256, 256), var=1.0):
    assert len(size) == 2

    key = random.PRNGKey(0)
    indices = (random.uniform(key, (nindices, 2)) * jnp.array(size)[None, :]).astype(jnp.int32)
    values = random.normal(key, (nindices,)) * var

    return indices, values

class TestTensors(unittest.TestCase):
    
    def test_sum(self):
        size = (5, 5)

        # create a batch of sparse matrices
        samples = [sample(nindices=3, size=size) for _ in range(3)]
        indices, values = [jnp.expand_dims(s[0], axis=0) for s in samples], [jnp.expand_dims(s[1], axis=0) for s in samples]

        indices, values = jnp.concatenate(indices, axis=0), jnp.concatenate(values, axis=0)

        print(indices)
        print(values)
        print('res', tensors.sum(indices, values, size))

    def test_log_softmax(self):

        size = (5, 5)

        # create a batch of sparse matrices
        samples = [sample(nindices=3, size=size) for _ in range(3)]
        indices, values = [jnp.expand_dims(s[0], axis=0) for s in samples], [jnp.expand_dims(s[1], axis=0) for s in samples]

        indices, values = jnp.concatenate(indices, axis=0), jnp.concatenate(values, axis=0)

        print('res', jnp.exp(tensors.logsoftmax(indices, values, size, method='naive')))
        print('res', jnp.exp(tensors.logsoftmax(indices, values, size, method='iteration')))

    def test(self):

        key = random.PRNGKey(0)
        a = jax.core.Primitive(lambda x: x)(random.normal(key, (1,)))
        a = jnp.array(a)
        x = random.normal(key, (15000, 15000))

        x = x * a
        x = x / 2

        loss = jnp.sum(x)

        loss_grad = grad(lambda a: jnp.sum((x * a) / 2))(a)
        time.sleep(600)